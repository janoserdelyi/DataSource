#!/bin/bash

# expect one and only one arg
if [ "$#" -ne 1 ]; then
	echo "error, this script expects one argument. the envionrment (dvm,tsm,tsr,prd)"
	exit 1
fi

envs="dvm tsm tsr prd"

env="$1"

contains () {
	# check space-separated list $1 contains value $2
	echo "$1" | tr ' ' '\n' | grep -F -x -q "$2"
}

if ! contains "${envs}" "${env}"; then
	echo "${env} is not a valid value"
	exit 1
fi

curl \
	-v \
	-F "key=form-injection/forms/standard-lead-form" \
	-F "file=@c:/Users/jerdelyi/projects/costar/we-marketing-automation-form-injection/src/templates/forms/standard-lead-form.js;type=text/javascript" \
	"https://ma-platform-services-use1.${env}.enterprise.aws.dshrp.com/we-marketing-automation-form-injection/manage/api/v1/s3"


