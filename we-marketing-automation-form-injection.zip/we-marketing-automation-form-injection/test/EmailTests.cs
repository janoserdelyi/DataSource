using WeMarketingAutomationFormInjection;

namespace Test;

public class EmailTests
{

	[Fact]
	public void ValidateEmailAddress_EmptyString_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_MissingAtSign_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("foo.com");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_MoreThanOneAtSign_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test@foo@bar.com");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_MissingTld_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test@foo");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_TrailingPeriod_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test@foo.com.");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_DoubePeriod_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test..lastname@foo..com");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_InvalidLocalpart_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("[test]@foo.com");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_ExampleDotComDomain_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test@example.com");

		Assert.True (result.IsFailure);
	}

	[Fact]
	public void ValidateEmailAddress_TestDotComDomain_ReturnsError () {

		var result = Utils.ValidateEmailAddress ("test@test.com");

		Assert.True (result.IsFailure);
	}

	[Theory]
	[InlineData ("test@mailinator.com", true)]
	public void ValidateEmailAddress_TemporaryMailDomain_ReturnsError (
		string input,
		bool expected
	) {

		var result = Utils.ValidateEmailAddress (input);

		Assert.Equal (expected, result.IsFailure);
	}

	[Theory]
	[InlineData ("test@gmial.com", true)]
	[InlineData ("test@gamil.com", true)]
	[InlineData ("test@gmaul.com", true)]
	[InlineData ("test@gnail.com", true)]
	[InlineData ("test@gmai.com", true)]
	[InlineData ("test@gmsil.com", true)]
	[InlineData ("test@ail.com", true)]
	[InlineData ("test@hitnail.com", true)]
	[InlineData ("test@hitmail.com", true)]
	[InlineData ("test@hotnail.com", true)]
	public void ValidateEmailAddress_TypoDomain_ReturnsError (
		string input,
		bool expected
	) {

		var result = Utils.ValidateEmailAddress (input);

		Assert.Equal (expected, result.IsFailure);
	}


}
