using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using FluentValidation;
using FluentValidation.TestHelper;
using Microsoft.Extensions.Localization;
using Moq;
using WeMarketingAutomationFormInjection.Models;

namespace Test;

public class LeadIngestionValidatorTests
{
	private readonly Mock<IStringLocalizer> mockLocalizer;
	private readonly Mock<IDynamoClient> mockDynamoClient;
	private readonly Mock<IOpenSearchClient> mockOpenSearchClient;
	private readonly LeadIngestionValidator validator;

	public LeadIngestionValidatorTests () {
		mockLocalizer = new Mock<IStringLocalizer> ();
		mockDynamoClient = new Mock<IDynamoClient> ();
		mockOpenSearchClient = new Mock<IOpenSearchClient> ();

		// Setup default localized strings
		SetupLocalizedString ("invalidRequest", "Invalid request");
		SetupLocalizedString ("invalidEmail", "Invalid email address");
		SetupLocalizedString ("invalidCountryCode", "Invalid country code");
		SetupLocalizedString ("invalidPostalCodeFormat", "Invalid postal code format");
		SetupLocalizedString ("invalidPostalCode", "Invalid postal code");
		SetupLocalizedString ("invalidPhoneNumber", "Invalid phone number");

		// Setup default mocks
		mockDynamoClient
			.Setup (x => x.GetCountry3to2 (It.IsAny<string> ()))
			.ReturnsAsync (new Country3to2 { Two = "US", Three = "USA", Name = "United States" });

		mockDynamoClient
			.Setup (x => x.GetAllBadDomainsSince (It.IsAny<DateTimeOffset> ()))
			.ReturnsAsync (new List<WeMarketingAutomationFormInjection.Models.DomainStatus> ());

		mockDynamoClient
			.Setup (x => x.GetAllGoodDomainsSince (It.IsAny<DateTimeOffset> ()))
			.ReturnsAsync (new List<WeMarketingAutomationFormInjection.Models.DomainStatus> ());

		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (It.IsAny<string> (), It.IsAny<string> ()))
			.ReturnsAsync (true);

		validator = new LeadIngestionValidator (
			mockDynamoClient.Object,
			mockOpenSearchClient.Object,
			mockLocalizer.Object
		);
	}

	private void SetupLocalizedString (string key, string value) {
		var localizedString = new LocalizedString (key, value);
		mockLocalizer.Setup (x => x[key]).Returns (localizedString);
	}

	#region NeverFill (Honeypot) Tests

	[Fact]
	public void NeverFill_WhenEmpty_ShouldPass () {
		// Arrange
		var lead = CreateValidLead ();
		lead.NeverFill = null;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.NeverFill);
	}

	[Theory]
	[InlineData ("bot-filled")]
	[InlineData ("anything")]
	[InlineData (" ")]
	public void NeverFill_WhenNotEmpty_ShouldFail (string neverFillValue) {
		// Arrange
		var lead = CreateValidLead ();
		lead.NeverFill = neverFillValue;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.NeverFill)
			.WithErrorMessage ("Invalid request");
	}

	#endregion

	#region FirstName Tests

	[Theory]
	[InlineData ("J")]
	[InlineData ("John")]
	[InlineData ("1234567890123456")] // 16 chars - max
	public void FirstName_ValidLengths_ShouldPass (string firstName) {
		// Arrange
		var lead = CreateValidLead ();
		lead.FirstName = firstName;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.FirstName);
	}

	[Fact]
	public void FirstName_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.FirstName = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.FirstName);
	}

	[Fact]
	public void FirstName_WhenNull_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.FirstName = null!;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.FirstName);
	}

	[Fact]
	public void FirstName_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.FirstName = "12345678901234567"; // 17 chars

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.FirstName);
	}

	#endregion

	#region LastName Tests

	[Theory]
	[InlineData ("D")]
	[InlineData ("Doe")]
	[InlineData ("1234567890123456789012345")] // 25 chars - max
	public void LastName_ValidLengths_ShouldPass (string lastName) {
		// Arrange
		var lead = CreateValidLead ();
		lead.LastName = lastName;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.LastName);
	}

	[Fact]
	public void LastName_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.LastName = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.LastName);
	}

	[Fact]
	public void LastName_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.LastName = "12345678901234567890123456"; // 26 chars

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.LastName);
	}

	#endregion

	#region CompanyName Tests

	[Theory]
	[InlineData ("AB")]
	[InlineData ("Acme Corp")]
	[InlineData ("A very long company name that goes on and on")]
	public void CompanyName_ValidLengths_ShouldPass (string companyName) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CompanyName = companyName;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.CompanyName);
	}

	[Fact]
	public void CompanyName_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.CompanyName = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CompanyName);
	}

	[Theory]
	[InlineData ("A")] // Too short - 1 char
	public void CompanyName_WhenTooShort_ShouldFail (string companyName) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CompanyName = companyName;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CompanyName);
	}

	[Fact]
	public void CompanyName_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.CompanyName = new string ('A', 256); // 256 chars

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CompanyName);
	}

	#endregion

	#region EmailAddress Tests

	[Theory]
	[InlineData ("a@b.c")]
	[InlineData ("test@foo.com")]
	[InlineData ("user.name+tag@foo.co.uk")]
	public void EmailAddress_ValidFormats_ShouldPass (string email) {
		// Arrange
		var lead = CreateValidLead ();
		lead.EmailAddress = email;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.EmailAddress);
	}

	[Fact]
	public void EmailAddress_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.EmailAddress = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.EmailAddress);
	}

	[Theory]
	[InlineData ("a@b")] // Too short - 3 chars
	[InlineData ("abcd")] // Too short - 4 chars
	public void EmailAddress_WhenTooShort_ShouldFail (string email) {
		// Arrange
		var lead = CreateValidLead ();
		lead.EmailAddress = email;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.EmailAddress);
	}

	[Fact]
	public void EmailAddress_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.EmailAddress = new string ('a', 90) + "@example.com"; // 101+ chars

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.EmailAddress);
	}

	#endregion

	#region CountryCode Tests

	[Theory]
	[InlineData ("US", "USA", "United States")]
	[InlineData ("GB", "GBR", "Great Britain")]
	[InlineData ("CA", "CAN", "Canada")]
	public void CountryCode_ValidFormats_ShouldPass (
		string countryCodeTwo,
		string countryCodeThree,
		string countryCodeName
	) {
		// Arrange
		mockDynamoClient
			.Setup (x => x.GetCountry3to2 (countryCodeThree))
			.ReturnsAsync (new Country3to2 { Two = countryCodeTwo, Three = countryCodeThree, Name = countryCodeName });

		var lead = CreateValidLead ();
		lead.CountryCode = countryCodeThree;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.CountryCode);
	}

	[Fact]
	public void CountryCode_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.CountryCode = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CountryCode);
	}

	[Theory]
	[InlineData ("US")] // Too short
	[InlineData ("USAA")] // Too long
	public void CountryCode_WhenWrongLength_ShouldFail (string countryCode) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CountryCode = countryCode;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CountryCode);
	}

	[Theory]
	[InlineData ("usa")] // lowercase
	[InlineData ("Usa")] // mixed case
	[InlineData ("UsA")] // mixed case
	public void CountryCode_WhenNotAllUppercase_ShouldFail (string countryCode) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CountryCode = countryCode;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CountryCode)
			.WithErrorMessage ("'{{countryCode}}' is not in the correct format.");
	}

	[Theory]
	[InlineData ("U1A")] // contains digit
	[InlineData ("U-A")] // contains special char
	public void CountryCode_WhenContainsNonLetters_ShouldFail (string countryCode) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CountryCode = countryCode;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CountryCode);
	}

	#endregion

	#region PostalCode Tests

	[Theory]
	[InlineData ("USA", "12345")]
	[InlineData ("USA", "12345-6789")]
	[InlineData ("GBR", "SW1A 1AA")]
	[InlineData ("CAN", "K1A 0B1")]
	public void PostalCode_ValidFormats_ShouldPass (string countryCode, string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ReturnsAsync (true);

		var lead = CreateValidLead ();
		lead.CountryCode = countryCode;
		lead.PostalCode = postalCode;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Fact]
	public void PostalCode_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.PostalCode = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("USA", "1234")] // Invalid format
	[InlineData ("GBR", "INVALID")] // Invalid format
	public void PostalCode_WhenInvalidFormat_ShouldFail (string countryCode, string postalCode) {
		// Arrange
		var lead = CreateValidLead ();
		lead.CountryCode = countryCode;
		lead.PostalCode = postalCode;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode);
	}

	#endregion

	#region PhoneNumber Tests

	[Theory]
	[InlineData ("US", "1234")] // Minimum length
	[InlineData ("US", "1234567890")]
	[InlineData ("US", "+1 (555) 123-4567")]
	[InlineData ("US", "12345678901234567890")] // Maximum length - 20 chars
	public void PhoneNumber_ValidLengths_ShouldPass (
		string countryIso2,
		string phone
	) {
		// Arrange
		var lead = CreateValidLead ();
		lead.PhoneNumber = phone;
		lead.CountryCodeIso2 = countryIso2;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		// there *will* be errors on these numbers, we just don't want to see the length error - '{{phone}}' must be between 4 and 20 characters. You entered 3 characters.
		if (result.Errors == null || result.Errors.Count == 0) {
			return;
		}

		foreach (var error in result.Errors) {
			if (error.ErrorMessage.StartsWith ("'{{phone}}' must be between 4 and 20 characters")) {
				result.ShouldNotHaveValidationErrorFor (x => x.PhoneNumber);
				return;
			}
		}
	}

	[Fact]
	public void PhoneNumber_WhenEmpty_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.PhoneNumber = "";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PhoneNumber);
	}

	[Theory]
	[InlineData ("123")] // Too short
	public void PhoneNumber_WhenTooShort_ShouldFail (string phone) {
		// Arrange
		var lead = CreateValidLead ();
		lead.PhoneNumber = phone;

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PhoneNumber);
	}

	[Fact]
	public void PhoneNumber_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.PhoneNumber = "123456789012345678901"; // 21 chars

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PhoneNumber);
	}

	#endregion

	#region Optional Field Length Tests

	[Theory]
	[InlineData (30)]
	[InlineData (29)]
	[InlineData (1)]
	public void City_ValidLengths_ShouldPass (int length) {
		// Arrange
		var lead = CreateValidLead ();
		lead.City = new string ('A', length);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.City);
	}

	[Fact]
	public void City_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.City = new string ('A', 31);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.City);
	}

	[Fact]
	public void StateCode_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.StateCode = new string ('A', 31);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.StateCode);
	}

	[Fact]
	public void Notes_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.Notes = new string ('A', 1001);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.Notes);
	}

	[Fact]
	public void ProductLineCode_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.ProductLineCode = new string ('A', 101);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.ProductLineCode);
	}

	[Fact]
	public void ProductName_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.ProductName = new string ('A', 301);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.ProductName);
	}

	[Fact]
	public void LanguageCode_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.LanguageCode = new string ('A', 21);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.LanguageCode);
	}

	[Fact]
	public void Locale_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.Locale = new string ('A', 11);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.Locale);
	}

	[Fact]
	public void SourceUrl_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.SourceUrl = new string ('A', 1001);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.SourceUrl);
	}

	[Fact]
	public void SourceArea_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.SourceArea = new string ('A', 1001);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.SourceArea);
	}

	[Fact]
	public void BusinessType_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.BusinessType = new string ('A', 51);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.BusinessType);
	}

	[Fact]
	public void BusinessSubType_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.BusinessSubType = new string ('A', 51);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.BusinessSubType);
	}

	[Fact]
	public void Brand_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.Brand = new string ('A', 101);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.Brand);
	}

	[Fact]
	public void CampaignId_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.CampaignId = new string ('A', 61);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.CampaignId);
	}

	[Fact]
	public void FormType_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.FormType = new string ('A', 21);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.FormType);
	}

	[Fact]
	public void SourceType_WhenTooLong_ShouldFail () {
		// Arrange
		var lead = CreateValidLead ();
		lead.SourceType = new string ('A', 21);

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.SourceType);
	}

	#endregion

	#region Complete Valid Lead Tests

	[Fact]
	public void CompleteValidLead_ShouldPass () {
		// Arrange
		var lead = CreateValidLead ();

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveAnyValidationErrors ();
	}

	[Fact]
	public void ValidLeadWithOptionalFields_ShouldPass () {
		// Arrange
		var lead = CreateValidLead ();
		lead.City = "New York";
		lead.StateCode = "NY";
		lead.Notes = "Some notes";
		lead.ProductLineCode = "PROD1,PROD2";
		lead.ProductName = "Product Name";
		lead.LanguageCode = "en";
		lead.Locale = "en-US";
		lead.SourceUrl = "https://example.com";
		lead.SourceArea = "Homepage";
		lead.BusinessType = "Commercial";
		lead.BusinessSubType = "Office";
		lead.Brand = "CoStar";
		lead.CampaignId = "CAMP123";
		lead.FormType = "Contact";
		lead.SourceType = "Web";

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveAnyValidationErrors ();
	}

	#endregion

	#region Cascade Mode Tests

	[Fact]
	public void CascadeMode_StopsAtFirstError () {
		// Arrange
		var lead = CreateValidLead ();
		lead.FirstName = ""; // Will fail NotEmpty
							 // Even though it's empty (and thus can't have a length),
							 // cascade should stop after NotEmpty

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		var errors = result.ShouldHaveValidationErrorFor (x => x.FirstName);
		// Should only have one error due to CascadeMode.Stop
		Assert.Single (errors);
	}

	#endregion

	#region Helper Methods

	private Lead CreateValidLead () {
		return new Lead {
			NeverFill = null,
			FirstName = "John",
			LastName = "Doe",
			CompanyName = "Acme Corp",
			EmailAddress = "john.doe@foo.com",
			CountryCode = "USA",
			CountryCodeIso2 = "US",
			PostalCode = "12345",
			PhoneNumber = "8043045488"
		};
	}

	#endregion
}