namespace Test;

public class LocaleCdTests
{
	[Fact]
	public void GetLocaleCd_NoHeaders_ReturnsEnUs () {
		var context = new DefaultHttpContext ();

		var result = Utils.GetLocaleCd (context);

		Assert.Equal ("en-US", result);
	}

	[Fact]
	public void GetLocaleCd_AcceptLanguageHeader_ReturnsEnUs () {
		var context = new DefaultHttpContext ();
		context.Request.Headers.AcceptLanguage = "en-US,en;q=0.7,es;q=0.3";

		var result = Utils.GetLocaleCd (context);

		Assert.Equal ("en-US", result);
	}

	[Fact]
	public void GetLocaleCd_AcceptLanguageHeader_ReturnsEsEs () {
		var context = new DefaultHttpContext ();
		context.Request.Headers.AcceptLanguage = "es-ES,es;q=0.7,en;q=0.3";
		context.Features.Set<Microsoft.AspNetCore.Localization.IRequestCultureFeature> (null);

		var result = Utils.GetLocaleCd (context);

		Assert.Equal ("es-ES", result);
	}
}