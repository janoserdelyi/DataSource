using System.Net;
using System.Text;
using Microsoft.Extensions.Logging;
using Moq;
using Amazon.S3;
using Amazon.DynamoDBv2.DataModel;

namespace Test;

public class EmailPreferenceTests
{
	private readonly TestServer server;

	private readonly HttpClient httpClient;

	/*
	builder.Services.AddAWSService<IAmazonS3> (ServiceLifetime.Singleton);
	builder.Services.AddAWSService<IAmazonDynamoDB> (ServiceLifetime.Singleton);
	builder.Services.AddSingleton<IDynamoDBContext, DynamoDBContext> ();
	builder.Services.AddSingleton<IDynamoClient, DynamoClient> ();
	builder.Services.AddSingleton<ITranslationClient, TranslationClient> ();
	builder.Services.AddSingleton<IOpenSearchClient, OpenSearchClient> ();
	builder.Services.AddSingleton<IValkeyClient, ValkeyClient> ();
	*/

	private readonly Mock<ILogger<EmailPreferenceModule>> mockEmailPreferenceLogger;
	private readonly Mock<IHttpClientFactory> mockHttpClientFactory;
	private readonly Mock<IAmazonS3> mockS3;
	private readonly Mock<IDynamoClient> mockDynamoClient;
	private readonly Mock<IDynamoDBContext> mockDynamoDBContext;
	private readonly Mock<ITranslationClient> mockTranslationClient;
	private readonly Mock<IOpenSearchClient> mockOpenSearchClient;
	private readonly Mock<IValkeyClient> mockValkeyClient;


	public EmailPreferenceTests () {

		mockEmailPreferenceLogger = new Mock<ILogger<EmailPreferenceModule>> ();
		mockHttpClientFactory = new Mock<IHttpClientFactory> ();
		// mockHttpClientFactory.Setup (x => x.CreateClient (It.IsAny<string> ())).Returns (httpClient);
		mockS3 = new Mock<IAmazonS3> ();
		mockDynamoClient = new Mock<IDynamoClient> ();
		mockDynamoDBContext = new Mock<IDynamoDBContext> ();
		mockTranslationClient = new Mock<ITranslationClient> ();
		mockOpenSearchClient = new Mock<IOpenSearchClient> ();
		mockValkeyClient = new Mock<IValkeyClient> ();

		mockDynamoDBContext
			.Setup (x => x.SaveAsync (It.IsAny<object> (), It.IsAny<CancellationToken> ()))
			.Returns (Task.CompletedTask);

		// mockDynamoClient
		// 	.Setup (x => x.GetCountry3to2 (It.IsAny<string> ()))
		// 	.ReturnsAsync (new Country3to2 { Two = "US", Three = "USA", Name = "United States" });
		mockDynamoClient
			.Setup (x => x.GetCountry3to2 (It.IsAny<string> ()))
			.ReturnsAsync ((string countryCode) => getCountry3to2 (countryCode));

		mockDynamoClient
			.Setup (x => x.GetAllBadDomainsSince (It.IsAny<DateTimeOffset> ()))
			.ReturnsAsync (new List<DomainStatus> ());

		mockDynamoClient
			.Setup (x => x.GetAllGoodDomainsSince (It.IsAny<DateTimeOffset> ()))
			.ReturnsAsync (new List<DomainStatus> ());

		mockDynamoClient
			.Setup (x => x.AddDomain (It.IsAny<string> (), It.IsAny<string> ()))
			.Returns (Task.CompletedTask);
		//

		// making some appsettings
		var inMemorySettings = new Dictionary<string, string?> {
			{ "CacheDurationMinutes:StandardForm", "5" },
			{ "CacheDurationMinutes:DemoForm", "5" },
			{ "OpenSearchIndexURI", "https://crm-os.dvm.dataservices.aws.dshrp.com" },
			{ "PostalCodeReaderIndex", "ma-zipcodes.reader" },
			{ "PostalCodeWriterIndex", "ma-zipcodes.writer" },
			{ "EmailPreferenceReaderIndex", "ma-email-preference.reader" },
			{ "BookingLogWriterIndex", "ma-lead-request-write" },
			{ "EmailPreferenceEndpoint", "https://marketing-automation-api-dvm.costar.com/email-preference" },
			{ "EmailPreferenceSecurityKey", "2dfa028d8478164fd111897044b728fbe2f4a914" }
		};

		IConfiguration configuration = new ConfigurationBuilder ().AddInMemoryCollection (inMemorySettings).Build ();

		this.server = new TestServer (
			new WebHostBuilder ()
				.UseWebRoot ("/")
				.UseEnvironment ("local")
				.UseConfiguration (configuration)
				.ConfigureServices (x => {

					x.AddHttpClient ();

					x.AddSingleton<IOpenSearchClient, OpenSearchClient> ();
					// x.AddSingleton<IDynamoDBContext, DynamoDBContext> ();
					// x.AddSingleton<IDynamoClient, DynamoClient> ();
					x.AddSingleton<IDynamoDBContext> (mockDynamoDBContext.Object);
					x.AddSingleton<IDynamoClient> (mockDynamoClient.Object);
					x.AddSingleton<IAmazonS3> (mockS3.Object);
					x.AddSingleton<IValkeyClient> (mockValkeyClient.Object);
					x.AddSingleton<ITranslationClient> (mockTranslationClient.Object);

					x.AddRouting ();

					x.AddCarter (configurator: c => {
						c.WithResponseNegotiator<NewtonsoftCustomResponseNegotiator> ();
						// Don't scan for validators at all
						c.WithEmptyValidators ();
					});
				})
				.Configure (x => {
					x.UseRouting ();
					x.UseEndpoints (builder => builder.MapCarter ());
				})
		);

		this.httpClient = this.server.CreateClient ();
	}

	private Country3to2? getCountry3to2 (
		string three
	) {
		if (three == "XYZ") {
			return null;
		}

		if (three == "UNK") {
			return null;
		}

		return new Country3to2 { Two = "US", Three = "USA", Name = "United States" };
	}


	[Theory]
	[InlineData ("GET", 2, "jerdelyi@costar.com")]
	public async Task GetEmailPreferences_InvalidVersion2_Returns404 (
		string httpMethod,
		int version,
		string emailAddress
	) {
		try {
			var response = await this.httpClient.SendAsync (
				new HttpRequestMessage (
					new HttpMethod (httpMethod),
					$"/api/v{version}/emailpreferences/{emailAddress}"
				) {
					Content = new StringContent (
						JsonConvert.SerializeObject (new EmailPreferenceResponseObject ()),
						Encoding.UTF8,
						"application/json"
					)
				},
				TestContext.Current.CancellationToken
			);

			Assert.Equal (HttpStatusCode.NotFound, response.StatusCode);
		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}

	[Theory]
	[InlineData ("GET", 1, "jerdelyi@costar.com")]
	public async Task GetEmailPreferences_VaildInputs_Returns200 (
		string httpMethod,
		int version,
		string emailAddress
	) {
		try {
			var response = await this.httpClient.SendAsync (
				new HttpRequestMessage (
					new HttpMethod (httpMethod),
					$"/api/v{version}/emailpreferences/{emailAddress}"
				) {
					Content = new StringContent (
						JsonConvert.SerializeObject (new EmailPreferenceResponseObject ()),
						Encoding.UTF8,
						"application/json"
					)
				},
				TestContext.Current.CancellationToken
			);

			Assert.Equal (HttpStatusCode.OK, response.StatusCode);

			var responseBody = await response.Content.ReadAsStringAsync (TestContext.Current.CancellationToken);
			var responseObj = JsonConvert.DeserializeObject<EmailPreferenceResponseObject> (responseBody);

			Assert.NotNull (response);
			Assert.NotNull (responseObj);
			Assert.True (responseObj.Success);

		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}


	[Theory]
	[InlineData ("GET", 1, "jerdelyi@costar.com", 9)]
	public async Task GetEmailPreferencesBySegment_VaildInputs_Returns200 (
		string httpMethod,
		int version,
		string emailAddress,
		int segmentId
	) {
		try {
			var response = await this.httpClient.SendAsync (
				new HttpRequestMessage (
					new HttpMethod (httpMethod),
					$"/api/v{version}/emailpreference/{emailAddress}/{segmentId}"
				) {
					Content = new StringContent (
						JsonConvert.SerializeObject (new EmailPreferenceResponseObject ()),
						Encoding.UTF8,
						"application/json"
					)
				},
				TestContext.Current.CancellationToken
			);

			Assert.Equal (HttpStatusCode.OK, response.StatusCode);

			var responseBody = await response.Content.ReadAsStringAsync (TestContext.Current.CancellationToken);
			var responseObj = JsonConvert.DeserializeObject<WeMarketingAutomationFormInjection.Models.OpenSearch.SegmentPreferenceResponse> (responseBody);

			Assert.NotNull (response);
			Assert.NotNull (responseObj);
			Assert.True (responseObj.Success);
			Assert.NotNull (responseObj.SegmentPreference);
			Assert.Equal (responseObj.SegmentPreference.Id, segmentId);

		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}

	[Theory]
	[InlineData ("GET", 1, "jerdelyi@costar.com", 1)]
	public async Task GetEmailPreferencesByBrand_VaildInputs_Returns200 (
		string httpMethod,
		int version,
		string emailAddress,
		int brandId
	) {
		try {
			var response = await this.httpClient.SendAsync (
				new HttpRequestMessage (
					new HttpMethod (httpMethod),
					$"/api/v{version}/emailpreferences/{emailAddress}/{brandId}"
				) {
					Content = new StringContent (
						JsonConvert.SerializeObject (new EmailPreferenceResponseObject ()),
						Encoding.UTF8,
						"application/json"
					)
				},
				TestContext.Current.CancellationToken
			);

			Assert.Equal (HttpStatusCode.OK, response.StatusCode);

			var responseBody = await response.Content.ReadAsStringAsync (TestContext.Current.CancellationToken);
			var responseObj = JsonConvert.DeserializeObject<WeMarketingAutomationFormInjection.Models.OpenSearch.BrandPreferenceResponse> (responseBody);

			Assert.NotNull (response);
			Assert.NotNull (responseObj);
			Assert.True (responseObj.Success);
			Assert.NotNull (responseObj.BrandPreference);
			Assert.Equal (responseObj.BrandPreference.Id, brandId);

		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}

	[Theory]
	[InlineData ("jerdelyi@costar.com", "USA", "CoStar", 9, true)]
	[InlineData ("jerdelyi@costar.com", "UNK", "CoStar", 9, false)] //testing that sumbitting with UNK leaves existing email country alone
	public async Task SubmitEmailPreference_VaildInputs_Returns200 (
		string emailAddress,
		string countryCode,
		string brand,
		int segmentId,
		bool optIn
	) {
		var emailPreference = new EmailPreference () {
			EmailAddress = emailAddress,
			CountryCode = countryCode,
			Brand = [brand],
			OptIntoSegments = [new MarketingBrandSegmentPreference () { MarketingBrandSegmentId = segmentId, OptIn = optIn }]
		};

		var stringContent = new StringContent (
			JsonConvert.SerializeObject (emailPreference),
			Encoding.UTF8,
			"application/json"
		);

		try {
			var responseObj = await submitEmailPreference (stringContent);

			// Assert.Equal (HttpStatusCode.OK, response.StatusCode);
			// Assert.NotNull (response);
			Assert.NotNull (responseObj);
			Assert.True (responseObj.Success);
		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}

	[Theory]
	[InlineData ("", "USA", "CoStar", 9, true)]
	[InlineData ("jerdelyi@costar.com", "", "CoStar", 9, true)]
	[InlineData ("jerdelyi@costar.com", "XYZ", "CoStar", 9, true)]
	public async Task SubmitEmailPreference_ValidationErrors_ReturnsErrorsWithDetails (
		string emailAddress,
		string countryCode,
		string brand,
		int segmentId,
		bool optIn
	) {
		var emailPreference = new EmailPreference () {
			EmailAddress = emailAddress,
			CountryCode = countryCode,
			Brand = [brand],
			OptIntoSegments = [new MarketingBrandSegmentPreference () { MarketingBrandSegmentId = segmentId, OptIn = optIn }]
		};

		var stringContent = new StringContent (
			JsonConvert.SerializeObject (emailPreference),
			Encoding.UTF8,
			"application/json"
		);

		try {
			var responseObj = await submitEmailPreference (stringContent);

			Assert.NotNull (responseObj);
			Assert.False (responseObj.Success);
			Assert.Equal ("Errors have been found", responseObj.Message);
			Assert.NotNull (responseObj.ValidationErrors);
		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			// force failure
			Assert.Equal (1, 2);
		}
	}

	private async Task<SubmitEmailPreferenceResponse> submitEmailPreference (
		StringContent stringContent
	) {
		var response = await this.httpClient.PostAsync ("/api/v1/emailpreference", stringContent, TestContext.Current.CancellationToken);

		response.EnsureSuccessStatusCode ();

		var responseBody = await response.Content.ReadAsStringAsync (TestContext.Current.CancellationToken);

		if (responseBody == null) {
			throw new Exception ("responseBody is null");
		}

		var responseObj = JsonConvert.DeserializeObject<SubmitEmailPreferenceResponse> (responseBody);

		if (responseObj == null) {
			throw new Exception ("failure to parse responseBody");
		}

		return responseObj;
	}
}

public class EmailPreferenceResponseObject
{
	public bool Success { get; set; }
	public string? Message { get; set; }
	public WeMarketingAutomationFormInjection.Models.OpenSearch.EmailPreference? Preferences { get; set; }
}














// using WeMarketingAutomationFormInjection;
// using WeMarketingAutomationFormInjection.Models;
// using Microsoft.AspNetCore.Http;
// using Microsoft.Extensions.Configuration;
// using Microsoft.Extensions.Localization;
// using Microsoft.Extensions.Logging;
// using Microsoft.AspNetCore.Hosting;
// using Microsoft.Extensions.Hosting;
// using Amazon.S3;
// using Moq;
// using Moq.Protected;
// using System.Net;
// using System.Text;
// using Newtonsoft.Json;

// namespace Test;

// public class SubmitEmailPreferenceTests
// {
// 	private readonly Mock<IWebHostEnvironment> _mockEnv;
// 	private readonly Mock<IConfiguration> _mockConfig;
// 	private readonly Mock<ILogger<HomeModule>> _mockLogger;
// 	private readonly Mock<IHttpClientFactory> _mockHttpClientFactory;
// 	private readonly Mock<IAmazonS3> _mockS3;
// 	private readonly Mock<IDynamoClient> _mockDynamoClient;
// 	private readonly Mock<ITranslationClient> _mockTranslationClient;
// 	private readonly Mock<IOpenSearchClient> _mockOpenSearchClient;
// 	private readonly Mock<IStringLocalizer> _mockLocalizer;
// 	private readonly Mock<HttpMessageHandler> _mockHttpMessageHandler;
// 	private readonly HttpClient _mockHttpClient;
// 	private readonly HomeModule _homeModule;

// 	public SubmitEmailPreferenceTests () {
// 		_mockEnv = new Mock<IWebHostEnvironment> ();
// 		_mockConfig = new Mock<IConfiguration> ();
// 		_mockLogger = new Mock<ILogger<HomeModule>> ();
// 		_mockHttpClientFactory = new Mock<IHttpClientFactory> ();
// 		_mockS3 = new Mock<IAmazonS3> ();
// 		_mockDynamoClient = new Mock<IDynamoClient> ();
// 		_mockTranslationClient = new Mock<ITranslationClient> ();
// 		_mockOpenSearchClient = new Mock<IOpenSearchClient> ();
// 		_mockLocalizer = new Mock<IStringLocalizer> ();

// 		// Setup HttpClient mock
// 		_mockHttpMessageHandler = new Mock<HttpMessageHandler> ();
// 		_mockHttpClient = new HttpClient (_mockHttpMessageHandler.Object);
// 		_mockHttpClientFactory.Setup (factory => factory.CreateClient (It.IsAny<string> ())).Returns (_mockHttpClient);

// 		// Setup basic configuration
// 		_mockEnv.Setup (env => env.WebRootPath).Returns ("/test/path");
// 		_mockEnv.Setup (env => env.EnvironmentName).Returns ("test");

// 		var mockConfigSection = new Mock<IConfigurationSection> ();
// 		mockConfigSection.Setup (section => section.Get<string> ()).Returns ("test-endpoint");
// 		_mockConfig.Setup (config => config.GetSection ("EmailPreferenceEndpoint")).Returns (mockConfigSection.Object);

// 		var mockSecurityKeySection = new Mock<IConfigurationSection> ();
// 		mockSecurityKeySection.Setup (section => section.Get<string> ()).Returns ("test-security-key");
// 		_mockConfig.Setup (config => config.GetSection ("EmailPreferenceSecurityKey")).Returns (mockSecurityKeySection.Object);

// 		var mockCacheDurationSection = new Mock<IConfigurationSection> ();
// 		_mockConfig.Setup (config => config.GetSection (CacheDurationMinutes.SectionName)).Returns (mockCacheDurationSection.Object);

// 		// Setup localizer
// 		_mockLocalizer.Setup (localizer => localizer["invalidRequest"]).Returns (new LocalizedString ("invalidRequest", "Invalid request"));

// 		_homeModule = new HomeModule (
// 			_mockEnv.Object,
// 			_mockConfig.Object,
// 			_mockLogger.Object,
// 			_mockHttpClientFactory.Object,
// 			_mockS3.Object,
// 			_mockDynamoClient.Object,
// 			_mockTranslationClient.Object,
// 			_mockOpenSearchClient.Object
// 		) {
// 			EnvironmentName = "test"
// 		};
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_InvalidVersion_Returns404 () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@example.com",
// 			FirstName = "Test",
// 			LastName = "User"
// 		};

// 		// Act
// 		await CallSubmitEmailPreference (context, 2, emailPreference);

// 		// Assert
// 		Assert.Equal (404, context.Response.StatusCode);
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_HoneypotFilled_ReturnsSuccessWithoutProcessing () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			NeverFill = "bot-filled-value", // Honeypot field filled
// 			EmailAddress = "test@example.com",
// 			FirstName = "Test",
// 			LastName = "User"
// 		};

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.True ((bool)response!.Success);
// 		Assert.Equal ("Thank you!", (string)response.Message);
// 	}



// 	[Fact]
// 	public async Task SubmitEmailPreference_ValidRequest_SuccessfulSubmission () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@costar.com",
// 			FirstName = "John",
// 			LastName = "Doe",
// 			Brand = new List<string> { "CoStar" },
// 			CountryCode = "USA",
// 			GlobalOptIn = true,
// 			BrandLevelMarketingOptIn = true
// 		};

// 		// Setup successful HTTP response
// 		var successResponse = new HttpResponseMessage (HttpStatusCode.OK) {
// 			Content = new StringContent ("Success", Encoding.UTF8, "application/json")
// 		};

// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Setup<Task<HttpResponseMessage>> (
// 				"SendAsync",
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			)
// 			.ReturnsAsync (successResponse);

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.True ((bool)response!.Success);
// 		Assert.Equal ("Thank you", (string)response.Message);
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_HttpRequestFails_ReturnsError () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@costar.com",
// 			FirstName = "John",
// 			LastName = "Doe",
// 			Brand = new List<string> { "CoStar" },
// 			CountryCode = "USA"
// 		};

// 		// Setup failed HTTP response
// 		var failedResponse = new HttpResponseMessage (HttpStatusCode.BadRequest) {
// 			ReasonPhrase = "Bad Request"
// 		};

// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Setup<Task<HttpResponseMessage>> (
// 				"SendAsync",
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			)
// 			.ReturnsAsync (failedResponse);

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.False ((bool)response!.Success);
// 		Assert.Contains ("Bad Request", (string)response.Message);
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_HttpRequestThrowsException_ReturnsError () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@costar.com",
// 			FirstName = "John",
// 			LastName = "Doe",
// 			Brand = new List<string> { "CoStar" },
// 			CountryCode = "USA"
// 		};

// 		// Setup HTTP client to throw exception
// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Setup<Task<HttpResponseMessage>> (
// 				"SendAsync",
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			)
// 			.ThrowsAsync (new HttpRequestException ("Network error"));

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.False ((bool)response!.Success);
// 		Assert.Contains ("Network error", (string)response.Message);
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_ForbiddenWithRetry_RetriesAndSucceeds () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@costar.com",
// 			FirstName = "John",
// 			LastName = "Doe",
// 			Brand = new List<string> { "CoStar" },
// 			CountryCode = "USA"
// 		};

// 		var callCount = 0;
// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Setup<Task<HttpResponseMessage>> (
// 				"SendAsync",
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			)
// 			.ReturnsAsync (() => {
// 				callCount++;
// 				if (callCount <= 2) // First two calls return Forbidden
// 				{
// 					return new HttpResponseMessage (HttpStatusCode.Forbidden) {
// 						ReasonPhrase = "Forbidden"
// 					};
// 				}
// 				// Third call succeeds
// 				return new HttpResponseMessage (HttpStatusCode.OK) {
// 					Content = new StringContent ("Success", Encoding.UTF8, "application/json")
// 				};
// 			});

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.True ((bool)response!.Success);
// 		Assert.Equal ("Thank you", (string)response.Message);

// 		// Verify retry happened
// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Verify (
// 				"SendAsync",
// 				Times.Exactly (3), // Should have tried 3 times
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			);
// 	}

// 	[Fact]
// 	public async Task SubmitEmailPreference_ForbiddenMaxRetries_ReturnsError () {
// 		// Arrange
// 		var context = new DefaultHttpContext ();
// 		context.Response.Body = new MemoryStream ();
// 		var emailPreference = new EmailPreference {
// 			EmailAddress = "test@costar.com",
// 			FirstName = "John",
// 			LastName = "Doe",
// 			Brand = new List<string> { "CoStar" },
// 			CountryCode = "USA"
// 		};

// 		// Setup to always return Forbidden
// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Setup<Task<HttpResponseMessage>> (
// 				"SendAsync",
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			)
// 			.ReturnsAsync (new HttpResponseMessage (HttpStatusCode.Forbidden) {
// 				ReasonPhrase = "Forbidden"
// 			});

// 		// Act
// 		await CallSubmitEmailPreference (context, 1, emailPreference);

// 		// Assert
// 		Assert.Equal (200, context.Response.StatusCode);
// 		var responseBody = GetResponseBody (context);
// 		var response = JsonConvert.DeserializeObject<dynamic> (responseBody);
// 		Assert.NotNull (response);
// 		Assert.False ((bool)response!.Success);
// 		Assert.Contains ("Forbidden", (string)response.Message);

// 		// Verify maximum retries were attempted (3 + 1 initial = 4 total)
// 		_mockHttpMessageHandler
// 			.Protected ()
// 			.Verify (
// 				"SendAsync",
// 				Times.Exactly (4),
// 				ItExpr.IsAny<HttpRequestMessage> (),
// 				ItExpr.IsAny<CancellationToken> ()
// 			);
// 	}

// 	private async Task CallSubmitEmailPreference (
// 		HttpContext context,
// 		int version,
// 		EmailPreference emailPreference
// 	) {
// 		// Use reflection to call the private method
// 		var method = typeof (HomeModule).GetMethod ("submitEmailPreference", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

// 		var task = (Task)method!.Invoke (_homeModule, new object[] { context, version, emailPreference })!;
// 		await task;
// 	}

// 	private static string GetResponseBody (HttpContext context) {
// 		context.Response.Body.Seek (0, SeekOrigin.Begin);
// 		using var reader = new StreamReader (context.Response.Body);
// 		return reader.ReadToEnd ();
// 	}
// }
