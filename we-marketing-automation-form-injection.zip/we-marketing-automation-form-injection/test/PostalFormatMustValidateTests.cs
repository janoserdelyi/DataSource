using System;
using Xunit;
using FluentValidation;
using FluentValidation.TestHelper;
using Microsoft.Extensions.Localization;
using Moq;
using WeMarketingAutomationFormInjection.Models;

namespace Test;

public class PostalFormatMustValidateTests
{
	private readonly Mock<IStringLocalizer> mockLocalizer;
	private readonly TestValidator validator;

	public PostalFormatMustValidateTests () {
		mockLocalizer = new Mock<IStringLocalizer> ();

		// Setup localized error message
		var localizedString = new LocalizedString ("invalidPostalCodeFormat", "Invalid postal code format");
		mockLocalizer.Setup (x => x["invalidPostalCodeFormat"]).Returns (localizedString);

		validator = new TestValidator (mockLocalizer.Object);
	}

	#region USA Postal Code Tests

	[Theory]
	[InlineData ("12345")]           // Valid: 5-digit
	[InlineData ("12345-6789")]      // Valid: 5+4 with hyphen
	[InlineData ("00000")]           // Valid: all zeros
	[InlineData ("99999")]           // Valid: all nines
	[InlineData ("00000-0000")]      // Valid: extended zeros
	public void PostalFormatMustValidate_USA_ValidFormats_ShouldPass (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("1234")]            // Invalid: too short
	[InlineData ("123456")]          // Invalid: 6 digits without hyphen
	[InlineData ("12345-")]          // Invalid: hyphen without extension
	[InlineData ("12345-678")]       // Invalid: incomplete extension
	[InlineData ("12345-67890")]     // Invalid: extension too long
	[InlineData ("ABCDE")]           // Invalid: letters
	[InlineData ("12345 6789")]      // Invalid: space instead of hyphen
	[InlineData ("")]                // Invalid: empty (should pass - other validators handle this)
	public void PostalFormatMustValidate_USA_InvalidFormats_ShouldFail (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		if (!string.IsNullOrEmpty (postalCode)) {
			result.ShouldHaveValidationErrorFor (x => x.PostalCode)
				.WithErrorMessage ("Invalid postal code format");
		}
	}

	#endregion

	#region UK (GBR) Postal Code Tests

	[Theory]
	[InlineData ("SW1A 1AA")]        // Valid: Westminster
	[InlineData ("GIR 0AA")]         // Valid: Girobank special case
	[InlineData ("M1 1AE")]          // Valid: Manchester
	[InlineData ("B33 8TH")]         // Valid: Birmingham
	[InlineData ("CR2 6XH")]         // Valid: Croydon
	[InlineData ("DN55 1PT")]        // Valid: Doncaster
	[InlineData ("W1A 0AX")]         // Valid: London BBC
	[InlineData ("EC1A1BB")]         // Valid: London no space
	[InlineData ("EC1A 1BB")]        // Valid: London with space
	[InlineData ("sw1a 1aa")]        // Valid: lowercase
	[InlineData ("SW1A1AA")]         // Valid: no space
	public void PostalFormatMustValidate_GBR_ValidFormats_ShouldPass (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "GBR",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("12345")]           // Invalid: US format
	[InlineData ("SW1A")]            // Invalid: incomplete
	[InlineData ("SW1A 1A")]         // Invalid: incomplete inward code
	[InlineData ("1SW1A 1AA")]       // Invalid: starts with number
	[InlineData ("SW1A 1AAA")]       // Invalid: too many letters at end
	[InlineData ("")]                // Empty (should pass - other validators handle)
	public void PostalFormatMustValidate_GBR_InvalidFormats_ShouldFail (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "GBR",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		if (!string.IsNullOrEmpty (postalCode)) {
			result.ShouldHaveValidationErrorFor (x => x.PostalCode)
				.WithErrorMessage ("Invalid postal code format");
		}
	}

	#endregion

	#region Canadian Postal Code Tests

	[Theory]
	[InlineData ("K1A 0B1")]         // Valid: Ottawa
	[InlineData ("M5W1E6")]          // Valid: Toronto no space
	[InlineData ("M5W 1E6")]         // Valid: Toronto with space
	[InlineData ("V6B 1A1")]         // Valid: Vancouver
	[InlineData ("H3Z 2Y7")]         // Valid: Montreal
	[InlineData ("T5J 3S4")]         // Valid: Edmonton
	[InlineData ("R3C 0A5")]         // Valid: Winnipeg
	[InlineData ("S7K 3J6")]         // Valid: Saskatoon
	[InlineData ("k1a 0b1")]         // Valid: lowercase
	[InlineData ("K1A0B1")]          // Valid: no space
	[InlineData ("A1A 1A1")]         // Valid: Newfoundland
	[InlineData ("X1A 1A1")]         // Valid: Northwest Territories
	[InlineData ("Y1A 1A1")]         // Valid: Yukon
	public void PostalFormatMustValidate_CAN_ValidFormats_ShouldPass (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "CAN",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("D1A 1A1")]         // Invalid: D not allowed in first position
	[InlineData ("K1D 0B1")]         // Invalid: D not allowed in third position
	[InlineData ("K1A 0D1")]         // Invalid: D not allowed in fifth position
	[InlineData ("12345")]           // Invalid: US format
	[InlineData ("K1A")]             // Invalid: incomplete
	[InlineData ("K1A 0B")]          // Invalid: incomplete LDU
	[InlineData ("1K1A 0B1")]        // Invalid: starts with number
	[InlineData ("KK1A 0B1")]        // Invalid: double letter at start
	[InlineData ("")]                // Empty (should pass - other validators handle)
	public void PostalFormatMustValidate_CAN_InvalidFormats_ShouldFail (string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = "CAN",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		if (!string.IsNullOrEmpty (postalCode)) {
			result.ShouldHaveValidationErrorFor (x => x.PostalCode)
				.WithErrorMessage ("Invalid postal code format");
		}
	}

	#endregion

	#region Edge Cases and Null Handling

	// [Fact]
	// public void PostalFormatMustValidate_NullLead_ShouldPass () {
	// 	// Arrange
	// 	Lead? lead = null;

	// 	// Act & Assert - should not throw
	// 	var result = validator.TestValidate (lead);

	// 	// The validator handles null gracefully by returning true
	// }

	[Fact]
	public void PostalFormatMustValidate_NullCountryCode_ShouldPass () {
		// Arrange
		var lead = new Lead {
			CountryCode = null,
			PostalCode = "12345"
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Fact]
	public void PostalFormatMustValidate_NullPostalCode_ShouldPass () {
		// Arrange
		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = null
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("FRA")]             // France - no pattern defined
	[InlineData ("DEU")]             // Germany - no pattern defined
	[InlineData ("JPN")]             // Japan - no pattern defined
	[InlineData ("AUS")]             // Australia - no pattern defined
	public void PostalFormatMustValidate_UnsupportedCountry_ShouldPass (string countryCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = "ANY_FORMAT_HERE"
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		// Should pass because there's no pattern defined for these countries
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	#endregion

	#region Case Sensitivity Tests

	[Theory]
	[InlineData ("USA", "12345")]
	[InlineData ("usa", "12345")]
	[InlineData ("UsA", "12345")]
	public void PostalFormatMustValidate_CountryCodeCaseInsensitive_ShouldWork (string countryCode, string postalCode) {
		// Arrange
		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	#endregion

	#region Multiple Country Validation

	[Theory]
	[InlineData ("USA", "12345", true)]
	[InlineData ("USA", "K1A 0B1", false)]
	[InlineData ("GBR", "SW1A 1AA", true)]
	[InlineData ("GBR", "12345", false)]
	[InlineData ("CAN", "K1A 0B1", true)]
	[InlineData ("CAN", "12345", false)]
	public void PostalFormatMustValidate_CrossCountryValidation_ShouldValidateCorrectly (
		string countryCode,
		string postalCode,
		bool shouldBeValid) {
		// Arrange
		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		if (shouldBeValid) {
			result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		} else {
			result.ShouldHaveValidationErrorFor (x => x.PostalCode)
				.WithErrorMessage ("Invalid postal code format");
		}
	}

	#endregion

	// Test validator class to test the custom validator
	private class TestValidator : AbstractValidator<Lead>
	{
		public TestValidator (IStringLocalizer localizer) {
			RuleFor (x => x.PostalCode).PostalFormatMustValidate (localizer);
		}
	}
}