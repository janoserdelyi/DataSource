
namespace Test;

public class InputQualityTests
{
	const int FAILING_SCORE = 35;

	[Theory]
	[InlineData ("aab", "bbb", 35)]
	[InlineData ("ere", "eef", 35)]
	[InlineData ("sgsegews", "svse", 35)]
	[InlineData ("HFDGF", "ETTYJRUYK", 40)] // this looks like an obvious knock-out, but the 'Y's counting as vowels lets it escape harsher punishment
	[InlineData ("SERFES", "RESRR", 45)]
	[InlineData ("reshrtdft", "resth", 45)]
	[InlineData ("fesfsef", "srfesr", 45)]
	[InlineData ("abcdefgh", "ijklmnopq", 50)]
	[InlineData ("dffggnhvhhjg", "ydfgyhulij", 55)]
	[InlineData ("ERTRE", "EREW", 55)]
	[InlineData ("XHJK", "SRTYUIO", 55)]
	[InlineData (@"\\XHJK", "SRTYUIO", 60)]
	[InlineData ("aaaaaa", "asdf", 65)]
	[InlineData ("ESHFGG", "DGFSTHFFH", 65)]
	[InlineData ("FGHJKL", "SRTYUIO", 70)]
	[InlineData ("DFSZDV", "VZDSV", 85)]
	[InlineData ("xdvx", "xccxvxc", 90)]
	// [InlineData ("sgsegews", "", 35)] // this one just gets a score of 25. this will be very hard to defend against. could somehow derive strange letter combos? like "sgs", "svs". this starts leaning hard into being very english-centric though
	// [InlineData ("sewf", "sswe", 35)] // this one just gets a score of 25. very difficult. if first name and last neame were evaluated separately, we might be in business. that last name having a .25 vowel distribution on 4 characters AND the only vowel is the last letter... that smells
	// [InlineData ("sewf", "", 35)] // not sure i can defend against this. it may as well be "beth"
	public void InputQuality_ObviousGarbage_ReturnsFailingScore (
		string firstName,
		string lastName,
		int expected
	) {

		var result = new InputQuality (firstName + lastName);

		var score = result.CalculateScore ();

		// var firstnameResult = new InputQuality (firstName);

		// var firstnameScore = firstnameResult.CalculateScore ();

		// var lastnameResult = new InputQuality (lastName);

		// var lastnameScore = lastnameResult.CalculateScore ();

		// var mergeScore = (score + lastnameScore + firstnameScore) / 3m;

		// Assert.True (mergeScore >= FAILING_SCORE);
		Assert.True (score >= FAILING_SCORE);
		// Assert.True (firstnameScore >= FAILING_SCORE);
		// Assert.True (lastnameScore >= FAILING_SCORE);
		Assert.True (score >= expected);
	}

	[Theory]
	[InlineData ("janos", "erdelyi")]
	[InlineData ("Seth", "Kim")]
	[InlineData ("Jungmok", "Chae")]
	[InlineData ("jim", "todd")]
	[InlineData ("ed", "edwards")]
	[InlineData ("ed", "tread")]
	[InlineData ("ella", "madsen")]
	[InlineData ("Joe", "Cummins")]
	[InlineData ("Eric", "Ely")]
	[InlineData ("Jessica", "Sanders")]
	[InlineData ("Rikki L.", "Krone")]
	[InlineData ("Robert", "Angstadt")]
	[InlineData ("Isaac", "Johnson")]
	[InlineData ("GERSHA", "PORTER")]
	[InlineData ("Dianne", "Rechel")]
	[InlineData ("Yvette", "Ursery")]
	[InlineData ("Wendy", "Pent")]
	[InlineData ("Karizma", "Stylez")]
	[InlineData ("Chas", "Schaffernoth")]
	[InlineData ("Andrew", "Black")]
	[InlineData ("Grace", "Lin")]
	[InlineData ("Laura", "Lopez")]
	[InlineData ("Olga", "Elmanovich")]
	[InlineData ("Glen W.", "Sutcliffe")] // this generated a score of 35 in one version. see why (high shannon entropy and large consonant repeats - really non-vowel repeats)
	[InlineData ("Glen", "Sutcliffe")] // let's see what happens when people actually follow instructions and it's JUST their first name in the first name field
	public void InputQuality_GoodValues_ReturnsSuccessfulScore (
		string firstName,
		string lastName
	) {

		var result = new InputQuality (firstName + lastName);

		var score = result.CalculateScore ();

		Assert.True (score < FAILING_SCORE);
	}

	// CalculateIsAllCaps tests
	[Theory]
	[InlineData ("HELLO", true)]
	[InlineData ("WORLD", true)]
	[InlineData ("ABC123", true)]
	[InlineData ("", true)]
	[InlineData ("Hello", false)]
	[InlineData ("hello", false)]
	[InlineData ("HeLLo", false)]
	[InlineData ("123abc", false)]
	public void CalculateIsAllCaps_VariousInputs_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.CalculateIsAllCaps (input);
		Assert.Equal (expected, result);
	}

	// CalculateVowelProportion tests
	[Theory]
	[InlineData ("aeiouy", 1.0)]
	[InlineData ("bcdfg", 0.0)]
	[InlineData ("hello", 0.4)]
	[InlineData ("", 0.0)]
	[InlineData ("a", 1.0)]
	[InlineData ("AEIOUYaeiouy", 1.0)]
	[InlineData ("xyz", 0.3333)]
	[InlineData ("beautiful", 0.5556)]
	public void CalculateVowelProportion_VariousInputs_ReturnsCorrectProportion (
		string input,
		decimal expected
	) {
		var result = InputQuality.CalculateVowelProportion (input);
		Assert.Equal (expected, result);
	}

	// CalculateMaxAdjacency tests
	[Theory]
	[InlineData ("qw", 1.0)]
	[InlineData ("qa", 1.0)]
	[InlineData ("qz", 2)]
	[InlineData ("qm", 6.32)]
	[InlineData ("abc", 4.12)]
	[InlineData ("qwerty", 1.0)]
	[InlineData ("asdf", 1.0)]
	[InlineData ("", 0.0)]
	[InlineData ("a", 0.0)]
	[InlineData ("az", 1)]
	public void CalculateMaxAdjacency_VariousInputs_ReturnsCorrectDistance (
		string input,
		decimal expected
	) {
		var result = InputQuality.CalculateMaxAdjacency (input);
		Assert.Equal (expected, result);
	}

	// CalculateShannonEntropy tests
	[Theory]
	[InlineData ("", 0.0)]
	[InlineData ("a", 0.0)]
	[InlineData ("aa", 0.0)]
	[InlineData ("aaa", 0.0)]
	[InlineData ("ab", 1.0)]
	[InlineData ("aabb", 1.0)]
	[InlineData ("abc", 1.585)]
	[InlineData ("abcd", 2.0)]
	[InlineData ("abcdefgh", 3.0)]
	[InlineData ("hello", 1.9219)]
	[InlineData ("password", 2.75)]
	public void CalculateShannonEntropy_VariousInputs_ReturnsCorrectEntropy (
		string input,
		double expected
	) {
		var result = InputQuality.CalculateShannonEntropy (input);
		Assert.Equal (expected, result, 3); // tolerance of 0.001
	}

	// CalculateExcessiveCharacterRepeat tests
	[Theory]
	[InlineData ("aaa", 3, true)]
	[InlineData ("aaaa", 3, true)]
	[InlineData ("aa", 3, false)]
	[InlineData ("aba", 3, false)]
	[InlineData ("abc", 3, false)]
	[InlineData ("hello", 3, false)]
	[InlineData ("helllo", 3, true)]
	[InlineData ("AAA", 3, true)] // case insensitive
	[InlineData ("AaA", 3, true)] // case insensitive
	[InlineData ("", 3, false)]
	[InlineData ("a", 3, false)]
	[InlineData ("aaaa", 4, true)]
	[InlineData ("aaa", 4, false)]
	[InlineData ("aa", 2, true)]
	[InlineData ("a", 2, false)]
	[InlineData ("ab", 1, false)] // threshold < 2 returns false
	public void CalculateExcessiveCharacterRepeat_VariousInputs_ReturnsCorrectResult (
		string input,
		int threshold,
		bool expected
	) {
		var result = InputQuality.CalculateExcessiveCharacterRepeat (input, threshold);
		Assert.Equal (expected, result);
	}

	[Theory]
	[InlineData ("aa", false)] // default threshold is 3
	[InlineData ("aaa", true)]
	public void CalculateExcessiveCharacterRepeat_DefaultThreshold_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.CalculateExcessiveCharacterRepeat (input);
		Assert.Equal (expected, result);
	}

	// CalculateIsSameKeyboardRow tests
	[Theory]
	[InlineData ("qwerty", true)]
	[InlineData ("asdf", true)]
	[InlineData ("zxcvbnm", true)]
	[InlineData ("qwertyuiop", true)]
	[InlineData ("asdfghjkl", true)]
	[InlineData ("qa", false)] // different rows
	[InlineData ("qz", false)] // different rows
	[InlineData ("hello", false)] // mixed rows
	[InlineData ("q", true)]
	[InlineData ("a", true)]
	[InlineData ("z", true)]
	[InlineData ("QWERTY", true)] // case insensitive
	[InlineData ("QwErTy", true)] // case insensitive
	[InlineData ("q1", false)] // number not in keyboard
	[InlineData ("1234", false)] // numbers not in keyboard
	[InlineData ("", false)]
	public void CalculateIsSameKeyboardRow_VariousInputs_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.CalculateIsSameKeyboardRow (input);
		Assert.Equal (expected, result);
	}

	// CalculateNumberOfVerbotenCharacters tests
	[Theory]
	[InlineData ("", 0)]
	[InlineData ("hello", 0)]
	[InlineData ("abc123", 0)]
	[InlineData ("test", 0)]
	[InlineData ("\\", 1)]
	[InlineData ("@", 1)]
	[InlineData ("[", 1)]
	[InlineData ("]", 1)]
	[InlineData ("{", 1)]
	[InlineData ("}", 1)]
	[InlineData ("^", 1)]
	[InlineData ("%", 1)]
	[InlineData ("$", 1)]
	[InlineData ("(", 1)]
	[InlineData (")", 1)]
	[InlineData ("hello@world", 1)]
	[InlineData ("test\\path", 1)]
	[InlineData ("100%", 1)]
	[InlineData ("$100", 1)]
	[InlineData ("(test)", 2)]
	[InlineData ("[test]", 2)]
	[InlineData ("{test}", 2)]
	[InlineData ("\\\\", 2)]
	[InlineData ("@@", 2)]
	[InlineData ("test@email.com", 1)]
	[InlineData ("\\@[]{}^%$()", 11)]
	[InlineData ("abc\\@[]def", 4)]
	[InlineData ("100% (complete)", 3)]
	public void CalculateNumberOfVerbotenCharacters_VariousInputs_ReturnsCorrectCount (
		string input,
		int expected
	) {
		var result = InputQuality.CalculateNumberOfVerbotenCharacters (input);
		Assert.Equal (expected, result);
	}

	// CalculateCommentSequences tests
	[Theory]
	[InlineData ("", true)]
	[InlineData ("hello", false)]
	[InlineData ("abc123", false)]
	[InlineData ("test name", false)]
	[InlineData ("John Doe", false)]
	[InlineData ("--", true)]
	[InlineData ("//", true)]
	[InlineData ("--comment", true)]
	[InlineData ("// comment", true)]
	[InlineData ("test--value", true)]
	[InlineData ("test//value", true)]
	[InlineData ("value--", true)]
	[InlineData ("value//", true)]
	[InlineData ("--test--", true)]
	[InlineData ("//test//", true)]
	[InlineData ("test--value//end", true)]
	[InlineData ("-- SQL comment", true)]
	[InlineData ("// JavaScript comment", true)]
	[InlineData ("https://example.com", true)] // URL contains //
	[InlineData ("c://path", true)]
	[InlineData ("re-reading", false)] // single dash ok
	[InlineData ("a/b", false)] // single slash ok
	[InlineData ("test-value", false)]
	[InlineData ("path/to/file", false)]
	public void CalculateCommentSequences_VariousInputs_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.CalculateCommentSequences (input);
		Assert.Equal (expected, result);
	}

	// CalculateUncommonRepeatCharacters tests
	[Theory]
	[InlineData ("", 0)]
	[InlineData ("hello", 0)]
	[InlineData ("abc", 0)]
	[InlineData ("test", 0)]
	[InlineData ("q", 0)] // single occurrence
	[InlineData ("qq", 1)] // q repeats
	[InlineData ("qqq", 1)] // q repeats multiple times, count is still 1
	[InlineData ("qz", 0)] // no repeats
	[InlineData ("qzqz", 2)] // both q and z repeat
	[InlineData ("zzzz", 1)] // z repeats
	[InlineData ("xyz", 0)] // no repeats
	[InlineData ("xyzxyz", 3)] // all three repeat
	[InlineData ("www", 1)] // w repeats
	[InlineData ("vvv", 1)] // v repeats
	[InlineData ("ggg", 1)] // g repeats
	[InlineData ("yyy", 1)] // y repeats
	[InlineData ("qwerty", 0)] // all single occurrences
	[InlineData ("QWQW", 2)] // case insensitive - Q repeats
	[InlineData ("quiz", 0)] // q and z single occurrence
	[InlineData ("quizz", 1)] // z repeats
	[InlineData ("qqqzzzxxxwwwvvvgggyyy", 7)] // all uncommon characters repeat
	[InlineData ("hello world", 0)] // no uncommon repeats
	[InlineData ("great day", 0)] // no uncommon repeats
	[InlineData ("zigzag", 2)] // z and g repeat
	public void CalculateUncommonRepeatCharacters_VariousInputs_ReturnsCorrectCount (
		string input,
		int expected
	) {
		var result = InputQuality.CalculateUncommonRepeatCharacters (input);
		Assert.Equal (expected, result);
	}

	// CalculateAreAllVowelsAtEndOfWord tests
	[Theory]
	[InlineData ("", false)]
	[InlineData ("hello", false)] // vowels scattered
	[InlineData ("world", false)] // vowel in middle
	[InlineData ("test", false)] // vowel in middle
	[InlineData ("bcdfg", true)] // no vowels
	[InlineData ("xyz", false)] // y is a vowel but x,z before it
	[InlineData ("bcdy", true)] // y at end
	[InlineData ("xsdfeao", true)] // vowels at end
	[InlineData ("swze", true)] // e at end
	[InlineData ("bcdaei", true)] // aei at end
	[InlineData ("tstae", true)] // ae at end
	[InlineData ("ae", true)] // all vowels
	[InlineData ("ea", true)] // all vowels
	[InlineData ("aeiou", true)] // all vowels
	[InlineData ("aeiouy", true)] // all vowels
	[InlineData ("a", true)] // single vowel
	[InlineData ("b", true)] // no vowels
	[InlineData ("ba", true)] // vowel at end
	[InlineData ("ab", false)] // consonant at end
	[InlineData ("bae", true)] // vowels at end
	[InlineData ("bea", true)] // vowels at end
	[InlineData ("beat", false)] // consonant at end after vowels
	[InlineData ("xyzaeiou", false)] // vowels at end, except for y
	[InlineData ("XSDFEAO", true)] // case insensitive
	[InlineData ("HeLLo", false)] // mixed case, vowels scattered
	[InlineData ("tstY", true)] // Y at end (case insensitive)
	public void CalculateAreAllVowelsAtEndOfWord_VariousInputs_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.CalculateAreAllVowelsAtEndOfWord (input, "en-US");
		Assert.Equal (expected, result);
	}

	// CalculateMaxCharacterFrequency tests
	[Theory]
	[InlineData ("", 0.0)]
	[InlineData ("a", 1.0)]
	[InlineData ("ab", 0.5)]
	[InlineData ("abc", 0.3333)]
	[InlineData ("aaa", 1.0)]
	[InlineData ("aaab", 0.75)]
	[InlineData ("ereeef", 0.6667)] // e appears 4/6 times
	[InlineData ("hello", 0.4)] // l appears 2/5 times
	[InlineData ("mississippi", 0.3636)] // i appears 4/11 times
	[InlineData ("bookkeeper", 0.3)] // e appears 3/10 times
	[InlineData ("AAaaBBbb", 0.5)] // case insensitive, a and b each 4/8
	[InlineData ("abcdefgh", 0.125)] // all unique
	public void CalculateMaxCharacterFrequency_VariousInputs_ReturnsCorrectRatio (
		string input,
		decimal expected
	) {
		var result = InputQuality.CalculateMaxCharacterFrequency (input);
		Assert.Equal (expected, result);
	}

	// CalculateRepeatedBigrams tests
	[Theory]
	[InlineData ("", 0)]
	[InlineData ("a", 0)]
	[InlineData ("ab", 0)]
	[InlineData ("abc", 0)]
	[InlineData ("aa", 0)] // only one bigram, can't repeat
	[InlineData ("aaa", 1)] // "aa" appears twice
	[InlineData ("abab", 1)] // "ab" appears twice, but it's just one repeater
	[InlineData ("ereeef", 1)] // "ee" appears twice. ditto
	[InlineData ("hello", 0)]
	[InlineData ("mississippi", 3)] // "is", "si", "ss" repeat
	[InlineData ("banana", 2)] // "an" and "na" repeat
	[InlineData ("abcabc", 2)] // all bigrams repeat
	[InlineData ("ABCABC", 2)] // case insensitive
	[InlineData ("test", 0)] // no repeating bigrams
	public void CalculateRepeatedBigrams_VariousInputs_ReturnsCorrectCount (
		string input,
		int expected
	) {
		var result = InputQuality.CalculateRepeatedBigrams (input);
		Assert.Equal (expected, result);
	}

	// CalculateMaxConsecutiveVowels tests
	[Theory]
	[InlineData ("", 0)]
	[InlineData ("a", 1)]
	[InlineData ("b", 0)]
	[InlineData ("ae", 2)]
	[InlineData ("aei", 3)]
	[InlineData ("aeio", 4)]
	[InlineData ("aeiou", 5)]
	[InlineData ("aeiouy", 6)]
	[InlineData ("ereeef", 3)] // eee
	[InlineData ("hello", 1)]
	[InlineData ("beautiful", 3)] // eau
	[InlineData ("queue", 4)] // ueue
	[InlineData ("bcdfg", 0)] // no vowels
	[InlineData ("eat", 2)] // ea
	[InlineData ("rhythm", 1)] // y is a vowel
	[InlineData ("AEIOU", 5)] // case insensitive
	public void CalculateMaxConsecutiveVowels_VariousInputs_ReturnsCorrectCount (
		string input,
		int expected
	) {
		var result = InputQuality.CalculateMaxConsecutiveVowels (input);
		Assert.Equal (expected, result);
	}

	// CalculateMaxConsecutiveConsonants tests
	[Theory]
	[InlineData ("", 0)]
	[InlineData ("a", 0)]
	[InlineData ("b", 1)]
	[InlineData ("bc", 2)]
	[InlineData ("bcd", 3)]
	[InlineData ("bcdfg", 5)]
	[InlineData ("hello", 2)] // ll
	[InlineData ("strength", 4)]
	[InlineData ("rhythm", 6)] // 'y' is a vowel!, but it's also included in the consonant list
	[InlineData ("aeiou", 0)] // all vowels
	[InlineData ("straights", 4)] // strt or ghts
	[InlineData ("twelfths", 5)] // lfths
	[InlineData ("BCDFG", 5)] // case insensitive
	[InlineData ("test", 2)] // st or st
	public void CalculateMaxConsecutiveConsonants_VariousInputs_ReturnsCorrectCount (
		string input,
		int expected
	) {
		var result = InputQuality.CalculateMaxConsecutiveConsonants (input);
		Assert.Equal (expected, result);
	}

	// CalculateConsonantVowelTransitionRatio tests
	[Theory]
	[InlineData ("", 1.0)]
	[InlineData ("a", 1.0)]
	[InlineData ("ab", 1)] // 1 transition in 2 chars
	[InlineData ("ba", 1)] // 1 transition in 2 chars
	[InlineData ("abc", 0.5)] // 1 transition1 in 3 chars
	[InlineData ("aaa", 0.0)] // no transitions
	[InlineData ("bbb", 0.0)] // no transitions
	[InlineData ("aba", 1.0)] // 2 transitions in 2 char positions (3 chars)
	[InlineData ("bab", 1.0)] // 2 transitions in 2 char positions
	[InlineData ("ereeef", 0.6)] // 3 transitions in 6 characters
	[InlineData ("hello", 0.75)] // h-e, e-l, l-o = 3 transitions in 5 chars
	[InlineData ("banana", 1)] // b-a, a-n, n-a, a-n, n-a = 5 transitions in 6 chars/5 possible transitions
	[InlineData ("test", 0.6667)] // t-e, e-s = 2 transitions in 4 chars
	[InlineData ("HELLO", 0.75)] // case insensitive
	public void CalculateConsonantVowelTransitionRatio_VariousInputs_ReturnsCorrectRatio (
		string input,
		decimal expected
	) {
		var result = InputQuality.CalculateConsonantVowelTransitionRatio (input);
		Assert.Equal (expected, result);
	}

	// HasRepeatingPattern tests
	[Theory]
	[InlineData ("", false)]
	[InlineData ("a", false)]
	[InlineData ("ab", false)]
	[InlineData ("abc", false)]
	[InlineData ("abab", true)] // "ab" repeats
	[InlineData ("aa", false)] // "a" repeats (pattern length 1 but method checks 2-4) but the input length is too short for this test
	[InlineData ("abcabc", true)] // "abc" repeats
	[InlineData ("abcdabcd", true)] // "abcd" repeats
	[InlineData ("abcdefgh", false)] // no repeats
	[InlineData ("ereeef", false)] // "ee" repeats, but it's not enough. that's just 3 consecutive e's.
	[InlineData ("hello", false)] // "ll" is consecutive but pattern detection may differ
	[InlineData ("testtest", true)] // "test" repeats
	[InlineData ("ABAB", true)] // case insensitive
	[InlineData ("xyxyxy", true)] // "xy" repeats multiple times
	public void HasRepeatingPattern_VariousInputs_ReturnsCorrectResult (
		string input,
		bool expected
	) {
		var result = InputQuality.HasRepeatingPattern (input);
		Assert.Equal (expected, result);
	}

}
