using System;
using System.Threading.Tasks;
using Xunit;
using FluentValidation;
using FluentValidation.TestHelper;
using Microsoft.Extensions.Localization;
using Moq;
using WeMarketingAutomationFormInjection.Models;

namespace Test;

public class PostalMustValidateTests
{
	private readonly Mock<IStringLocalizer> mockLocalizer;
	private readonly Mock<IOpenSearchClient> mockOpenSearchClient;
	private readonly TestValidator validator;

	public PostalMustValidateTests () {
		mockLocalizer = new Mock<IStringLocalizer> ();
		mockOpenSearchClient = new Mock<IOpenSearchClient> ();

		// Setup localized error message
		var localizedString = new LocalizedString ("invalidPostalCode", "Invalid postal code");
		mockLocalizer.Setup (x => x["invalidPostalCode"]).Returns (localizedString);

		validator = new TestValidator (mockOpenSearchClient.Object, mockLocalizer.Object);
	}

	#region USA Postal Code Tests

	[Theory]
	[InlineData ("12345")]           // Valid: 5-digit
	[InlineData ("12345-6789")]      // Valid: 5+4 with hyphen
	[InlineData ("90210")]           // Valid: Beverly Hills
	[InlineData ("10001")]           // Valid: New York
	[InlineData ("60601")]           // Valid: Chicago
	public void PostalMustValidate_USA_ValidPostalCodes_ShouldPass (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("USA", postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("USA", postalCode), Times.Once);
	}

	[Theory]
	[InlineData ("00000")]           // Invalid: doesn't exist
	[InlineData ("99999")]           // Invalid: doesn't exist
	[InlineData ("12345-0000")]      // Invalid: fake extension
	public void PostalMustValidate_USA_InvalidPostalCodes_ShouldFail (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("USA", postalCode))
			.ReturnsAsync (false);

		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("USA", postalCode), Times.Once);
	}

	#endregion

	#region UK (GBR) Postal Code Tests

	[Theory]
	[InlineData ("SW1A 1AA")]        // Valid: Westminster
	[InlineData ("GIR 0AA")]         // Valid: Girobank special case
	[InlineData ("M1 1AE")]          // Valid: Manchester
	[InlineData ("EC1A 1BB")]        // Valid: London
	[InlineData ("W1A 0AX")]         // Valid: London BBC
	public void PostalMustValidate_GBR_ValidPostalCodes_ShouldPass (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("GBR", postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = "GBR",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("GBR", postalCode), Times.Once);
	}

	[Theory]
	[InlineData ("SW1A 1ZZ")]        // Invalid: fake postcode
	[InlineData ("XX1 1XX")]         // Invalid: doesn't exist
	[InlineData ("AA99 9ZZ")]        // Invalid: fake format
	public void PostalMustValidate_GBR_InvalidPostalCodes_ShouldFail (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("GBR", postalCode))
			.ReturnsAsync (false);

		var lead = new Lead {
			CountryCode = "GBR",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("GBR", postalCode), Times.Once);
	}

	#endregion

	#region Canadian Postal Code Tests

	[Theory]
	[InlineData ("K1A 0B1")]    // Valid: Ottawa
	[InlineData ("M5W 1E6")]    // Valid: Toronto
	[InlineData ("V6B 1A1")]    // Valid: Vancouver
	[InlineData ("H3Z 2Y7")]    // Valid: Montreal
	[InlineData ("T5J 3S4")]    // Valid: Edmonton
	[InlineData ("l5v 3c3")]    // valid: lowercase
	public void PostalMustValidate_CAN_ValidPostalCodes_ShouldPass (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("CAN", postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = "CAN",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("CAN", postalCode), Times.Once);
	}

	[Theory]
	[InlineData ("K1A 0B9")]    // Invalid: fake postal code
	[InlineData ("X9X 9X9")]    // Invalid: doesn't exist
	[InlineData ("Z1Z 1Z1")]    // Invalid: Z not used
	[InlineData ("l5v3c3")]     // no spaces
	public void PostalMustValidate_CAN_InvalidPostalCodes_ShouldFail (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("CAN", postalCode))
			.ReturnsAsync (false);

		var lead = new Lead {
			CountryCode = "CAN",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("CAN", postalCode), Times.Once);
	}

	#endregion

	#region Edge Cases and Null Handling

	[Fact]
	public void PostalMustValidate_NullLead_ShouldFail () {
		// Arrange
		Lead? lead = new Lead {
			CountryCode = null,
			PostalCode = "12345"
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");

		// Should not call OpenSearch if lead is invalid
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (It.IsAny<string> (), It.IsAny<string> ()), Times.Never);
	}

	[Fact]
	public void PostalMustValidate_NullCountryCode_ShouldFail () {
		// Arrange
		var lead = new Lead {
			CountryCode = null,
			PostalCode = "12345"
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");

		// Should not call OpenSearch if country code is null
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (It.IsAny<string> (), It.IsAny<string> ()), Times.Never);
	}

	[Fact]
	public void PostalMustValidate_NullPostalCode_ShouldFail () {
		// Arrange
		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = null
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");

		// Should not call OpenSearch if postal code is null
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (It.IsAny<string> (), It.IsAny<string> ()), Times.Never);
	}

	[Fact]
	public void PostalMustValidate_EmptyPostalCode_ShouldFail () {
		// Arrange
		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = ""
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");
	}

	[Theory]
	[InlineData ("FRA", "75001")]            // France
	[InlineData ("DEU", "10115")]            // Germany
	[InlineData ("JPN", "100-0001")]         // Japan
	[InlineData ("AUS", "2000")]             // Australia
	public void PostalMustValidate_OtherCountries_ShouldCallOpenSearch (string countryCode, string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (countryCode, postalCode), Times.Once);
	}

	#endregion

	#region Case Sensitivity Tests

	[Theory]
	[InlineData ("USA", "12345")]
	[InlineData ("usa", "12345")]
	[InlineData ("UsA", "12345")]
	public void PostalMustValidate_CountryCodeCaseInsensitive_ShouldWork (string countryCode, string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (It.IsAny<string> (), postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	[Theory]
	[InlineData ("GBR", "SW1A 1AA")]
	[InlineData ("GBR", "sw1a 1aa")]
	[InlineData ("GBR", "Sw1A 1aA")]
	public void PostalMustValidate_PostalCodeCaseInsensitive_ShouldWork (string countryCode, string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, It.IsAny<string> ()))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
	}

	#endregion

	#region OpenSearch Integration Tests

	[Fact]
	public void PostalMustValidate_OpenSearchReturnsTrue_ShouldPass () {
		// Arrange
		string countryCode = "USA";
		string postalCode = "12345";

		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (countryCode, postalCode), Times.Once);
	}

	[Fact]
	public void PostalMustValidate_OpenSearchReturnsFalse_ShouldFail () {
		// Arrange
		string countryCode = "USA";
		string postalCode = "00000";

		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ReturnsAsync (false);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldHaveValidationErrorFor (x => x.PostalCode)
			.WithErrorMessage ("Invalid postal code");
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode (countryCode, postalCode), Times.Once);
	}

	[Fact]
	public async Task PostalMustValidate_OpenSearchThrowsException_ShouldFail () {
		// Arrange
		string countryCode = "USA";
		string postalCode = "12345";

		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ThrowsAsync (new Exception ("OpenSearch connection failed"));

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act & Assert
		// await Assert.ThrowsAsync<Exception> (() => validator.TestValidateAsync (lead, cancellationToken: TestContext.Current.CancellationToken));
		// Act & Assert
		// i'm not entirely sure why, but even though i'm telling this to throw an Exception, an AggregateException is what's really being thrown
		await Assert.ThrowsAsync<AggregateException> (async () => {
			await validator.TestValidateAsync (lead, cancellationToken: TestContext.Current.CancellationToken);
		});
	}

	#endregion

	#region Multiple Country Validation

	[Theory]
	[InlineData ("USA", "12345", true)]
	[InlineData ("USA", "00000", false)]
	[InlineData ("GBR", "SW1A 1AA", true)]
	[InlineData ("GBR", "XX1 1XX", false)]
	[InlineData ("CAN", "K1A 0B1", true)]
	[InlineData ("CAN", "X9X 9X9", false)]
	public void PostalMustValidate_CrossCountryValidation_ShouldValidateCorrectly (
		string countryCode,
		string postalCode,
		bool isRealPostalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode (countryCode, postalCode))
			.ReturnsAsync (isRealPostalCode);

		var lead = new Lead {
			CountryCode = countryCode,
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		if (isRealPostalCode) {
			result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		} else {
			result.ShouldHaveValidationErrorFor (x => x.PostalCode)
				.WithErrorMessage ("Invalid postal code");
		}
	}

	#endregion

	#region Whitespace Handling

	[Theory]
	[InlineData ("12345")]           // No whitespace
	[InlineData (" 12345")]          // Leading whitespace
	[InlineData ("12345 ")]          // Trailing whitespace
	[InlineData (" 12345 ")]         // Both
	public void PostalMustValidate_WithWhitespace_ShouldCallOpenSearchWithOriginal (string postalCode) {
		// Arrange
		mockOpenSearchClient
			.Setup (x => x.IsRealPostalCode ("USA", postalCode))
			.ReturnsAsync (true);

		var lead = new Lead {
			CountryCode = "USA",
			PostalCode = postalCode
		};

		// Act
		var result = validator.TestValidate (lead);

		// Assert
		result.ShouldNotHaveValidationErrorFor (x => x.PostalCode);
		mockOpenSearchClient.Verify (x => x.IsRealPostalCode ("USA", postalCode), Times.Once);
	}

	#endregion

	// Test validator class to test the custom validator
	private class TestValidator : AbstractValidator<Lead>
	{
		public TestValidator (
			IOpenSearchClient openSearchClient,
			IStringLocalizer localizer
		) {
			RuleFor (x => x.PostalCode).PostalMustValidate (openSearchClient, localizer);
		}
	}
}