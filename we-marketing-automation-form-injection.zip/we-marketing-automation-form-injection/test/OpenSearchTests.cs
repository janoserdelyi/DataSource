using System.Net;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using WeMarketingAutomationFormInjection.Models;
using WeMarketingAutomationFormInjection.Models.OpenSearch;

namespace Test;

public class OpenSearchTests
{
	private readonly Mock<IWebHostEnvironment> mockEnv;
	private readonly Mock<IConfiguration> mockConfig;
	private readonly Mock<HttpMessageHandler> mockHttpMessageHandler;
	private readonly HttpClient mockHttpClient;
	private const string TestEndpointUrl = "https://test-opensearch.example.com";

	public OpenSearchTests () {
		mockEnv = new Mock<IWebHostEnvironment> ();
		mockConfig = new Mock<IConfiguration> ();
		mockHttpMessageHandler = new Mock<HttpMessageHandler> ();

		// Setup environment
		mockEnv.Setup (e => e.EnvironmentName).Returns ("test");

		// Setup configuration
		SetupMockConfig ("OpenSearchIndexURI", TestEndpointUrl);
		SetupMockConfig ("PostalCodeReaderIndex", "test-postal-reader");
		SetupMockConfig ("PostalCodeWriterIndex", "test-postal-writer");
		SetupMockConfig ("EmailPreferenceReaderIndex", "test-email-reader");
		SetupMockConfig ("BookingLogWriterIndex", "test-booking-writer");
		SetupMockConfig ("FormLogWriterIndex", "test-form-writer");
		SetupMockConfig ("ContactSearchReaderIndex", "test-contact-reader");
		SetupMockConfig ("ContactGaSessionReaderIndex", "test-ga-session-reader");
		SetupMockConfig ("ContactGaSessionWriterIndex", "test-ga-session-writer");

		mockHttpClient = new HttpClient (mockHttpMessageHandler.Object);
	}

	private void SetupMockConfig (
		string key,
		string value
	) {
		var mockSection = new Mock<IConfigurationSection> ();
		mockSection.Setup (s => s.Value).Returns (value);
		mockConfig.Setup (c => c.GetSection (key)).Returns (mockSection.Object);
	}

	private OpenSearchClient CreateClient () {
		var client = new OpenSearchClient (
			mockEnv.Object,
			mockConfig.Object
		);

		// Use reflection to inject mock HttpClient
		var httpClientField = typeof (OpenSearchClient).GetField (
			"httpClient",
			System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static
		);
		httpClientField?.SetValue (null, mockHttpClient);

		return client;
	}

	#region IsRealPostalCode Tests

	[Theory]
	[InlineData ("USA", "23114", "fakename", true)]
	[InlineData ("USA", "12345", "fakename", true)]
	[InlineData ("GBR", "SW1A 1AA", "fakename", true)]
	[InlineData ("CAN", "K1A 0B1", "fakename", true)]
	public async Task IsRealPostalCode_ValidPostalCode_ReturnsTrue (
		string countryCode,
		string postalCode,
		string name,
		bool expected
	) {
		// Arrange
		var responseContent = CreateOpenSearchResponse (new PostalCountry {
			PostalCountryCd = "test",
			CountryCd = countryCode,
			PostalCd = postalCode,
			Name = name
		}, 1);

		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.IsRealPostalCode (countryCode, postalCode);

		// Assert
		Assert.Equal (expected, result);
	}

	[Theory]
	[InlineData ("USA", "99999")]
	[InlineData ("GBR", "INVALID")]
	[InlineData ("CAN", "ZZZZZ")]
	public async Task IsRealPostalCode_InvalidPostalCode_ReturnsFalse (
		string countryCode,
		string postalCode
	) {
		// Arrange
		var responseContent = CreateOpenSearchResponse<PostalCountry> (null, 0);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.IsRealPostalCode (countryCode, postalCode);

		// Assert
		Assert.False (result);
	}

	[Fact]
	public async Task IsRealPostalCode_USA_LongPostalCode_TruncatesTo5Digits () {
		// Arrange
		var responseContent = CreateOpenSearchResponse (new PostalCountry {
			PostalCountryCd = "test",
			CountryCd = "USA",
			PostalCd = "23114",
			Name = "fakename"
		}, 1);

		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.IsRealPostalCode ("USA", "23114-1234");

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task IsRealPostalCode_HttpException_ReturnsFalse () {
		// Arrange
		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.IsRealPostalCode ("USA", "23114");

		// Assert
		Assert.False (result);
	}

	#endregion

	#region GetContact Tests

	[Fact]
	public async Task GetContact_SingleMatch_ReturnsContact () {
		// Arrange
		var contact = new ContactSearch {
			ContactId = 123,
			EmailAddress = "test@example.com",
			FirstName = "John",
			LastName = "Doe",
			PhoneNumber = "1234567890"
		};

		var responseContent = CreateOpenSearchResponse (contact, 1);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetContact ("test@example.com", "John", "Doe", "1234567890");

		// Assert
		Assert.NotNull (result);
		Assert.Equal ("test@example.com", result.EmailAddress);
		Assert.Equal ("John", result.FirstName);
	}

	[Fact]
	public async Task GetContact_NoMatch_ReturnsNull () {
		// Arrange
		var responseContent = CreateOpenSearchResponse<ContactSearch> (null, 0);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetContact ("test@example.com", "John", "Doe", "1234567890");

		// Assert
		Assert.Null (result);
	}

	[Fact]
	public async Task GetContact_MultipleMatches_ReturnsPhoneMatch () {
		// Arrange
		var contacts = new List<ContactSearch>
		{
			new ContactSearch
			{
				ContactId =  123,
				EmailAddress = "test@example.com",
				FirstName = "Jane",
				LastName = "Smith",
				PhoneNumber = "9876543210"
			},
			new ContactSearch
			{
				ContactId = 456,
				EmailAddress = "test@example.com",
				FirstName = "John",
				LastName = "Doe",
				PhoneNumber = "1234567890"
			}
		};

		var responseContent = CreateOpenSearchResponseMultiple (contacts, contacts.Count);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetContact ("test@example.com", "John", "Doe", "1234567890");

		// Assert
		Assert.NotNull (result);
		Assert.Equal ("1234567890", result.PhoneNumber);
	}

	[Fact]
	public async Task GetContact_HttpException_ReturnsNull () {
		// Arrange
		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.GetContact ("test@example.com", "John", "Doe", "1234567890");

		// Assert
		Assert.Null (result);
	}

	#endregion

	#region ContactGaSessions Tests

	[Fact]
	public async Task WriteContactGaSession_NewSession_CreatesSuccessfully () {
		// Arrange
		var gaSession = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-123" }
		};

		// First call returns null (no existing sessions)
		var emptyResponse = CreateOpenSearchResponse<ContactGaSessions> (null, 0);
		SetupHttpResponse (HttpStatusCode.OK, emptyResponse);

		var client = CreateClient ();

		// Act
		var result = await client.WriteContactGaSession (gaSession);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task WriteContactGaSession_ExistingSession_MergesSessions () {
		// Arrange
		var existing = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-old" }
		};

		var newSession = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-new" }
		};

		// Setup two responses: first for GET, second for PUT
		var getResponse = CreateOpenSearchResponse (existing, 1);
		var putResponse = "{\"result\":\"updated\"}";

		var responses = new Queue<HttpResponseMessage> ();
		responses.Enqueue (new HttpResponseMessage {
			StatusCode = HttpStatusCode.OK,
			Content = new StringContent (getResponse, Encoding.UTF8, "application/json")
		});
		responses.Enqueue (new HttpResponseMessage {
			StatusCode = HttpStatusCode.OK,
			Content = new StringContent (putResponse, Encoding.UTF8, "application/json")
		});

		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ReturnsAsync (() => responses.Dequeue ());

		var client = CreateClient ();

		// Act
		var result = await client.WriteContactGaSession (newSession);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task WriteContactGaSession_DuplicateSession_ReturnsTrueWithoutWriting () {
		// Arrange
		var existing = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-123" }
		};

		var duplicate = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-123" }
		};

		var getResponse = CreateOpenSearchResponse (existing, 1);
		SetupHttpResponse (HttpStatusCode.OK, getResponse);

		var client = CreateClient ();

		// Act
		var result = await client.WriteContactGaSession (duplicate);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task WriteContactGaSession_EmptySessionList_ReturnsFalse () {
		// Arrange
		var gaSession = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> ()
		};

		var client = CreateClient ();

		// Act
		var result = await client.WriteContactGaSession (gaSession);

		// Assert
		Assert.False (result);
	}

	[Fact]
	public async Task GetContactGaSessions_ExistingSessions_ReturnsData () {
		// Arrange
		var expected = new ContactGaSessions {
			ContactId = 12345,
			GaSessionIds = new List<string> { "session-1", "session-2" }
		};

		var responseContent = CreateOpenSearchResponse (expected, 1);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetContactGaSessions (12345);

		// Assert
		Assert.NotNull (result);
		Assert.Equal (12345, result.ContactId);
		Assert.Equal (2, result.GaSessionIds.Count);
	}

	[Fact]
	public async Task GetContactGaSessions_NoSessions_ReturnsNull () {
		// Arrange
		var responseContent = CreateOpenSearchResponse<ContactGaSessions> (null, 0);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetContactGaSessions (12345);

		// Assert
		Assert.Null (result);
	}

	#endregion

	#region LogFormRequest Tests

	[Fact]
	public async Task LogFormRequest_ValidRecord_ReturnsTrue () {
		// Arrange
		var logRecord = new FormLogRecord {
			FormCd = "test-form",
			RequestDt = DateTimeOffset.Now.ToUnixTimeMilliseconds (),
			Timestamp = DateTimeOffset.Now.ToString ("o"),
			SourceIp = "192.168.1.1",
			UserAgent = "Mozilla/5.0",
			Method = "POST",
			Protocol = "HTTPS",
			Host = "example.com",
			Path = "/api/v1/test",
			Querystring = "",
			Headers = "Content-Type: application/json",
			Body = "{}",
			Locale = "en-US",
			Id = Guid.NewGuid ().ToString ()
		};

		SetupHttpResponse (HttpStatusCode.OK, "{\"result\":\"created\"}");
		var client = CreateClient ();

		// Act
		var result = await client.LogFormRequest (logRecord);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task LogFormRequest_HttpException_ReturnsFalse () {
		// Arrange
		var logRecord = new FormLogRecord {
			FormCd = "test-form",
			RequestDt = DateTimeOffset.Now.ToUnixTimeMilliseconds (),
			Timestamp = DateTimeOffset.Now.ToString ("o"),
			SourceIp = "192.168.1.1",
			UserAgent = "Mozilla/5.0",
			Method = "POST",
			Protocol = "HTTPS",
			Host = "example.com",
			Path = "/api/v1/test",
			Querystring = "",
			Headers = "Content-Type: application/json",
			Body = "{}",
			Locale = "en-US",
			Id = Guid.NewGuid ().ToString ()
		};

		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.LogFormRequest (logRecord);

		// Assert
		Assert.False (result);
	}

	#endregion

	#region LogBookingRequest Tests

	[Fact]
	public async Task LogBookingRequest_ValidRecord_ReturnsTrue () {
		// Arrange
		var logRecord = new BookingLogRecord {
			TrackingId = Guid.NewGuid ().ToString (),
			SubmitDate = DateTimeOffset.Now,
			FormCd = "demo-form",
			Locale = "en-US",
			BookingId = "booking-123"
		};

		SetupHttpResponse (HttpStatusCode.OK, "{\"result\":\"created\"}");
		var client = CreateClient ();

		// Act
		var result = await client.LogBookingRequest (logRecord);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task LogBookingRequest_HttpException_ReturnsFalse () {
		// Arrange
		var logRecord = new BookingLogRecord {
			TrackingId = Guid.NewGuid ().ToString (),
			SubmitDate = DateTimeOffset.Now,
			FormCd = "demo-form",
			Locale = "en-US"
		};

		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.LogBookingRequest (logRecord);

		// Assert
		Assert.False (result);
	}

	#endregion

	#region GetAllFormRequestLogSince Tests

	[Fact]
	public async Task GetAllFormRequestLogSince_WithResults_ReturnsRecords () {
		// Arrange
		var formLogs = new List<FormLogRecord>
		{
			new FormLogRecord
			{
				FormCd = "test-form",
				RequestDt = DateTimeOffset.Now.ToUnixTimeMilliseconds(),
				Timestamp = DateTimeOffset.Now.ToString("o"),
				SourceIp = "192.168.1.1",
				UserAgent = "Mozilla/5.0",
				Method = "POST",
				Protocol = "HTTPS",
				Host = "example.com",
				Path = "/api/v1/test",
				Querystring = "",
				Headers = "",
				Body = "{}",
				Locale = "en-US",
				Id = Guid.NewGuid().ToString()
			}
		};

		var responseContent = CreateOpenSearchResponseMultiple (formLogs, formLogs.Count);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetAllFormRequestLogSince ("test-form", "en-US", DateTimeOffset.Now.AddDays (-1));

		// Assert
		Assert.NotNull (result);
		Assert.Single (result);
		Assert.Equal ("test-form", result[0].FormCd);
	}

	[Fact]
	public async Task GetAllFormRequestLogSince_WithMethod_ReturnsFilteredRecords () {
		// Arrange
		var formLogs = new List<FormLogRecord>
		{
			new FormLogRecord
			{
				FormCd = "test-form",
				RequestDt = DateTimeOffset.Now.ToUnixTimeMilliseconds(),
				Timestamp = DateTimeOffset.Now.ToString("o"),
				SourceIp = "192.168.1.1",
				UserAgent = "Mozilla/5.0",
				Method = "POST",
				Protocol = "HTTPS",
				Host = "example.com",
				Path = "/api/v1/test",
				Querystring = "",
				Headers = "",
				Body = "{}",
				Locale = "en-US",
				Id = Guid.NewGuid().ToString()
			}
		};

		var responseContent = CreateOpenSearchResponseMultiple (formLogs, formLogs.Count);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetAllFormRequestLogSince ("test-form", "en-US", DateTimeOffset.Now.AddDays (-1), "POST");

		// Assert
		Assert.NotNull (result);
		Assert.Single (result);
		Assert.Equal ("POST", result[0].Method);
	}

	[Fact]
	public async Task GetAllFormRequestLogSince_NoResults_ReturnsEmptyList () {
		// Arrange
		var responseContent = CreateOpenSearchResponseMultiple<FormLogRecord> (new List<FormLogRecord> (), 0);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetAllFormRequestLogSince ("test-form", "en-US", DateTimeOffset.Now.AddDays (-1));

		// Assert
		Assert.NotNull (result);
		Assert.Empty (result);
	}

	#endregion

	#region GetAllEmailPreferences Tests

	[Fact]
	public async Task GetAllEmailPreferences_ExistingPreferences_ReturnsData () {
		// Arrange
		var emailPref = new WeMarketingAutomationFormInjection.Models.OpenSearch.EmailPreference {
			Id = "123",
			BrandPreferences = new List<BrandPreference> ()
		};
		emailPref.BrandPreferences.Add (new BrandPreference () {
			Id = 1,
			Name = "CoStar"
		});
		emailPref.BrandPreferences[0].SegmentPreferences.Add (new SegmentPreference () {
			Id = 9,
			Name = "Marketing Offers and Information",
			CanEmail = true,
			CanEmailCountryDefault = true
		});

		var responseContent = CreateOpenSearchResponse (emailPref, 1);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetAllEmailPreferences ("test@example.com");

		// Assert
		Assert.NotNull (result);
		Assert.True (result.BrandPreferences![0].SegmentPreferences[0].CanEmail);
	}

	[Fact]
	public async Task GetAllEmailPreferences_NoPreferences_ReturnsNull () {
		// Arrange
		var responseContent = CreateOpenSearchResponse<WeMarketingAutomationFormInjection.Models.OpenSearch.EmailPreference> (null, 0);
		SetupHttpResponse (HttpStatusCode.OK, responseContent);
		var client = CreateClient ();

		// Act
		var result = await client.GetAllEmailPreferences ("test@example.com");

		// Assert
		Assert.Null (result);
	}

	[Fact]
	public async Task GetAllEmailPreferences_HttpException_ReturnsNull () {
		// Arrange
		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.GetAllEmailPreferences ("test@example.com");

		// Assert
		Assert.Null (result);
	}

	#endregion

	#region WritePostalCodes Tests

	[Fact]
	public async Task WritePostalCodes_ValidRecords_ReturnsTrue () {
		// Arrange
		var records = new List<PostalCountry>
		{
			new PostalCountry
			{
				PostalCountryCd = "test-1",
				CountryCd = "USA",
				PostalCd = "23114",
				Name = "Richmond"
			},
			new PostalCountry
			{
				PostalCountryCd = "test-2",
				CountryCd = "USA",
				PostalCd = "23113",
				Name = "Midlothian"
			}
		};

		SetupHttpResponse (HttpStatusCode.OK, "{\"items\":[]}");
		var client = CreateClient ();

		// Act
		var result = await client.WritePostalCodes (records);

		// Assert
		Assert.True (result);
	}

	[Fact]
	public async Task WritePostalCodes_HttpException_ReturnsFalse () {
		// Arrange
		var records = new List<PostalCountry>
		{
			new PostalCountry
			{
				PostalCountryCd = "test-1",
				CountryCd = "USA",
				PostalCd = "23114",
				Name = "Richmond"
			}
		};

		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ThrowsAsync (new HttpRequestException ("Network error"));

		var client = CreateClient ();

		// Act
		var result = await client.WritePostalCodes (records);

		// Assert
		Assert.False (result);
	}

	#endregion

	#region Helper Methods

	private void SetupHttpResponse (
		HttpStatusCode statusCode,
		string content
	) {
		mockHttpMessageHandler
			.Protected ()
			.Setup<Task<HttpResponseMessage>> (
				"SendAsync",
				ItExpr.IsAny<HttpRequestMessage> (),
				ItExpr.IsAny<CancellationToken> ())
			.ReturnsAsync (new HttpResponseMessage {
				StatusCode = statusCode,
				Content = new StringContent (content, Encoding.UTF8, "application/json")
			});
	}

	private string CreateOpenSearchResponse<T> (
		T? source,
		int totalHits
	) {
		if (source == null || totalHits == 0) {
			return JsonConvert.SerializeObject (new {
				took = 1,
				timed_out = false,
				hits = new {
					total = new { value = 0, relation = "eq" },
					hits = new object[0]
				}
			});
		}

		return JsonConvert.SerializeObject (new {
			took = 1,
			timed_out = false,
			hits = new {
				total = new { value = totalHits, relation = "eq" },
				hits = new[]
				{
					new
					{
						_index = "test-index",
						_type = "_doc",
						_id = "test-id",
						_score = 1.0,
						_source = source
					}
				}
			}
		});
	}

	private string CreateOpenSearchResponseMultiple<T> (
		List<T> sources,
		int totalHits
	) {
		if (sources == null || sources.Count == 0) {
			return JsonConvert.SerializeObject (new {
				took = 1,
				timed_out = false,
				hits = new {
					total = new { value = 0, relation = "eq" },
					hits = new object[0]
				}
			});
		}

		var hits = sources.Select ((source, index) => new {
			_index = "test-index",
			_type = "_doc",
			_id = $"test-id-{index}",
			_score = 1.0,
			_source = source
		}).ToArray ();

		return JsonConvert.SerializeObject (new {
			took = 1,
			timed_out = false,
			hits = new {
				total = new { value = totalHits, relation = "eq" },
				hits = hits
			}
		});
	}

	#endregion
}