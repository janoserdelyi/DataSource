using System.Security.Cryptography;
using System.Text;

namespace Test;

public class UtilsTests
{
	#region Encrypt Tests

	[Theory]
	[InlineData ("Hello World", "1234567890123456")]
	[InlineData ("test@example.com", "abcdefghijklmnop")]
	[InlineData ("Special chars: !@#$%^&*()", "mysecretkey12345")]
	public void Encrypt_ValidInput_ReturnsBase64String (string inputText, string salt) {
		// Act
		var result = Utils.Encrypt (inputText, salt);

		// Assert
		Assert.NotNull (result);
		Assert.NotEmpty (result);

		// Verify it's valid base64
		Assert.True (IsBase64String (result));
	}

	[Theory]
	[InlineData ("", "1234567890123456")]
	[InlineData ("   ", "1234567890123456")]
	public void Encrypt_EmptyOrWhitespaceInput_ThrowsArgumentNullException (string inputText, string salt) {
		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Encrypt (inputText, salt));
	}

	[Theory]
	[InlineData ("Hello World", "")]
	[InlineData ("Hello World", "   ")]
	public void Encrypt_EmptyOrWhitespaceSalt_ThrowsArgumentNullException (string inputText, string salt) {
		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Encrypt (inputText, salt));
	}

	[Fact]
	public void Encrypt_SameInputDifferentSalts_ProducesDifferentResults () {
		// Arrange
		var input = "test data";
		var salt1 = "1234567890123456";
		var salt2 = "abcdefghijklmnop";

		// Act
		var result1 = Utils.Encrypt (input, salt1);
		var result2 = Utils.Encrypt (input, salt2);

		// Assert
		Assert.NotEqual (result1, result2);
	}

	[Fact]
	public void Encrypt_SameInputSameSalt_ProducesDifferentResults_DueToRandomIV () {
		// Arrange
		var input = "test data";
		var salt = "1234567890123456";

		// Act
		var result1 = Utils.Encrypt (input, salt);
		var result2 = Utils.Encrypt (input, salt);

		// Assert
		// Results should be different because a new random IV is generated each time
		Assert.NotEqual (result1, result2);
	}

	[Theory]
	[InlineData ("a")]
	[InlineData ("This is a much longer string with various characters 1234567890 !@#$%")]
	public void Encrypt_DifferentInputLengths_Succeeds (string inputText) {
		// Arrange
		var salt = "1234567890123456";

		// Act
		var result = Utils.Encrypt (inputText, salt);

		// Assert
		Assert.NotNull (result);
		Assert.NotEmpty (result);
	}

	[Fact]
	public void Encrypt_SaltLengthNot16Bytes_ThrowsArgumentException () {
		// Arrange
		var input = "test data";
		var shortSalt = "short"; // Less than 16 bytes
		var longSalt = "this is a very long salt that exceeds 16 bytes"; // More than 16 bytes

		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Encrypt (input, shortSalt));
		Assert.Throws<ArgumentException> (() => Utils.Encrypt (input, longSalt));
	}

	#endregion

	#region Decrypt Tests

	[Theory]
	[InlineData ("Hello World", "1234567890123456")]
	[InlineData ("test@example.com", "abcdefghijklmnop")]
	[InlineData ("Special chars: !@#$%^&*()", "mysecretkey12345")]
	[InlineData ("12345", "1234567890123456")]
	public void Decrypt_ValidEncryptedText_ReturnsOriginalText (string originalText, string salt) {
		// Arrange
		var encrypted = Utils.Encrypt (originalText, salt);

		// Act
		var decrypted = Utils.Decrypt (encrypted, salt);

		// Assert
		Assert.Equal (originalText, decrypted);
	}

	[Theory]
	[InlineData ("", "1234567890123456")]
	[InlineData ("   ", "1234567890123456")]
	public void Decrypt_EmptyOrWhitespaceEncryptedText_ThrowsArgumentNullException (string encryptedText, string salt) {
		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Decrypt (encryptedText, salt));
	}

	[Theory]
	[InlineData ("validbase64text", "")]
	[InlineData ("validbase64text", "   ")]
	public void Decrypt_EmptyOrWhitespaceSalt_ThrowsArgumentNullException (string encryptedText, string salt) {
		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Decrypt (encryptedText, salt));
	}

	[Fact]
	public void Decrypt_WrongSalt_ThrowsCryptographicException () {
		// Arrange
		var originalText = "secret data";
		var correctSalt = "1234567890123456";
		var wrongSalt = "abcdefghijklmnop";
		var encrypted = Utils.Encrypt (originalText, correctSalt);

		// Act & Assert
		Assert.Throws<CryptographicException> (() => Utils.Decrypt (encrypted, wrongSalt));
	}

	[Theory]
	[InlineData ("not-base64!@#$")]
	[InlineData ("invalid")]
	public void Decrypt_InvalidBase64_ThrowsFormatException (string invalidEncryptedText) {
		// Arrange
		var salt = "1234567890123456";

		// Act & Assert
		Assert.Throws<FormatException> (() => Utils.Decrypt (invalidEncryptedText, salt));
	}

	[Fact]
	public void Decrypt_TamperedCiphertext_ThrowsCryptographicException () {
		// Arrange
		var originalText = "secret data";
		var salt = "1234567890123456";
		var encrypted = Utils.Encrypt (originalText, salt);

		// Tamper with the encrypted data
		var bytes = Convert.FromBase64String (encrypted);
		bytes[bytes.Length - 1] ^= 0xFF; // Flip bits in last byte
		var tampered = Convert.ToBase64String (bytes);

		// Act & Assert
		Assert.Throws<CryptographicException> (() => Utils.Decrypt (tampered, salt));
	}

	[Fact]
	public void Decrypt_ShortCiphertext_ThrowsException () {
		// Arrange
		var salt = "1234567890123456";
		// Create a base64 string that's too short (less than 16 bytes for IV)
		var shortEncrypted = Convert.ToBase64String (new byte[8]);

		// Act & Assert
		var exception = Assert.ThrowsAny<Exception> (() => Utils.Decrypt (shortEncrypted, salt));
	}

	[Fact]
	public void Decrypt_SaltLengthNot16Bytes_ThrowsArgumentException () {
		// Arrange
		var validEncrypted = "dGVzdCBlbmNyeXB0ZWQgZGF0YQ=="; // Some base64 string
		var shortSalt = "short"; // Less than 16 bytes
		var longSalt = "this is a very long salt that exceeds 16 bytes"; // More than 16 bytes

		// Act & Assert
		Assert.Throws<ArgumentException> (() => Utils.Decrypt (validEncrypted, shortSalt));
		Assert.Throws<ArgumentException> (() => Utils.Decrypt (validEncrypted, longSalt));
	}

	#endregion

	#region Encrypt/Decrypt Round-trip Tests

	[Theory]
	[InlineData ("")]
	[InlineData ("a")]
	[InlineData ("Short text")]
	[InlineData ("This is a longer text with multiple words and special characters !@#$%^&*()")]
	[InlineData ("Unicode: 你好世界 🌍")]
	[InlineData ("Newlines:\nand\ttabs")]
	[InlineData ("{\"json\":\"data\",\"nested\":{\"value\":123}}")]
	public void EncryptDecrypt_RoundTrip_PreservesOriginalText (string originalText) {
		// Skip empty string test as it throws ArgumentNullException
		if (string.IsNullOrWhiteSpace (originalText)) {
			return;
		}

		// Arrange
		var salt = "1234567890123456";

		// Act
		var encrypted = Utils.Encrypt (originalText, salt);
		var decrypted = Utils.Decrypt (encrypted, salt);

		// Assert
		Assert.Equal (originalText, decrypted);
	}

	[Fact]
	public void EncryptDecrypt_MultipleRoundTrips_MaintainsDataIntegrity () {
		// Arrange
		var originalText = "sensitive data";
		var salt = "1234567890123456";

		// Act - Multiple encrypt/decrypt cycles
		var encrypted1 = Utils.Encrypt (originalText, salt);
		var decrypted1 = Utils.Decrypt (encrypted1, salt);

		var encrypted2 = Utils.Encrypt (decrypted1, salt);
		var decrypted2 = Utils.Decrypt (encrypted2, salt);

		var encrypted3 = Utils.Encrypt (decrypted2, salt);
		var decrypted3 = Utils.Decrypt (encrypted3, salt);

		// Assert
		Assert.Equal (originalText, decrypted1);
		Assert.Equal (originalText, decrypted2);
		Assert.Equal (originalText, decrypted3);
	}

	[Fact]
	public void EncryptDecrypt_LargeText_Succeeds () {
		// Arrange
		var largeText = new string ('A', 10000); // 10KB of data
		var salt = "1234567890123456";

		// Act
		var encrypted = Utils.Encrypt (largeText, salt);
		var decrypted = Utils.Decrypt (encrypted, salt);

		// Assert
		Assert.Equal (largeText, decrypted);
		Assert.Equal (10000, decrypted.Length);
	}
	#endregion

	#region Helper Methods

	private bool IsBase64String (string value) {
		if (string.IsNullOrEmpty (value)) {
			return false;
		}

		try {
			Convert.FromBase64String (value);
			return true;
		} catch {
			return false;
		}
	}

	#endregion
}