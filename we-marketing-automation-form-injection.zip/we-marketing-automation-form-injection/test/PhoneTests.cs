using WeMarketingAutomationFormInjection;
using CoStar.PhoneNumbers;

namespace Test;

public class PhoneTests
{
	[Theory]
	[InlineData ("555-123-4567", "5551234567")]
	[InlineData ("(555) 123-4567", "5551234567")]
	[InlineData ("+1 555-123-4567", "+15551234567")]
	[InlineData ("1-612-385-4494", "16123854494")]
	public void PhoneNumber_NonPhoneCharacters_ReturnsCleanedPhoneNumber (
		string input,
		string expected
	) {

		var result = Utils.DeformatPhoneNumber (input);

		Assert.Equal (expected, result);
	}

	[Theory]
	[InlineData ("US", "555-123-4567", false)]
	[InlineData ("US", "1-612-385-4494", true)]
	[InlineData ("US", "(612) 385-4494", true)]
	[InlineData ("US", "6123857299", true)]
	[InlineData ("US", "16123857299", true)]
	[InlineData ("US", "+1 7744569206", true)]
	[InlineData ("US", "1-800-869-3557", true)]
	[InlineData ("US", "+1-760-420-3135", true)]
	[InlineData ("US", "406-922-8949", true)]
	[InlineData ("US", "2406268787", true)]
	[InlineData ("US", "1247841112", false)] // there are no US area codes which start with '1'
	[InlineData ("US", "227-225-4917", true)]
	[InlineData ("US", "804 304 5488", true)]
	[InlineData ("FR", "01 12.23.45.78", true)] // landline
	[InlineData ("FR", "07 33.45.99.01", true)] // mobile
	[InlineData ("FR", "+33 0800 555 777", true)] // toll-free, with international code
	[InlineData ("FR", "0648730719", true)] // stanislas used this number to test in france
	[InlineData ("FR", " +33 1 76 45 37 55 ", true)] // pulled from https://www.loopnet.fr/annonce/15-rue-des-feuillantines-paris/38096378/ spaces added for more testing
	public void PhoneNumber_ValidAndPossible_ReturnsSuccess (
		string countrycode,
		string phonenumber,
		bool expected
	) {

		var justnumbersplus = Utils.DeformatPhoneNumber (phonenumber);

		var parser = new Parser ();
		var parsed = parser.Parse (new PhoneNumber { CountryCode = countrycode, Number = justnumbersplus });

		var success = true;
		/*
		from the interwebz :
		isPossibleNumber:
			his method offers a quick, lightweight check based primarily on the length of the phone number.
			It determines if a given number, in conjunction with a specified region, has a length that could potentially
			correspond to a valid phone number in that region. This check is significantly faster than a full validation
			because it avoids more complex pattern matching and prefix analysis. It's useful for initial filtering or
			in scenarios where performance is critical and a rough estimation of possibility is sufficient.
		isValid:
			This method performs a comprehensive validation, taking into account both the length and the specific
			digit patterns (prefixes) associated with valid phone numbers in a given region. It provides a more
			definitive answer regarding the validity of a phone number, confirming whether it adheres to the established
			rules and patterns for that region. This method is more resource-intensive but offers a higher degree of
			accuracy in determining if a number is truly a valid, assignable phone number within its specified region.
		*/

		// just setting these here vs inline in the conditional for easier debugging
		var ispossible = parsed.IsPossibleNumber ();
		var isvalid = parsed.IsValid ();

		if (ispossible == false || isvalid == false) {
			success = false;
		}

		Assert.Equal (success, expected);
	}


}
