# Marketing Automation Form Injection Service

> A flexible C#-based backend-for-frontend (BFF) service providing end-to-end control over lead creation and form submission workflows for Marketing Automation.

[![.NET](https://img.shields.io/badge/.NET-8.0-512BD4)](https://dotnet.microsoft.com/)
[![License](https://img.shields.io/badge/license-Proprietary-red)](LICENSE)

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Getting Started](#getting-started)
- [API Reference](#api-reference)
- [Configuration](#configuration)
- [Development](#development)
- [Testing](#testing)
- [Deployment](#deployment)
- [Security](#security)
- [Contributing](#contributing)
- [Keeping the Changelog up to date](#keeping-the-changelog-up-to-date)


## Overview

The **Marketing Automation Form Injection Service** (`we-marketing-automation-form-injection`) is a robust .NET 8.0 application designed to handle the complete lifecycle of marketing form submissions. From dynamic form retrieval to lead processing and email preference management, this service provides a flexible foundation for Marketing Automation workflows.

### What Problems Does It Solve?

- **Centralized Form Management**: Single source of truth for marketing forms across all brands
- **Lead Quality**: Comprehensive validation ensures high-quality lead data
- **Performance**: Caching and optimization for high-traffic marketing campaigns
- **Security**: Rate limiting, authentication, and input validation protect against abuse
- **Flexibility**: Configurable workflows to meet diverse stakeholder requirements

## Features

### 🎯 Core Capabilities

- **Dynamic Form Serving**: JavaScript forms delivered based on form codes and locale preferences
- **Lead Processing**: Advanced validation, deduplication, and routing logic
- **Demo Scheduling**: Enterprise demo reservation workflow management
- **Email Preferences**: Granular subscription and preference management by segment and brand
- **Multi-language**: Built-in i18n/l10n support for global campaigns

### 🚀 Technical Features

- **High Performance**: Redis/Valkey caching with configurable TTLs
- **Cloud Native**: Full AWS integration (DynamoDB, S3, OpenSearch)
- **Observability**: DataDog APM, distributed tracing, and structured logging
- **Resilience**: Rate limiting, circuit breakers, and graceful degradation
- **Security**: JWT authentication, honeypot detection, IP filtering

## Architecture

### Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Runtime** | .NET 8.0 | Core framework and performance |
| **Web Framework** | Carter | Minimal API routing and handlers |
| **Validation** | FluentValidation | Input validation and business rules |
| **Cloud Services** | AWS SDK | DynamoDB, S3, IAM integration |
| **Search/Logging** | OpenSearch | Centralized logging and analytics |
| **Cache** | Redis/Valkey | Session management and response caching |
| **Monitoring** | DataDog | APM, metrics, and distributed tracing |

### Project Structure

```
we-marketing-automation-form-injection/
├── src/
│   ├── HomeModule.cs              # Main API endpoints
│   ├── Models/                    # Domain models
│   │   ├── Lead.cs
│   │   ├── FormConfig.cs
│   │   └── EmailPreference.cs
│   ├── Clients/                   # External service clients
│   │   ├── DynamoDbClient.cs
│   │   ├── OpenSearchClient.cs
│   │   └── ValkeyClient.cs
│   ├── Validators/                # Input validation
│   ├── Middleware/                # Request pipeline
│   └── Extensions/                # Utility extensions
├── test/                          # Unit and integration tests
├── infra/
│   ├── tf/                        # Terraform IaC
│   └── helm/                      # Kubernetes Helm charts
└── docs/                          # Additional documentation
```

### System Architecture

```
┌─────────────┐
│   Client    │
│  (Browser)  │
└──────┬──────┘
       │ HTTPS
       ▼
┌─────────────────────────────────┐
│  Form Injection Service (BFF)   │
│  - Rate Limiting                │
│  - Authentication               │
│  - Validation                   │
└────┬────────┬────────┬──────────┘
     │        │        │
     ▼        ▼        ▼
┌─────────┐ ┌────────┐ ┌──────────┐
│DynamoDB │ │   S3   │ │OpenSearch│
│(Config) │ │(Assets)│ │ (Logs)   │
└─────────┘ └────────┘ └──────────┘
```

## Getting Started

### Prerequisites

Before you begin, ensure you have:

- [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) or later
- [Visual Studio Code](https://code.visualstudio.com/) with C# extension (recommended)
- [AWS CLI](https://aws.amazon.com/cli/) configured with CoStar credentials
- Access to CoStar AWS environment (dev, test, or prod)
- Git for version control

### Quick Start

1. **Clone and Navigate**
   ```bash
   git clone https://github.com/costar/we-marketing-automation-form-injection.git
   cd we-marketing-automation-form-injection
   ```

2. **Restore Dependencies**
   ```bash
   dotnet restore src/we-marketing-automation-form-injection.csproj
   ```

3. **Configure Local Settings**
   ```bash
   cp src/appsettings.json src/appsettings.local.json
   # Edit appsettings.local.json with your local configuration
   ```

4. **Build and Run**
   ```bash
   dotnet run --project src/we-marketing-automation-form-injection.csproj
   ```

5. **Verify Installation**
   Open your browser to `http://localhost:5000/script-test` to see the test page.

### VS Code Configuration

Create the following files in `.vscode/` directory:

**`.vscode/launch.json`**
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Launch Form Injection Service",
            "type": "coreclr",
            "request": "launch",
            "program": "${workspaceFolder}/src/bin/Debug/net8.0/WeMarketingAutomationFormInjection.dll",
            "args": [],
            "cwd": "${workspaceFolder}/src",
            "stopAtEntry": false,
            "console": "internalConsole",
            "env": {
                "ASPNETCORE_ENVIRONMENT": "local"
            },
            "preLaunchTask": "build"
        }
    ]
}
```

**`.vscode/tasks.json`**
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "build",
            "command": "dotnet",
            "type": "process",
            "args": [
                "build",
                "${workspaceFolder}/src/we-marketing-automation-form-injection.csproj",
                "/property:GenerateFullPaths=true",
                "/consoleloggerparameters:NoSummary;ForceNoAlign"
            ],
            "problemMatcher": "$msCompile"
        },
        {
            "label": "test",
            "command": "dotnet",
            "type": "process",
            "args": [
                "test",
                "${workspaceFolder}/test/Test.csproj"
            ],
            "problemMatcher": "$msCompile",
            "group": {
                "kind": "test",
                "isDefault": true
            }
        }
    ]
}
```

Press **F5** to start debugging!

## API Reference

### Form Management

#### Get Form Script
```http
GET /api/v1/script/{formcd}?locale={locale}
```
Retrieves the JavaScript form bundle for the specified form code and locale.

**Parameters:**
- `formcd` (path, required): Form code identifier
- `locale` (query, optional): Language/region code (e.g., `en-US`, `fr-CA`)

**Response:** JavaScript file with form rendering logic

#### Submit Lead Form
```http
POST /api/v1/script/{formcd}
Content-Type: application/json
```
Processes a lead submission for the specified form.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "phone": "+1-555-0123",
  "company": "Acme Corp",
  "additionalData": {
    "interest": "commercial-real-estate"
  }
}
```

**Response:** 
- `200 OK`: Lead successfully processed
- `400 Bad Request`: Validation errors
- `429 Too Many Requests`: Rate limit exceeded

### Demo Booking

#### Submit Demo Request
```http
POST /api/v1/demo/{formcd}
Content-Type: application/json
```
Creates a demo reservation request.

**Request Body:**
```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane.smith@enterprise.com",
  "company": "Enterprise Inc",
  "preferredDate": "2024-02-15T14:00:00Z",
  "participants": 5
}
```

### Email Preferences

#### Update Preferences
```http
POST /api/v1/emailpreference
Content-Type: application/json
```
Updates email marketing preferences for a contact.

#### Get All Preferences
```http
GET /api/v1/emailpreferences/{emailaddress}
```
Retrieves all email preferences for an email address.

#### Get Segment Preferences
```http
GET /api/v1/emailpreference/{emailaddress}/{segmentid}
```
Retrieves preferences for a specific segment.

#### Get Brand Preferences
```http
GET /api/v1/emailpreferences/{emailaddress}/{brandid}
```
Retrieves preferences for a specific brand.

### Static Resources

#### CSS Stylesheets
```http
GET /api/v1/css/{filename}
```

#### JavaScript Files
```http
GET /api/v1/js/{filename}
```

## Configuration

### Environment-Specific Settings

The service uses hierarchical configuration with environment-specific overrides:

```
appsettings.json              # Base configuration
appsettings.local.json        # Local development (gitignored)
appsettings.dev.main.json     # Development environment
appsettings.tst.main.json     # Testing environment
appsettings.tst.rele.json     # Release testing
appsettings.prd.json          # Production environment
```

## Development

### Building the Project

```bash
# Debug build
dotnet build src/we-marketing-automation-form-injection.csproj

# Release build
dotnet build src/we-marketing-automation-form-injection.csproj -c Release

# Clean build artifacts
dotnet clean
```

### Running Locally

```bash
# Run with default profile
dotnet run --project src/we-marketing-automation-form-injection.csproj

# Run with specific environment
ASPNETCORE_ENVIRONMENT=dev.main dotnet run --project src/

# Watch mode (auto-restart on changes)
dotnet watch --project src/we-marketing-automation-form-injection.csproj
```

### Code Style and Standards

- **C# Conventions**: Follow [Microsoft's C# Coding Conventions](https://docs.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions)
- **Async/Await**: Use async patterns for all I/O operations
- **Null Safety**: Enable nullable reference types
- **Dependency Injection**: Constructor injection preferred
- **Minimal APIs**: Use Carter for routing and endpoint definitions

## Testing

### Running Tests

```bash
# Run all tests
dotnet test test/Test.csproj

# Run with coverage
dotnet test test/Test.csproj /p:CollectCoverage=true

# Run specific test category
dotnet test test/Test.csproj --filter Category=Integration

# Watch mode
dotnet watch test --project test/Test.csproj
```

### Test Structure

```
test/
├── EmailPreferenceTests.cs           # Email preference management and validation
├── EmailTests.cs                     # Email address validation and formatting
├── KeyProviderTests.cs               # JWT key provider and authentication tests
├── LeadIngestionValidatorTests.cs    # Lead submission validation rules
├── LocaleCdTests.cs                  # Locale code validation and formatting
├── OpenSearchTests.cs                # OpenSearch client and logging tests
├── PhoneTests.cs                     # Phone number validation and formatting
├── PostalFormatMustValidateTests.cs  # Postal code format validation
├── PostalMustValidateTests.cs        # Postal code validation rules
├── UtilsTests.cs                     # Utility function and extension tests
└── Test.csproj                       # Test project file
```

## Deployment

### Environments

| Environment | Purpose | URL |
|-------------|---------|-----|
| **local** | Local development | `http://localhost:5000` |
| **dev.main** | Development testing | `https://ma-platform-services-use1.dvm.enterprise.aws.dshrp.com/we-marketing-automation-form-injection` |
| **tst.main** | QA testing | `https://ma-platform-services-use1.tsm.enterprise.aws.dshrp.com/we-marketing-automation-form-injection` |
| **tst.rele** | Release candidate | `https://ma-platform-services-use1.tsr.enterprise.aws.dshrp.com/we-marketing-automation-form-injection` |
| **prd** | Production Internal | `https://ma-platform-services-use1.prd.enterprise.aws.dshrp.com/we-marketing-automation-form-injection` |
| **prd** | Production Public-facing | `https://ma-platform-services.costar.com/we-marketing-automation-form-injection` |


### Infrastructure as Code

```
infra/
├── tf/                        # Terraform configurations
│   ├── main.tf               # Primary resources
│   ├── variables.tf          # Input variables
│   ├── outputs.tf            # Output values
│   └── environments/
│       ├── dev/
│       ├── test/
│       └── prod/
└── helm/                      # Kubernetes Helm charts
    ├── Chart.yaml
    ├── values.yaml           # Default values
    └── templates/
        ├── deployment.yaml
        ├── service.yaml
        └── ingress.yaml
```

## Security

### Security Features

✅ **Rate Limiting**: Prevents abuse and DDoS attacks  
✅ **JWT Authentication**: Secure API access with token validation  
✅ **Input Validation**: Comprehensive FluentValidation rules  
✅ **Honeypot Protection**: Bot detection and blocking  
✅ **IP Filtering**: Source IP validation and allowlisting  
✅ **CORS Policy**: Strict origin checking  
✅ **Content Security Policy**: XSS protection  
✅ **HTTPS Only**: TLS 1.2+ required  

### Authentication

API endpoints require JWT authentication. Include token in request header:

```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

See [Marketing & Sales Endpoint Documentation](https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint) for obtaining credentials.

## Contributing

We welcome contributions! Please follow these guidelines:

### Workflow

1. **Create Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Changes**
   - Follow code style conventions
   - Add/update tests
   - Update documentation

3. **Commit Changes**
   ```bash
   git commit -m "feat: add new validation rule for email domains"
   ```
   Use [Conventional Commits](https://www.conventionalcommits.org/) format

4. **Push and Create PR**
   ```bash
   git push origin feature/your-feature-name
   ```
   Create pull request using the provided template

### Code Review Process

- All PRs require at least one approval
- Code coverage must not decrease
- Documentation must be updated

## Support

### Resources

- 📖 [Form Injector Wiki](https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209027178/Form+Injector)
- 📖 [Marketing & Sales Endpoint Docs](https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint)

### Contact

- **Marketing Automation Team**: TEAM JE (jerdelyi@costar.com)

## License

Copyright © 2025 CoStar Group. All rights reserved.

This is proprietary software. Unauthorized copying, modification, distribution, or use of this software is strictly prohibited.


## Keeping the Changelog up to date
 - I run `git log --date=short --pretty=format:"%h - %ad : %s" --since="14 months ago" > gitlog` - pick your timeframe
 - Using Claude 4.5 (as of this writing) i include `gitlog` in the context
 - Then i use the following instructions : 
 ```
#file:gitlog 
update the Changelog using the gitlog file. entries should be in descending date order and date format should follw iso8601 format of yyyy-MM-dd
be sure to include attribution. format with first name initial last name. example: full name of "janos erdelyi" should be formatted as "jerdelyi"
do not edit existing entries. add new entries starting on line 3
 ```