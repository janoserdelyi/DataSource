# ChangeLog

## 2025-12-03 - jerdelyi

### Changed
- Removed overly-restrictive IP filter on endpoints
- Removed company name from privacy payload
- Refactored vault keys for better security management

### Added
- Error logging for booking requests

## 2025-12-02 - jerdelyi

### Fixed
- Added privacy.costar.com to CORS allowed origins

### Changed
- Cleaned up and reworked how vault key values are delivered
- Re-ordered and re-labeled privacy payload description
- Enhanced caching mechanisms and cleanup

## 2025-12-01 - jerdelyi

### Added
- Script-side support for contact/GA-session save

### Changed
- Some more caching and cleanup

### Fixed
- Various typo fixes

## 2025-11-25 - jerdelyi

### Added
- More response payload data for debugging

### Fixed
- Encryption misnomer correction

## 2025-11-21 - jerdelyi

### Added
- Encrypt/decrypt unit tests and public POST endpoint
- Additional OpenSearch methods to save contactId and GA session ID

### Fixed
- OpenSearch query bug fix

## 2025-11-20 - jnewcomer

### Added
- Encryption-key vault secret

## 2025-11-18 - jerdelyi

### Added
- More unit tests on email preferences

### Changed
- Removed not-needed SourceType property on booking payload

## 2025-11-12 - jerdelyi

### Added
- New endpoint for debugging purposes
- More error messaging on S3 retrieval

### Changed
- Changed serializer for case payload

## 2025-11-11 - jerdelyi

### Added
- Privacy rights tests

## 2025-10-21 - jerdelyi

### Changed
- Refactored and tested privacy form handling
- Carved out special case for Homes page

## 2025-10-15 - jerdelyi

### Changed
- Refactored locale conveyance through codebase

## 2025-10-13 - jerdelyi

### Added
- Groundwork for bundled/split consent
- More tests

### Changed
- CampaignId handling for Homes misprint scenario
- Short-circuit for UNK country code in certain situations

## 2025-10-09 - jerdelyi

### Added
- Postal code format validator with additional tests

## 2025-10-06 - jerdelyi

### Added
- CompanyType to reservation request payload for book-a-demo
- Case management functionality with tests

### Changed
- Script changes for demo forms to not override hard-coded campaign IDs

## 2025-09-25 - jerdelyi

### Added
- Stubbed in case submissions
- zh-CN locale support

## 2025-09-17 - jerdelyi

### Fixed
- Minor button event bug

## 2025-09-16 - jerdelyi

### Added
- HTTPS testing for local environment only

## 2025-09-15 - jerdelyi

### Added
- CampaignId to book-a-demo reservation request

## 2025-09-10 - jerdelyi

### Added
- New validator for country codes
- New translation value

## 2025-09-05 - jerdelyi

### Added
- Dynamic booking reservation cache duration
- More logging throughout application

## 2025-09-04 - jerdelyi

### Changed
- Retired DynamoDB-based logging in favor of OpenSearch

### Fixed
- Unfortunate refactoring accident correction

## 2025-09-03 - jerdelyi

### Added
- More properties to demo orchestrator contract
- More comprehensive unit tests

## 2025-09-02 - jerdelyi

### Added
- Interfaces for two core services

## 2025-08-29 - jerdelyi

### Changed
- Request logging from DynamoDB to OpenSearch
- Some refactoring work

### Fixed
- Double reference issue

## 2025-08-26 - jerdelyi

### Added
- Kill switch for booking demo process

## 2025-08-25 - jerdelyi

### Added
- Global form handling overrides
- Failed swagger/OpenAPI attempt (experimental)

## 2025-08-23 - jerdelyi

### Fixed
- Test bug fixes
- Malformed connection string

## 2025-08-22 - jerdelyi

### Added
- PostgreSQL connection support

### Changed
- Updated appsettings
- Removed DataDog logging in DVM environment

## 2025-08-20 - jerdelyi

### Added
- More cache duration to demo forms

### Changed
- Tightened field constraints

## 2025-08-19 - jerdelyi

### Changed
- Converted reservation request additional data to custom serializer

## 2025-08-18 - jerdelyi / nsura

### Added
- Homes TSR domain to CORS

### Changed
- Ensured productLineCode goes to additionalData for booking orchestrator

## 2025-08-14 - jerdelyi

### Added
- Postal code downloader

### Changed
- Skipped country load on unknown ISO2 code
- Removed unused code

## 2025-08-13 - jerdelyi

### Added
- Auth for booking endpoint (DOSP-64315 Vault annotations for book-demo creds)

### Fixed
- Overzealous CSS selector bug

## 2025-08-12 - nsura

### Added
- Vault annotations for book-demo credentials

## 2025-08-07 - jerdelyi

### Added
- Submission and error custom hooks
- localhost:5001 to CORS for DVM

## 2025-08-05 - jerdelyi

### Changed
- Enhanced README
- Split out preferences saving for demo requests

## 2025-08-01 - jerdelyi

### Added
- OpenSearch request logging
- Honeypot input auto-addition if missing

### Changed
- SourceType value for demo submission
- Added additionalData to reservation request
- Convert SourceUrl to SourceArea for book-a-demo

### Fixed
- TSM/tst.main references corrected
- Various bug fixes

## 2025-07-31 - jerdelyi

### Added
- IpAddress and UserAgent to booking orchestrator

## 2025-07-30 - jerdelyi

### Added
- Caching for duplicate demo schedule requests

## 2025-07-29 - jerdelyi

### Added
- New domain to TSM CORS
- Valkey to health checks

## 2025-07-28 - jerdelyi

### Changed
- Making implicit empty checks explicit values

## 2025-07-25 - dedwards

### Changed
- Reverted batch upload CORS changes
- Added CORS for batch upload tool (Contact Staging and Feedback #2624332)

## 2025-07-25 - jerdelyi

### Added
- Full-flow demo form
- Initial demo request support

### Changed
- Not reducing content in local and DVM environments

## 2025-07-24 - jerdelyi

### Added
- Some initial demo request support

## 2025-07-22 - jerdelyi

### Changed
- Reduced DataDog logging verbosity

## 2025-07-21 - jerdelyi

### Added
- New Homes TSM URL to CORS
- Pick up more utm_* values

## 2025-07-18 - jerdelyi

### Added
- More language-based TLD for LoopNet CORS

## 2025-07-17 - jerdelyi

### Added
- Production Valkey endpoint URL

## 2025-07-08 - jerdelyi

### Changed
- Improved template cache mechanism

## 2025-07-07 - jerdelyi

### Fixed
- Spacing issues with compression
- Ugly changes for specific Ten-X situation

## 2025-07-02 - jerdelyi

### Added
- More Ten-X CORS
- Valkey client and Ten-X CORS

### Changed
- More error-handling on Valkey

## 2025-07-01 - jerdelyi

### Added
- Origin header checking
- Request headers logging
- CoStar PRD 'test' hostnames (prevent submissions)

## 2025-06-30 - jerdelyi

### Changed
- Converting regex's to compiled

## 2025-06-27 - jerdelyi

### Added
- More logging throughout for debugging

### Changed
- Removed string localizer
- Cleaned out unnecessary debugging

### Fixed
- Isolated performance issues to translationClient

## 2025-06-26 - jerdelyi

### Added
- More timers for performance checking

## 2025-06-25 - jerdelyi

### Fixed
- Double-quote problem

## 2025-06-23 - jerdelyi

### Added
- New form type plus debugging

### Fixed
- TenX test harness cleanup
- Too much minifying
- Flipped file reducer types
- Local test causing problems elsewhere

## 2025-06-10 - jerdelyi

### Added
- Script to hide noscript banner

## 2025-06-09 - jerdelyi

### Changed
- Updated dependencies
- Pathbase tests
- Error handling for log insertion

## 2025-06-04 - jerdelyi

### Added
- New languages support
- Only adding DNS servers from active adapters

### Changed
- Translation client creates new lang directory if needed

## 2025-06-03 - jerdelyi

### Added
- Test endpoint for bad domains

### Changed
- Flipped OpenSearch URLs back to nice domains

### Fixed
- Case-insensitive postal code matches in OpenSearch

## 2025-06-02 - jerdelyi

### Changed
- Switched to internal DNS names for OpenSearch

## 2025-05-30 - jerdelyi

### Added
- More logging to expose in DataDog
- File reduction on returned form scripts

## 2025-05-29 - jerdelyi

### Added
- WE to CORS

## 2025-05-28 - jerdelyi

### Changed
- Minor style cleanup

## 2025-05-24 - jerdelyi

### Fixed
- Concurrency issues with collections

## 2025-05-22 - jerdelyi

### Added
- Headers to JavaScript resource 404 failures

### Fixed
- Bad endpoint definition

## 2025-05-20 - jerdelyi

### Changed
- Starting to deprecate marketingOptIn field

## 2025-05-16 - jerdelyi

### Added
- Extended response message processing from create-lead endpoint

## 2025-05-14 - jerdelyi

### Fixed
- Overly broad cache key

## 2025-05-12 - jerdelyi

### Added
- Dynamo TTL field for logging

### Fixed
- Removed quotes from type
- Fixed namespace

## 2025-05-09 - jerdelyi

### Fixed
- Country translation test harness

## 2025-05-06 - jerdelyi

### Added
- Mechanism to load country code lookups
- Endpoint to test country code 3-to-2 conversion
- Dynamo country code test
- Additional method for passing 2-char country code to validator
- Unit test on phone validation

### Changed
- More form submission logging

## 2025-05-02 - jerdelyi

### Changed
- Added nuance to email validation bypass
- Country code requirement to email prefs endpoint

## 2025-04-30 - jerdelyi

### Added
- Bypass to skip email validation for emailpreference endpoint

## 2025-04-29 - jerdelyi

### Added
- Current time and uptime to diagnostics
- Retry to email preference endpoint
- Retry to create-lead endpoint
- CORS to diagnostics

### Changed
- More error messaging
- More thread safety on collections

## 2025-04-28 - jerdelyi

### Changed
- More error messaging

## 2025-04-25 - jerdelyi

### Changed
- Temporarily removed caching mechanism for S3 requests

### Fixed
- Concurrency issue addressed

## 2025-04-22 - jerdelyi

### Added
- More diagnostics for template cache

## 2025-03-17 - jerdelyi

### Changed
- Minor style improvements on structural messaging
- Added LoopNet TSM domain to CORS

## 2025-03-03 - jerdelyi

### Fixed
- Bug fix in dependency

## 2025-02-26 - jerdelyi

### Added
- LoopNet TSM domain to CORS

## 2025-02-13 - jerdelyi

### Added
- CoStar dev env to TSM CORS allowance

## 2025-01-14 - jerdelyi

### Added
- More testing and unit tests

## 2025-01-02 - jerdelyi

### Added
- Unit tests for various components

## 2024-12-31 - jerdelyi

### Added
- Localized full form injection

## 2024-12-26 - jerdelyi

### Added
- JWT middleware for authentication

## 2024-12-19 - jerdelyi

### Fixed
- MxConfig caching issue

## 2024-12-18 - jerdelyi

### Added
- Clean implementation of full form injection

### Changed
- Updated internals of test email check

## 2024-12-10 - jerdelyi

### Changed
- Working on full injection
- Better request log filtering

## 2024-12-04 - jerdelyi

### Added
- Content-type to S3 push through management API
- Management route to get S3 resources
- SessionStorage for utm_campaign_id persistence
- Administrative interface to delete record from domainStatus

## 2024-12-03 - jerdelyi

### Changed
- Switched OpenSearch query to match_phrase
- Only use IP filter on publicly-accessible production

## 2024-11-25 - jerdelyi

### Changed
- Switched resources to use different endpoint
- Changed some resource calls to also look in S3

## 2024-11-22 - jerdelyi

### Added
- Elastic query test

## 2024-11-21 - jerdelyi

### Changed
- Removed non-key attributes from new projection
- Changed request log projection type to all

## 2024-11-20 - jerdelyi

### Added
- Secondary index to formrequestlog
- Some management APIs and configurable index naming
- More logging and error handling

### Changed
- Changed OpenSearch URL for TSM
- Changed source IP address filter to only work in production
- Longer Helm timeout
- Added locale to request logging Dynamo
- Changed IP address headers and order

### Fixed
- Test brand designation
- Reverted OpenSearch URL

## 2024-11-19 - jerdelyi

### Added
- Some Dynamo management endpoints

## 2024-11-18 - jerdelyi

### Added
- Home IP address for testing

### Fixed
- Address parse issue
- Added Salesforce IPs

## 2024-11-15 - jerdelyi

### Fixed
- Merge conflict resolution

## 2024-11-14 - jerdelyi

### Added
- More CORS domains
- LoopNet PRD endpoint

### Changed
- More preference endpoint work
- Cleanup and code organization

## 2024-11-12 - jerdelyi

### Fixed
- Merge from release branch

## 2024-11-11 - jerdelyi

### Added
- DevOps bypass header
- Akamai header check
- More diagnostics

## 2024-11-08 - jerdelyi

### Added
- LoopNet TSM form

## 2024-11-07 - jerdelyi

### Added
- Logging and organizing test endpoints
- Securing public production endpoints

## 2024-11-06 - jerdelyi

### Changed
- Increased parameter options on test form

## 2024-11-05 - jerdelyi

### Added
- Rate limiter

## 2024-11-04 - jerdelyi

### Added
- Anti-bot field to email preference submission

### Changed
- Updated wiki references
- Removed IP restriction test
- Extended IP restriction test to form submit
- CORS-based IP address allow list

## 2024-10-31 - jerdelyi

### Added
- OpenSearch to health checks

## 2024-10-29 - jerdelyi

### Added
- BImmo dev CORS
- OpenSearch to diagnostics

### Changed
- OpenSearch endpoint update

### Fixed
- Trailing slash issue

## 2024-10-28 - jerdelyi

### Added
- OpenSearch integration

## 2024-10-25 - jerdelyi

### Added
- More form CSS work
- Email preference testing endpoint
- Show hidden form functionality
- OpenSearch URLs

## 2024-10-24 - jnewcomer

### Changed
- Updated System.Text.Json version

## 2024-10-24 - jerdelyi

### Added
- New test forms

### Changed
- Endpoint changes

## 2024-10-23 - jerdelyi

### Added
- Request headers and body to test
- Auth timer configuration

### Changed
- Hiding test endpoints from public PRD host
- More logging improvements

### Fixed
- Dumping headers for debugging

## 2024-10-22 - jerdelyi

### Changed
- More logging improvements
- Resetting security key
- More diagnostic error handling

## 2024-10-21 - jerdelyi

### Added
- Email preferences endpoint in place
- More diagnostic work

### Changed
- Default security key updated

### Fixed
- Public PRD endpoint

## 2024-10-18 - jerdelyi

### Changed
- Changed lead creation endpoint
- Changed production endpoints for lead creation
- Changed release branch trigger

### Fixed
- Comment cleanup

## 2024-10-17 - jerdelyi

### Added
- Real health checks
- CORS and new forms

### Changed
- Improved health output
- Changed PRD base URL to public

### Fixed
- TST main vs RELE parsing

## 2024-10-16 - jerdelyi

### Changed
- Removed not-needed Dynamo table
- Removed Dynamo postal lookup

### Fixed
- TSM/TSR mixup
- Explicit IAM S3 to bucket permissions reverted

## 2024-10-15 - jerdelyi

### Added
- Opt-in endpoint
- More diagnostics
- Mostly Pardot work

### Changed
- Minor changes to capture bad domains

## 2024-10-14 - jerdelyi

### Added
- Dynamo tables for postal and country data

### Changed
- Changing postalcountry Dynamo table structure

## 2024-10-13 - jerdelyi

### Added
- More translation work

## 2024-10-11 - jerdelyi

### Added
- i18n directory to build

### Changed
- Testing and shoring up translation issues
- Reworking location of localization in deployment
- Changed Unix permissions on directory create
- Added Windows OS preprocessor directive
- Migrated translation client to use resource JSON files

## 2024-10-10 - jerdelyi

### Added
- More CORS support
- Reading labels from forms
- New value override to inputs
- New DynamoDB table resource
- Initial BImmo forms

### Changed
- DynamoDB policy update
- Renamed columns
- Confine error message

### Fixed
- Multiple TF syntax errors

## 2024-10-09 - jerdelyi

### Added
- Bypass domain logging

## 2024-10-08 jerdelyi
### Added
- more than i recall. i haven't kept up with the changelog :(
- reading host machine network interfaces for DNS information for email validation
- implementing translation services. not as cohesive as i would like though

## 2024-10-07 - jerdelyi

### Added
- Dynamo table for domain status
- Capturing all MX record failures for translation
- DNS servers from host machine
- Cluster DNS to test harness
- Testing endpoints for MX and full email checks

### Changed
- Trimming values for firstname, lastname, companyname
- Using cluster DNS server
- Display when invalid form submit attempted
- Temporarily disabled extended email validation
- Reworking localizations
- Changed DNS servers
- Re-enabled full email check
- Updated endpoint settings

### Fixed
- Added translation client
- Something wrong with TSM translation service

## 2024-10-04 - jerdelyi

### Added
- Translation client
- Using placeholders for field name substitutions
- Loading campaign ID automatically

## 2024-08-06 jerdelyi

### Added
- stage 1 : eval of forms in lower environments
- stage 2 : hijack form submission and massage payload into proper format, submitting to our endpoint

### Changed 
- more than i recall. i forgot to update this file
- no longer targeting injecting the form as it is content. changing to two stage eval then submit

## 2024-07-10 jerdelyi

### Added
- Culture middleware to start extracting culture info to be able to feed proper forms based on form code and locale info
- Added new output type to give people a whitepaper, for example

### Changed
- Now using CSS selectors to determine where the form would inject for greater flexibility

## 2024-07-03 jerdelyi

### Added
- split out the Home module into 3 modules. one for basic diagnostic endpoints like `/ping` and `/health-check`
- split out the test harness endpoint to separate it away from the actual work 

### Changed
- JWT decryption functions were still returning data from a test scenario. they are now returning a proper `SecurityToken`

## 2024-07-01 jerdelyi

### Added
- .vscode/launch.json and .vscode/tasks.json but since they are .gitignore'd i added them to the README
- common extension methods on the environment used by most other C# projects. methods like `IsLocal()`, `IsDevelopment()`, etc

## 2024-06-28 jerdelyi

### Added 
- initial project setup
