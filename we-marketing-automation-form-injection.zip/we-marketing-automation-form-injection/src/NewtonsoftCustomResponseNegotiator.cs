using System.Collections.Specialized;
using System.Net;
using System.Threading;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection;

public class NewtonsoftCustomResponseNegotiator : IResponseNegotiator
{
	private readonly static JsonSerializerSettings jsonSettings;

	static NewtonsoftCustomResponseNegotiator () {
		var contractResolver = new DefaultContractResolver () {
			NamingStrategy = new CamelCaseNamingStrategy ()
		};

		jsonSettings = new JsonSerializerSettings () { ContractResolver = contractResolver, NullValueHandling = NullValueHandling.Ignore };
		jsonSettings.Converters.Add (new IPAddressConverter ());
		jsonSettings.Converters.Add (new IPEndpointConverter ());
		jsonSettings.Converters.Add (new NameValueCollectionConverter ());
		jsonSettings.Converters.Add (new NameValueCollectionKeyValueConverter ());
	}

	public NewtonsoftCustomResponseNegotiator () {

	}

	public static JsonSerializerSettings Serializer {
		get { return jsonSettings; }
	}

	public bool CanHandle (
		MediaTypeHeaderValue accept
	) {
		return accept.MediaType.ToString ().IndexOf ("json", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	public Task Handle<T> (
		HttpRequest req,
		HttpResponse res,
		T model,
		CancellationToken cancellationToken
	) {
		res.ContentType = "application/json; charset=utf-8";
		return res.WriteAsync (JsonConvert.SerializeObject (model, jsonSettings), cancellationToken);
	}
}

public class IPAddressConverter : JsonConverter
{
	public override bool CanConvert (
		Type objectType
	) {
		return objectType == typeof (IPAddress);
	}

	public override void WriteJson (JsonWriter writer, object? value, JsonSerializer serializer) {
		writer.WriteValue (value?.ToString ());
	}

	public override object? ReadJson (JsonReader reader, Type objectType, object? existingValue, JsonSerializer serializer) {
		if (reader.Value == null) {
			return null;
		}
		return IPAddress.Parse ((string)reader.Value);
	}
}

public class IPEndpointConverter : JsonConverter
{
	public override bool CanConvert (
		Type objectType
	) {
		return objectType == typeof (IPEndPoint);
	}

	public override void WriteJson (JsonWriter writer, object? value, JsonSerializer serializer) {
		if (value == null) {
			writer.WriteNull ();
			return;
		}

		IPEndPoint ep = (IPEndPoint)value;
		JObject jo = new JObject {
			{ "Address", JToken.FromObject(ep.Address, serializer) },
			{ "Port", ep.Port }
		};

		jo.WriteTo (writer);
	}

	public override object? ReadJson (JsonReader reader, Type objectType, object? existingValue, JsonSerializer serializer) {
		if (reader.Value == null) {
			return null;
		}

		JObject jo = JObject.Load (reader);

		if (jo == null) {
			return null;
		}

		if (jo.ContainsKey ("Address") == false) {
			return null;
		}
		if (jo.ContainsKey ("Port") == false) {
			return null;
		}

		IPAddress address = jo["Address"]!.ToObject<IPAddress> (serializer)!;
		int port = (int)jo["Port"]!;

		return new IPEndPoint (address, port);
	}
}

public class NameValueCollectionConverter : JsonConverter<NameValueCollection>
{
	public override void WriteJson (
		JsonWriter writer,
		NameValueCollection? value,
		JsonSerializer serializer
	) {
		if (value == null) {
			writer.WriteNull ();
			return;
		}

		var keyname = "name";

		writer.WriteStartArray ();
		foreach (string key in value.Keys) {
			if (key != null) {
				writer.WriteStartObject ();
				writer.WritePropertyName (keyname);
				writer.WriteValue (key);
				writer.WritePropertyName ("value");
				writer.WriteValue (value[key]);
				writer.WriteEndObject ();
			}
		}
		writer.WriteEndArray ();
	}

	public override NameValueCollection? ReadJson (
		JsonReader reader,
		Type objectType,
		NameValueCollection? existingValue,
		bool hasExistingValue,
		JsonSerializer serializer
	) {
		// use the default deserializer
		return serializer.Deserialize<NameValueCollection> (reader);
	}
}

public class NameValueCollectionKeyValueConverter : JsonConverter<NameValueCollectionKeyValue>
{
	public override void WriteJson (
		JsonWriter writer,
		NameValueCollectionKeyValue? value,
		JsonSerializer serializer
	) {
		if (value == null) {
			writer.WriteNull ();
			return;
		}

		var keyname = "key";

		writer.WriteStartArray ();
		foreach (string key in value.Keys) {
			if (key != null) {
				writer.WriteStartObject ();
				writer.WritePropertyName (keyname);
				writer.WriteValue (key);
				writer.WritePropertyName ("value");
				writer.WriteValue (value[key]);
				writer.WriteEndObject ();
			}
		}
		writer.WriteEndArray ();
	}

	public override NameValueCollectionKeyValue? ReadJson (
		JsonReader reader,
		Type objectType,
		NameValueCollectionKeyValue? existingValue,
		bool hasExistingValue,
		JsonSerializer serializer
	) {
		// use the default deserializer
		return serializer.Deserialize<NameValueCollectionKeyValue> (reader);
	}
}

// some efforts for serializing the NameValueCollection want name/value pairs, others want key/value
// creating this to let me control that
public class NameValueCollectionKeyValue : NameValueCollection
{

}