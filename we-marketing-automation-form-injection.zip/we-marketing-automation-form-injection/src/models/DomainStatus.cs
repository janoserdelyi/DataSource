
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace WeMarketingAutomationFormInjection.Models;

public class DomainStatus
{
	public DomainStatus () {

	}

	[DynamoDBHashKey ("domain")]
	public required string Domain { get; set; }

	[DynamoDBRangeKey ("statuscd")]
	public required string StatusCd { get; set; }

	[DynamoDBProperty ("statusdt")]
	public required long StatusDt { get; set; } // unix epoch number for better selection/sort

	[DynamoDBProperty ("timestamp")]
	public required string Timestamp { get; set; } // iso 8601 timstamp for better reading, processing

}