
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class FormLogRecord
{
	public FormLogRecord () {

	}

	public required string FormCd { get; set; }
	public required long RequestDt { get; set; } // unix epoch number (milliseconds) for better selection/sort
	public required string Timestamp { get; set; } // ISO date format including time zone info for easier human consumption
	public required string SourceIp { get; set; }
	public required string UserAgent { get; set; }
	public required string Method { get; set; }
	public required string Protocol { get; set; }
	public required string Host { get; set; }
	public required string Path { get; set; }
	public required string Querystring { get; set; }
	public required string Headers { get; set; }
	public required string Body { get; set; }
	public required string Locale { get; set; }
	public bool? RequestSucceeded { get; set; }
	public List<string>? RequestErrors { get; set; }
	public long? TtlMeasure { get; set; }
	public required string Id { get; set; }

	public static FormLogRecord BuildLog (
		HttpContext ctx,
		string formcd,
		string locale
	) {
		string? body = null;
		ctx.Request.Body.Position = 0;
		using (var reader = new StreamReader (ctx.Request.Body, encoding: System.Text.Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true)) {
			body = reader.ReadToEndAsync ().Result;
		}
		ctx.Request.Body.Position = 0;

		var now = DateTimeOffset.Now;
		var headerstring = string.Empty;
		foreach (var key in ctx.Request.Headers.Keys) {
			headerstring += $"{key}={ctx.Request.Headers[key]}, ";
		}
		// var headerlist = new List<string> ();
		// foreach (var header in ctx.Request.Headers) {
		// 	headerlist.Add ($"{header.Key}={header.Value}");
		// }

		var record = new FormLogRecord () {
			RequestDt = now.ToUnixTimeMilliseconds (),
			Timestamp = now.ToString ("yyyy-MM-dd HH:mm:ss:fff zzz"),
			FormCd = formcd,
			SourceIp = ctx.SessionStorage ().SourceIp!.ToString (),
			UserAgent = ctx.SessionStorage ().UserAgent!,
			Method = ctx.Request.Method,
			Protocol = ctx.Request.Protocol,
			Host = ctx.Request.Host.Value,
			Path = ctx.Request.Path.Value ?? "",
			Querystring = ctx.Request.QueryString.HasValue ? ctx.Request.QueryString.Value : "",
			Headers = headerstring,
			Body = body,
			Locale = locale,
			TtlMeasure = now.ToUnixTimeSeconds (),
			Id = $"{formcd}-{locale}-{now.ToUnixTimeMilliseconds ()}"
		};

		return record;
	}
}