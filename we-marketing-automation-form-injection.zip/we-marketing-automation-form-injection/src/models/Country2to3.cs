
namespace WeMarketingAutomationFormInjection.Models;

//[DynamoDBTable ("we-marketing-automation-form-injection-api-country2to3-dvm")]
public class Country2to3
{

	public Country2to3 () {

	}

	[DynamoDBHashKey ("two")]
	public required string Two { get; set; }

	[DynamoDBProperty ("three")]
	public required string Three { get; set; }

	[DynamoDBProperty ("name")]
	public required string Name { get; set; }

}