
namespace WeMarketingAutomationFormInjection.Models;

// this maps to the "DynamoTables" section in appsettings
public interface IDynamoTables
{
	string Form { get; set; }
	string RequestLog { get; set; }
	string PostalCountry { get; set; }
	string Country3to2 { get; set; }
	string Country2to3 { get; set; }
	string DomainStatus { get; set; }
}

public class DynamoTables : IDynamoTables
{
	public DynamoTables (
		string form,
		string requestLog,
		string postalCountry,
		string country3to2,
		string country2to3,
		string domainStatus
	) {
		Form = form;
		RequestLog = requestLog;
		PostalCountry = postalCountry;
		Country3to2 = country3to2;
		Country2to3 = country2to3;
		DomainStatus = domainStatus;
	}

	public required string Form { get; set; }
	public required string RequestLog { get; set; }
	public required string PostalCountry { get; set; }
	public required string Country3to2 { get; set; }
	public required string Country2to3 { get; set; }
	public required string DomainStatus { get; set; }
}