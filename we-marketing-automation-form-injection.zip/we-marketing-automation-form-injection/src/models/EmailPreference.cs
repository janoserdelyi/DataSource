
// https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028505/Email+Preferences+Endpoint

using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

// NOTE: this is the model for submitting Email Preferences, *not* the the elastic model
public class EmailPreference
{
	// included so that if bots fill out every field we know this is a bogus request
	[JsonProperty ("additionalValues")]
	[JsonPropertyName ("additionalValues")]
	public string? NeverFill { get; set; }

	[JsonProperty ("firstName")]
	public string? FirstName { get; set; }

	[JsonProperty ("lastName")]
	public string? LastName { get; set; }

	[JsonProperty ("phone")]
	[JsonPropertyName ("phone")]
	public string? PhoneNumber { get; set; }

	[JsonProperty ("activitySource")]
	public string? ActivitySource { get; set; }

	[JsonProperty ("requestedBy")]
	public string? RequestedBy { get; set; }

	[JsonProperty ("emailAddress")]
	public string? EmailAddress { get; set; }

	[JsonProperty ("countryCode")]
	[JsonPropertyName ("countryCode")]
	public string? CountryCode { get; set; }

	[JsonProperty ("contactId")]
	public int? ContactId { get; set; }

	[JsonProperty ("brand")]
	[JsonPropertyName ("brand")]
	public IList<string>? Brand { get; set; }

	[JsonProperty ("globalOptIn")]
	[JsonPropertyName ("globalOptIn")]
	public bool? GlobalOptIn { get; set; }

	[JsonProperty ("marketingOptIn")]
	[JsonPropertyName ("marketingOptIn")]
	public bool? BrandLevelMarketingOptIn { get; set; }

	[JsonProperty ("optIntoSegments")]
	public IList<MarketingBrandSegmentPreference>? OptIntoSegments { get; set; }

	[JsonProperty ("validateAddress")]
	public bool ValidateAddress { get; set; } = true;
}