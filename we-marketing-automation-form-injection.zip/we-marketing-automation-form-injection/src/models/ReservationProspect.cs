// reservation API-related
using System.Collections.Specialized;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ReservationProspect
{
	public required string FirstName { get; set; }
	public required string LastName { get; set; }
	public required string EmailAddress { get; set; }
	public required string PhoneNumber { get; set; }
	public required string CompanyName { get; set; }
	public required string CountryCode { get; set; }
	[JsonProperty ("zipCode")]
	public required string PostalCode { get; set; }
	public string? CompanyType { get; set; }
	public required string Locale { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ReservationCreationRequest
{
	public required ReservationProspect Prospect { get; set; }
	public required string TrackerId { get; set; }
	public required string SourceArea { get; set; }
	// public required string IpAddress { get; set; }
	// public required string UserAgent { get; set; }
	public required string LeadSource { get; set; } // ex: Homes
	public required string Brand { get; set; } // ex: Homes
	public required string RequestType { get; set; } // ex: Demo

	// add an additionalData array of name/value pairs
	// add ipaddress and useragent to this. simplify the model
	public NameValueCollection AdditionalData { get; set; } = [];
	public required string Locale { get; set; } // added to Prospect as well just incase it's asked for
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ReservationConfirmation
{
	public required string BookingId { get; set; }
	public required string ReservationLink { get; set; }
	public DateTimeOffset? ExpirationDate { get; set; }
	public int? Status { get; set; } // 1 = Success, 2 = InactiveSourceArea, 3 = OutOfService

}