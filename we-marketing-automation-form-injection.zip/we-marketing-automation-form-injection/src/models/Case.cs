using System.Collections.Specialized;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

// https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028538/Create+case+REST+endpoint
[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Case
{
	public int? CaseContactId { get; set; }
	public int? CaseWith { get; set; }
	public int? CompanyId { get; set; }
	public int? CreatedByContactId { get; set; } = 1449;
	public required string Description { get; set; }
	public int[]? FollowerContactIds { get; set; }
	public int? Priority { get; set; }
	public string? SourceReferenceKey { get; set; }
	public string? SourceType { get; set; }
	public string? Subject { get; set; }
	public DateTimeOffset? SubmitDate { get; set; }
	public int? Topic { get; set; }

	// there is a custom serializer on NameValueCollections to suit how JC's org accepts AdditionalData. the ReservationProspect being another example of this
	// 2025-11-11 JC requested key vs name so changing this
	public NameValueCollectionKeyValue AdditionalData { get; set; } = [];

	// 2025-10-27 more added since the advent of the privacy form
	public int? Status { get; set; }
	public string? Type { get; set; }
	public string? CaseSubject { get; set; }
	public int? LocationId { get; set; }
	public int? ContactId { get; set; }
	public int? AssignedToQueueId { get; set; }
	public int? SupportGroupId { get; set; }
	public int? CaseTypeCategoryId { get; set; }
	public int? CaseSourceAreaId { get; set; }
	public DateTimeOffset? ReportedDate { get; set; }

}