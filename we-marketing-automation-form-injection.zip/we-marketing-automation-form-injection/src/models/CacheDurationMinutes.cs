namespace WeMarketingAutomationFormInjection.Models;

public class CacheDurationMinutes
{
	public const string SectionName = "CacheDurationMinutes";
	public int StandardForm { get; set; } = 5;
	public int DemoForm { get; set; } = 60;
}