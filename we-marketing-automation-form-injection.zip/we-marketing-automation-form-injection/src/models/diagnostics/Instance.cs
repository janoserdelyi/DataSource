using System.Net;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace WeMarketingAutomationFormInjection.Models.Diagnostics;

public class Instance
{
	public Instance (
		DateTimeOffset startTime,
		IWebHostEnvironment env,
		HttpContext ctx,
		IAmazonS3 amazonS3,
		IConfiguration config
	) {
		WebHost = env;
		StartTime = startTime;
		Environment = new DiagnosticEnvironment (env, config);
		Request = new DiagnosticRequest (ctx);
		Culture = new DiagnosticCulture (ctx);
	}

	public DateTimeOffset StartTime { get; set; }
	public DateTimeOffset CurrentTime { get; private set; } = DateTimeOffset.Now;
	public TimeSpan Uptime {
		get {
			return CurrentTime - StartTime;
		}
	}
	public string? AwsRegion { get; set; }
	public IWebHostEnvironment WebHost { get; set; }

	public Machine Machine { get; set; } = new Machine ();
	public DiagnosticRequest Request { get; set; }
	public DiagnosticCulture Culture { get; set; }
	public DiagnosticEnvironment Environment { get; set; }
}

public class Machine
{
	public string MachineName { get; private set; } = System.Environment.MachineName;
	public int ProcessorCount { get; private set; } = System.Environment.ProcessorCount;
	public int SystemPageSize { get; private set; } = System.Environment.SystemPageSize;
	public long WorkingSet { get; private set; } = System.Environment.WorkingSet;
	public List<string> DnsServers { get; private set; } = Utils.GetMachineDns ();
}

public class DiagnosticRequest
{
	public DiagnosticRequest (
		HttpContext ctx
	) {
		Address = ctx.SessionStorage ().SourceIp;
		UserAgent = ctx.SessionStorage ().UserAgent;
		Hostname = ctx.Request.Host.Host;

		foreach (var header in ctx.Request.Headers) {
			Headers.Add (new DiagnosticRequestHeader (header.Key, header.Value));
		}

	}

	public IPAddress? Address { get; set; }
	public string? UserAgent { get; set; }
	public string? Hostname { get; set; }
	public List<DiagnosticRequestHeader> Headers { get; set; } = [];
}

public class DiagnosticRequestHeader
{
	public DiagnosticRequestHeader (
		string key,
		string? value
	) {
		Key = key;
		Value = value;
	}

	public string Key { get; set; }
	public string? Value { get; set; }
}

public class DiagnosticCulture
{
	public DiagnosticCulture (
		HttpContext ctx
	) {
		IetfLanguageTag = ctx.GetCurrentCulture ()?.IetfLanguageTag;
		ContextCulture = ctx.GetCurrentCulture ();
		AcceptLanguageHeader = (ctx.Request.Headers.ContainsKey ("Accept-Language") ? ctx.Request.Headers["Accept-Language"].ToString () : null);
		GetLocaleCode = Utils.GetLocaleCd (ctx);
	}

	public string? IetfLanguageTag { get; set; }
	public System.Globalization.CultureInfo? CurrentCulture { get; private set; } = System.Globalization.CultureInfo.CurrentCulture;
	public System.Globalization.CultureInfo? ThreadCulture { get; private set; } = System.Threading.Thread.CurrentThread.CurrentCulture;
	public System.Globalization.CultureInfo? ContextCulture { get; set; }
	public string? AcceptLanguageHeader { get; set; }
	public string? GetLocaleCode { get; set; }
}

public class DiagnosticEnvironment
{
	public DiagnosticEnvironment (
		IWebHostEnvironment env,
		IConfiguration config
	) {
		Name = env.SanitizedEnvironment ();
		IsProduction = env.IsProduction ();
		WebRootPath = env.WebRootPath;

		if (Directory.Exists ("/vault/secrets")) {
			var files = Directory.GetFiles ("/vault/secrets");
			if (files != null && files.Length > 0) {
				foreach (var file in files) {
					VaultSecretKeys.Add (file);
				}
			}
		}

		CorsDomains = config.GetSection ("CorsDomains").Get<List<string>> ();
	}

	public Version DotnetVersion { get; private set; } = System.Environment.Version;
	public string FrameworkDescription { get; private set; } = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
	public string OsDescription { get; private set; } = System.Runtime.InteropServices.RuntimeInformation.OSDescription;
	public string Name { get; set; }
	public bool IsProduction { get; set; }
	public string WebRootPath { get; set; }
	public List<string> VaultSecretKeys { get; set; } = [];
	public Dictionary<IPAddress, string>? AllowedIps { get; private set; } = Program.AllowedIps;
	public Dictionary<string, TemplateCache> TemplateCache { get; private set; } = Utils.GetTemplateCache ();
	public List<string>? CorsDomains { get; private set; }
}