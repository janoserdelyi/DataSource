
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace WeMarketingAutomationFormInjection.Models.DynamoDb;

public class FormRequestLog
{
	public FormRequestLog () {

	}

	[DynamoDBHashKey ("formcd")]
	public required string FormCd { get; set; }

	[DynamoDBRangeKey ("requestdt")]
	public required long RequestDt { get; set; } // unix epoch number (milliseconds) for better selection/sort

	[DynamoDBProperty ("timestamp")]
	public required string Timestamp { get; set; } // ISO date format including time zone info for easier human consumption

	[DynamoDBProperty ("sourceIp")]
	public required string SourceIp { get; set; }

	[DynamoDBProperty ("userAgent")]
	public required string UserAgent { get; set; }

	[DynamoDBProperty ("method")]
	public required string Method { get; set; }

	[DynamoDBProperty ("protocol")]
	public required string Protocol { get; set; }

	[DynamoDBProperty ("host")]
	public required string Host { get; set; }

	[DynamoDBProperty ("path")]
	public required string Path { get; set; }

	[DynamoDBProperty ("querystring")]
	public required string Querystring { get; set; }

	[DynamoDBProperty ("headers")]
	public required string Headers { get; set; }

	[DynamoDBProperty ("body")]
	public required string Body { get; set; }

	[DynamoDBProperty ("locale")]
	public required string Locale { get; set; }

	[DynamoDBProperty ("requestSucceeded")]
	public bool? RequestSucceeded { get; set; }

	[DynamoDBProperty ("requestErrors")]
	public List<string>? RequestErrors { get; set; }

	// https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/TTL.html
	// unfortunately i need a new column to implement TTL - it needs unix epoch at seconds granularity and RequestDt is milliseconds granularity
	[DynamoDBProperty ("ttlMeasure")]
	public long? TtlMeasure { get; set; }

	public static FormRequestLog BuildLog (
		HttpContext ctx,
		string formcd,
		string locale
	) {
		string? body = null;
		ctx.Request.Body.Position = 0;
		using (var reader = new StreamReader (ctx.Request.Body, encoding: System.Text.Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true)) {
			body = reader.ReadToEndAsync ().Result;
		}
		ctx.Request.Body.Position = 0;

		var now = DateTimeOffset.Now;
		var headerstring = string.Empty;
		foreach (var key in ctx.Request.Headers.Keys) {
			headerstring += $"{key}={ctx.Request.Headers[key]}, ";
		}
		// var headerlist = new List<string> ();
		// foreach (var header in ctx.Request.Headers) {
		// 	headerlist.Add ($"{header.Key}={header.Value}");
		// }

		var record = new FormRequestLog () {
			RequestDt = now.ToUnixTimeMilliseconds (),
			Timestamp = now.ToString ("yyyy-MM-dd HH:mm:ss:fff zzz"),
			FormCd = formcd,
			SourceIp = ctx.SessionStorage ().SourceIp!.ToString (),
			UserAgent = ctx.SessionStorage ().UserAgent!,
			Method = ctx.Request.Method,
			Protocol = ctx.Request.Protocol,
			Host = ctx.Request.Host.Value,
			Path = ctx.Request.Path.Value ?? "",
			Querystring = ctx.Request.QueryString.HasValue ? ctx.Request.QueryString.Value : "",
			Headers = headerstring,
			Body = body,
			Locale = locale,
			TtlMeasure = now.ToUnixTimeSeconds ()
		};

		return record;
	}
}