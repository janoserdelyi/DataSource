namespace WeMarketingAutomationFormInjection.Models;

public interface IConnectionStrings
{
	string PgMktSupport { get; set; }
	string MsMarketingSupport { get; set; }
}

public class ConnectionStrings : IConnectionStrings
{
	public ConnectionStrings (
		string pgMktSupport,
		string msMarketingSupport
	) {
		PgMktSupport = pgMktSupport;
		MsMarketingSupport = msMarketingSupport;
	}

	public required string PgMktSupport { get; set; }
	public required string MsMarketingSupport { get; set; }
}