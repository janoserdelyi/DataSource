using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactSearch
{
	[JsonProperty ("id")]
	public required int ContactId { get; set; }
	public string? FirstName { get; set; }
	public string? LastName { get; set; }
	public string? EmailAddress { get; set; }
	public string? PhoneNumber { get; set; }
	public int? LocationId { get; set; }
}