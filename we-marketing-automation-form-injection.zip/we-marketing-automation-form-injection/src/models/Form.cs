
namespace WeMarketingAutomationFormInjection.Models;

// i'll need to pass something like this to all dynamo calls since we can't decorate this table with the name
// var conf = new DynamoDBOperationConfig () {
// 	OverrideTableName = tableName
// };
//[DynamoDBTable ("we-marketing-automation-form-injection-api-form-dvm")]
public class Form
{

	public Form () {

	}

	[DynamoDBHashKey ("cd")]
	public required string Cd { get; set; }

	[DynamoDBRangeKey ("locale")]
	public required string Locale { get; set; }

	[DynamoDBProperty ("name")]
	public required string Name { get; set; }

	[DynamoDBProperty ("injectionPoint")]
	public required string InjectionPoint { get; set; }

	[DynamoDBProperty ("submissionEndpoint")]
	public required string SubmissionEndpoint { get; set; }

	[DynamoDBProperty ("formTemplatePath")]
	public required string FormTemplatePath { get; set; }

	[DynamoDBProperty ("cssTemplatePath")]
	public string? CssTemplatePath { get; set; }

	[DynamoDBProperty ("securityKey")]
	public required string SecurityKey { get; set; }

	[DynamoDBProperty ("marketingBrandId")]
	public required int MarketingBrandId { get; set; } // this is really the brand mapping id

	[DynamoDBProperty ("marketingBrand")]
	public required string MarketingBrand { get; set; }

	[DynamoDBProperty ("formTypeCd")]
	public required string FormTypeCd { get; set; }

	[DynamoDBProperty ("formType")]
	public required string FormType { get; set; }

	[DynamoDBProperty ("formSourceTypeCd")]
	public required string FormSourceTypeCd { get; set; }

	[DynamoDBProperty ("formSourceType")]
	public required string FormSourceType { get; set; }

	[DynamoDBProperty ("addedConfig")]
	public required string AddedConfig { get; set; }

	[DynamoDBProperty ("active")]
	public required bool Active { get; set; }

	[DynamoDBProperty ("inboundExternalCampaignId")]
	public string? InboundExternalCampaignId { get; set; }

	[DynamoDBProperty ("outboundExternalCampaignId")]
	public string? OutboundExternalCampaignId { get; set; }

	[DynamoDBProperty ("formLeadSourceCd")]
	public string? FormLeadSourceCd { get; set; }

	[DynamoDBProperty ("formLeadSource")]
	public string? FormLeadSource { get; set; }

	[DynamoDBProperty ("url")]
	public required string Url { get; set; }
}
