// https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint

using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

public class MarketingBrandSegmentPreference
{
	// public  MarketingBrandSegmentPreference (
	// 	int marketingBrandSegmentId,
	// 	bool optIn
	// ) {
	// 	MarketingBrandSegmentId = marketingBrandSegmentId;
	// 	OptIn = optIn;
	// }

	[JsonProperty ("segment")]
	[JsonPropertyName ("segment")]
	public int? MarketingBrandSegmentId { get; set; }

	[JsonProperty ("optInPref")]
	[JsonPropertyName ("optInPref")]
	public bool? OptIn { get; set; }
}