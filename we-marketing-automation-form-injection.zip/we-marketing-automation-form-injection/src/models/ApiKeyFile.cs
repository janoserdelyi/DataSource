using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ApiKeyFile
{
	public ApiTokens? Apitokens { get; set; }
}


[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ApiTokens
{
	public SecretKey? MaBookADemo { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SecretKey
{
	public required string Secret { get; set; }
}