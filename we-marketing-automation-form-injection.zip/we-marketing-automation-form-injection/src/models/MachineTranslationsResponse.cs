using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class MachineTranslationsResponse<T> : MachineTranslationsModel<T>
{
	public List<string>? ErrorKeys { get; set; }
}
