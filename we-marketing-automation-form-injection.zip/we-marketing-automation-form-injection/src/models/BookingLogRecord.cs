using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public record BookingLogRecord
{
	public required string TrackingId { get; set; }
	public required DateTimeOffset SubmitDate { get; set; }
	public required string FormCd { get; set; }
	public required string Locale { get; set; }
	public Models.Lead? OriginalLead { get; set; }
	public List<string>? Errors { get; set; }
	public string? BookingId { get; set; }
	public string? LeadId { get; set; }
	public string? SourceArea { get; set; }
	public ReservationProspect? Prospect { get; set; }
	public HeaderDictionary? RawHeaders { get; set; }
	public string? RequestHash { get; set; }
	public string? IpAddress { get; set; }
	public string? UserAgent { get; set; }
	public bool CachedResponse { get; set; } = false;
}