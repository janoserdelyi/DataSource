using FluentValidation;
using CoStar.PhoneNumbers;
using Microsoft.Extensions.Localization;

namespace WeMarketingAutomationFormInjection.Models;

public class EmailPreferenceValidator : AbstractValidator<EmailPreference>
{
	public EmailPreferenceValidator (
		IDynamoClient dynamoClient,
		IStringLocalizer localizer,
		bool doFullEmailValidation = true
	) {
		RuleFor (x => x.NeverFill).Empty ().WithMessage (x => localizer["invalidRequest"]);

		RuleFor (x => x.FirstName).Length (1, 16);

		RuleFor (x => x.LastName).Length (1, 25);

		RuleFor (x => x.EmailAddress).NotEmpty ();
		RuleFor (x => x.EmailAddress).Length (5, 100);
		RuleFor (x => x.EmailAddress).EmailMustValidate (dynamoClient, localizer, doFullEmailValidation);

		RuleFor (x => x.Brand).NotNull ();

		RuleFor (x => x.CountryCode).NotEmpty ();
		RuleFor (x => x.CountryCode).Length (3);
		RuleFor (x => x.CountryCode).CountryCodeMustValidate (dynamoClient, localizer);
	}

}