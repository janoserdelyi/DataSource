namespace WeMarketingAutomationFormInjection.Models;

public class MachineTranslationConfig
{
	public required string ProtocolAnddomain { get; set; }
	public required string Route { get; set; }
	public required string ApiClientId { get; set; }
	public int BatchSize { get; set; } = 20;
}