using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

// properties in this class are what get translated and generate the various locale files

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CommonTranslationValues
{
	public string FirstName { get; set; } = "First Name";
	public string LastName { get; set; } = "Last Name";
	public string Company { get; set; } = "Company";
	public string Email { get; set; } = "Email";
	public string WorkEmail { get; set; } = "Work Email";
	public string Phone { get; set; } = "Phone";
	public string Country { get; set; } = "Country";
	public string StateCode { get; set; } = "State";
	public string PostalCode { get; set; } = "Postal Code";
	public string Brand { get; set; } = "Brand";
	public string Required { get; set; } = "Required";
	public string Submitting { get; set; } = "Submitting";
	public string InvalidFormat { get; set; } = "Invalid format";
	public string UnsupportedCountryCode { get; set; } = "Unsupported Country Code";
	public string UnsupportedPhoneCountryCode { get; set; } = "Unsupported Phone Country Code";
	public string InvalidEmailDomain { get; set; } = "Invalid email domain";
	public string InvalidPostalCode { get; set; } = "Invalid postal code";
	public string InvalidPostalCodeFormat { get; set; } = "Invalid postal code format";
	public string InvalidPhoneNumberFormat = "Invalid phone number format";
	public string InvalidRequest { get; set; } = "Invalid request";
	public string InvalidPhoneNumber { get; set; } = "Invalid phone number";
	public string RequestType { get; set; } = "Request type";
	public string SelectOne { get; set; } = "Select one";
	public string Relationship { get; set; } = "Relationship";
	public string Address { get; set; } = "Address";
}
