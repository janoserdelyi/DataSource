// https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint

using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

public class Lead
{
	private string? companyName;
	private string? campaignId;
	private string? countryCode;

	// included so that if bots fill out every field we know this is a bogus request
	[JsonProperty ("additionalValues")]
	[JsonPropertyName ("additionalValues")]
	public string? NeverFill { get; set; }

	[JsonProperty ("firstName")]
	public string? FirstName { get; set; }

	[JsonProperty ("lastName")]
	public string? LastName { get; set; }

	[JsonProperty ("company")]
	[JsonPropertyName ("company")]
	public string? CompanyName {
		get {
			// sanitize the company name some
			if (string.IsNullOrEmpty (companyName)) {
				return companyName;
			}

			companyName = companyName
				.Replace ("<!--", "")
				.Replace ("-->", "")
				.Replace ("\\", "");

			return companyName;
		}
		set {
			companyName = value;
		}
	}

	[JsonProperty ("zipCode")]
	[JsonPropertyName ("zipCode")]
	public string? PostalCode { get; set; }

	[JsonProperty ("phone")]
	[JsonPropertyName ("phone")]
	public string? PhoneNumber { get; set; }

	[JsonProperty ("emailAddress")]
	public string? EmailAddress { get; set; }

	[JsonProperty ("countryCode")]
	public string? CountryCode {
		get {
			if (string.IsNullOrEmpty (countryCode)) {
				return countryCode;
			}

			return System.Text.RegularExpressions.Regex.Replace (countryCode, @"[^a-zA-Z]", "");
		}
		set {
			countryCode = value;
		}
	}

	[Newtonsoft.Json.JsonIgnore ()]
	public string? CountryCodeIso2 { get; set; }

	[JsonProperty ("formType")]
	public string? FormType { get; set; }

	[JsonProperty ("leadSource")]
	public string? LeadSource { get; set; }

	[JsonProperty ("sourceType")]
	public string? SourceType { get; set; }

	[JsonProperty ("contactId")]
	public int? ContactId { get; set; }

	[JsonProperty ("brand")]
	public string? Brand { get; set; }

	[JsonProperty ("city")]
	public string? City { get; set; }

	[JsonProperty ("stateCode")]
	public string? StateCode { get; set; }

	[JsonProperty ("notes")]
	public string? Notes { get; set; }

	[JsonProperty ("productLineCode")]
	public string? ProductLineCode { get; set; }

	[JsonProperty ("productName")]
	public string? ProductName { get; set; }

	[JsonProperty ("campaignId")]
	public string? CampaignId {
		get {
			if (string.IsNullOrEmpty (campaignId)) {
				return campaignId;
			}

			return System.Text.RegularExpressions.Regex.Replace (campaignId, @"[^a-zA-Z0-9\-\._\s]", "");
		}
		set {
			campaignId = value;
		}
	}

	[JsonProperty ("language")]
	[JsonPropertyName ("language")]
	public string? LanguageCode { get; set; }

	[JsonProperty ("sourceUrl")]
	public string? SourceUrl { get; set; }

	[JsonProperty ("sourceArea")]
	public string? SourceArea { get; set; }

	[JsonProperty ("businessType")]
	public string? BusinessType { get; set; }

	[JsonProperty ("businessSubType")]
	public string? BusinessSubType { get; set; }

	[JsonProperty ("sfLeadOrContactId")]
	public string? SfLeadOrContactId { get; set; }

	[JsonProperty ("sfOutBoundCampaignId")]
	public string? SfOutBoundCampaignId { get; set; }

	[JsonProperty ("marketingOptIn")]
	[JsonPropertyName ("marketingOptIn")]
	public bool? BrandLevelMarketingOptIn { get; set; }

	[JsonProperty ("optIntoSegments")]
	public IList<MarketingBrandSegmentPreference>? OptIntoSegments { get; set; }

	/*
	"additionalData": {
		"additionalProp1": "string",
		"additionalProp2": "string",
		"additionalProp3": "string"
	}
	*/
	// we don't parse this
	//[JsonProperty("additionalData")]
	// public string? AdditionalData {get;set;}
	[JsonProperty ("additionalData")]
	public Dictionary<string, string> AdditionalData { get; set; } = new Dictionary<string, string> ();

	// if the brands want to force a locale for the form submission
	[JsonProperty ("locale")]
	public string? Locale { get; set; }

	[JsonProperty ("nameScore")]
	public int NameScore { get; set; } = 0;
}


public class PrivacyLead : Lead
{
	[JsonProperty ("relationship")]
	public string? Relationship { get; set; }

	[JsonProperty ("address")]
	public string? Address { get; set; }
}