using Newtonsoft.Json;

namespace WeMarketingAutomationFormInjection.Models.OpenSearch;

// this is the model which represents what's stored in OpenSearch
public record ContactGaSessions
{
	public int ContactId { get; set; }
	public List<string> GaSessionIds { get; set; } = [];
}

// thos model represents what is submitted to us in the POST payload
public record ContactGaSession
{
	public required string Ecid { get; set; }
	public required string SessionId { get; set; }
}