
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models.OpenSearch;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class PostalCountry
{

	public PostalCountry () {

	}

	[JsonProperty ("id")]
	public required string PostalCountryCd { get; set; }

	[JsonProperty ("postalCode")]
	public required string PostalCd { get; set; }

	[JsonProperty ("countryCode")]
	public required string CountryCd { get; set; }

	[JsonProperty ("name")]
	public required string Name { get; set; }

}