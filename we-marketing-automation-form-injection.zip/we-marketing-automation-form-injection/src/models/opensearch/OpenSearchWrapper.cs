/*
{
	"took": 3,
	"timed_out": false,
	"_shards": {
		"total": 5,
		"successful": 5,
		"skipped": 0,
		"failed": 0
	},
	"hits": {
		"total": {
			"value": 1,
			"relation": "eq"
		},
		"max_score": 17.64356,
		"hits": [
			{
				"_index": "ma-zipcodes.3321988",
				"_type": "_doc",
				"_id": "b2b1a38e84ac5491",
				"_score": 17.64356,
				"_source": {
					"id": "b2b1a38e84ac5491",
					"countryCode": "USA",
					"postalCode": "23114",
					"name": "Midlothian"
				}
			}
		]
	}
}
*/

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models.OpenSearch;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class OpensearchWrapper<T>
{
	public int Took { get; set; }

	[JsonProperty ("timed_out")]
	public bool TimedOut { get; set; }

	public OpenSearchHits<T>? Hits { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class OpensSearchTotal
{
	public int? Value { get; set; }
	public string? Relation { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class OpenSearchHits<T>
{
	public OpensSearchTotal? Total { get; set; }

	public List<OpenSearchHitResult<T>>? Hits { get; set; }
}

public class OpenSearchHitResult<T>
{
	[JsonProperty ("_index")]
	public string? Index { get; set; }

	[JsonProperty ("_type")]
	public string? Type { get; set; }

	[JsonProperty ("_id")]
	public string? Id { get; set; }

	[JsonProperty ("_score")]
	public decimal? Score { get; set; }

	[JsonProperty ("_source")]
	public T? Source { get; set; }
}