using Newtonsoft.Json;

namespace WeMarketingAutomationFormInjection.Models.OpenSearch;

public class EmailPreference
{
	[JsonProperty ("id")]
	public required string Id { get; set; }

	[JsonProperty ("brandPreferences")]
	public List<BrandPreference>? BrandPreferences { get; set; }
}

public class BrandPreference
{
	[JsonProperty ("marketingBrandId")]
	public required int Id { get; set; }

	[JsonProperty ("marketingBrandName")]
	public required string Name { get; set; }

	[JsonProperty ("segmentPreferences")]
	public List<SegmentPreference> SegmentPreferences { get; set; } = [];
}

public class SegmentPreference
{
	[JsonProperty ("marketingBrandSegmentId")]
	public required int Id { get; set; }

	[JsonProperty ("name")]
	public required string Name { get; set; }

	[JsonProperty ("canEmail")]
	public required bool CanEmail { get; set; }

	[JsonProperty ("canEmailCountryDefault")]
	public required bool CanEmailCountryDefault { get; set; }
}

// a wrapper to more strongly type the response and to aid in unit testing
public class SegmentPreferenceResponse
{
	public required bool Success { get; set; }
	public string? Message { get; set; }
	public SegmentPreference? SegmentPreference { get; set; }
}

// another wrapper for more strongly-typed response and unit testing
public class BrandPreferenceResponse
{
	public required bool Success { get; set; }
	public string? Message { get; set; }
	public BrandPreference? BrandPreference { get; set; }
}


/*
{
"id": "jerdelyi@costar.com",
"brandPreferences": [
	{
	"marketingBrandId": 7,
	"marketingBrandName": "BusinessImmo",
	"segmentPreferences": [
		{
		"marketingBrandSegmentId": 1,
		"name": "Business Immo Offers",
		"canEmail": false,
		"canEmailCountryDefault": false
		},
		{
		"marketingBrandSegmentId": 3,
		"parentId": 2,
		"name": "24h dans l'immobilier",
		"canEmail": false,
		"canEmailCountryDefault": false
		},
		{
		"marketingBrandSegmentId": 7,
		"parentId": 2,
		"name": "Transactions",
		"canEmail": false,
		"canEmailCountryDefault": false
		}
	]
	},
	{
	"marketingBrandId": 6,
	"marketingBrandName": "Homes",
	"segmentPreferences": [
		{
		"marketingBrandSegmentId": 8,
		"name": "Membership Offers and Information",
		"canEmail": false,
		"canEmailCountryDefault": false
		}
	]
	},
	{
	"marketingBrandId": 5,
	"marketingBrandName": "STR",
	"segmentPreferences": [
		{
		"marketingBrandSegmentId": 13,
		"name": "Marketing Offers and Information",
		"canEmail": true,
		"canEmailCountryDefault": false
		}
	]
	}
]
}
*/