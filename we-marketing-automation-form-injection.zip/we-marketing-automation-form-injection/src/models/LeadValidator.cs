using FluentValidation;
using Microsoft.Extensions.Localization;

namespace WeMarketingAutomationFormInjection.Models;

public class LeadIngestionValidator<T> : AbstractValidator<T> where T : Lead
{

	protected readonly IDynamoClient dynamoClient;
	protected readonly IOpenSearchClient openSearchClient;
	protected readonly IStringLocalizer localizer;

	public LeadIngestionValidator (
		IDynamoClient dynamoClient,
		IOpenSearchClient openSearchClient,
		IStringLocalizer localizer
	) {

		this.dynamoClient = dynamoClient;
		this.openSearchClient = openSearchClient;
		this.localizer = localizer;

		DefineLeadRules ();
	}

	protected virtual void DefineLeadRules () {
		RuleFor (x => x.NeverFill)
			.Empty ()
			.MaximumLength (0)
			.WithMessage (x => localizer["invalidRequest"]);

		RuleFor (x => x.FirstName)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (1, 16)
			.WithName ("{{firstName}}");

		RuleFor (x => x.LastName)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (1, 25)
			.WithName ("{{lastName}}");

		RuleFor (x => x.CompanyName)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (2, 255)
			.WithName ("{{company}}");

		RuleFor (x => x.EmailAddress)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (5, 100)
			.EmailMustValidate (dynamoClient, localizer)
			.WithName ("{{emailAddress}}");

		RuleFor (x => x.CountryCode)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (3)
			.Matches ("^[A-Z]{3}$") // all three character must be uppercase
			.CountryCodeMustValidate (dynamoClient, localizer)
			.WithName ("{{countryCode}}");

		RuleFor (x => x.PostalCode)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.PostalFormatMustValidate (localizer)
			.PostalMustValidate (openSearchClient, localizer)
			.WithName ("{{zipCode}}");

		RuleFor (x => x.PhoneNumber)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.Length (4, 20) // 20 is the max we accept in the Contact and MarketingLead tables. 4 appears to be the smallest possible international value
			.PhoneMustValidate (localizer)
			.WithName ("{{phone}}");

		// RuleFor(x => x.FormType).NotEmpty().WithMessage("A Form Type is required");

		// RuleFor(x => x.LeadSource).NotEmpty().WithMessage("A Lead Source is required");

		// RuleFor(x => x.SourceType).NotEmpty().WithMessage("A Source Type is required");

		// RuleFor(x => x.Brand).NotEmpty().WithMessage("A Brand is required");

		RuleFor (x => x.City).MaximumLength (30).WithName ("City");
		RuleFor (x => x.StateCode).MaximumLength (30).WithName ("State code");
		RuleFor (x => x.Notes).MaximumLength (1000).WithName ("Notes"); // ok i don't actually know what the max length is on this. but we don't currently use it and i wanted something to constrain it
		RuleFor (x => x.ProductLineCode).MaximumLength (100).WithName ("Productline code"); // this can be a comma-delimited list. i really don't expect more than 100 chars. ever
		RuleFor (x => x.ProductName).MaximumLength (300).WithName ("Product name"); // again, just a constraint
		RuleFor (x => x.LanguageCode).MaximumLength (20).WithName ("Language");
		RuleFor (x => x.Locale).MaximumLength (10).WithName ("Locale");
		RuleFor (x => x.SourceUrl).MaximumLength (1000).WithName ("Source URL");
		RuleFor (x => x.SourceArea).MaximumLength (1000).WithName ("Source area");
		RuleFor (x => x.BusinessType).MaximumLength (50).WithName ("Business type");
		RuleFor (x => x.BusinessSubType).MaximumLength (50).WithName ("Business subtype");

		// just adding some length constraints that i don't ever expect the public to see
		RuleFor (x => x.Brand).MaximumLength (100).WithName ("Brand selection");
		RuleFor (x => x.CampaignId).MaximumLength (60).WithName ("Campaign Id");
		RuleFor (x => x.FormType).MaximumLength (20).WithName ("Form type");
		RuleFor (x => x.SourceType).MaximumLength (20).WithName ("Source type");
	}
}

// Non-generic version for backward compatibility
public class LeadIngestionValidator : LeadIngestionValidator<Lead>
{
	public LeadIngestionValidator (
		IDynamoClient dynamoClient,
		IOpenSearchClient openSearchClient,
		IStringLocalizer localizer
	) : base (
		dynamoClient,
		openSearchClient,
		localizer
	) {

	}
}

public class PrivacyLeadIngestionValidator : LeadIngestionValidator<PrivacyLead>
{
	public PrivacyLeadIngestionValidator (
		IDynamoClient dynamoClient,
		IOpenSearchClient openSearchClient,
		IStringLocalizer localizer
	) : base (
		dynamoClient,
		openSearchClient,
		localizer
	) {
		DefinePrivacyLeadRules ();
	}

	private void DefinePrivacyLeadRules () {
		RuleFor (x => x.Relationship)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.MaximumLength (100)
			.WithName ("{{relationship}}");

		RuleFor (x => x.Address)
			.Cascade (CascadeMode.Stop)
			.NotEmpty ()
			.MaximumLength (500)
			.WithName ("{{address}}");
	}
}