using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DemoKillSwitchRequest
{
	public required int Requestor { get; set; }
	public required string Value { get; set; }
	public string? FormCd { get; set; }
	public string? Locale { get; set; }
	public int? BrandMappingId { get; set; }
	public string? Route { get; set; }
}