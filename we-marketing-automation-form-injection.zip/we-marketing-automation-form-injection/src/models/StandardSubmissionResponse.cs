namespace WeMarketingAutomationFormInjection.Models;

public class StandardSubmissionResponse
{
	public StandardSubmissionResponse (
		bool success,
		string message,
		string? fullMessage = null,
		List<FluentValidation.Results.ValidationFailure>? errors = null
	) {
		Success = success;
		Message = message;
		FullMessage = fullMessage;
		Errors = errors;
	}

	public bool Success { get; set; }
	public string Message { get; set; }
	public string? FullMessage { get; set; }
	public List<FluentValidation.Results.ValidationFailure>? Errors { get; set; }
}


