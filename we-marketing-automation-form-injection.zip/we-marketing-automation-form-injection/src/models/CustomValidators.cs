using FluentValidation;
using CoStar.PhoneNumbers;
using Microsoft.Extensions.Localization;
using System.Text.RegularExpressions;

namespace WeMarketingAutomationFormInjection.Models;

public static class CustomValidators
{
	public static IRuleBuilderOptions<T, TElement> EmailMustValidate<T, TElement> (
		this IRuleBuilder<T, TElement> ruleBuilder,
		IDynamoClient dynamoClient,
		IStringLocalizer localizer,
		bool doFullEmailValidation = true
	) {

		return ruleBuilder.Must ((rootObject, email, context) => {
			bool dofullValidation = false;

			// https://docs.fluentvalidation.net/en/latest/advanced.html#root-context-data
			// do more extensive validation for non-local environments
			if (
				context.RootContextData != null &&
				context.RootContextData.ContainsKey ("EnvironmentName") &&
				context.RootContextData["EnvironmentName"].ToString () != "local"
			) {
				//dofullValidation = true;
				// local should never try (due to firewalls) but upper envs should check with what's passed in
				dofullValidation = doFullEmailValidation;
			}

			var timer = new System.Diagnostics.Stopwatch ();
			timer.Start ();
			var validationResult = Utils.ValidateEmailAddress (email!.ToString ()!, dofullValidation, dynamoClient);
			timer.Stop ();
			TimeSpan timetaken = timer.Elapsed;
			Console.WriteLine ($"LeadValidator.EmailMustValidate time taken : {timetaken.ToString (@"m\:ss\.fff")}");

			// a nicer message than "Email validation failed. Error determining MX at dns '1.1.1.1' for 'foo.com'
			string? errorMessage = validationResult.ErrorMessage;

			if (
				validationResult.IsFailure &&
				validationResult.ErrorMessage != null &&
				(validationResult.ErrorMessage.Contains ("MX") || validationResult.ErrorMessage.Contains ("not an allowed domain"))
			) {
				errorMessage = localizer["invalidEmailDomain"];
			}

			// a fun one i'm only encountering in TSM (not DVM) is janos.erdelyi@foo.com returns no error message. DVM sas no MX
			if (string.IsNullOrEmpty (errorMessage)) {
				errorMessage = localizer["invalidEmailDomain"];
			}

			if (validationResult.IsFailure) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", errorMessage);
			}

			return validationResult.IsSuccess;

		}).WithMessage ("{ErrorMessage}");
	}

	public static IRuleBuilderOptions<T, TElement> PhoneMustValidate<T, TElement> (
		this IRuleBuilder<T, TElement> ruleBuilder,
		IStringLocalizer localizer
	) {
		return ruleBuilder.Must ((rootObject, phone, context) => {
			string? countryCode = null;

			if (
				context.RootContextData != null &&
				context.RootContextData.ContainsKey ("CountryCodeTwoChar") &&
				context.RootContextData["CountryCodeTwoChar"] != null
			) {
				countryCode = context.RootContextData["CountryCodeTwoChar"].ToString ()!.ToUpper ();
			}

			var lead = rootObject as Models.Lead;

			if (countryCode == null) {
				countryCode = lead!.CountryCodeIso2;
			}

			// save aside original input in case we re-display
			var justnumbersplus = Utils.DeformatPhoneNumber (phone!.ToString ()!);

			if (countryCode == null) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizer["unsupportedPhoneCountryCode"]);
				return false;
			}

			var parser = new Parser ();
			var parsed = parser.Parse (new PhoneNumber { CountryCode = countryCode, Number = justnumbersplus });

			if (parsed.IsPossibleNumber () == false || parsed.IsValid () == false) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizer["invalidPhoneNumber"]);
				return false;
			}

			return true;
		}).WithMessage ("{ErrorMessage}");
	}

	public static IRuleBuilderOptions<T, TElement> PostalMustValidate<T, TElement> (
		this IRuleBuilder<T, TElement> ruleBuilder,
		IOpenSearchClient openSearchClient,
		IStringLocalizer localizer
	) {
		return ruleBuilder.Must ((rootObject, postalCd, context) => {

			var leadObj = context.InstanceToValidate as Models.Lead;

			string localizedError = localizer["invalidPostalCode"];

			if (leadObj == null || leadObj.CountryCode == null) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
				return false;
			}

			if (postalCd == null || postalCd.ToString () == null) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
				return false;
			}

			var postalIsReal = openSearchClient.IsRealPostalCode (leadObj.CountryCode, postalCd.ToString ()!).Result;

			if (postalIsReal == false) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
				return false;
			}

			return true;
		}).WithMessage ("{ErrorMessage}");
	}

	public static IRuleBuilderOptions<T, TElement> PostalFormatMustValidate<T, TElement> (
		this IRuleBuilder<T, TElement> ruleBuilder,
		IStringLocalizer localizer
	) {
		return ruleBuilder.Must ((rootObject, postalCd, context) => {

			var leadObj = context.InstanceToValidate as Models.Lead;

			string localizedError = localizer["invalidPostalCodeFormat"];

			if (leadObj == null) {
				// since the vast majority of countries wil not have patterns defined, this is ok to pass. a lack of a leadObj is going to trigger other, clearer errors
				return true;
			}

			if (leadObj.CountryCode == null) {
				// since the vast majority of countries wil not have patterns defined, this is ok to pass. a lack of a leadObj.CountryCode is going to trigger other, clearer errors
				return true;
			}

			if (postalCd == null || postalCd.ToString () == null) {
				// other, earlier validators will kick this out with a better message. let this pass
				return true;
			}

			string? pattern = null;

			switch (leadObj.CountryCode) {
				case "USA":
					pattern = @"^(\d{5})(-\d{4})?$";
					break;
				case "GBR":
					// Full UK Government specification
					//pattern = @"^(GIR\s?0AA|[A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]([0-9ABEHMNPRV-Y])?)|[0-9][A-HJKPS-UW])\s?[0-9][ABD-HJLNP-UW-Z]{2})$";
					// not as tight, but pretty good
					// matches A9 9AA, A99 9AA, AA9 9AA, AA99 9AA, A9A 9AA, AA9A 9AA, GIR 0AA
					pattern = @"^([A-Z]{1,2}\d{1,2}[A-Z]?|GIR)\s?\d[A-Z]{2}$";
					break;
				case "CAN":
					// Strict pattern - excludes invalid letters per Canada Post rules
					pattern = @"^[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTV-Z]\s?\d[ABCEGHJ-NPRSTV-Z]\d$";
					break;
			}

			if (pattern == null) {
				return true;
			}

			// eval the pattern
			if (Regex.IsMatch (postalCd.ToString ()!, pattern, RegexOptions.IgnoreCase)) { // i do case-insensitve opensearch queries on these
				return true;
			}

			context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
			return false;

		}).WithMessage ("{ErrorMessage}");
	}

	public static IRuleBuilderOptions<T, TElement> CountryCodeMustValidate<T, TElement> (
		this IRuleBuilder<T, TElement> ruleBuilder,
		IDynamoClient dynamoClient,
		IStringLocalizer localizer
	) {

		return ruleBuilder.Must ((rootObject, countryCode, context) => {

			var localizedError = localizer["unsupportedCountryCode"];

			if (countryCode == null || countryCode.ToString () == null) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
				return false;
			}

			// this could have some side-effects...
			// considering UNK a legit country code for the sake of setting email preferences
			if (countryCode.ToString () == "UNK") {
				return true;
			}

			// if there is no 2 character country code for the 3 character passed in, we can consider it bad/non-existant
			var country3to2 = dynamoClient.GetCountry3to2 (countryCode.ToString ()!.ToUpper ()).Result;

			if (country3to2 == null || country3to2.Two == null) {
				context.MessageFormatter.AppendArgument ("ErrorMessage", localizedError);
				return false;
			}

			return true;

		}).WithMessage ("{ErrorMessage}");
	}
}