using System.Net;

namespace WeMarketingAutomationFormInjection.Models;

public class SubmitEmailPreferenceResponse
{
	public required bool Success { get; set; }
	public required string Message { get; set; }
	public string? FullMessage { get; set; }
	public IList<FluentValidation.Results.ValidationFailure>? ValidationErrors { get; set; }
	public HttpStatusCode? StatusCode { get; set; }
}


