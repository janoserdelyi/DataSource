using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateLeadResponse
{
	public required bool Success { get; set; }
	public List<string>? SentTo { get; set; }
	public string? MessageGroup { get; set; }
	// public bool OptsProcessed { get; set; } = true; // initially, basic form submission handles the opts, but other form processing mechanisms showed up which do not
}