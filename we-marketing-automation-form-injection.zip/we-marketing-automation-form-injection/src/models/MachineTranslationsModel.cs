using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WeMarketingAutomationFormInjection.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class MachineTranslationsModel<T>
{
	public string? SourceCulture { get; set; }

	public string? TargetCulture { get; set; }
	public T? Values { get; set; }
}
