
namespace WeMarketingAutomationFormInjection.Models;

//[DynamoDBTable ("we-marketing-automation-form-injection-api-country3to2-dvm")]
public class Country3to2
{

	public Country3to2 () {

	}

	[DynamoDBHashKey ("three")]
	public required string Three { get; set; }

	[DynamoDBProperty ("two")]
	public required string Two { get; set; }

	[DynamoDBProperty ("name")]
	public required string Name { get; set; }

}