using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System.Linq;
using System.Threading;

namespace WeMarketingAutomationFormInjection;

public static class VaultKeys
{
	public const string LeadSubmission = "2dfa028d8478164fd111897044b728fbe2f4a914";
	public const string BookADemo = "book-demo-creds";
	public const string ContactEncryption = "encryption-key";

	// get all the const's above. using reflection so that i'm not had-coding anything more than once
	public static readonly List<string> KeyList = typeof (VaultKeys)
		.GetFields (System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static)
		.Where (f => f.FieldType == typeof (string))
		.Select (f => (string)f.GetValue (null)!)
		.ToList ();

	public static bool IsValidKeyId (
		string keyid
	) {
		return VaultKeys.KeyList.Contains (keyid);
	}
}

public interface IKeyProvider
{
	static abstract string GetKeyContents (string keyid);
}

public class VaultKeyProvider : IKeyProvider
{
	// the main issue we have here is that (as of this writing) we have three different keys in three different formats and it's ugly
	// also i want a unified filesystemwatcher to rotate the keys if they change and it should cover all the keys

	static VaultKeyProvider () {

		if (Directory.Exists ("/vault/secrets")) {
			keyDirectory = "/vault/secrets";
		} else {
			var homedir = Environment.GetFolderPath (Environment.SpecialFolder.UserProfile);

			if (homedir == null) {
				throw new Exception ("unable to find home directory");
			}

			keyDirectory = Path.Combine (homedir, "keys");
		}

		if (keyDirectory == null || Directory.Exists (keyDirectory) == false) {
			throw new Exception ("unable to find keys directory");
		}
		// set up a filesystemwatcher to keep these up to date
		physicalFileProvider = new PhysicalFileProvider (root: keyDirectory);

		ChangeToken.OnChange (() => physicalFileProvider.Watch ("*.*"), SomeFileChanged);
	}

	private static readonly string keyDirectory;
	// private static readonly List<string> keyList = [
	// 	"book-demo-creds",
	// 	"encryption-key",
	// 	"2dfa028d8478164fd111897044b728fbe2f4a914"
	// ];
	// private static readonly List<string> keyList = typeof (VaultKeys)
	// 	.GetFields (System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static)
	// 	.Where (f => f.FieldType == typeof (string))
	// 	.Select (f => (string)f.GetValue (null)!)
	// 	.ToList ();

	private static readonly Dictionary<string, string> keycache = [];
	private static readonly object keycachelock = new ();
	private const int ENCRYPTION_KEY_BYTE_SIZE = 16;
	private static PhysicalFileProvider? physicalFileProvider;
	private static Timer? debounceTimer;
	private static readonly object debounceTimerLock = new ();
	private const int DEBOUNCE_DELAY_MS = 500; // Wait 500ms after last change

	// i'm watching a directory
	private static void SomeFileChanged (

	) {
		// this really needs some sort of debounce. single write operations can trigger 3 or more of these events (i've seen up to 7)
		Console.WriteLine ("some file changed - debouncing...");

		lock (debounceTimerLock) {
			// Cancel existing timer if it exists
			debounceTimer?.Dispose ();

			// Create new timer that will execute after delay
			debounceTimer = new Timer (
				callback: _ => reloadKeys (),
				state: null,
				dueTime: DEBOUNCE_DELAY_MS,
				period: Timeout.Infinite
			);
		}
	}

	private static void reloadKeys () {
		Console.WriteLine ("debounce timer elapsed - reloading keys");

		// 1. clear cache!
		lock (keycachelock) {
			keycache.Clear ();
		}

		// 2. not necessary really, since the next call to GetKeyContents will address this but let's go ahead and potentially reduce some latency
		foreach (var key in VaultKeys.KeyList) {
			try {
				GetKeyContents (key);
			} catch (Exception oops) {
				Console.WriteLine ($"Error reloading key {key}: {oops.Message}");
			}
		}
	}

	public static string GetKeyContents (
		string keyid
	) {
		// 1. see if it's in cache. if so, return it
		lock (keycachelock) {
			if (keycache.TryGetValue (keyid, out string? cacheHit)) {
				return cacheHit;
			}
		}

		// 2. is this even a keyid we know about?
		if (VaultKeys.IsValidKeyId (keyid) == false) {
			throw new ArgumentException ($"{keyid} is not a valid key to lookup in this project");
		}

		// 3. get the contents (unparsed)
		var rawContents = getKeyContents (keyid);

		// 4. here's where things split - there are 3 different key formats
		var keycontents = parseKeyContents (keyid, rawContents);

		// 5. cache the value
		lock (keycachelock) {
			keycache.TryAdd (keyid, keycontents);
		}

		return keycontents;
	}

	private static string getKeyContents (
		string keyid
	) {
		string? keysdir = null;
		string? keypath = null;

		// this *should* only be the case in non-local envs, but we shall see
		if (Directory.Exists ("/vault/secrets")) {
			keysdir = "/vault/secrets";
			keypath = Path.Combine (keysdir, keyid);
		}

		if (keysdir == null) {
			// this is local
			var homedir = Environment.GetFolderPath (Environment.SpecialFolder.UserProfile);

			if (homedir == null) {
				throw new Exception ("unable to find home directory");
			}

			keysdir = Path.Combine (homedir, "keys");

			if (string.IsNullOrEmpty (keysdir)) {
				throw new Exception ("unable to find keys directory");
			}

			var keydir = Path.Combine (keysdir, keyid);

			if (keydir == null) {
				throw new Exception ("unable to find key directory");
			}

			// some paths are directories with a "key" file in them
			if (Directory.Exists (keydir)) {
				keypath = Path.Combine (keydir, "key");
			} else {
				keypath = keydir;
			}
		}

		if (File.Exists (keypath) == false) {
			throw new Exception ("unable to find key file");
		}

		string keyvalue = readFileNonLocking (keypath, System.Text.Encoding.UTF8); //File.ReadAllText (keypath, System.Text.Encoding.UTF8);

		return keyvalue;
	}

	private static string readFileNonLocking (
		string filepath,
		System.Text.Encoding encoding
	) {
		// File.ReadAllText just made me sad. so here we are

		using var fs = File.Open (
			filepath,
			System.IO.FileMode.Open,
			System.IO.FileAccess.Read,
			System.IO.FileShare.ReadWrite
		);
		using var textReader = new StreamReader (fs, encoding);
		return textReader.ReadToEnd ();
	}

	// yes, i could have gone with a factory pattern. that's just too much cruft for this
	private static string parseKeyContents (
		string keyid,
		string rawcontents
	) {
		switch (keyid) {
			// this one is easy
			case "2dfa028d8478164fd111897044b728fbe2f4a914":
				return rawcontents;
			case "book-demo-creds":
				var bookademoObj = JsonConvert.DeserializeObject<Models.ApiKeyFile> (rawcontents);

				if (bookademoObj == null) {
					throw new Exception ("unable to parse key file");
				}

				if (bookademoObj.Apitokens == null) {
					throw new Exception ($"unable to find apiTokens in {keyid} key file");
				}

				if (bookademoObj.Apitokens.MaBookADemo == null) {
					throw new Exception ($"unable to find maBookADemo key in {keyid} key file");
				}

				if (bookademoObj.Apitokens.MaBookADemo.Secret == null) {
					throw new Exception ($"unable to find maBookADemo secret in {keyid} key file");
				}

				return bookademoObj.Apitokens.MaBookADemo.Secret;
			case "encryption-key":
				var encryptionkeyObj = JsonConvert.DeserializeObject<Models.EncryptionKey> (rawcontents);

				if (encryptionkeyObj == null) {
					throw new Exception ($"unable to parse {keyid} key file");
				}

				if (encryptionkeyObj.Key == null) {
					throw new Exception ($"unable to find key in {keyid} key file");
				}

				if (encryptionkeyObj.Key.Length != ENCRYPTION_KEY_BYTE_SIZE) {
					throw new Exception ($"a key byte size of {encryptionkeyObj.Key.Length} found, but expecting {ENCRYPTION_KEY_BYTE_SIZE}");
				}

				return encryptionkeyObj.Key;
		}

		throw new Exception ($"unknown error. no value returned for keyid {keyid}");
	}
}