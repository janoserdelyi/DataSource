using System.Security.Cryptography;
using System.Linq;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using WeMarketingAutomationFormInjection.Models.OpenSearch;
using Amazon.DynamoDBv2.Model.Internal.MarshallTransformations;

namespace WeMarketingAutomationFormInjection;

public interface IOpenSearchClient
{
	Task<bool> IsRealPostalCode (
		string countryCode,
		string postalCode
	);

	Task<bool> WritePostalCodes (
		List<Models.OpenSearch.PostalCountry> records
	);

	Task<EmailPreference?> GetAllEmailPreferences (
		string emailAddress
	);

	Task<bool> LogBookingRequest (
		Models.BookingLogRecord logRecord
	);

	Task<bool> LogFormRequest (
		Models.FormLogRecord logRecord
	);

	Task<List<Models.FormLogRecord>> GetAllFormRequestLogSince (
		string formcd,
		string locale,
		DateTimeOffset sinceDt
	);

	Task<List<Models.FormLogRecord>> GetAllFormRequestLogSince (
		string formcd,
		string locale,
		DateTimeOffset sinceDt,
		string method
	);

	Task<Models.ContactSearch?> GetContact (
		string emailAddress,
		string firstName,
		string lastName,
		string phoneNumber
	);

	Task<bool> WriteContactGaSession (
		Models.OpenSearch.ContactGaSessions contactGaSessions
	);

	Task<Models.OpenSearch.ContactGaSessions?> GetContactGaSessions (
		long contactId
	);
}

public class OpenSearchClient : IOpenSearchClient
{
	private static HttpClient httpClient = new ();
	private readonly string endpointUrl;
	private readonly string postalCodeReader;
	private readonly string postalCodeWriter;
	private readonly string emailPreferenceReader;
	private readonly string bookingLogWriter;
	private readonly string formLogWriter;
	private readonly string contactSearchReader;
	private readonly string contactGaSessionReader;
	private readonly string contactGaSessionWriter;
	private IWebHostEnvironment env;
	private string environmentName;

	public OpenSearchClient (
		IWebHostEnvironment env,
		IConfiguration config
	) {
		this.env = env;
		this.environmentName = env.SanitizedEnvironment ();
		this.endpointUrl = config.GetSection ("OpenSearchIndexURI").Get<string> ()!;
		this.postalCodeReader = config.GetSection ("PostalCodeReaderIndex").Get<string> ()!;
		this.postalCodeWriter = config.GetSection ("PostalCodeWriterIndex").Get<string> ()!;
		this.emailPreferenceReader = config.GetSection ("EmailPreferenceReaderIndex").Get<string> ()!;
		this.bookingLogWriter = config.GetSection ("BookingLogWriterIndex").Get<string> ()!;
		this.formLogWriter = config.GetSection ("FormLogWriterIndex").Get<string> ()!;
		this.contactSearchReader = config.GetSection ("ContactSearchReaderIndex").Get<string> ()!;
		this.contactGaSessionReader = config.GetSection ("ContactGaSessionReaderIndex").Get<string> ()!;
		this.contactGaSessionWriter = config.GetSection ("ContactGaSessionWriterIndex").Get<string> ()!;
	}

	public async Task<bool> WriteContactGaSession (
		Models.OpenSearch.ContactGaSessions contactGaSessions
	) {
		ArgumentNullException.ThrowIfNull (contactGaSessions);

		// if no sessions are being passed in, get out
		if (contactGaSessions.GaSessionIds.Count == 0) {
			return false;
		}

		// i don't know if GA session id's are case-sensitive, so i will leave them alone

		// first see if there is existing.
		// not, proceed. if so, we need to merge in the new ga session and write
		var existing = await GetContactGaSessions (contactGaSessions.ContactId);

		if (existing != null) {
			// if it already contains this session id, don't bother writing. get out
			if (existing.GaSessionIds.Contains (contactGaSessions.GaSessionIds[0])) {
				return true;
			}

			contactGaSessions.GaSessionIds.AddRange (existing.GaSessionIds);
		}

		try {
			var json = JsonConvert.SerializeObject (contactGaSessions);
			var content = new StringContent (
				json,
				Encoding.UTF8,
				"application/json"
			);

			var requestUri = $"{endpointUrl}/{contactGaSessionWriter}/_doc/{contactGaSessions.ContactId}";

			var request = new HttpRequestMessage (HttpMethod.Put, requestUri) {
				Content = content
			};

			var response = await httpClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			Console.WriteLine (await response.Content.ReadAsStringAsync ());

		} catch (Exception ex) {
			Console.WriteLine ($"WriteContactGaSession failure: {ex.Message}");
			return false;
		}

		return true;
	}

	public async Task<Models.OpenSearch.ContactGaSessions?> GetContactGaSessions (
		long contactId
	) {
		try {
			var searchQuery = new {
				query = new {
					term = new {
						_id = contactId
					}
				}
			};

			var httpMethod = HttpMethod.Post;
			var index = $"/{contactGaSessionReader}/_search";

			var request = new HttpRequestMessage (httpMethod, endpointUrl + index);
			request.Content = new StringContent (JsonConvert.SerializeObject (searchQuery));
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");

			var response = await httpClient.SendAsync (request);
			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				return null;
			}

			var responseObject = JsonConvert.DeserializeObject<OpensearchWrapper<ContactGaSessions>> (responseString);

			if (responseObject?.Hits?.Hits == null || responseObject.Hits.Hits.Count == 0) {
				return null;
			}

			return responseObject.Hits.Hits[0].Source;

		} catch (Exception ex) {
			Console.WriteLine ($"GetContactGaSessions error: {ex.Message}");
			return null;
		}
	}

	public async Task<bool> LogFormRequest (
		Models.FormLogRecord logRecord
	) {
		ArgumentNullException.ThrowIfNull (logRecord);

		try {
			var json = JsonConvert.SerializeObject (logRecord);
			var content = new StringContent (
				json,
				System.Text.Encoding.UTF8,
				System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json")
			);

			var versionType = "external";
			var version = DateTimeOffset.Now.ToUnixTimeMilliseconds ();

			var requestUri = $"{endpointUrl}/{formLogWriter}/_doc/{logRecord.Id}?version={version}&version_type={versionType}";
			var request = new HttpRequestMessage (HttpMethod.Put, requestUri);

			request.Content = content;

			var response = await httpClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			Console.WriteLine (await response.Content.ReadAsStringAsync ());

		} catch (Exception oops) {
			Console.WriteLine ($"logRecord failure : {oops.Message}");
			return false;
		}

		return true;
	}

	public async Task<bool> LogBookingRequest (
		Models.BookingLogRecord logRecord
	) {
		ArgumentNullException.ThrowIfNull (logRecord);

		try {
			var json = JsonConvert.SerializeObject (logRecord);
			var content = new StringContent (
				json,
				System.Text.Encoding.UTF8,
				System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json")
			);

			var versionType = "external";
			var version = DateTimeOffset.Now.ToUnixTimeMilliseconds ();

			var requestUri = $"{endpointUrl}/{bookingLogWriter}/_doc/{logRecord.TrackingId}?version={version}&version_type={versionType}";
			var request = new HttpRequestMessage (HttpMethod.Put, requestUri);

			request.Content = content;

			var response = await httpClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			Console.WriteLine (await response.Content.ReadAsStringAsync ());

		} catch (Exception oops) {
			Console.WriteLine ($"logRecord failure : {oops.Message}");
			return false;
		}

		return true;
	}

	public async Task<List<Models.FormLogRecord>> GetAllFormRequestLogSince (
		string formcd,
		string locale,
		DateTimeOffset sinceDt
	) {
		ArgumentNullException.ThrowIfNull (formcd);
		ArgumentNullException.ThrowIfNull (locale);

		var sinceDateMillis = sinceDt.ToUnixTimeMilliseconds ();

		var searchQuery = new {
			query = new {
				@bool = new {
					must = new object[] {
					new {
						term = new {
							formCd = formcd
						}
					},
					new {
						term = new {
							locale = locale
						}
					},
					new {
						range = new {
							requestDt = new {
								gt = sinceDateMillis
							}
						}
					}
				}
				}
			},
			sort = new object[] {
			new {
				requestDt = new {
					order = "desc"
				}
			}
		},
			size = 1000
		};

		return await queryFormLog (searchQuery);
	}

	public async Task<List<Models.FormLogRecord>> GetAllFormRequestLogSince (
		string formcd,
		string locale,
		DateTimeOffset sinceDt,
		string method
	) {
		ArgumentNullException.ThrowIfNull (formcd);
		ArgumentNullException.ThrowIfNull (locale);
		ArgumentNullException.ThrowIfNull (method);

		var sinceDateMillis = sinceDt.ToUnixTimeMilliseconds ();

		var searchQuery = new {
			query = new {
				@bool = new {
					must = new object[] {
						new {
							term = new {
								formCd = formcd
							}
						},
						new {
							term = new {
								locale = locale
							}
						},
						new {
							term = new {
								method = method
							}
						},
						new {
							range = new {
								requestDt = new {
									gt = sinceDateMillis
								}
							}
						}
					}
				}
			},
			sort = new object[] {
			new {
				requestDt = new {
					order = "desc"
				}
			}
		},
			size = 1000
		};

		return await queryFormLog (searchQuery);
	}

	public async Task<Models.ContactSearch?> GetContact (
		string emailAddress,
		string firstName,
		string lastName,
		string phoneNumber
	) {
		ArgumentNullException.ThrowIfNull (emailAddress);
		ArgumentNullException.ThrowIfNull (firstName);
		ArgumentNullException.ThrowIfNull (lastName);
		ArgumentNullException.ThrowIfNull (phoneNumber);

		// var searchQuery = new {
		// 	query = new {

		// 		term = new {
		// 			emailAddress_keyword = emailAddress
		// 		}

		// 	},
		// 	sort = new object[] {
		// 		new {
		// 			updatedDate = new {
		// 				order = "desc"
		// 			}
		// 		}
		// 	},
		// 	size = 10
		// };

		var searchQuery = new Dictionary<string, object> {
			["query"] = new Dictionary<string, object> {
				["term"] = new Dictionary<string, object> {
					["emailAddress.keyword"] = emailAddress  // Direct field path with dot notation
				}
			},
			["sort"] = new object[] {
				new Dictionary<string, object> {
					["updatedDate"] = new Dictionary<string, object> {
						["order"] = "desc"
					}
				}
			},
			["size"] = 10
		};

		List<Models.ContactSearch>? results = null;

		try {
			results = await queryContacts (searchQuery);
		} catch (Exception oops) {
			Console.WriteLine ($"Error querying contacts from {contactSearchReader} for email {emailAddress}: {oops.Message}");
			return null;
		}

		if (results.Count == 0) {
			return null;
		}

		if (results.Count == 1) {
			return results[0];
		}

		// if multiple come back, let's do a really rough/naive approximation of a match
		foreach (var result in results) {
			// phone match is probably going to be more solid than name. let's do that first
			if (result.PhoneNumber != null && Utils.DeformatPhoneNumber (result.PhoneNumber) == Utils.DeformatPhoneNumber (phoneNumber)) {
				return result;
			}

			// check fname/lname match. nothing fancy
			if (
				result.FirstName != null &&
				result.LastName != null &&
				result.FirstName.ToLower () == firstName.ToLower () &&
				result.LastName.ToLower () == lastName.ToLower ()
			) {
				return result;
			}
		}

		// no great matches.. but we still have an email match. just return the first
		return results[0];
	}
	private async Task<List<Models.ContactSearch>> queryContacts (object searchQuery) {
		try {
			var httpMethod = HttpMethod.Post;
			var index = $"/{contactSearchReader}/_search";

			var request = new HttpRequestMessage (httpMethod, this.endpointUrl + index);
			request.Content = new StringContent (JsonConvert.SerializeObject (searchQuery));
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");

			var response = await httpClient.SendAsync (request);
			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				return new List<Models.ContactSearch> ();
			}

			var responseObject = JsonConvert.DeserializeObject<OpensearchWrapper<Models.ContactSearch>> (responseString);

			if (responseObject?.Hits?.Hits == null) {
				return new List<Models.ContactSearch> ();
			}

			var results = responseObject.Hits.Hits.Select (hit => hit.Source).ToList ();

			return results!;

		} catch (Exception oops) {
			Console.WriteLine ($"Error retrieving contacts: {oops.Message}");
			return new List<Models.ContactSearch> ();
		}
	}

	private async Task<List<Models.FormLogRecord>> queryFormLog (
		object searchQuery
	) {
		try {
			var httpMethod = HttpMethod.Post;
			var index = $"/{formLogWriter}/_search";

			var request = new HttpRequestMessage (httpMethod, this.endpointUrl + index);
			request.Content = new StringContent (JsonConvert.SerializeObject (searchQuery));
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");

			var response = await httpClient.SendAsync (request);
			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				return new List<Models.FormLogRecord> ();
			}

			var responseObject = JsonConvert.DeserializeObject<OpensearchWrapper<Models.FormLogRecord>> (responseString);

			if (responseObject?.Hits?.Hits == null) {
				return new List<Models.FormLogRecord> ();
			}

			var results = responseObject.Hits.Hits.Select (hit => hit.Source).ToList ();

			return results!;

		} catch (Exception oops) {
			Console.WriteLine ($"Error retrieving form requests: {oops.Message}");
			return new List<Models.FormLogRecord> ();
		}
	}

	public async Task<EmailPreference?> GetAllEmailPreferences (
		string emailAddress
	) {
		ArgumentNullException.ThrowIfNull (emailAddress);

		// var searchQuery = new {
		// 	query = new {
		// 		term = new {
		// 			id = emailAddress
		// 		}
		// 	}
		// };

		// 		var searchQueryString = $@"
		// {{
		// 	""query"": {{
		// 		""term"":{{
		// 			""id.keyword"": ""{emailAddress}""
		// 		}}
		// 	}}
		// }}";
		// 		if (env.IsLocal () || env.IsDevelopment ()) {
		// 			searchQueryString = $@"
		// {{
		// 	""query"": {{
		// 		""term"":{{
		// 			""id"": ""{emailAddress}""
		// 		}}
		// 	}}
		// }}";
		// 		}

		// taking a different approach. too much variablility with id. PRD ended up being different than TSM, even
		var searchQueryString = $@"
{{
	""query"": {{
		""match_phrase"":{{
			""id"": ""{emailAddress}""
		}}
	}}
}}";


		var payloadContent = new StringContent (searchQueryString);

		try {
			var method = HttpMethod.Post;
			var index = $"/{emailPreferenceReader}/_search";

			var request = new HttpRequestMessage (method, this.endpointUrl + index);

			//request.Content = new StringContent (JsonConvert.SerializeObject (searchQuery));
			request.Content = payloadContent;
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");

			var response = await httpClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				throw new Exception ($"No email preferences found for {emailAddress}");
			}

			var responseObject = JsonConvert.DeserializeObject<OpensearchWrapper<EmailPreference>> (responseString);

			if (responseObject == null) {
				throw new Exception ($"No email preferences found for {emailAddress}");
			}

			if (
				responseObject.Hits == null ||
				responseObject.Hits.Total == null ||
				responseObject.Hits.Total.Value == null ||
				responseObject.Hits.Total.Value.Value == 0
			) {
				return null;
			}

			return responseObject.Hits.Hits![0].Source;

		} catch (Exception oops) {
			Console.WriteLine ($"error checking if email preference exists : {oops.Message}");
			return null;
		}
	}

	public async Task<bool> IsRealPostalCode (
		string countryCode,
		string postalCode
	) {
		ArgumentNullException.ThrowIfNull (countryCode);
		ArgumentNullException.ThrowIfNull (postalCode);

		// ensure that the country code is always uppercase
		countryCode = countryCode.ToUpper ();

		// strip any non-alpha-numeric values from the postal code and replace with a space
		postalCode = System.Text.RegularExpressions.Regex.Replace (postalCode, "[^a-zA-Z0-9\\-]+", " ").Trim ();

		// i don't know that i like this logic here... but if this is USA and the postal is more than 5 chars, just eval the first 5 chars
		if (countryCode == "USA" && postalCode.Length > 5) {
			postalCode = postalCode.Substring (0, 5);
		}

		var searchQuery = new {
			query = new {
				@bool = new {
					must = new object[] {
						new {
							term = new {
								countryCode = countryCode
							}
						},
						new {
							term = new {
								postalCode = new {
									value = postalCode,
									case_insensitive = true
								}
							}
						}
					}
				}
			}
		};

		/*
		{
			"query": {
				"bool": {
					"must": [
						{
							"term": {
								"countryCode": "USA"
							}
						},
						{
							"term": {
								"postalCode": "23114"
							}
						}
					]
				}
			}
		}
		*/

		try {
			var method = HttpMethod.Post;
			var index = $"/{postalCodeReader}/_search";

			var request = new HttpRequestMessage (method, this.endpointUrl + index);

			request.Content = new StringContent (JsonConvert.SerializeObject (searchQuery));
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");

			var response = await httpClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				throw new Exception ($"No postal code found for {countryCode}, {postalCode}");
			}

			var responseObject = JsonConvert.DeserializeObject<OpensearchWrapper<PostalCountry>> (responseString);

			if (responseObject == null) {
				throw new Exception ($"No postal code found for {countryCode}, {postalCode}");
			}

			if (
				responseObject.Hits == null ||
				responseObject.Hits.Total == null ||
				responseObject.Hits.Total.Value == null ||
				responseObject.Hits.Total.Value.Value == 0
			) {
				return false;
			}

			return true;

		} catch (Exception oops) {
			Console.WriteLine ($"error checking if postal code exists using {endpointUrl} {postalCodeReader} index, {countryCode} {postalCode} : {oops.Message}");
			return false;
		}
	}

	public async Task<bool> WritePostalCodes (
		List<Models.OpenSearch.PostalCountry> records
	) {
		ArgumentNullException.ThrowIfNull (records);

		try {
			// Prepare bulk request body for Elasticsearch _bulk API
			var bulkBody = new System.Text.StringBuilder ();
			foreach (var record in records) {
				var indexAction = new {
					index = new {
						_index = postalCodeWriter,
						_id = record.PostalCountryCd
					}
				};
				bulkBody.AppendLine (JsonConvert.SerializeObject (indexAction));
				bulkBody.AppendLine (JsonConvert.SerializeObject (record));
			}

			var bulkContent = new StringContent (bulkBody.ToString (), Encoding.UTF8, "application/x-ndjson");

			var bulkUri = $"{endpointUrl}/{postalCodeWriter}/_bulk";
			var bulkRequest = new HttpRequestMessage (
				HttpMethod.Post,
				bulkUri
			) {
				Content = bulkContent
			};

			var bulkResponse = await httpClient.SendAsync (bulkRequest);
			bulkResponse.EnsureSuccessStatusCode ();

			var bulkResponseString = await bulkResponse.Content.ReadAsStringAsync ();
			Console.WriteLine (bulkResponseString);


		} catch (Exception oops) {
			Console.WriteLine ($"WritePostalCodes failure : {oops.Message}");
			return false;
		}

		return true;
	}
}