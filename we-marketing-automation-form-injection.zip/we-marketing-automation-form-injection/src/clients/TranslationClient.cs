using System.Linq;
using System.Net.Http;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using WeMarketingAutomationFormInjection.Models;
using Amazon.Runtime;

namespace WeMarketingAutomationFormInjection;

public interface ITranslationClient
{
	Task<MachineTranslationsResponse<T>> Translate<T> (MachineTranslationsModel<T> input);
	T MergeCulture<T> (string locale);
	T LoadCulture<T> (string locale);
}

public class TranslationClient : ITranslationClient
{
	private static HttpClient translationClient = new ();
	private string i18nBasePath;
	private Models.MachineTranslationConfig machineConfig;
	private Models.MachineTranslationConfig machineConfigFallback;

	public TranslationClient (
		IWebHostEnvironment env,
		IConfiguration config
	) {
		// the container /app directory is immutable.
		// so when running in non-local, the i18n directory is copied to /tmp and we will operate from there
		if (env.IsLocal ()) {
			this.i18nBasePath = Path.Combine (env.WebRootPath, "i18n");
		} else {
			this.i18nBasePath = Path.Combine ("/tmp", "i18n");
		}
		this.machineConfig = config.GetSection ("MachineTranslation").Get<Models.MachineTranslationConfig> ()!;
		this.machineConfigFallback = config.GetSection ("MachineTranslationFallback").Get<Models.MachineTranslationConfig> ()!;
	}

	// 2025-12-18 here's a fun one. new translation endpoint
	// i'm really not loving what i had to do here
	// the new endpoint has a max Values input of 20. my strongly typed common translations class has more than that
	// i need to break it down into JObjects, roll through the properties in batches, and merge down the responses into one object to become the strongly types object again
	public async Task<MachineTranslationsResponse<T>> Translate<T> (
		 MachineTranslationsModel<T> input
	) {
		ArgumentNullException.ThrowIfNull (input);

		if (input.Values == null) {
			throw new Exception ($"No values provided to translate");
		}

		// unfortunately, the new translation endpoint doesn't yet support ja-JP and zh-CN which i need
		// so we'll keep two machine configs and fallback to the old one in the event of a 400 error (that seems to be the error i get for unsupported locales)
		MachineTranslationConfig machineConfigToUse = machineConfig;
		var hasRetried = false;

	retry:

		// Convert the entire input to JObject
		var inputObj = JObject.FromObject (input);

		var trimmedResult = getTrimmedValuesObject (inputObj, machineConfig.BatchSize);

		// there is nothing to translate! bad input. this should NOT happen since the original input was checked. but let's be sure things are working correctly
		if (trimmedResult.Trimmed == null) {
			throw new Exception ($"No values provided to translate");
		}

		JObject? baseObject = null;
		var mergeSettings = new JsonMergeSettings {
			MergeArrayHandling = MergeArrayHandling.Union
		};

		// loop until there is no more
		while (trimmedResult.Trimmed != null) {
			// temporarily print out the values
			var valuesObj = (JObject?)trimmedResult.Trimmed["values"];
			if (valuesObj != null) {
				Console.WriteLine ($"Trimmed values count: {valuesObj.Count}");
				Console.WriteLine (JsonConvert.SerializeObject (valuesObj, Formatting.Indented));
			}

			// translate
			JObject translatedObject;
			try {
				translatedObject = await translate<T> (machineConfigToUse, JsonConvert.SerializeObject (trimmedResult.Trimmed, Formatting.Indented), input.TargetCulture!);
			} catch (System.Net.Http.HttpRequestException) {
				if (hasRetried) {
					throw;
				}
				machineConfigToUse = machineConfigFallback;
				hasRetried = true;
				goto retry;
			}

			if (baseObject == null) {
				baseObject = translatedObject;
			} else {
				if (translatedObject != null) {
					baseObject.Merge (translatedObject, mergeSettings);
				}
			}

			if (trimmedResult.Remainder == null) {
				break;
			}

			trimmedResult = getTrimmedValuesObject (trimmedResult.Remainder, machineConfigToUse.BatchSize);
		}

		// convert the baseObject to a strongly typed class
		if (baseObject == null) {
			throw new Exception ($"No translations to return");
		}

		var responseObject = baseObject.ToObject<MachineTranslationsResponse<T>> ()!;

		// TODO: the file stuff needs to be removed from this function. this is is more than just "Translate"
		var locale = input.TargetCulture!;

		if (responseObject.Values != null) {
			WriteTranslationsToFile (locale, (responseObject.Values as CommonTranslationValues)!);
		}

		return responseObject;
	}

	private async Task<JObject> translate<T> (
		MachineTranslationConfig mconfig,
		string jsonPayload,
		string targetCulture
	) {
		try {
			var method = HttpMethod.Post;

			var request = new HttpRequestMessage (method, mconfig.ProtocolAnddomain + mconfig.Route) {
				Content = new StringContent (jsonPayload)
			};
			request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse ("application/json");
			request.Content.Headers.Add ("api-client-id", mconfig.ApiClientId);

			var response = await translationClient.SendAsync (request);

			response.EnsureSuccessStatusCode ();

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				throw new Exception ($"No translation found for locale {targetCulture}");
			}

			var responseObject = JObject.Parse (responseString);

			if (responseObject == null) {
				throw new Exception ($"No translation found for locale {targetCulture}");
			}

			return responseObject;
		} catch (System.Net.Http.HttpRequestException oops) {
			Console.WriteLine ($"error in translation {oops.Message} with payload `{jsonPayload}`");
			throw;
		} catch (Exception) {
			throw;
		}
	}

	// return trimmed object and remainder object
	private static (JObject? Trimmed, JObject? Remainder) getTrimmedValuesObject (
		JObject input,
		int batchSize
	) {
		var valuesObj = (JObject?)input["values"];

		if (valuesObj == null || valuesObj.Count == 0) {
			return (null, null);
		}

		if (valuesObj.Count > batchSize) {

			// Trim to first (batchSize) properties
			var trimmedValues = new JObject (
				valuesObj.Properties ().Take (batchSize)
			);

			// Store the remaining values
			var remainingValues = new JObject (
				valuesObj.Properties ().Skip (batchSize)
			);

			// Replace the Values property with the trimmed version
			input["values"] = trimmedValues;

			// create a new input with the remaining values
			var remainderInput = (JObject)input.DeepClone ();
			remainderInput["values"] = remainingValues;

			return (input, remainderInput);
		}

		// otherwise just return the object and no remainder object
		return (input, null);
	}

	public void WriteTranslationsToFile (
		string locale,
		CommonTranslationValues responseValues
	) {
		var lang = locale.Split ('-')[0];

		if (Directory.Exists ($"{this.i18nBasePath}/{lang}") == false) {
			Directory.CreateDirectory ($"{this.i18nBasePath}/{lang}");
		}

		File.WriteAllText ($"{this.i18nBasePath}/{lang}/resources.{locale}.machine-translations.jsonc", JsonConvert.SerializeObject (responseValues, formatting: Formatting.Indented));
	}

	public T MergeCulture<T> (
		string locale
	) {

		var lang = locale.Split ('-')[0];

		var machinePath = $"{this.i18nBasePath}/{lang}/resources.{locale}.machine-translations.jsonc";
		var transPath = $"{this.i18nBasePath}/{lang}/resources.{locale}.transperfect.jsonc";
		var humanPath = $"{this.i18nBasePath}/{lang}/resources.{locale}.overrides.jsonc";

		// at the very least a machine translation is required
		if (File.Exists (machinePath) == false) {
			throw new FileNotFoundException ($"no machine translation found for {locale}");
		}

		JObject machineObj = JObject.Parse (File.ReadAllText (machinePath));
		JObject? transObj = null;
		JObject? humanObj = null;

		if (File.Exists (transPath)) {
			transObj = JObject.Parse (File.ReadAllText (transPath));
		}
		if (File.Exists (humanPath)) {
			humanObj = JObject.Parse (File.ReadAllText (humanPath));
		}

		var mergeSettings = new JsonMergeSettings {
			MergeArrayHandling = MergeArrayHandling.Union
		};

		if (transObj != null) {
			machineObj.Merge (transObj, mergeSettings);
		}

		if (humanObj != null) {
			machineObj.Merge (humanObj, mergeSettings);
		}

		var result = machineObj.ToObject<T> ();

		if (result == null) {
			throw new FileNotFoundException ($"no translations found for {locale}");
		}

		File.WriteAllText ($"{this.i18nBasePath}/resources.{locale}.jsonc", JsonConvert.SerializeObject (result, formatting: Formatting.Indented));

		return result;
	}

	public T LoadCulture<T> (
		string locale
	) {

		var path = $"{this.i18nBasePath}/resources.{locale}.jsonc";

		// if it does not exist at first, kick it back up to MergeCulture
		if (File.Exists (path) == false) {
			var merged = MergeCulture<T> (locale);
			return merged;
		}

		if (File.Exists (path) == false) {
			throw new FileNotFoundException ($"Culture file not found for {locale}");
		}

		return JsonConvert.DeserializeObject<T> (File.ReadAllText (path))!;
	}
}

// this doesn't really belong here, but here it goes
public class TranslationManager
{
	public TranslationManager (
		IWebHostEnvironment env,
		ITranslationClient translationClient
	) {

		// the container /app directory is immutable.
		// so when running in non-local, the i18n directory is copied to /tmp and we will operate from there
		if (env.IsLocal ()) {
			this.i18nBasePath = Path.Combine (env.WebRootPath, "i18n");
		} else {
			this.i18nBasePath = Path.Combine ("/tmp", "i18n");
		}

		this.translationClient = translationClient;

		if (Directory.Exists (i18nBasePath) == false) {
			Directory.CreateDirectory (i18nBasePath);
		}

		// now if not local, copy the contents of /app/i18n to /tmp/i18n
		if (env.IsLocal () == false && Directory.Exists (Path.Combine (env.WebRootPath, "i18n"))) {
			try {
				Utils.CopyDirectory ("/app/i18n", this.i18nBasePath, true);
			} catch (Exception oops) {
				Console.WriteLine ($"Error copying /app/i18n to {this.i18nBasePath}");
				Console.WriteLine (oops.ToString ());
			}
		}
	}

	public async Task<CommonTranslationValues> Get (
		string locale
	) {

		if (commonTranslationCache.ContainsKey (locale)) {
			Console.WriteLine ($"TranslationManager.Get returning cached translations for {locale}");
			return commonTranslationCache[locale];
		}

		bool getMachineTranslation = false;
		string lang = locale.Split ('-')[0];

		if (Directory.Exists (Path.Combine (this.i18nBasePath, lang)) == false) {
			getMachineTranslation = true;
#if WINDOWS_OS
			Directory.CreateDirectory (Path.Combine (this.i18nBasePath, lang));
#else
			Directory.CreateDirectory (Path.Combine (this.i18nBasePath, lang), UnixFileMode.UserExecute);
#endif
		}

		string machineFilePath = $"{Path.Combine (this.i18nBasePath, lang)}/resources.{locale}.machine-translations.jsonc";

		if (File.Exists (machineFilePath) == false) {
			getMachineTranslation = true;
		}

		lock (syncroot) {
			if (defaultTranslations.ContainsKey (locale) == false) {
				defaultTranslations.TryAdd (
					locale,
					 new MachineTranslationsModel<CommonTranslationValues> () {
						 Values = new CommonTranslationValues (),
						 SourceCulture = "en-US",
						 TargetCulture = locale
					 }
				);
			}
		}

		MachineTranslationsModel<CommonTranslationValues>? machineTranslation = null;

		if (getMachineTranslation) {
			try {
				System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch ();
				timer.Start ();
				machineTranslation = await translationClient.Translate<CommonTranslationValues> (defaultTranslations[locale]);
				timer.Stop ();
				Console.WriteLine ($"TranslationClient.Get ({locale}) time taken : {timer.Elapsed.ToString (@"m\:ss\.fff")}");
			} catch (Exception oops) {
				// for now, let it fall through and add the en-US version as the locale being detected just to get by while i investigate
				Console.WriteLine (oops.ToString ());
				machineTranslation = defaultTranslations[locale];
			}
		}

		if (machineTranslation != null) {
			// i got here because the machine translation fle didn't exist. create it
			try {
				Console.WriteLine ($"TranslationManager.Get writing machine translations for {locale} to {machineFilePath}");
				File.WriteAllText (machineFilePath, JsonConvert.SerializeObject (machineTranslation.Values, formatting: Formatting.Indented));
			} catch (Exception oops) {
				Console.WriteLine ($"error writing {machineFilePath}, {oops.Message}");
			}

			machineTranslation.Values = translationClient.MergeCulture<CommonTranslationValues> (locale);
		}

		lock (syncroot) {
			if (commonTranslationCache.ContainsKey (locale) == false) {

				// var translationValues = translationClient.LoadCulture<CommonTranslationValues> (locale);
				// do a fresh merge instead. regenerate the merged file
				Console.WriteLine ($"TranslationManager.Get MergeCulture for {locale}");
				var translationValues = translationClient.MergeCulture<CommonTranslationValues> (locale);

				if (translationValues == null) {
					commonTranslationCache.TryAdd (locale, defaultTranslations["en-US"].Values!);
				} else {
					commonTranslationCache.TryAdd (locale, translationValues);
				}
			}
		}

		return commonTranslationCache[locale];
	}

	// static method to force a full regeneration of machine translations and merge files
	internal static void RegenerateAllTranslations (
		IWebHostEnvironment env,
		ITranslationClient translationClient
	) {
		string i18nBasePath = Path.Combine (env.WebRootPath, "i18n");

		if (env.IsLocal () == false) {
			i18nBasePath = Path.Combine ("/tmp", "i18n");
		}

		var directories = Directory.GetDirectories (i18nBasePath);

		foreach (var directory in directories) {
			var di = new DirectoryInfo (directory);
			if (di == null) {
				continue;
			}
			string lang = di.Name;

			// get all machine translations. extract the locale from the file name
			var machineFiles = Directory.GetFiles (directory, "*machine*");

			foreach (var machineFile in machineFiles) {
				// the file name pattern is resources.{locale}.machine-translations.jsonc
				// not bothering with regex since i can split on the .
				var filename = Path.GetFileName (machineFile);
				if (filename == null || filename.Contains ('.') == false) {
					continue;
				}
				string locale = filename.Split ('.')[1];

				var translationTask = translationClient.Translate<CommonTranslationValues> (new MachineTranslationsModel<CommonTranslationValues> () {
					Values = new CommonTranslationValues (),
					SourceCulture = "en-US",
					TargetCulture = locale
				});
				translationTask.Wait ();
				translationClient.MergeCulture<CommonTranslationValues> (locale);
			}

			Console.WriteLine ();
		}
	}

	// regenerate a single translation
	internal static string RegenerateTranslation (
		IWebHostEnvironment env,
		ITranslationClient translationClient,
		string locale
	) {
		string i18nBasePath = Path.Combine (env.WebRootPath, "i18n");

		if (env.IsLocal () == false) {
			i18nBasePath = Path.Combine ("/tmp", "i18n");
		}

		if (locale.IndexOf ('-') == -1) {
			return $"invalid locale : {locale}";
		}

		string lang = locale.Split ('-')[0];

		var directoryInfo = new DirectoryInfo (Path.Combine (i18nBasePath, lang));

		if (directoryInfo == null) {
			return $"language {lang} does not appear to exist in this project yet. cannot be regenerated";
		}

		// get all machine translations. extract the locale from the file name
		var machineFiles = Directory.GetFiles (directoryInfo.ToString (), "*machine*");

		bool localeFound = false;

		foreach (var machineFile in machineFiles) {
			// the file name pattern is resources.{locale}.machine-translations.jsonc
			// not bothering with regex since i can split on the .
			var filename = Path.GetFileName (machineFile);
			if (filename == null || filename.Contains ('.') == false) {
				continue;
			}

			string localeOfFile = filename.Split ('.')[1];

			if (locale != localeOfFile) {
				continue;
			}

			localeFound = true;

			try {
				var translationTask = translationClient.Translate<CommonTranslationValues> (new MachineTranslationsModel<CommonTranslationValues> () {
					Values = new CommonTranslationValues (),
					SourceCulture = "en-US",
					TargetCulture = locale
				});
				translationTask.Wait ();
				translationClient.MergeCulture<CommonTranslationValues> (locale);
			} catch (Exception oops) {
				return $"error regenerating {locale} : {oops.Message}";
			}
		}

		if (localeFound == false) {
			return $"{locale} not found and not regenerated";
		}

		return $"{locale} regenerated";
	}

	// for diagnostics, expose the internal cache
	public static Dictionary<string, CommonTranslationValues> GetTemplateCache (

	) {
		// i'm going to return a shallow copy instead
		lock (syncroot) {
			return new Dictionary<string, CommonTranslationValues> (commonTranslationCache);
		}
	}

	public static void FlushTemplateCache () {
		lock (syncroot) {
			commonTranslationCache.Clear ();
		}
	}

	private ITranslationClient translationClient;
	private string i18nBasePath;
	private static Dictionary<string, MachineTranslationsModel<CommonTranslationValues>> defaultTranslations = [];
	private static Dictionary<string, CommonTranslationValues> commonTranslationCache = []; // keyed by locale
	private static object syncroot = new object ();
}

// i need to figure out where i want this to live as a separate file
public class JsonStringLocalizer : IStringLocalizer
{
	private readonly string baseDirectory;
	private readonly JsonSerializer _serializer = new JsonSerializer ();
	private static Dictionary<string, TemplateCache> cache = new ();
	private static object syncroot = new object ();

	public JsonStringLocalizer (
		IWebHostEnvironment env
	) {
		if (env.IsLocal ()) {
			this.baseDirectory = Path.Combine (env.WebRootPath, "i18n");
		} else {
			this.baseDirectory = Path.Combine ("/tmp", "i18n");
		}
	}

	public LocalizedString this[string name] {
		get {
			string? value = GetString (name);
			return new LocalizedString (name, value ?? name, value == null);
		}
	}

	public LocalizedString this[string name, params object[] arguments] {
		get {
			var actualValue = this[name];
			return !actualValue.ResourceNotFound
				? new LocalizedString (name, string.Format (actualValue.Value, arguments), false)
				: actualValue;
		}
	}

	public IEnumerable<LocalizedString> GetAllStrings (
		bool includeParentCultures
	) {
		string filePath = $"{this.baseDirectory}/resources.{System.Threading.Thread.CurrentThread.CurrentCulture.Name}.jsonc";

		using (var str = new FileStream (filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
		using (var sReader = new StreamReader (str))
		using (var reader = new JsonTextReader (sReader)) {
			while (reader.Read ()) {
				if (reader.TokenType != JsonToken.PropertyName) {
					continue;
				}
				if (reader.Value == null) {
					continue;
				}

				string key = (string)reader.Value;

				reader.Read ();

				string value = _serializer.Deserialize<string> (reader)!;

				yield return new LocalizedString (key, value, false);
			}
		}
	}

	private string? GetString (
		string key
	) {
		string filePath = $"{this.baseDirectory}/resources.{System.Threading.Thread.CurrentThread.CurrentCulture.Name}.jsonc";

		if (File.Exists (filePath)) {
			string cacheKey = $"locale_{Thread.CurrentThread.CurrentCulture.Name}_{key}";

			lock (syncroot) {
				if (cache.ContainsKey (cacheKey)) {
					var cacheHit = cache[cacheKey];

					if (DateTimeOffset.Now < cacheHit.CacheTill) {
						return cacheHit.CacheContent;
					}

					// too old! purge!
					cache.Remove (cacheKey);
				}
			}

			string? result = GetValueFromJSON (key, filePath);

			if (!string.IsNullOrEmpty (result)) {
				lock (syncroot) {
					cache.TryAdd (
						cacheKey,
						new TemplateCache (result, 60 * 5)
					);
				}
			}

			return result;
		}

		return null;
	}

	private string? GetValueFromJSON (
		string propertyName,
		string filePath
	) {
		if (propertyName == null) return default;
		if (filePath == null) return default;

		using (var str = new FileStream (filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
		using (var sReader = new StreamReader (str))
		using (var reader = new JsonTextReader (sReader)) {
			while (reader.Read ()) {
				if (reader.Value == null) {
					continue;
				}

				if (reader.TokenType == JsonToken.PropertyName && (string)reader.Value == propertyName) {
					reader.Read ();
					return _serializer.Deserialize<string> (reader);
				}
			}
			return null;
		}
	}

}