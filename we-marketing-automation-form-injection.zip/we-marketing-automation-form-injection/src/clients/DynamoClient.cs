using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2.DocumentModel;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;

namespace WeMarketingAutomationFormInjection;

public interface IDynamoClient
{
	Task<Models.Form?> GetForm (string cd, string locale);
	// TODO : list all forms
	Task UpsertForm (Models.Form form);
	Task DeleteForm (string cd, string locale);
	// Task InsertLog (Models.DynamoDb.FormRequestLog requestlog);
	// Task<List<Models.DynamoDb.FormRequestLog>> GetAllFormRequestLogSince (string formcd, string locale, DateTimeOffset sinceDt);
	// Task<List<Models.DynamoDb.FormRequestLog>> GetAllFormRequestLogSince (string formcd, string locale, DateTimeOffset sinceDt, string method);
	Task<Models.Country3to2?> GetCountry3to2 (string three);
	Task<Models.Country2to3?> GetCountry2to3 (string two);
	//Task<Models.PostalCountry?> GetPostalCountry (string postalCd, string countryCd);
	Task InsertCountry2to3 (Models.Country2to3 request);
	Task InsertCountry3to2 (Models.Country3to2 request);
	Task AddDomain (string domain, string statusCd = "ok");
	Task<List<Models.DomainStatus>> GetAllGoodDomainsSince (DateTimeOffset sinceDt);
	Task<List<Models.DomainStatus>> GetAllBadDomainsSince (DateTimeOffset sinceDt);
	Task<List<Models.DomainStatus>> GetAllDomainsSince (DateTimeOffset sinceDt, string statusCd);
	Task DeleteDomain (string domain, string statusCd);

	//Task DescribeTable (string table)
}

public class DynamoClient : IDynamoClient
{
	public DynamoClient (
		IConfiguration config,
		IWebHostEnvironment env,
		IDynamoDBContext dynamoDBContext
	) {
		this.context = dynamoDBContext;

		if (env.IsLocal ()) {
			this.client = new AmazonDynamoDBClient (new AmazonDynamoDBConfig () {
				RegionEndpoint = Amazon.RegionEndpoint.USEast1,
				Profile = new Profile (Program.AWS_LOCAL_ROLE_NAME)
			});
		} else {
			this.client = new AmazonDynamoDBClient ();
		}

		var dynamoTables = config.GetSection ("DynamoTables").Get<Models.DynamoTables> ();

		if (dynamoTables == null) {
			throw new NullReferenceException ("'DynamoTables' configuration section is missing");
		}

		this.tables = dynamoTables;
	}

	public async Task<Models.Form?> GetForm (
		string cd,
		string locale
	) {
		var conf = new LoadConfig () {
			OverrideTableName = tables.Form
		};

		Models.Form? form = null;

		try {
			form = await context.LoadAsync<Models.Form> (cd, locale, conf);
		} catch (Exception oops) {
			Console.WriteLine ($"error getting form data : {oops.Message}");
		}

		return form;
	}

	public async Task UpsertForm (
		Models.Form form
	) {
		var conf = new SaveConfig () {
			OverrideTableName = tables.Form
		};

		await context.SaveAsync<Models.Form> (form, conf);
	}

	public async Task DeleteForm (
		string cd,
		string locale
	) {
		var conf = new DeleteConfig () {
			OverrideTableName = tables.Form
		};

		await context.DeleteAsync<Models.Form> (cd, locale, conf);
	}

	// public async Task InsertLog (
	// 	Models.DynamoDb.FormRequestLog requestlog
	// ) {

	// 	var conf = new DynamoDBOperationConfig () {
	// 		OverrideTableName = tables.RequestLog
	// 	};

	// 	try {
	// 		await context.SaveAsync<Models.DynamoDb.FormRequestLog> (requestlog, conf);
	// 	} catch (Exception oops) {
	// 		Console.WriteLine ($"Error inserting request log : {JsonConvert.SerializeObject (requestlog)}");
	// 		Console.WriteLine (oops.ToString ());
	// 	}
	// }

	// public async Task<List<Models.DynamoDb.FormRequestLog>> GetAllFormRequestLogSince (
	// 	string formcd,
	// 	string locale,
	// 	DateTimeOffset sinceDt
	// ) {

	// 	string conditionExpression = "formcd = :fcd and locale = :lc";

	// 	var query = new QueryRequest {
	// 		TableName = tables.RequestLog,
	// 		IndexName = "formcd_by_locale_index",
	// 		KeyConditionExpression = conditionExpression,
	// 		FilterExpression = "requestdt > :rdt",
	// 		ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
	// 			{":fcd", new AttributeValue { S = formcd}},
	// 			{":lc", new AttributeValue { S = locale }},
	// 			{":rdt", new AttributeValue { N = sinceDt.ToUnixTimeMilliseconds ().ToString()}}
	// 		}
	// 	};

	// 	var context = new DynamoDBContext (client);

	// 	var ret = new List<Models.DynamoDb.FormRequestLog> ();

	// paginationNext:

	// 	var response = await client.QueryAsync (query);

	// 	foreach (Dictionary<string, AttributeValue> item in response.Items) {
	// 		var doc = Document.FromAttributeMap (item);
	// 		var typedDoc = context.FromDocument<Models.DynamoDb.FormRequestLog> (doc);
	// 		ret.Add (typedDoc);
	// 	}

	// 	// pagination of results when over 1MiB
	// 	if (response.LastEvaluatedKey.Count > 0) {
	// 		query.ExclusiveStartKey = response.LastEvaluatedKey;
	// 		goto paginationNext;
	// 	}

	// 	return ret;
	// }

	// public async Task<List<Models.DynamoDb.FormRequestLog>> GetAllFormRequestLogSince (
	// 	string formcd,
	// 	string locale,
	// 	DateTimeOffset sinceDt,
	// 	string method
	// ) {

	// 	string conditionExpression = "formcd = :fcd and locale = :lc";

	// 	var query = new QueryRequest {
	// 		TableName = tables.RequestLog,
	// 		IndexName = "formcd_by_locale_index",
	// 		KeyConditionExpression = conditionExpression,
	// 		FilterExpression = "requestdt > :rdt and #m = :mtd",
	// 		ExpressionAttributeNames = new Dictionary<string, string> {
	// 			{"#m", "method"} // method is a reserved word, so this is basically an alias
	// 		},
	// 		ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
	// 			{":fcd", new AttributeValue { S = formcd}},
	// 			{":lc", new AttributeValue { S = locale }},
	// 			{":rdt", new AttributeValue { N = sinceDt.ToUnixTimeMilliseconds ().ToString()}},
	// 			{":mtd", new AttributeValue { S = method }}
	// 		}
	// 	};

	// 	var context = new DynamoDBContext (client);

	// 	var ret = new List<Models.DynamoDb.FormRequestLog> ();

	// paginationNext:

	// 	var response = await client.QueryAsync (query);

	// 	foreach (Dictionary<string, AttributeValue> item in response.Items) {
	// 		var doc = Document.FromAttributeMap (item);
	// 		var typedDoc = context.FromDocument<Models.DynamoDb.FormRequestLog> (doc);
	// 		ret.Add (typedDoc);
	// 	}

	// 	// pagination of results when over 1MiB
	// 	if (response.LastEvaluatedKey.Count > 0) {
	// 		query.ExclusiveStartKey = response.LastEvaluatedKey;
	// 		goto paginationNext;
	// 	}

	// 	return ret;
	// }

	public async Task<Models.Country3to2?> GetCountry3to2 (
		string three
	) {
		var conf = new LoadConfig () {
			OverrideTableName = tables.Country3to2
		};

		Models.Country3to2? country3to2 = null;

		try {
			country3to2 = await context.LoadAsync<Models.Country3to2> (three, conf);
		} catch (Exception oops) {
			Console.WriteLine ($"error getting Country3to2 data : {oops.Message}");
		}

		return country3to2;
	}

	public async Task<Models.Country2to3?> GetCountry2to3 (
		string two
	) {
		var conf = new LoadConfig () {
			OverrideTableName = tables.Country2to3
		};

		Models.Country2to3? country2to3 = null;

		try {
			country2to3 = await context.LoadAsync<Models.Country2to3> (two, conf);
		} catch (Exception oops) {
			Console.WriteLine ($"error getting Country2to3 data : {oops.Message}");
		}

		return country2to3;
	}

	// public async Task<Models.PostalCountry?> GetPostalCountry (
	// 	string postalCd,
	// 	string countryCd
	// ) {

	// 	var conf = new DynamoDBOperationConfig () {
	// 		OverrideTableName = tables.PostalCountry
	// 	};

	// 	Models.PostalCountry? postalCountry = null;

	// 	try {
	// 		postalCountry = await context.LoadAsync<Models.PostalCountry> ($"{countryCd}-{postalCd}", conf);
	// 	} catch (Exception oops) {
	// 		Console.WriteLine ($"error getting PostalCountry data : {oops.Message}");
	// 	}

	// 	return postalCountry;
	// }

	public async Task InsertCountry2to3 (
		Models.Country2to3 request
	) {
		var conf = new SaveConfig () {
			OverrideTableName = tables.Country2to3
		};

		await context.SaveAsync<Models.Country2to3> (request, conf);
	}

	public async Task InsertCountry3to2 (
		Models.Country3to2 request
	) {
		var conf = new SaveConfig () {
			OverrideTableName = tables.Country3to2
		};

		await context.SaveAsync<Models.Country3to2> (request, conf);
	}

	public async Task AddDomain (
		string domain,
		string statusCd = "ok"
	) {
		var conf = new SaveConfig () {
			OverrideTableName = tables.DomainStatus
		};

		var now = DateTimeOffset.Now;

		var obj = new Models.DomainStatus {
			Domain = domain,
			StatusCd = statusCd,
			StatusDt = now.ToUnixTimeMilliseconds (),
			Timestamp = now.ToString ("yyyy-MM-dd HH:mm:ss:fff zzz")
		};

		await context.SaveAsync<Models.DomainStatus> (obj, conf);
	}

	public async Task<List<Models.DomainStatus>> GetAllDomainsSince (
		DateTimeOffset sinceDt,
		string statusCd // "ok", "bad"
	) {
		var query = new QueryRequest {
			TableName = tables.DomainStatus,
			IndexName = "statuscd_by_time_index",
			KeyConditionExpression = "statuscd = :scd and statusdt > :sdt",
			ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
				{":scd", new AttributeValue { S = statusCd}},
				{":sdt", new AttributeValue { N = sinceDt.ToUnixTimeMilliseconds ().ToString()}}
			}
		};

		// var context = new DynamoDBContext (client);
		// var context = new DynamoDBContextBuilder ()
		// 	.WithDynamoDBClient (() => client)
		// 	.Build ();

		var ret = new List<Models.DomainStatus> ();

	paginationNext:

		var response = await client.QueryAsync (query);

		if (response == null) {
			return ret;
		}

		foreach (Dictionary<string, AttributeValue> item in response.Items) {
			var doc = Document.FromAttributeMap (item);
			var typedDoc = context.FromDocument<Models.DomainStatus> (doc);
			ret.Add (typedDoc);
		}

		// pagination of results when over 1MiB
		if (response.LastEvaluatedKey != null && response.LastEvaluatedKey.Count > 0) {
			query.ExclusiveStartKey = response.LastEvaluatedKey;
			goto paginationNext;
		}

		return ret;
	}

	public async Task<List<Models.DomainStatus>> GetAllGoodDomainsSince (
		DateTimeOffset sinceDt
	) {
		return await GetAllDomainsSince (sinceDt, "ok");
	}

	public async Task<List<Models.DomainStatus>> GetAllBadDomainsSince (
		DateTimeOffset sinceDt
	) {
		return await GetAllDomainsSince (sinceDt, "bad");
	}

	// kill things which should not be there
	public async Task DeleteDomain (
		string domain,
		string statusCd
	) {
		var conf = new DeleteConfig () {
			OverrideTableName = tables.DomainStatus
		};

		await context.DeleteAsync<Models.DomainStatus> (domain, statusCd, conf);
	}

	private Models.DynamoTables tables;
	private IDynamoDBContext context;
	private AmazonDynamoDBClient client;
}