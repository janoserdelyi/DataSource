using StackExchange.Redis;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;

namespace WeMarketingAutomationFormInjection;

public interface IValkeyClient
{
	// these interfaces will change. this is p[urely for initial testing that access to valkey is functioning in the envs
	public Task<bool> SetString (string key, string val, TimeSpan? expiry = null);
	public Task<RedisValue> GetString (string key);
}

public class ValkeyClient : IValkeyClient
{
	private readonly IDatabase? db;

	public ValkeyClient (
		IConfiguration config,
		IWebHostEnvironment env
	) {

		var endpoint = config.GetSection ("ValKeyEndpoint").Get<string> ();

		if (string.IsNullOrEmpty (endpoint)) {
			return;
		}

		var options = new ConfigurationOptions {
			EndPoints = {
				endpoint
			},
			Ssl = true
		};

		var redis = ConnectionMultiplexer.Connect (options);
		db = redis.GetDatabase ();
	}

	public async Task<bool> SetString (
		string key,
		string val,
		TimeSpan? expiry = null
	) {
		if (db == null) {
			throw new Exception ("no database configure. possibly missing an endpoint url");
		}

		return await db.StringSetAsync (key, val, expiry: expiry);
	}

	public async Task<RedisValue> GetString (
		string key
	) {
		if (db == null) {
			throw new Exception ("no database configure. possibly missing an endpoint url");
		}

		return await db.StringGetAsync (key);
	}

}