namespace WeMarketingAutomationFormInjection;

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Amazon.S3;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Extensions.NETCore.Setup;
using System.Linq;
using System.Threading.RateLimiting;
using Amazon.IdentityManagement.Model;
using Datadog.Trace;
using Datadog.Trace.Configuration;

public class Program
{
	public static void Main (
		string[] args
	) {
		// go ahead and auth2aws if running local
#if (WINDOWS_OS || DEBUG)
		Utils.AuthAws (AWS_LOCAL_ROLE_NAME);
#endif

		var settings = TracerSettings.FromDefaultSources ();
		Tracer.Configure (settings);

		string webrootPath = getWebRootPath ();

		var builder = WebApplication.CreateBuilder (args);
		builder.Host.ConfigureAppSettings (webrootPath);

		var basePath = builder.Configuration.GetSection ("BasePath").Get<string> ();
		var servingDomain = builder.Configuration.GetSection ("ServingDomain").Get<string> ();

		RootUrl = createRootUrl (servingDomain, basePath);

		// builder.Services.AddAuthorization (options => {
		// 	options.AddPolicy ("is_admin", policy => {
		// 		policy.RequireAuthenticatedUser ();
		// 		policy.RequireClaim ("admin", "true");
		// 	});
		// });

		// https://dev.azure.com/costargroup/DotNetExtensions/_search?action=preview&text=ProfilesLocation&type=code&lp=code-Project&filters=ProjectFilters%7BDotNetExtensions%7DRepositoryFilters%7BDotNetExtensions%7D&pageSize=25&result=DefaultCollection/DotNetExtensions/DotNetExtensions/GBmain//Aws.CredentialRotation/README.md
		// builder.Services.AddDefaultAWSOptionsWithRotatingCredentials (builder.Configuration);

		builder.Services.AddAWSService<IAmazonS3> (ServiceLifetime.Singleton);
		builder.Services.AddAWSService<IAmazonDynamoDB> (ServiceLifetime.Singleton);

		builder.Services.AddSingleton<IDynamoDBContext, DynamoDBContext> ();
		builder.Services.AddSingleton<IDynamoClient, DynamoClient> ();
		builder.Services.AddSingleton<ITranslationClient, TranslationClient> ();
		builder.Services.AddSingleton<IOpenSearchClient, OpenSearchClient> ();
		builder.Services.AddSingleton<IValkeyClient, ValkeyClient> ();

		var cors = builder.Configuration.GetSection ("CorsDomains").Get<string[]> ();
		var initCors = cors != null && cors.Length > 0;

		if (initCors) {
			builder.Services.AddCors (options => {
				options.AddPolicy (name: CORS_POLICY_NAME, policy => {
					policy.WithOrigins (cors!);
					policy.WithMethods (["GET", "POST", "OPTIONS"]);
					policy.WithHeaders (["Content-Type"]);
				});
			});

			// i don't have access to environment at this point, so if on a windows machine (assumed to be local dev), then hard-set a good dns server
			// otherwise the local dns servers don't place nice, there are many of them, and it slows down project development
			// the prep-processor use to be WINDOWS_OS here, but i was somehow seeing 1.1.1.1 poke through in other environments
			// debug is only local so this should be good to go
#if DEBUG
			AllowedIps = Utils.GetARecordIpAddresses ([.. cors!], ["1.1.1.1"]).Result;
#else
			AllowedIps = Utils.GetARecordIpAddresses ([.. cors!], DnsServers).Result;

			// add 13.111.250.0-15 for salesforce
			for (int i = 0; i < 16; i++) {
				var ipaddr = System.Net.IPAddress.Parse ($"13.111.250.{i}");
				if (AllowedIps.ContainsKey (ipaddr) == false) {
					AllowedIps.Add (ipaddr, "SalesForce Marketing Cloud");
				}
			}

			// just testing. adding my home to verify routes through the public akamai route
			AllowedIps.Add (System.Net.IPAddress.Parse ("71.176.211.4"), "janos home");
#endif

		}

		var myOptions = new Models.RateLimitOptions ();
		builder.Configuration.GetSection (Models.RateLimitOptions.SectionName).Bind (myOptions);

		// https://learn.microsoft.com/en-us/aspnet/core/performance/rate-limit?view=aspnetcore-8.0
		builder.Services.AddRateLimiter (_ => _
			.AddSlidingWindowLimiter (
				policyName: RATE_LIMIT_POLICY_NAME,
				options => {
					options.PermitLimit = myOptions.PermitLimit;
					options.Window = TimeSpan.FromSeconds (myOptions.Window);
					options.SegmentsPerWindow = myOptions.SegmentsPerWindow;
					options.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
					options.QueueLimit = myOptions.QueueLimit;
				}
			));

		builder.Services.AddCarter (configurator: c => {
			c.WithResponseNegotiator<NewtonsoftCustomResponseNegotiator> ();
			// Don't scan for validators at all
			c.WithEmptyValidators ();
		});

		builder.Services.AddHttpClient ();

		#region openapi
		// builder.Services.AddEndpointsApiExplorer ();

		// builder.Services.AddSwaggerGen (options => {
		// 	options.SwaggerDoc ("v1", new OpenApiInfo {
		// 		Description = "CoStar Group Form Injection",
		// 		Version = "v1",
		// 		Title = "A Carter API to manage form ingestion across the enterprise"
		// 	});

		// 	options.DocInclusionPredicate ((s, description) => {
		// 		foreach (var metaData in description.ActionDescriptor.EndpointMetadata) {
		// 			if (metaData is IIncludeOpenApi) {
		// 				return true;
		// 			}
		// 		}
		// 		return false;
		// 	});
		// });

		// builder.Services.AddCarter ();
		#endregion

		// enumerateValidatorRegistrations (builder);

		var app = builder.Build ();

		IWebHostEnvironment environment = app.Environment;
		app.Environment.WebRootPath = webrootPath;

		// if (environment.IsProduction () == false) {
		// 	app.UseSwagger ();
		// 	app.UseSwaggerUI (c => {
		// 		c.SwaggerEndpoint ("/swagger/v1/swagger.json", "Marketing Automation API v1");
		// 		c.RoutePrefix = "swagger";
		// 		c.DisplayRequestDuration ();
		// 		c.EnableDeepLinking ();
		// 		c.EnableFilter ();
		// 	});
		// }

		if (environment.IsLocal () && AllowedIps != null) {
			if (System.Net.IPAddress.TryParse ("127.0.0.1", out System.Net.IPAddress? localIpv4)) {
				if (AllowedIps.ContainsKey (localIpv4) == false) {
					AllowedIps.Add (localIpv4, "localhost");
				}
			}
			if (System.Net.IPAddress.TryParse ("::1", out System.Net.IPAddress? localIpv6)) {
				if (AllowedIps.ContainsKey (localIpv6) == false) {
					AllowedIps.Add (localIpv6, "localhost");
				}
			}
		}

		app.UseRateLimiter ();
		app.UseBansAndBlocks ();
		app.UseRequestLocalization ();

		if (!string.IsNullOrEmpty (basePath)) {
			app.UsePathBase (basePath);
		}

		if (initCors) {
			app.UseCors (CORS_POLICY_NAME);
		}

		app.UseJwt ();

		int cachePeriod = app.Configuration.GetValue<int> ("Cache:Static:CachePeriod");

		app.UseStaticFiles (new StaticFileOptions () {
			FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider (Path.Combine (webrootPath, "staticfiles")),
			RequestPath = "/static",
			OnPrepareResponse = ctx => {
				var corsPolicyProvider = app.Services.GetRequiredService<Microsoft.AspNetCore.Cors.Infrastructure.ICorsPolicyProvider> ();
				var corsService = app.Services.GetRequiredService<Microsoft.AspNetCore.Cors.Infrastructure.ICorsService> ();

				var policy = corsPolicyProvider.GetPolicyAsync (ctx.Context, CORS_POLICY_NAME)
					.ConfigureAwait (false)
					.GetAwaiter ().GetResult ();

				if (policy != null) {
					var corsResult = corsService.EvaluatePolicy (ctx.Context, policy);
					corsService.ApplyResult (corsResult, ctx.Context.Response);
				}

				ctx.Context.Response.Headers.Append ("Cache-Control", $"public, max-age={cachePeriod}");
			}
		});

		app.UseRequestLogging ();
		app.UsePathBaseInterception ();

		app.MapCarter ();

		app.Run ();
	}

	private static string getWebRootPath () {
		// ok, this is truly awful, but i'm doing it
		// when running in a container, it's in the root-level /app directory.
		// we don't have that locally. let's just see if that exists
		if (Directory.Exists ("/app")) {
			return "/app";
		}

		Console.WriteLine ("/app directory not found. attempting to detect");

		var currentDir = System.Environment.CurrentDirectory;

		var lastDir = new DirectoryInfo (currentDir).Name;

		if (lastDir == "src" || lastDir == "app") {
			return currentDir;
		}

		var bin = $"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}";
		var app = $"{Path.DirectorySeparatorChar}app{Path.DirectorySeparatorChar}";

		// work back through the parent tree while the current path still contains bin
		// the currentDir doesn't end with a directory separator, so i add it for comparison. i don't want a directory like "binary" to match with "bin" so i bracket it in
		while ((currentDir + Path.DirectorySeparatorChar).Contains (bin) || (currentDir + Path.DirectorySeparatorChar).Contains (app)) {
			currentDir = Directory.GetParent (currentDir)!.FullName;
		}

		return currentDir;
	}

	private static string createRootUrl (
		string? servingDomain,
		string? basePath
	) {
		if (!string.IsNullOrEmpty (servingDomain) && !string.IsNullOrEmpty (basePath)) {
			return servingDomain + basePath;
		}

		if (string.IsNullOrEmpty (servingDomain) && !string.IsNullOrEmpty (basePath)) {
			return basePath;
		}

		if (!string.IsNullOrEmpty (servingDomain) && string.IsNullOrEmpty (basePath)) {
			return servingDomain;
		}

		return "";
	}

	// some fun debugging
	private static void enumerateValidatorRegistrations (
		WebApplicationBuilder builder
	) {
		Console.WriteLine ("=== Searching for Validator Registrations ===");
		var validators = builder.Services
			.Where (s => s.ServiceType.Namespace?.Contains ("FluentValidation") == true ||
						s.ServiceType.Name.Contains ("Validator") ||
						s.ImplementationType?.Name.Contains ("Validator") == true)
			.ToList ();

		foreach (var v in validators) {
			Console.WriteLine ($"Service: {v.ServiceType.FullName}");
			Console.WriteLine ($"  Impl: {v.ImplementationType?.FullName ?? "Instance/Factory"}");
			Console.WriteLine ();
		}
	}

	public const string AWS_LOCAL_ROLE_NAME = "aws_enterprise_dev_developers";
	public const string CORS_POLICY_NAME = "BrandLevelCorsPolicy";
	public const string RATE_LIMIT_POLICY_NAME = "sliding";
	public static string RootUrl = ""; // this is the combination of ServingDomain and BasePath appsettings
	public static readonly DateTimeOffset StartTime = DateTimeOffset.Now;
	public static List<string> DnsServers { get; private set; } = Utils.GetMachineDns ();
	public static Dictionary<System.Net.IPAddress, string>? AllowedIps { get; private set; }
	public static IDictionary<string, List<string>> Roles { get; private set; } = new Dictionary<string, List<string>> {
		{"is_admin", ["admin"]}
	}; // key is policy name. value is collection of roles
}

public static class HostExtensions
{
	public static IHostBuilder ConfigureAppSettings (
		this IHostBuilder host,
		string webrootPath
	) {
		var environment = Environment.GetEnvironmentVariable ("ASPNETCORE_ENVIRONMENT");

		host.ConfigureAppConfiguration ((ctx, builder) => {
			builder.AddJsonFile (Path.Combine (webrootPath, "appsettings/appsettings.json"), false, true);
			builder.AddJsonFile (Path.Combine (webrootPath, $"appsettings/appsettings.{environment}.json"), true, true);
			builder.AddEnvironmentVariables ();
		});

		return host;
	}
}