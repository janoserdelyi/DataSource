using DNS.Client;
using DNS.Protocol;
using DNS.Protocol.ResourceRecords;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Amazon.S3.Util;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System.Linq;

namespace WeMarketingAutomationFormInjection;

public static partial class Utils
{

	private static bool emailValidationFirstRun = true;
	private static MxConfig? mxConfig = null;
	private static IList<string> disallowDomains = [];

	public static string GetLocaleCd (
		HttpContext ctx
	) {
		string? localeCd = ctx.GetCurrentCulture ()?.IetfLanguageTag;

		// check the Accept-Language header. it will have values like "en-US,en;q=0.7,es;q=0.3" but beware, it may also just have a value like "en"
		if (string.IsNullOrEmpty (localeCd) && !string.IsNullOrEmpty (ctx.Request.Headers.AcceptLanguage)) {
			string firstValue = ctx.Request.Headers.AcceptLanguage.ToString ().Split (',')[0];
			if (firstValue.Contains ('-')) {
				localeCd = firstValue;
			}
		}

		if (string.IsNullOrEmpty (localeCd)) {
			localeCd = "en-US";
		}

		return localeCd;
	}

	internal static SecurityToken? ValidateToken (
		string token,
		string keyId
	) {
		ArgumentNullException.ThrowIfNull (token);

		string privateKey = VaultKeyProvider.GetKeyContents (keyId);

		var tokenHandler = new JwtSecurityTokenHandler ();
		var key = Encoding.ASCII.GetBytes (privateKey);

		try {
			tokenHandler.ValidateToken (
				token,
				new TokenValidationParameters () {
					ValidateIssuerSigningKey = true,
					IssuerSigningKey = new SymmetricSecurityKey (key),
					ValidateIssuer = false,
					ValidateAudience = false,
					ClockSkew = TimeSpan.Zero
				},
				out SecurityToken validatedToken
			);

			var jwtToken = (JwtSecurityToken)validatedToken;

			return jwtToken;
		} catch (Exception oops) {
			Console.WriteLine (oops.ToString ());
			return null;
		}
	}

	internal static SecurityToken? ValidateRsaToken (
		string token,
		string keyId
	) {
		ArgumentNullException.ThrowIfNull (token);

		string privateKey = VaultKeyProvider.GetKeyContents (keyId);

		var rsa = System.Security.Cryptography.RSA.Create ();
		rsa.ImportFromPem (privateKey);
		var signingKey = new RsaSecurityKey (rsa) { KeyId = keyId };

		var tokenHandler = new JwtSecurityTokenHandler ();
		var key = Encoding.ASCII.GetBytes (privateKey);

		try {
			tokenHandler.ValidateToken (
				token,
				new TokenValidationParameters () {
					ValidateIssuerSigningKey = true,
					IssuerSigningKey = signingKey,
					ValidateIssuer = false,
					ValidateAudience = false,
					ClockSkew = TimeSpan.Zero
				},
				out SecurityToken validatedToken
			);

			var jwtToken = (JwtSecurityToken)validatedToken;

			return jwtToken;
		} catch (Exception oops) {
			Console.WriteLine (oops.Message);
			return null;
		}
	}

	internal static string CreateJwt (
		string keyId,
		string issuer,
		string audience,
		IList<Claim> claims,
		DateTime expireDt
	) {

		string privateKey = VaultKeyProvider.GetKeyContents (keyId);

		var key = Encoding.ASCII.GetBytes (privateKey);
		var symmetricKey = new SymmetricSecurityKey (key) {
			KeyId = keyId
		};

		var tokenDescriptor = new SecurityTokenDescriptor () {
			Subject = new ClaimsIdentity (claims),
			Expires = expireDt,
			SigningCredentials = new SigningCredentials (symmetricKey, SecurityAlgorithms.HmacSha256),
			Issuer = issuer,
			Audience = audience
		};

		var tokenHandler = new JwtSecurityTokenHandler ();

		SecurityToken? token = null;

		try {
			token = tokenHandler.CreateToken (tokenDescriptor);
		} catch (Exception oops) {
			Console.WriteLine (oops.ToString ());
			throw;
		}

		return tokenHandler.WriteToken (token);
	}

	internal static string CreateRsaJwt (
		string keyId,
		DateTime expireDt,
		IList<Claim>? claims = null,
		string? issuer = null,
		string? audience = null
	) {

		string privateKey = VaultKeyProvider.GetKeyContents (keyId);

		var rsa = System.Security.Cryptography.RSA.Create ();
		rsa.ImportFromPem (privateKey);

		var credentials = new SigningCredentials (
			new RsaSecurityKey (rsa) { KeyId = keyId },
			SecurityAlgorithms.RsaSha256
		) {
			CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
		};

		// =================================================

		var tokenDescriptor = new SecurityTokenDescriptor () {
			Expires = expireDt,
			SigningCredentials = credentials
		};
		if (claims != null) {
			tokenDescriptor.Subject = new ClaimsIdentity (claims);
		}
		if (issuer != null) {
			tokenDescriptor.Issuer = issuer;
		}
		if (audience != null) {
			tokenDescriptor.Audience = audience;
		}

		var tokenHandler = new JwtSecurityTokenHandler ();

		SecurityToken? token = null;

		try {
			token = tokenHandler.CreateToken (tokenDescriptor);
		} catch (Exception oops) {
			Console.WriteLine (oops.ToString ());
			throw;
		}

		return tokenHandler.WriteToken (token);
	}

	// from https://tfs.prd.costargroup.com/CoStarCollection/CoStar%20One/_git/we-marketing-system-admin-services?path=/src/Domain/Helpers/SecretsManagerCacheHelper.cs&version=GBmain&_a=contents
	// with modifications to suit this env
	public static string Decrypt (
		string encryptedText,
		string initializationVector
	) {
		ArgumentNullException.ThrowIfNullOrWhiteSpace (encryptedText);
		ArgumentNullException.ThrowIfNullOrWhiteSpace (initializationVector);

		byte[] ivBytes = Encoding.UTF8.GetBytes (initializationVector);

		if (ivBytes.Length != 16) {
			throw new ArgumentException ("IV must be 16 bytes");
		}

		var encryptedBytes = Convert.FromBase64String (encryptedText);
		var iv = new byte[16];
		var cipher = new byte[encryptedBytes.Length - iv.Length];
		Buffer.BlockCopy (encryptedBytes, 0, iv, 0, iv.Length);
		Buffer.BlockCopy (encryptedBytes, iv.Length, cipher, 0, cipher.Length);

		using (var aesAlgorithm = Aes.Create ()) {
			using (var decrypter = aesAlgorithm.CreateDecryptor (ivBytes, iv)) {
				string result;
				using (var msDecrypt = new MemoryStream (cipher)) {
					using (var csDecrypt = new CryptoStream (msDecrypt, decrypter, CryptoStreamMode.Read)) {
						using (var srDecrypt = new StreamReader (csDecrypt)) {
							result = srDecrypt.ReadToEnd ();
						}
					}
				}

				return result;
			}
		}
	}

	public static string Encrypt (
		string inputText,
		string initializationVector
	) {
		ArgumentNullException.ThrowIfNullOrWhiteSpace (inputText);
		ArgumentNullException.ThrowIfNullOrWhiteSpace (initializationVector);

		byte[] ivBytes = Encoding.UTF8.GetBytes (initializationVector);

		if (ivBytes.Length != 16) {
			throw new ArgumentException ("IV must be 16 bytes");
		}

		using (var aesAlgorithm = Aes.Create ()) {
			using (var encrypter = aesAlgorithm.CreateEncryptor (ivBytes, aesAlgorithm.IV)) {
				using (var msEncrypt = new MemoryStream ()) {
					using (var csEncrypt = new CryptoStream (msEncrypt, encrypter, CryptoStreamMode.Write)) {
						using (var swEncrypt = new StreamWriter (csEncrypt)) {
							swEncrypt.Write (inputText);
						}
					}

					var iv = aesAlgorithm.IV;

					var decryptedContent = msEncrypt.ToArray ();

					// our full message is the IV followed by the encrypted bytes
					var result = new byte[iv.Length + decryptedContent.Length];

					Buffer.BlockCopy (iv, 0, result, 0, iv.Length);
					Buffer.BlockCopy (decryptedContent, 0, result, iv.Length, decryptedContent.Length);

					return Convert.ToBase64String (result);
				}
			}
		}
	}

	public static bool RemoveDisallowedDomain (
		string domain,
		IDynamoClient? dynamoClient = null
	) {
		if (disallowDomains.Contains (domain)) {
			disallowDomains.Remove (domain);

			if (dynamoClient != null) {
				try {
					var adtask = dynamoClient.DeleteDomain (
						domain,
						"bad"
					);
					adtask.Wait ();
				} catch (Exception oops) {
					Console.WriteLine ($"dynamoClient.DeleteDomain failed to delete domain {domain}");
					Console.WriteLine (oops.ToString ());
				}
			}

			return true;
		}
		return false;
	}

	public static bool AddDisallowedDomain (
		string domain,
		IDynamoClient? dynamoClient = null
	) {
		if (disallowDomains.Contains (domain)) {
			return false;
		}
		disallowDomains.Add (domain);

		if (dynamoClient != null) {
			try {
				var adtask = dynamoClient.AddDomain (
					domain,
					"bad"
				);
				adtask.Wait ();
			} catch (Exception oops) {
				Console.WriteLine ($"dynamoClient.AddDomain failed to add domain {domain}");
				Console.WriteLine (oops.ToString ());
			}
		}

		return true;
	}

	public static Result<Email>? RetestBadDomain (
		string domain,
		IDynamoClient dynamoClient
	) {
		// first remove it so that the test will try it
		var removed = RemoveDisallowedDomain (domain, dynamoClient);

		if (!removed) {
			return null;
		}

		// at this point i don't really care about the result - i'm not expressing it anywhere
		return ValidateEmailAddress ($"test@{domain}", true, dynamoClient);
	}

	public static void RetestAllBadDomains (
		IDynamoClient dynamoClient
	) {
		foreach (var domain in disallowDomains) {
			// first remove it so that the test will try it
			var removed = RemoveDisallowedDomain (domain, dynamoClient);

			if (!removed) {
				continue;
			}

			// at this point i don't really care about the result - i'm not expressing it anywhere
			ValidateEmailAddress ($"test@{domain}", true, dynamoClient);
		}
	}

	public static Result<Email> ValidateEmailAddress (
		string emailAddress,
		bool doFullCheck = false,
		IDynamoClient? dynamoClient = null
	) {

		if (emailValidationFirstRun) {

			if (dynamoClient != null) {
				var baddomains = dynamoClient.GetAllBadDomainsSince (DateTimeOffset.Now.AddDays (-7)).Result;
				foreach (var baddomain in baddomains) {
					disallowDomains.Add (baddomain.Domain);
				}
			}

			if (!disallowDomains.Contains ("test.com")) {
				disallowDomains.Add ("test.com");
			}

			if (!disallowDomains.Contains ("example.com")) {
				disallowDomains.Add ("example.com");
			}

			var dnsServers = Program.DnsServers;

			if (dnsServers.Count == 0) {
				dnsServers.Add ("172.20.0.10"); // hard-coded. at the time of this writing (2024-10-07) this is the cluster dns when deployed
			}

			var bypassDomains = new List<string> ();

			if (dynamoClient != null) {
				var bpdomains = dynamoClient.GetAllGoodDomainsSince (DateTimeOffset.Now.AddMonths (-3)).Result;
				foreach (var bpdomain in bpdomains) {
					bypassDomains.Add (bpdomain.Domain);
				}
			}

			if (bypassDomains.Count == 0) {
				bypassDomains = [
					"gmail.com",
					"yahoo.com",
					"yahoo.fr",
					"live.com",
					"outlook.com",
					"costar.com",
					"costargroup.com"
				];
			}

			mxConfig = new MxConfig () {
				BypassDomains = bypassDomains,
				DnsServers = dnsServers
			};

			emailValidationFirstRun = false;
		}

		var emailvalidator = Email.Validator (emailAddress)
			.Lower ()
			.Trim ()
			.ValidateFormat ()
			.Parse ();

		// splitting here after Parse() because i want to keep the domain for later to store as a bad domain (error's don't return all the parts)
		if (emailvalidator.IsFailure) {
			return emailvalidator;
		}

		string domain = emailvalidator.Value!.Domain!;

		emailvalidator = emailvalidator
			.LocalIsValid ()
			.CommonTypos ( // if you were to pass nothing into CommonTypos() this is the standard list you would get. but you can pass in a dictionary like this to override and extend the options
				new Dictionary<string, TypoMatch> () {
					["gmial.com"] = new TypoMatch ("gmial.com", "gmail.com", "'{typodomain}' is a squatter domain. Did you mean '{local}@{domain}'?"),
					["gamil.com"] = new TypoMatch ("gamil.com", "gmail.com"),
					["gmaul.com"] = new TypoMatch ("gmaul.com", "gmail.com"),
					["gnail.com"] = new TypoMatch ("gnail.com", "gmail.com"),
					["gmai.com"] = new TypoMatch ("gmai.com", "gmail.com"),
					["gmsil.com"] = new TypoMatch ("gmsil.com", "gmail.com"),
					["ail.com"] = new TypoMatch ("ail.com", "aol.com", "'{typodomain}' is a squatter domain. Did you mean '{local}@{domain}'?"),
					["hitnail.com"] = new TypoMatch ("hitnail.com", "hotmail.com"),
					["hitmail.com"] = new TypoMatch ("hitmail.com", "hotmail.com"),
					["hotnail.com"] = new TypoMatch ("hotnail.com", "hotmail.com")
				}
			)
			.DisallowDomains (disallowDomains)
			.DisallowTemporaryServiceDomains ( // https://github.com/disposable/disposable
				new TemporaryServiceConfig ("https://raw.githubusercontent.com/disposable/disposable-email-domains/master/domains.txt")
			).Result;

		// TODO: for lower environments, allow Mailinator.com addresses through so that Andrew can continue to test

		if (emailvalidator.IsFailure) {
			return emailvalidator;
		}

		if (doFullCheck == true) {

			emailvalidator = emailvalidator.VerifyMxRecords (mxConfig).Result;

			// add the success domain to dynamodb
			if (dynamoClient != null) {
				try {
					var adtask = dynamoClient.AddDomain (
						domain,
						emailvalidator.IsSuccess ? "ok" : "bad"
					);
					adtask.Wait ();
				} catch (Exception oops) {
					Console.WriteLine ($"dynamoClient.AddDomain failed to add domain for {emailAddress}");
					Console.WriteLine (oops.ToString ());
				}
			}
		}

		return emailvalidator;
	}

	public static IPAddress GetSourceIp (
		Microsoft.AspNetCore.Http.HttpRequest r
	) {
		ArgumentNullException.ThrowIfNull (r);

		if (r.Headers == null || r.Headers.Count == 0) {
			IPAddress? addr;

			if (IPAddress.TryParse (firstValue (r.Host.Host), out addr) == false) {
				throw new InvalidCastException ($"Unable to parse '{firstValue (r.Host.Host)}' as an IPAddress");
			}

			return addr;
		}

		IPAddress? ret =
			parseHeaderCommaSeparated (r.Headers, "x-forwarded-for") ??
			parseHeaderCommaSeparated (r.Headers, "true-client-ip") ??
			parseHeaderCommaSeparated (r.Headers, "x-real-ip") ??
			parseHeaderCommaSeparated (r.Headers, "x-client-ip") ??
			parseHeaderCommaSeparated (r.Headers, "CF-Connecting-IP") ??
			r.HttpContext.Connection.RemoteIpAddress
			;

		if (ret == null) {
			throw new Exception ("Unable to determine incoming ip address");
		}

		if (ret.IsIPv4MappedToIPv6) {
			return ret.MapToIPv4 ();
		}

		if (ret.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) {
			return ret.MapToIPv4 ();
		}

		if (ret.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6) {
			return ret.MapToIPv6 ();
		}

		throw new Exception ("Unable to determine incoming ip address");
	}

	private static IPAddress? parseHeaderCommaSeparated (
		IHeaderDictionary headers,
		string headerName,
		int offset = 0
	) {
		if (!headers.ContainsKey (headerName)) {
			return null;
		}

		var values = headers[headerName];

		if (values.Count > offset) {
			if (IPAddress.TryParse (values[offset], out var addr)) {
				return addr;
			}
		}

		return null;
	}

	// // some environments, like aws with loadbalancers, can return multi-ips in the headers
	private static string firstValue (string ips) {
		if (ips.Contains (',') == false) {
			return ips;
		}
		return ips.Split (',', StringSplitOptions.RemoveEmptyEntries)[0];
	}

	// private static string secondValue (string ips) {
	// 	if (ips.Contains(',') == false) {
	// 		return ips;
	// 	}
	// 	return ips.Split(',', StringSplitOptions.RemoveEmptyEntries)[1];
	// }

	// private static string stripPort (string ip) {
	// 	if (ip.Split(':').Length == 2) { // catch only ipv4 with ports, not ipv6
	// 		return ip.Split(':')[0];
	// 	}
	// 	return ip;
	// }

	// this is a way to get files from s3, but without getting it from s3 every single time
	// TODO: store the s3 object's etag (essentially an md5 hash) along with our own has of the object. try GetObjectMetadataAsync
	public static string GetTemplateContentsFromS3 (
		IAmazonS3 s3client,
		string templateUrl, // this should be a full s3:// url
		bool reduceContent = false
	) {
		string content = "";
		string? contentType = null;
		string? etag = null;

		// the templateUrl is also the cachekey
		lock (syncroot) {
			if (templateCache.TryGetValue (templateUrl, out TemplateCache? cacheHit)) {

				if (cacheHit == null) {
					goto purge;
				}

				if (DateTimeOffset.Now < cacheHit.CacheTill) {
					return cacheHit.CacheContent;
				}

				// if the cache time has passed, check etag and reset cache time if the tags match
				if (cacheHit.ETag != null) {
					etag = GetS3TemplateEtag (templateUrl, s3client);

					if (cacheHit.ETag == etag) {
						templateCache[templateUrl].CacheTill = DateTimeOffset.Now.AddSeconds (60);
						return cacheHit.CacheContent;
					}
				}

			purge:
				// too old! purge!
				templateCache.Remove (templateUrl);
			}
		}


		if (!AmazonS3Uri.TryParseAmazonS3Uri (templateUrl, out AmazonS3Uri s3Uri)) {
			throw new ArgumentOutOfRangeException (nameof (templateUrl));
		}

		var uri = new AmazonS3Uri (templateUrl);

		try {
			using (var objectRepsonse = s3client.GetObjectAsync (uri.Bucket, uri.Key).Result) {

				contentType = objectRepsonse.Headers.ContentType.ToLower ();
				etag = objectRepsonse.ETag;

				using (var reader = new StreamReader (objectRepsonse.ResponseStream)) {
					content = reader.ReadToEnd ();
				}
			}
		} catch (Exception oops) {
			throw new Exception ($"Error getting '{uri.Key}' from bucket '{uri.Bucket}' : {oops.Message}", oops);
		}

		// before caching, minify the content here in-line
		if (reduceContent) {
			if (templateUrl.EndsWith (".js") || contentType == "text/javascript") {
				content = ReduceJavascript (content);
			}
			if (templateUrl.EndsWith (".css") || contentType == "text/css") {
				content = ReduceCss (content);
			}
		}

		lock (syncroot) {
			if (templateCache.ContainsKey (templateUrl)) {
				templateCache.Remove (templateUrl);
			}
			templateCache.TryAdd (
				templateUrl,
				new TemplateCache (content, etag: etag)
			);
		}

		return content;
	}

	// another take. get the base template, get its etag
	// do the reductions, translations etc
	// store the etag with the final-final result
	// only flush cache on etag change
	public static string? GetProcessedTemplate (
		string templatePath,
		Microsoft.AspNetCore.Hosting.IWebHostEnvironment env,
		Models.Form form,
		IAmazonS3 s3client,
		TranslationManager translationManager
	) {

		string cacheKey = $"{templatePath}_{form.Cd}_{form.Locale}";
		string environmentName = env.SanitizedEnvironment ();
		string? etag = null;

		if (templateCache.ContainsKey (cacheKey)) {

			TemplateCache? cacheHit = null;

			lock (syncroot) {
				cacheHit = templateCache[cacheKey];
			}

			if (cacheHit == null) {
				goto purge;
			}

			// if we are within the cache time, return the contents. if not, do a fresh etag check.
			// if that also differs, purge
			if (DateTimeOffset.Now > cacheHit.CacheTill) {
				if (cacheHit.ETag == null) {
					goto purge;
				}

				etag = GetS3TemplateEtag (templatePath, s3client);

				if (etag != cacheHit.ETag) {
					goto purge;
				}

				// we're still good. no need to re-process.
				// update the CacheTill and return the contents
				lock (syncroot) {
					templateCache[cacheKey].CacheTill = DateTimeOffset.Now.AddSeconds (60);
				}
			}

			// Console.WriteLine ($"Utils.GetProcessedTemplate cache hit on {cacheKey}");
			return cacheHit.CacheContent;

		purge:
			// too old! purge!
			lock (syncroot) {
				templateCache.Remove (cacheKey);
			}
		}

		// process and cache
		string? templateContents = GetTemplateContents (
			templatePath,
			!(environmentName == "local" || environmentName == "dev.main"),
			s3client
		);

		if (templateContents == null) {
			return null;
		}

		templateContents = GetTranslatedTemplateContents (
			templateContents,
			environmentName,
			form,
			translationManager
		);

		if (templateContents == null) {
			return null;
		}

		etag ??= GetS3TemplateEtag (templatePath, s3client);

		lock (syncroot) {
			templateCache.TryAdd (cacheKey, new TemplateCache (templateContents, etag: etag));
		}

		return templateContents;
	}

	public static string? GetS3TemplateEtag (
		string templatePath,
		IAmazonS3 s3client
	) {
		if (templatePath.StartsWith ("s3://") == false) {
			return null;
		}

		try {
			if (!AmazonS3Uri.TryParseAmazonS3Uri (templatePath, out AmazonS3Uri s3Uri)) {
				throw new ArgumentOutOfRangeException (nameof (templatePath));
			}

			var uri = new AmazonS3Uri (templatePath);

			try {
				var objectRepsonse = s3client.GetObjectMetadataAsync (uri.Bucket, uri.Key).Result;

				return objectRepsonse.ETag;
			} catch (Exception oops) {
				throw new Exception ($"Error getting '{uri.Key}' from bucket '{uri.Bucket}' : {oops.Message}", oops);
			}
		} catch (Exception oops) {
			Console.WriteLine ($"GetS3TemplateEtag failed for template {templatePath} : {oops.Message}");
			return null;
		}
	}

	// this will get from either the local filesystem or from s3 depending on the formation of the provided path
	public static string? GetTemplateContents (
		string templatePath,
		bool reduceContent,
		IAmazonS3 s3client
	) {
		string? templateContents = null;

		if (templatePath.StartsWith ("s3://")) {
			try {
				templateContents = Utils.GetTemplateContentsFromS3 (s3client, templatePath, reduceContent: reduceContent);
			} catch (ArgumentOutOfRangeException oops) {
				Console.WriteLine ($"error getting {templatePath} : {oops.Message}");
				templateContents = null;
			}
		} else {
			try {
				templateContents = File.ReadAllText (templatePath);
				if (reduceContent) {
					if (templatePath.EndsWith (".js")) {
						templateContents = ReduceJavascript (templateContents);
					}
					if (templatePath.EndsWith (".css")) {
						templateContents = ReduceCss (templateContents);
					}
				}
				// note i'm not caching. this is largely for local development
			} catch {
				templateContents = null;
			}
		}

		return templateContents;
	}

	[Obsolete ("use the other version of this with fewer arguments")]
	public static string GetTranslatedTemplateContents (
		string templateContents,
		string locale,
		string cacheKey, // this is templatePath_formcd_locale
		string environmentName,
		Models.Form form,
		Microsoft.AspNetCore.Hosting.IWebHostEnvironment env,
		TranslationManager translationManager
	) {

		System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch ();

		// the templateUrl is also the cachekey
		if (templateCache.ContainsKey (cacheKey)) {

			TemplateCache? cacheHit = null;

			lock (syncroot) {
				cacheHit = templateCache[cacheKey];
			}

			if (cacheHit == null) {
				goto purge;
			}

			if (DateTimeOffset.Now < cacheHit.CacheTill) {
				Console.WriteLine ($"Utils.GetTranslatedTemplateContents cache hit on {cacheKey}");
				return cacheHit.CacheContent;
			}

		purge:
			// too old! purge!
			lock (syncroot) {
				templateCache.Remove (cacheKey);
			}
		}

		// do the stuff
		Models.CommonTranslationValues? translations = null;

		try {
			timer.Start ();
			translations = translationManager.Get (locale).Result;
			timer.Stop ();
			Console.WriteLine ($"translationManager.Get for {locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");
		} catch (Exception oops) {
			throw new TranslationException ($"Error translating for locale {locale}", oops);
		}

		timer.Reset ();
		timer.Start ();
		var translationsSerialized = Newtonsoft.Json.JsonConvert.SerializeObject (translations);
		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents translationsSerialized for {form.Cd} {locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		timer.Reset ();
		timer.Start ();
		// just a quick example. if we wanted to inject values that we know we would prefer to inject...
		// i really should inject a json object and consume that in the javascript
		templateContents = templateContents
			.Replace ("{{scriptcd}}", form.Cd)
			.Replace ("{{injectionPoint}}", form.InjectionPoint)
			.Replace ("{{locale}}", form.Locale)
			.Replace ("{{environment}}", environmentName)
			.Replace ("{{rooturl}}", Program.RootUrl)
			.Replace ("{{config}}", form.AddedConfig ?? "{}")
			.Replace ("\"{{translations}}\"", translationsSerialized);

		// thinking about replacing this with handlebars.net (except for the translations token. that's a special case)
		// i don't see how it's possible that i gain any performance benefit though, more it would just make this code look nicer
		// var localizer = new JsonStringLocalizer (env);

		// templateContents = templateContents
		// 	.Replace ("{{label.FirstName}}", localizer["firstName"])
		// 	.Replace ("{{label.LastName}}", localizer["lastName"])
		// 	.Replace ("{{label.EmailAddress}}", localizer["email"])
		// 	.Replace ("{{label.CountryCode}}", localizer["country"])
		// 	.Replace ("{{label.StateCode}}", localizer["stateCode"])
		// 	.Replace ("{{label.PhoneNumber}}", localizer["phone"])
		// 	.Replace ("{{label.PostalCode}}", localizer["postalCode"])
		// 	.Replace ("{{label.CompanyName}}", localizer["company"])
		// 	.Replace ("{{label.Brand}}", localizer["brand"])
		// 	.Replace ("{{label.Required}}", localizer["required"])
		// 	.Replace ("{{label.SelectOne}}", localizer["selectOne"])
		// 	.Replace ("{{label.RequestType}}", localizer["requestType"]);

		templateContents = templateContents
			.Replace ("{{label.FirstName}}", translations.FirstName)
			.Replace ("{{label.LastName}}", translations.LastName)
			.Replace ("{{label.EmailAddress}}", translations.Email)
			.Replace ("{{label.CountryCode}}", translations.Country)
			.Replace ("{{label.StateCode}}", translations.StateCode)
			.Replace ("{{label.PhoneNumber}}", translations.Phone)
			.Replace ("{{label.PostalCode}}", translations.PostalCode)
			.Replace ("{{label.CompanyName}}", translations.Company)
			.Replace ("{{label.Brand}}", translations.Brand)
			.Replace ("{{label.Required}}", translations.Required)
			.Replace ("{{label.SelectOne}}", translations.SelectOne)
			.Replace ("{{label.RequestType}}", translations.RequestType);

		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents internal replacement for {form.Cd} {locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		timer.Reset ();
		timer.Start ();
		// if (env.IsLocal () == false) {
		templateContents = Utils.ReduceJavascript (templateContents);
		// }
		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents internal reduction for {form.Cd} {locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		lock (syncroot) {
			var added = templateCache.TryAdd (
				cacheKey,
				new TemplateCache (templateContents, cacheSeconds: 60 * 5)
			);
			Console.WriteLine ($"added {cacheKey} to templateCache? {added}");
		}

		return templateContents;
	}

	// this version does not have any of the caching bits in it - handled outside of this
	public static string GetTranslatedTemplateContents (
		string templateContents,
		string environmentName,
		Models.Form form,
		TranslationManager translationManager
	) {

		System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch ();

		// do the stuff
		Models.CommonTranslationValues? translations = null;

		try {
			timer.Start ();
			translations = translationManager.Get (form.Locale).Result;
			timer.Stop ();
			Console.WriteLine ($"translationManager.Get for {form.Locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");
		} catch (Exception oops) {
			throw new TranslationException ($"Error translating for locale {form.Locale}", oops);
		}

		timer.Reset ();
		timer.Start ();
		var translationsSerialized = Newtonsoft.Json.JsonConvert.SerializeObject (translations);
		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents translationsSerialized for {form.Cd} {form.Locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		timer.Reset ();
		timer.Start ();
		// just a quick example. if we wanted to inject values that we know we would prefer to inject...
		// i really should inject a json object and consume that in the javascript
		templateContents = templateContents
			.Replace ("{{scriptcd}}", form.Cd)
			.Replace ("{{injectionPoint}}", form.InjectionPoint)
			.Replace ("{{locale}}", form.Locale)
			.Replace ("{{environment}}", environmentName)
			.Replace ("{{rooturl}}", Program.RootUrl)
			.Replace ("{{config}}", form.AddedConfig ?? "{}")
			.Replace ("\"{{translations}}\"", translationsSerialized);

		templateContents = templateContents
			.Replace ("{{label.FirstName}}", translations.FirstName)
			.Replace ("{{label.LastName}}", translations.LastName)
			.Replace ("{{label.EmailAddress}}", translations.Email)
			.Replace ("{{label.CountryCode}}", translations.Country)
			.Replace ("{{label.StateCode}}", translations.StateCode)
			.Replace ("{{label.PhoneNumber}}", translations.Phone)
			.Replace ("{{label.PostalCode}}", translations.PostalCode)
			.Replace ("{{label.CompanyName}}", translations.Company)
			.Replace ("{{label.Brand}}", translations.Brand)
			.Replace ("{{label.Required}}", translations.Required)
			.Replace ("{{label.SelectOne}}", translations.SelectOne)
			.Replace ("{{label.RequestType}}", translations.RequestType);

		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents internal replacement for {form.Cd} {form.Locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		timer.Reset ();
		timer.Start ();
		if (!(environmentName == "local" || environmentName == "dev.main")) {
			templateContents = Utils.ReduceJavascript (templateContents);
		}
		timer.Stop ();
		Console.WriteLine ($"Utils.GetTranslatedTemplateContents internal reduction for {form.Cd} {form.Locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		return templateContents;
	}

	// just storing in memory for now. these aren't big. for example as of this writing the standard script is 13kB
	private static object syncroot = new object ();
	private static Dictionary<string, TemplateCache> templateCache = new Dictionary<string, TemplateCache> ();

	// for diagnostics, expose the internal cache
	public static Dictionary<string, TemplateCache> GetTemplateCache (

	) {
		// i'm going to return a shallow copy instead
		//return templateCache;
		lock (syncroot) {
			return new Dictionary<string, TemplateCache> (templateCache);
		}
	}

	public static void FlushTemplateCache () {
		//templateCache = new Dictionary<string, TemplateCache> ();
		lock (syncroot) {
			templateCache.Clear ();
		}
	}

	public static string ReduceJavascript (
		string content
	) {
		//first, reduce carriage return / line feeds to something more consistent and small
		content = RegexNewlineCarriageReturn ().Replace (content, "\n");

		//strip out all block comments
		content = RegexBlockCommentsOne ().Replace (content, "");
		content = RegexBolckCommentTwo ().Replace (content, "");

		//remove single line comments at the beginning of a line
		content = RegexSingleLineCommentStart ().Replace (content, "\n");
		//remove single line comments with space before them
		content = RegexSingleLineCommentLeadingSpaces ().Replace (content, "\n");
		content = RegexSingleLineCommentLeadingSpacesMulti ().Replace (content, "\n");

		//remove single-line comments which end up somewhere later in a line, but don't kill protocol-based lines like "http://". so dont strip if colon preceeds
		//i need a negative look-behind here
		//content = Regex.Replace(content, @"(.*?)//(.*?)\n", "$1\n", RegexOptions.Multiline);
		content = RegexSingleLineCommentInContent ().Replace (content, "$1\n");

		//strip out all tabs, replace them with spaces
		content = RegexTabsToSpaces ().Replace (content, " ");
		//but spaces which are at the beginning of a line can be killed
		content = RegexRemoveLeadingSpaces ().Replace (content, "");

		//replace multiple spaces with one
		content = RegexReduceSpacesToOne ().Replace (content, " ");

		//try to fix for loops that do not use curly braces around their scope
		//first normalize some things
		content = RegexForLoopOne ().Replace (content, "for (");
		content = RegexForLoopTwo ().Replace (content, "for ($1) { $2; }");

		//try to fix conditional "if"s that do not use curly braces around their scope
		//first normalize some things
		content = RegexIfConditionOne ().Replace (content, "if (");
		content = RegexIfConditionTwo ().Replace (content, "if ($1) { $2; }");
		//some more prototype devs being lazy imo
		content = RegexElseCondition ().Replace (content, "else { $1; }");

		//remove carriage returns after semi-colons. this should be safe.
		content = RegexReturnsAfterSemicolons ().Replace (content, ";");

		//just remove all newlines
		content = RegexRemoveNewlines ().Replace (content, "");

		//hit up spaces again
		content = RegexRemoveSpacePreCloseCurly ().Replace (content, "}");
		// content = RegexRemoveSpacePostCloseCurly ().Replace (content, "}"); // this is causing problems with literals and spaces after which are expected
		content = RegexRemoveSpacePreOpenCurly ().Replace (content, "{");
		content = RegexRemoveSpacePostOpenCurly ().Replace (content, "{");
		content = RegexRemoveSpacePreCloseParens ().Replace (content, ")");
		content = RegexRemoveSpacePostCloseParens ().Replace (content, ")");
		content = RegexRemoveSpacePreOpenParens ().Replace (content, "(");
		content = RegexRemoveSpacePostOpenParens ().Replace (content, "(");
		content = RegexRemoveSpacePostEquals ().Replace (content, "=");
		content = RegexRemoveSpacePreEquals ().Replace (content, "=");
		content = RegexRemoveSpacePrePlus ().Replace (content, "+");
		content = RegexRemoveSpacePostPlus ().Replace (content, "+");
		content = RegexRemoveSpaceInterCloseCurly ().Replace (content, "};}");
		//content = Regex.Replace(content, @") }", ")}");
		content = RegexRemoveSpacePostSemicolon ().Replace (content, ";");
		content = RegexRemoveSpacePostComma ().Replace (content, ",");
		content = RegexRemoveSpacePostColon ().Replace (content, ":");

		return content;
	}

	public static string ReduceCss (
		string content
	) {
		//strip out all comments
		//content = Regex.Replace(content, @"/\*(.*?)\*/", "", RegexOptions.Multiline);
		content = RegexRemoveBlockComments ().Replace (content, "");

		//strip out all tabs
		content = RegexTabsToSpaces ().Replace (content, "");

		//add a space after every semicolon, because it'm not completely cruel
		content = RegexAddSpacePostSemicolon ().Replace (content, "; ");

		//remove all carriage returns
		content = RegexNewlineCarriageReturn ().Replace (content, "\n");
		content = RegexRemoveNewlines ().Replace (content, "");

		//remove the trailing semicolon space when it's the last item
		content = RegexRemoveTrailingSpacePostSemicolon ().Replace (content, ";}");

		//now in an act of human decency, add a carriage return after each closing curly brace
		content = RegexAddReturnPostCloseCurly ().Replace (content, "}\n");

		//some people like to put a space between the attribute and the value. remove that
		//example - color: #fff; --> color:#fff;
		content = RegexRemoveSpacePostColon ().Replace (content, ":");

		//strip out all comments, second pass
		//content = Regex.Replace(content, @"/\*(.*?)\*/", "", RegexOptions.Multiline);

		//fix the way a horrid ie6 syntax hack gets broken by this ("\"}\"";)
		content = RegexFixIe6Garbage ().Replace (content, "}\\");

		//replace multiple spaces with one
		content = RegexReduceWhitespacesToOne ().Replace (content, " ");

		//now split the content and roll through it line-by-line
		string[] lines = content.Split ('\n');
		StringBuilder contentBuffer = new StringBuilder ();
		foreach (string line in lines) {
			//some style declarations are placeholders and empty. remove them
			string newline = line;
			if (newline.Contains ("{}") || newline.Contains ("{ }")) {
				newline = "";
			}

			if (newline.Length > 0) {
				contentBuffer.Append (newline);
				contentBuffer.Append ("\n");
			}
		}

		// you can end up with multiple import statements in a line. also with a trailing style declaration
		// drop a carriage return after
		content = Regex.Replace (contentBuffer.ToString (), @"(@import[^;]+;)", "$1\n");

		//spaces which are at the beginning of a line can be killed
		content = RegexRemoveLeadingSpaces ().Replace (content, "");

		return content;
	}

	// leave just numbers and plus
	public static string DeformatPhoneNumber (
		string input
	) {
		return Regex.Replace (input, "[^0-9\\+]+", "");
	}

	// TODO: i may also want to put a filesystemwatcher on the ~/.aws/credentials file
	public static void AuthAws (
		string roleName
	) {
		// look for an Amazon.S3.AmazonS3Exception? look for 'The provided toke has expired.' in the error message
		// inner exception with Amazon.Runtime.Internal.HttpErrorResponseException
		// just set a file wth a timestamp. don't bother re-authing if within the last 6 hours
		var timestamppath = Path.Combine (Environment.GetFolderPath (Environment.SpecialFolder.ApplicationData), "last-auth2aws.txt");

		if (File.Exists (timestamppath)) {
			var timestamptext = File.ReadAllText (timestamppath);
			if (DateTimeOffset.TryParse (timestamptext, out DateTimeOffset lastauthdt)) {
				if (DateTimeOffset.Now < lastauthdt.AddHours (6)) {
					// we're good. no need to auth
					return;
				}
			}
		}

		string auth2awsPath = Path.Combine (Environment.GetFolderPath (Environment.SpecialFolder.LocalApplicationData), @"Programs\auth2aws\auth2aws.exe");

		if (File.Exists (auth2awsPath) == false) {
			return;
		}

		System.Diagnostics.Process auth2aws = new System.Diagnostics.Process ();
		auth2aws.StartInfo.FileName = auth2awsPath;
		auth2aws.StartInfo.Arguments = $"login -r {roleName}";
		auth2aws.StartInfo.UseShellExecute = false;
		auth2aws.StartInfo.CreateNoWindow = true;
		auth2aws.StartInfo.RedirectStandardOutput = true;
		auth2aws.StartInfo.RedirectStandardError = true;
		auth2aws.EnableRaisingEvents = true;
		auth2aws.Start ();

		// left for debugging
		// var output = auth2aws.StandardOutput.ReadToEnd ();
		// var error = auth2aws.StandardError.ReadToEnd ();
		// Console.WriteLine ();

		// auth can take a few seconds so i'm sleeping the thread so that this project doesn't get started before the auth has occurred. otherwise you need to stop and start the project again
		System.Threading.Thread.Sleep (new TimeSpan (0, 0, 5));

		File.WriteAllText (timestamppath, DateTimeOffset.Now.ToString ());
	}

	public static List<string> GetMachineDns () {

		var dnsServers = new HashSet<string> ();

		NetworkInterface[]? adapters = null;

		try {
			adapters = NetworkInterface.GetAllNetworkInterfaces ().Where (adapter => adapter.OperationalStatus == OperationalStatus.Up).ToArray ();
		} catch (Exception oops) {
			Console.WriteLine ("error getting all network interfaces : ");
			Console.WriteLine (oops.ToString ());
			return dnsServers.ToList ();
		}

		if (adapters.Length == 0) {
			Console.WriteLine ("error getting all network interfaces : no interfaces found");
			return dnsServers.ToList ();
		}

		foreach (NetworkInterface adapter in adapters) {

			IPInterfaceProperties adapterProperties = adapter.GetIPProperties ();

			IPAddressCollection dnsAddresses = adapterProperties.DnsAddresses;

			if (dnsAddresses.Count > 0) {
				foreach (IPAddress dnsAddress in dnsAddresses) {
					if (dnsAddress.IsLinkLocalOrLoopback ()) {
						continue;
					}

					if (dnsServers.Contains (dnsAddress.ToString ()) == false) {
						dnsServers.Add (dnsAddress.ToString ());
					}
				}
			}
		}

		return dnsServers.ToList ();
	}

	public async static Task<Dictionary<System.Net.IPAddress, string>> GetARecordIpAddresses (
		List<string> domains,
		List<string> dnsServers
	) {
		ArgumentNullException.ThrowIfNull (domains);
		ArgumentNullException.ThrowIfNull (dnsServers);

		var rets = new Dictionary<System.Net.IPAddress, string> ();

		foreach (string domain in domains) {
			var d = domain;
			if (domain.StartsWith ("http")) {
				d = domain.Split ("//")[1];
			}

			// don't waste time plowing through all dns servers if you already got responses
			var receivedResponses = false;

			foreach (string dnsServer in dnsServers) {

				if (receivedResponses) {
					continue;
				}

				IResponse? aRecordResponse = null;
				try {
					aRecordResponse = await GetAnswersAsync (d, RecordType.A, dnsServer: dnsServer);
				} catch (Exception oops) {
					Console.WriteLine ("(A record lookup failure against dns '" + dnsServer + "' for '" + d + "') ");
					Console.WriteLine (oops.Message);
					continue;
				}

				if (aRecordResponse == null) {
					// Console.WriteLine ("no response!");
					continue;
				}

				foreach (IResourceRecord resourceRecord in aRecordResponse.AnswerRecords) {
					if (!(resourceRecord is IPAddressResourceRecord)) {
						// Console.WriteLine (resourceRecord.Name.ToString () + " is expecting IP Address Resource Record. this is not that");
						continue;
					}

					IPAddressResourceRecord ipRecord = (IPAddressResourceRecord)resourceRecord;

					// Console.WriteLine ($"{ipRecord.Name} - {ipRecord.IPAddress}");

					if (rets.ContainsKey (ipRecord.IPAddress) == false) {
						rets.Add (ipRecord.IPAddress, ipRecord.Name.ToString ());
					}

					receivedResponses = true;
				}
			}
		}

		return rets;
	}

	public async static Task<IResponse?> GetAnswersAsync (
		string domain,
		RecordType recordType,
		string dnsServer = "1.1.1.1",
		bool configureAwait = false
	) {
		ClientRequest request = new ClientRequest (dnsServer);

		request.Questions.Add (new Question (Domain.FromString (domain), recordType));
		request.RecursionDesired = true;

		IResponse? response = null;

		try {
			response = await request.Resolve ().ConfigureAwait (continueOnCapturedContext: configureAwait);
		} catch (DNS.Client.ResponseException oops) {
			if (!oops.Message.Contains ("NameError")) {
				throw;
			}

			if (response != null && response.ResponseCode == ResponseCode.NameError) {
				return response;
			}

			return null;
		}

		return response;
	}

	// from https://learn.microsoft.com/en-us/dotnet/standard/io/how-to-copy-directories with a few modifications
	public static void CopyDirectory (string sourceDir, string destinationDir, bool recursive) {
		// Get information about the source directory
		var dir = new DirectoryInfo (sourceDir);

		// Check if the source directory exists
		if (!dir.Exists) {
			throw new DirectoryNotFoundException ($"Source directory not found: {dir.FullName}");
		}

		// Cache directories before we start copying
		DirectoryInfo[] dirs = dir.GetDirectories ();

		// Create the destination directory
		Directory.CreateDirectory (destinationDir);

		// Get the files in the source directory and copy to the destination directory
		foreach (FileInfo file in dir.GetFiles ()) {
			string targetFilePath = Path.Combine (destinationDir, file.Name);
			file.CopyTo (targetFilePath, true);
		}

		// If recursive and copying subdirectories, recursively call this method
		if (recursive) {
			foreach (DirectoryInfo subDir in dirs) {
				string newDestinationDir = Path.Combine (destinationDir, subDir.Name);
				CopyDirectory (subDir.FullName, newDestinationDir, true);
			}
		}
	}

	public static string GetNoConflictValue (
		Func<string, bool> existenceChecker,
		bool isCaseSensitive = false,
		int initialKeyLength = 4
	) {
		int keylength = initialKeyLength;
		int collisions = 0;
		string val = Utils.GeneratePassword (isCaseSensitive, keylength);
		while (existenceChecker (val)) {
			collisions++;
			if (collisions > 2) {
				keylength++;
				collisions = 0;
			}
			val = Utils.GeneratePassword (isCaseSensitive, keylength);
		}

		return val;
	}

	public static string GeneratePassword (
		bool isCaseSensitive,
		int length
	) {
		string allowedChars = "@abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ0123456789";

		if (isCaseSensitive == false) {
			allowedChars = "@abcdefghijkmnopqrstuvwxyz0123456789";
		}

		return generateValue (allowedChars, length);
	}

	public static string GenerateNumericCode (
		int length
	) {

		const string allowedChars = "0123456789";

		return generateValue (allowedChars, length);
	}

	private static string generateValue (
		string allowedChars,
		int length
	) {
		char[] chars = new char[length];

		int seed = System.Security.Cryptography.RandomNumberGenerator.GetInt32 (System.Int32.MaxValue);

		Random random = new Random (seed);

		for (int i = 0; i < length; i++) {
			chars[i] = allowedChars[random.Next (0, allowedChars.Length - 1)];
		}

		return new string (chars);
	}

	public static string CreateMD5 (
		string input
	) {
		using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create ()) {
			byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes (input);
			byte[] hashBytes = md5.ComputeHash (inputBytes);
			return Convert.ToHexString (hashBytes);
		}
	}

	[GeneratedRegex (@"\r\n")]
	private static partial Regex RegexNewlineCarriageReturn ();
	[GeneratedRegex (@"^/\*(.*?)\*/", RegexOptions.Singleline)]
	private static partial Regex RegexBlockCommentsOne ();
	[GeneratedRegex (@"(\s){1,}/\*(.*?)\*/", RegexOptions.Singleline)]
	private static partial Regex RegexBolckCommentTwo ();
	[GeneratedRegex (@"^//(.*?)\n", RegexOptions.Multiline)]
	private static partial Regex RegexSingleLineCommentStart ();
	[GeneratedRegex (@" {1,}//(.*?)\n", RegexOptions.Multiline)]
	private static partial Regex RegexSingleLineCommentLeadingSpaces ();
	[GeneratedRegex (@"(\s){1,}//(.*?)\n", RegexOptions.Multiline)]
	private static partial Regex RegexSingleLineCommentLeadingSpacesMulti ();
	[GeneratedRegex (@"(.*?)(?<!:)//(.*?)\n", RegexOptions.Multiline)]
	private static partial Regex RegexSingleLineCommentInContent ();
	[GeneratedRegex (@"\t")]
	private static partial Regex RegexTabsToSpaces ();
	[GeneratedRegex (@"^(\s){1,}", RegexOptions.Multiline)]
	private static partial Regex RegexRemoveLeadingSpaces ();
	[GeneratedRegex (@" {2,}")]
	private static partial Regex RegexReduceSpacesToOne ();
	[GeneratedRegex (@"for\(")]
	private static partial Regex RegexForLoopOne ();
	[GeneratedRegex (@"for \((.*?)\)\n(.*?);")]
	private static partial Regex RegexForLoopTwo ();
	[GeneratedRegex (@"if\(")]
	private static partial Regex RegexIfConditionOne ();
	[GeneratedRegex (@"if \((.*?)\)\n(.*?);")]
	private static partial Regex RegexIfConditionTwo ();
	[GeneratedRegex (@"else\n(.*?);")]
	private static partial Regex RegexElseCondition ();
	[GeneratedRegex (@";\n")]
	private static partial Regex RegexReturnsAfterSemicolons ();
	[GeneratedRegex (@"\n")]
	private static partial Regex RegexRemoveNewlines ();
	[GeneratedRegex (@" }")]
	private static partial Regex RegexRemoveSpacePreCloseCurly ();
	[GeneratedRegex (@"} ")]
	private static partial Regex RegexRemoveSpacePostCloseCurly ();
	[GeneratedRegex (@" {")]
	private static partial Regex RegexRemoveSpacePreOpenCurly ();
	[GeneratedRegex (@"{ ")]
	private static partial Regex RegexRemoveSpacePostOpenCurly ();
	[GeneratedRegex (@" \)")]
	private static partial Regex RegexRemoveSpacePreCloseParens ();
	[GeneratedRegex (@"\) ")]
	private static partial Regex RegexRemoveSpacePostCloseParens ();
	[GeneratedRegex (@"\( ")]
	private static partial Regex RegexRemoveSpacePreOpenParens ();
	[GeneratedRegex (@" \(")]
	private static partial Regex RegexRemoveSpacePostOpenParens ();
	[GeneratedRegex (@"= ")]
	private static partial Regex RegexRemoveSpacePostEquals ();
	[GeneratedRegex (@" =")]
	private static partial Regex RegexRemoveSpacePreEquals ();
	[GeneratedRegex (@" \+")]
	private static partial Regex RegexRemoveSpacePrePlus ();
	[GeneratedRegex (@"\+ ")]
	private static partial Regex RegexRemoveSpacePostPlus ();
	[GeneratedRegex (@"}; }")]
	private static partial Regex RegexRemoveSpaceInterCloseCurly ();
	[GeneratedRegex (@"; ")]
	private static partial Regex RegexRemoveSpacePostSemicolon ();
	[GeneratedRegex (@", ")]
	private static partial Regex RegexRemoveSpacePostComma ();
	[GeneratedRegex (@": ")]
	private static partial Regex RegexRemoveSpacePostColon ();
	[GeneratedRegex (@"}")]
	private static partial Regex RegexAddReturnPostCloseCurly ();
	[GeneratedRegex (@"; }")]
	private static partial Regex RegexRemoveTrailingSpacePostSemicolon ();
	[GeneratedRegex (@";")]
	private static partial Regex RegexAddSpacePostSemicolon ();
	[GeneratedRegex (@"/\*(.*?)\*/", RegexOptions.Singleline)]
	private static partial Regex RegexRemoveBlockComments ();
	[GeneratedRegex (@"\s{2,}")]
	private static partial Regex RegexReduceWhitespacesToOne ();
	[GeneratedRegex (@"}\n\\")]
	private static partial Regex RegexFixIe6Garbage ();
}

public class TemplateCache
{
	public TemplateCache (
		string cacheContent,
		int cacheSeconds = 60,
		string? etag = null
	) {
		CacheSeconds = cacheSeconds;
		CacheContent = cacheContent;
		CacheTill = new DateTimeOffset (DateTime.Now.AddSeconds (cacheSeconds));
		ETag = etag;
	}

	public DateTimeOffset CacheTill { get; set; } = new DateTimeOffset (DateTime.Now.AddSeconds (60));
	public int CacheSeconds { get; set; }
	public string CacheContent { get; set; }
	public string? ETag { get; set; }
}

public static class IpAddressExtensions
{
	/// <summary>
	/// Returns true if the IP is link-local or loopback.
	/// IPv4:
	///		- Link-local: 169.254.x.x
	///		- Loopback: 127.x.x.x
	/// IPv6:
	///		- Link-local: fe80::/10
	///		- Loopback: 0:0:0:0:0:0:0:1 or ::1
	/// </summary>
	/// <param name="ipAddress"></param>
	/// <returns></returns>
	public static bool IsLinkLocalOrLoopback (this IPAddress ipAddress) {
		// Map back to IPv4 if mapped to IPv6 (i.e. "::ffff:1.2.3.4" -> "1.2.3.4")
		if (ipAddress.IsIPv4MappedToIPv6)
			ipAddress = ipAddress.MapToIPv4 ();

		if (IPAddress.IsLoopback (ipAddress))
			return true;

		// If IPv4
		if (ipAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) {
			var addressBytes = ipAddress.GetAddressBytes ();

			return addressBytes[0] == 169 && addressBytes[1] == 254;
		}

		// If IPv6
		return ipAddress.IsIPv6LinkLocal;
	}
}
