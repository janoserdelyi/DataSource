// <copyright file="EnvironmentExtensionMethods.cs" company="CoStar Group, Inc.">All rights reserved.</copyright>

using System.Diagnostics;
using Microsoft.Extensions.Hosting;

namespace WeMarketingAutomationFormInjection;

internal static class EnvironmentExtensionMethods
{
	public static bool IsLocal (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.IsEnvironment ("local") ||
		Debugger.IsAttached;

	public static bool IsDevelopment (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.IsEnvironment ("dev.main") ||
		Debugger.IsAttached;

	public static bool IsTest (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.IsEnvironment ("tst.main");

	public static bool IsTestRelease (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.IsEnvironment ("tst.rele");

	public static bool IsProduction (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.IsEnvironment ("prd");

	public static bool IsEnvironment (this IHostEnvironment hostingEnvironment, string environmentName) =>
		hostingEnvironment.SanitizedEnvironment () == environmentName ||
		hostingEnvironment.SanitizedEnvironment ().StartsWith ($"{environmentName}.");

	public static string SanitizedEnvironment (this IHostEnvironment hostingEnvironment) =>
		hostingEnvironment.EnvironmentName.ToLowerInvariant ();
}
