using System;
using Microsoft.Extensions.Logging;

namespace WeMarketingAutomationFormInjection;

public static class LoggerExtensions
{
	public static void LogErrorWithSpan (
		this ILogger logger,
		string message,
		string spanName,
		string spanId,
		Exception? ex = null,
		string? dataMessage = null
	) {
		var logMessage = $@"
			Error occurred:
			Span: [{spanName}: {spanId}]
			Message: {message}
			{(dataMessage != null ? $"Data: {dataMessage}" : string.Empty)}
		";

		if (ex != null) {
			logger.LogError (ex, logMessage);
		} else {
			logger.LogError (logMessage);
		}
	}
}