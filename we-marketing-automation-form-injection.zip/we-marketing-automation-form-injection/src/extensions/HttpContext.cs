using System.Globalization;
using System.Net;

namespace WeMarketingAutomationFormInjection;

public static class ContextExtensions
{
	private static SessionStorage? session;

	public static SessionStorage SessionStorage (
		this Microsoft.AspNetCore.Http.HttpContext ctx
	) {
		if (session == null) {
			session = new SessionStorage ();
		}
		return session;
	}

	public static CultureInfo? GetCurrentCulture (
		this Microsoft.AspNetCore.Http.HttpContext ctx
	) {
		var requestCulture = ctx.Features.Get<Microsoft.AspNetCore.Localization.IRequestCultureFeature> ();

		if (requestCulture == null) {
			//return new CultureInfo("en-US");
			return null;
		}

		return requestCulture.RequestCulture.Culture;
	}

	public static async Task RespondWithSuccess (
		this Microsoft.AspNetCore.Http.HttpContext ctx,
		string message,
		string? fullMessage = null
	) {
		await ctx.Response.AsJson (new Models.StandardSubmissionResponse (true, message, fullMessage));
	}

	public static async Task RespondWithFailure (
		this Microsoft.AspNetCore.Http.HttpContext ctx,
		string message,
		string? fullMessage = null,
		List<FluentValidation.Results.ValidationFailure>? errors = null
	) {
		await ctx.Response.AsJson (new Models.StandardSubmissionResponse (false, message, fullMessage, errors));
	}

	public static async Task RespondWithValidationErrors (
		this Microsoft.AspNetCore.Http.HttpContext ctx,
		FluentValidation.Results.ValidationResult validationResult
	) {
		await ctx.RespondWithFailure ("Errors have been found", errors: validationResult.Errors);
	}
}

public class SessionStorage
{
	public IPAddress? SourceIp { get; set; } = null;
	public string? UserAgent { get; set; } = null;
	// we can add any number of properties in here for the session, attached to the http context

	public void Clear () {
		SourceIp = null;
		UserAgent = null;
	}
}