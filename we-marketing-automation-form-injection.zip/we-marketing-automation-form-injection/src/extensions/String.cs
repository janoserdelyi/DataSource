namespace WeMarketingAutomationFormInjection;

internal static class StringExtensionMethods
{
	public static string? NullIfEmpty (
		this string? input
	) {
		if (string.IsNullOrEmpty (input)) {
			return null;
		}

		return input;
	}
}