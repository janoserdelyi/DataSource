// i only use a few things from jquery. let's see about eliminating it from our usual suspects

// this could be a mistake. just be being clunky. we shall see
// i just want to simplify the window onload cruft
export let window = function () {
	return {
		onload: function (callback) {

			if (!callback || typeof(callback) !== "function") {
				return;
			}

			document.onreadystatechange = async function () {
				if (document.readyState === 'complete') {
					callback();
				}
			}
		}
	}
}();

/*
args = {
	url, // string
	data, // object
	success, // function
	error, // function
	overrides // object
}

overrides = {
	method : GET, POST, PUT, DELETE, etc.
	mode : // no-cors, *cors, same-origin
	cache : // default, no-cache, reload, force-cache, only-if-cached
	credentials : // include, same-origin, omit
	redirect : // manual, follow, error
	referralPolicy : // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
	headers = {
		'Content-Type' : 'application/json','application/x-www-form-urlencoded',etc,
		'User-Agent' : 'foo',
		etc
	}
}
*/

// note: there is such a thing as an abort controller to abort long-running fetches
// https://developer.mozilla.org/en-US/docs/Web/API/AbortController
// i don't see a need to implement at this point

export let ajax = function () {

	return {
		// the promise returns false on failure, true on success
		// actual useful return values are handled through the success and error callbacks
		post: async function (
			args
		) {
			args = args || { url: null, data: {}, success: null, error: null, complete: null, overrides: {}, stringify: true };

			if (args.url === null) {
				return false;
			}

			if (args.stringify === undefined) {
				args.stringify = true;
			}

			args.overrides = args.overrides || {};

			if (args.overrides.method) {
				args.overrides.method = args.overrides.method.toUpperCase(); // yes i've been bitten by this with certain caches and proxies. yes it's dumb
			}

			let ret = await fetch (
				args.url,
				{
					method: args.overrides.method || 'POST',
					mode: args.overrides.mode || 'same-origin',
					cache: args.overrides.cache || 'no-cache',
					credentials: args.overrides.credentials || 'same-origin',
					headers: args.overrides.headers || {
						'Content-Type': 'application/json'
					},
					redirect: args.overrides.redirect || 'follow',
					referrerPolicy: args.overrides.referrerPolicy || 'no-referrer',
					body: (args.data === undefined || args.data === null) ? null : (args.stringify ? JSON.stringify(args.data) : args.data)
				}
			).then (
				async response => {

					let contentType = await response.headers.get("Content-Type");

					let data;

					// this is probably a bad idea
					switch (contentType) {
						case null :
						case "text/javascript" :
						case "application/javascript" :
							data = await response.text();
							break;
						default:
							data = await response.json();
							break;
					}

					if (response.status !== 200) {
						if (args.error !== null && typeof (args.error) === "function") {
							args.error(data);
							return false;
						}
						return false;
					}

					if (args.success !== null && typeof (args.success) === "function") {
						args.success(data);
					}

					return true;
				}
			).catch (
				(error) => {
					if (args.error !== null && typeof (args.error) === "function") {
						args.error(error);
					}
					if (error.message != null) {
						console.log("caught fetch error : ");
						console.error(error.message);
					}
					return false;
				}
			).finally (
				(info) => {
					if (args.complete !== null && typeof (args.complete) === "function") {
						args.complete(info);
					}
				}
			);

			return ret;
		},
		get: async function (args) {
			args = args || { url: null, data: {}, success: null, error: null, overrides: {} };

			if (args.url === null) {
				return false;
			}

			args.overrides = args.overrides || {};
			args.overrides.method = "get";

			return ajax.post(args);
		},
		patch: async function (args) {
			args = args || { url: null, data: {}, success: null, error: null, overrides: {} };

			if (args.url === null) {
				return false;
			}

			args.overrides = args.overrides || {};
			args.overrides.method = "patch";

			return ajax.post(args);
		},
		delete: async function (args) {
			args = args || { url: null, data: {}, success: null, error: null, overrides: {} };

			if (args.url === null) {
				return false;
			}

			args.overrides = args.overrides || {};
			args.overrides.method = "delete";

			return ajax.post(args);
		},
		getScript: async function (args) {
			args = args || { url: null, data: {}, success: null, error: null, overrides: {} };

			if (args.url === null) {
				return false;
			}

			args.overrides = args.overrides || {};
			args.overrides.method = "get";
			args.overrides.headers = {
				'Content-Type': 'text/javascript; charset=utf-8'
			};

			return ajax.post(args);
		}
	}
}();

// i would like to optionally import formObj since its form handling, type coersion and property naming overrides are nice
//let frm = import('./common.js'); // if this a non-existant reference it's not graceful about it

export let strings  = function () {

	let rdashAlpha = /-([a-z])/g;

	// Used by camelCase as callback to replace()
	function fcamelCase (_all, letter) {
		return letter.toUpperCase();
	}

	return {
		// lifted from jquery and reformatted to suit how i'm using it
		camelCase: function (string) {
			return string.replace(rdashAlpha, fcamelCase);
		}
	};
}();

// to be able to remove (anonymous) events from objects, i have to keep track of them
let _events = {};
// like jquery i will have this operating on multiple objects internally
export let el = function (selector) {

	// this will ultimately be an array
	let o;

	function oCheck () {
		if (o === undefined) {
			return false;
		}
		if (o === null) {
			return false;
		}
		if (o.length === 0) {
			return false;
		}
		return Array.isArray(o);
	}

	// i still can't believe there isn't a deep clone/copy. this breaks the references
	function deepCloneData (obj) {
		return JSON.parse(JSON.stringify(obj));
	}

	let obj = {
		// i may remove this from obj
		get: function (selector) {
			if (selector === undefined || selector === null || selector === "") {
				return null;
			}

			if (o !== undefined) {
				return o;
			}

			if (typeof (selector) === "string") {
				let res = document.querySelectorAll(selector);
				if (typeof(res) === "object") {
					if (res instanceof NodeList) {
						return Array.from(res);
					}
					return [res];
				}
				return null;
			}
			// this is not bulletproof by any means but testing for Node is being elusive
			if (typeof (selector) === "object") {
				if (Array.isArray(selector)) {
					return selector;
				}
				if (selector instanceof NodeList) {
					return Array.from(selector);
				}
				if (selector instanceof HTMLCollection) {
					return Array.from(selector);
				}
				return [selector];
			}

			console.log("unknown selector type for el.get : ");
			console.log(selector);
			return null;
		},
		find: function (selector) {
			if (!oCheck()) {
				return this;
			}

			// only accepting strings here. also killing the chain
			if (selector === undefined || typeof (selector) !== "string") {
				return this;
			}

			let temp = [];

			o.forEach(function(x){
				let res = x.querySelectorAll(selector);
				if (res.length > 0 && typeof(res) === "object") {
					if (res instanceof NodeList) {
						//temp = temp.concat(Array.from(res));
						temp = temp.concat(temp, Array.from(res));
					} else {
						temp.push(res);
					}
				}
			});

			return el(temp);
		},
		parents: function (selector) {
			if (!oCheck()) {
				return this;
			}

			if (selector === undefined || typeof (selector) !== "string") {
				return this;
			}

			let temp = [];

			o.forEach(function(x){
				for ( ; x && x !== document; x = x.parentNode ) {
					if (x.matches(selector)) {
						temp.push(x);
					}
				}
			});

			return el(temp);
		},
		parent: function (selector) {
			if (!oCheck()) {
				return this;
			}

			if (selector && typeof (selector) !== "string") {
				return this;
			}

			let temp = [];

			o.forEach(function(x){
				let p = x.parentNode;
				if (!p) {
					return;
				}

				if (selector === undefined) {
					temp.push(p);
				} else {
					if (p.matches(selector)) {
						temp.push(p);
					}
				}
			});

			return el(temp);
		},
		remove: function (selector) {
			if (!oCheck()) {
				return null;
			}

			if (selector && typeof (selector) !== "string") {
				return null;
			}

			// if there is a selector, the remove is scoped to elements within the 'o' collection
			// with no selector, o's are being removed so we'll need to go up to their parents and remove from there

			if (!selector) {
				o.forEach(function(x){
					x.remove();
				});
				return null;
			}

			o.forEach(function(x){
				el(x).find(selector).remove();
			});

			return null; // yeah i'm killing the chain. i have no idea what this should possibly return if you're killing self
		},
		base: function() {
			return o;
		},
		addClass: function (className) {
			if (!oCheck()) {
				//return null;
				return this;
			}

			if (className === undefined || className === null || className.trim() == "") {
				return this;
			}

			o.forEach(function(x){
				// it's possible now to pass in space-delimited classes
				let classes = className.split(' ');

				classes.forEach(function(cname){
					if (!x.classList.contains(cname)) {
						x.classList.add(cname);
					}
				});

				//if (!x.classList.contains(className)) {
				//	x.classList.add(className);
				//}
			});

			return this;
		},
		removeClass: function (className) {
			if (!oCheck()) {
				//return null;
				return this;
			}

			o.forEach(function(x){
				if (x.classList && x.classList.contains(className)) {
					x.classList.remove(className);
				}
			});

			return this;
		},
		toggleClass: function (className) {
			if (!oCheck()) {
				return null;
			}

			o.forEach(function(x){
				if (x.classList === undefined) {
					console.log("classList is undefined on");
					console.log(x);
				} else {
					x.classList.toggle(className);
				}
			});

			return this;
		},
		hasClass: function (className) {
			if (!oCheck()) {
				return null;
			}

			// matching jquery's description
			// Description: Determine whether any of the matched elements are assigned the given class.

			let ret = false;

			o.forEach(function(x){
				if (x.classList.contains(className)) {
					ret = true;
					return; // gtfo. no need to continue further eval
				}
			});

			return ret;
		},
		css: function (val) {
			if (!oCheck()) {
				return null;
			}

			o.forEach(function(x){
				Object.keys(val).forEach((key, index) => {
					//console.log(`${key}: ${val[key]}`);
					x.style[strings.camelCase(key)] = val[key];
				});
			});

			return this;
		},
		style: function (key, val) {
			if (!oCheck()) {
				return null;
			}

			o.forEach(function(x){
				x.style[strings.camelCase(key)] = val;
			});

			return this;
		},
		html: function (val) {
			if (!oCheck()) {
				return null;
			}

			// html(val) stops the chain
			// also.. since just a single string value is expected in the return, this will only hit the first element
			if (val === undefined || val === null) {
				return o[0].innerHTML;
			}

			o.forEach(function(x){
				x.innerHTML = val;
			});

			return this;
		},
		text: function (val) {
			if (!oCheck()) {
				return null;
			}

			// text(val) stops the chain
			// also.. since just a single string value is expected in the return, this will only hit the first element
			if (val === undefined || val === null) {
				return o[0].textContent;
			}

			o.forEach(function(x){
				x.textContent = val;
			});

			return this;
		},
		attr: function (key, val) {
			if (!oCheck()) {
				return null;
			}

			if (key === undefined) {
				return this;
			}

			// this stops the chain and just returns the value for the first object
			if (val === undefined || val === null) {
				return o[0].getAttribute(key);
			}

			o.forEach(function(x){
				x.setAttribute(key, val);
			});

			return this;
		},
		removeAttr: function (key) {
			if (!oCheck()) {
				return null;
			}

			if (key === undefined) {
				return this;
			}

			o.forEach(function(x){
				x.removeAttribute(key);
			});

			return this;
		},
		offset: function () {
			if (!oCheck()) {
				return null;
			}

			let elem = o[0];
			let rect, win;

			rect = elem.getBoundingClientRect();
			win = elem.ownerDocument.defaultView;

			return {
				top: rect.top + win.pageYOffset,
				left: rect.left + win.pageXOffset
			};
		},
		show: function () {
			if (!oCheck()) {
				return null;
			}

			o.forEach(function(x){
				x.style.display = 'inherit';
			});

			return this;
		},
		hide: function () {
			if (!oCheck()) {
				return null;
			}

			o.forEach(function(x){
				x.style.display = 'none';
			});

			return this;
		},
		append: function (val) {
			if (!oCheck()) {
				return this;
			}

			if (val === undefined || val === null) {
				return this;
			}

			if (typeof(val) == "object") {
				// this could be a jshim object. i really need a real way to test this
				// going to see if it is and if the first element is an element
				if (!(val instanceof Element) && Array.isArray(val)) {
					val = val[0];
				}
			}

			if ((val instanceof Element) || (val instanceof DocumentFragment)) {
				o.forEach(function(x){
					x.appendChild(val);
				});

				return this
			}

			// i think the original below is expecting a textual val, not a node

			//let parser = new DOMParser(); console.log('parser'); console.log(parser); console.log(parser.parseFromString(val, 'text/html'));
			//let content = parser.parseFromString(val, 'text/html').body.children; // a doc is returned, so we need the body contents

			let temp = document.createElement('template');
			temp.innerHTML = val;

			o.forEach(function(x){
				x.appendChild(temp.content);
			});

			return this;
		},
		before: function (val) {
			if (!oCheck()) {
				return this;
			}

			if (val === undefined || val === null) {
				return this;
			}

			if ((val instanceof Element) || (val instanceof DocumentFragment)) {
				o.forEach(function(x){
					if (x.parentNode) {
						x.parentNode.insertBefore(val, x);
					}
				});

				return this
			}

			let temp = document.createElement('template');
			temp.innerHTML = val;

			o.forEach(function(x){
				if (x.parentNode) {
					x.parentNode.insertBefore(temp.content, x);
				}
			});

			return this;
		},
		after: function (val) {
			if (!oCheck()) {
				return this;
			}

			if (val === undefined || val === null) {
				return this;
			}

			if ((val instanceof Element) || (val instanceof DocumentFragment)) {
				o.forEach(function(x){
					if (x.parentNode) {
						x.parentNode.insertBefore(val, x.nextSibling);
					}
				});

				return this
			}

			let temp = document.createElement('template');
			temp.innerHTML = val;

			o.forEach(function(x){
				if (x.parentNode) {
					x.parentNode.insertBefore(temp.content, x.nextSibling);
				}
			});

			return this;
		},
		empty: function () {
			if (!oCheck()) {
				return this;
			}

			o.forEach(function(x){
				while (x.firstChild) {
					x.firstChild.remove();
				}
			});

			return this;
		},
		on: function (eventName, callback, options) {
			if (!oCheck()) {
				return null;
			}

			if (eventName === undefined) {
				return this;
			}

			if (callback === undefined || typeof(callback) !== "function") {
				return this;
			}

			options = options || {};

			o.forEach(function(x){

				// saving events in a jshim scope
				if(!(x in _events)) {
					_events[x] = {};
				}
				if(!(eventName in _events[x])) {
					_events[x][eventName] = []; // store each event type
				}
				_events[x][eventName].push([callback, options]);

				x.addEventListener(eventName, callback, options);
			});

			return this;
		},
		off: function (eventName, options) {
			if (!oCheck()) {
				return null;
			}

			if (eventName === undefined) {
				return this;
			}

			options = options || {};

			o.forEach(function(x){
				/*
				if (typeof(x) === "object") {
					for (let prop in x) {
						if (prop === eventName && typeof(x[prop]) === "function") {
							//console.log(x[prop]);
							x[prop] = null;
							//x.removeEventListener(prop, x[prop], options);
						}
					}
				}
				*/

				// i had to move to storing event references. the functions end up being anonymous so they cannot be removed
				if (x in _events) {
					if (eventName in _events[x]) {
						let eventHandlers = _events[x][eventName];
						for (let i = eventHandlers.length; i--;) {
							let handler = eventHandlers[i];
							x.removeEventListener(eventName, handler[0], handler[1]);
							delete _events[x][eventName];
						}
					}
				}

			});

			return this;
		},
		each: function (callback) {
			if (!oCheck()) {
				return null;
			}

			if (callback === undefined || typeof(callback) !== "function") {
				return this;
			}

			o.forEach(function(x){
				callback(x);
			});

			return this;
		},
		val: function (input) {
			if (!oCheck()) {
				return null;
			}

			// while i would REALLY prefer to use common.formObj, i'm going to do a light implementation here to get values
			if (input || input === "" || input !== undefined) { // yep... empty string evals as false

				if (!(typeof(input) === "string" || typeof(input) === "number" || Array.isArray(input))) {
					console.log("invalid input type : '" + typeof(input) + "'");
					return null;
				}

				o.forEach(function(x){
					switch (x.nodeName) {
						case "INPUT" :
							if (o[0].type.toLowerCase() === "checkbox" || o[0].type.toLowerCase() === "radio") {
								if (typeof(input) === "string") {
									x.checked = x.value === input;
									break;
								}
								if (Array.isArray(input)) {
									x.checked = input.includes(x.value);
								}
								break;
							}
							x.value = input;
							break;
						case "SELECT" :
							x.value = input;
							break;
						case "TEXTAREA" :
							x.value = input;
							break;
					}
				});
			}

			if (!o || !o[0]) {
				return "";
			}

			switch (o[0].nodeName) {
				case "INPUT" :
					if (o[0].type.toLowerCase() === "checkbox" || o[0].type.toLowerCase() === "radio") {
						// get the name, then re-get the node collection by name
						let col = Array.from(document.getElementsByName(o[0].name));
						if (col && col.length > 0) {
							return col.map(function(i){
								if (i.checked === true) {
									return i.value;
								}
							}).filter(function(i){ return i;});
						}
						return "";
					}
					return o[0].value;
				case "SELECT" :
					return o[0].options[o[0].selectedIndex].value;
					break;
				case "TEXTAREA" :
					return o[0].value;
				default :
					return "";
			}

			return "";
		},
		data: function (key, val) {
			if (!oCheck()) {
				return null;
			}

			// data(val) stops the chain
			// also.. since just a single string value is expected in the return, this will only hit the first element
			if (val === undefined) {
				return o[0].dataset[key];
			}

			o.forEach(function(x){
				if (val === null) {
					delete x.dataset[key];
				} else {
					x.dataset[key] = val;
				}
			});

			return this;
		},
		count: function () {
			// get the number of objects in the current collection and terminate the chain
			return o.length;
		},
		trigger: function (eventType) {
			// just doing a very shallow implementation
			// and no return values. using this ends the chain

			if (!oCheck()) {
				return;
			}

			if (eventType === undefined) {
				return;
			}

			let event = new Event(eventType, {
				//view: window,
				bubbles: true,
				cancelable: true
			});

			o.forEach(function(x){
				let canceled = !x.dispatchEvent(event);

				if (canceled) {
					// A handler called preventDefault.
					//console.log("cancelled");
				} else {
					// None of the handlers called preventDefault.
					//console.log("not cancelled");
				}
			});
		}
	};

	o = obj.get(selector);

	return obj;
};
