import "{{rooturl}}/api/v1/js/eventlisteners";
import * as Common from "{{rooturl}}/api/v1/js/common";
import { standardFormUtils as std } from "{{rooturl}}/api/v1/js/standard-form-functions";

let standardInjection = function (
	env,
	locale,
	config
) {
	// it's coming in as a string
	if (config) {
		config = JSON.parse(config);
	}

	let injectionLoaded = false;

	let ip = null;
	let formElement = null;
	let responseContainer = null;
	let translations = null;
	let formConfig = null; // this is configuration that the page owner can directly provide via window.formconfig. it allows overriding base values

	let fields = {};
	fields["firstName"] = {
		type: "text",
		name: "FirstName",
		required: "required",
		minlength: 2,
		maxlength: 20,
		pattern: "[a-zA-Z\s]{2,20}",
		autocorrect: false,
		autocapitalize: false,
		autocomplete: "given-name",
		placeholder: "{{label.FirstName}}",
		bindingname: "firstName"
	};

	function renderField (fieldObj) {

	}

	function isObject (item) {
		return (item && typeof item === 'object' && !Array.isArray(item));
	}

	function deepMerge (target, ...sources) {
		if (!sources.length) {
			return target;
		}
		const source = sources.shift();

		if (isObject(target) && isObject(source)) {
			for (const key in source) {
				if (isObject(source[key])) {
					if (!target[key]) {
						Object.assign(target, { [key]: {} });
					}
					deepMerge(target[key], source[key]);
				} else {
					Object.assign(target, { [key]: source[key] });
				}
			}
		}
		return deepMerge(target, ...sources);
	}

	function getFieldValue (
		fieldName,
		fieldPropertyName
	) {
		if (fields[fieldName] === undefined || fields[fieldName][fieldPropertyName] === undefined) {
			return null;
		}
		return fields[fieldName][fieldPropertyName];
	}

	function clearMessages () {
		if (responseContainer) {
			responseContainer.innerHTML = "";
		}
	}

	function loadUtms () {
		let utms = std.getUtms();
		let campaignField = document.querySelector("[data-bindingname=campaignId]");

		if (campaignField) {
			if (utms.campaignId) {
				campaignField.value = utms.campaignId;
				window.sessionStorage.setItem("campaignId", utms.campaignId);
				//console.log(`campaign id value '${utms.campaignId}' found in the querystring. setting input value and sessionStorage`);
				return;
			}

			let sessionCampaignId = window.sessionStorage.getItem("campaignId");

			if (sessionCampaignId) {
				//console.log(`campaign id value '${sessionCampaignId}' found in sessionStorage. setting input value`);
				campaignField.value = sessionCampaignId;
			}
		}
	}

	return {
		init: function (injectionPoint) {
			if (injectionLoaded == true) {
				console.log("script already loaded. exiting.");
				return;
			} else {
				console.log(`injectionLoaded : ${injectionLoaded}`);
			}

			console.log("formscript initialized");

			translations = "{{translations}}";

			ip = document.querySelector(injectionPoint);

			if (ip === undefined || ip === null) {
				console.log("no injection point found");
				return;
			}

			loadUtms();

			// load a base stylesheet for this form
			document.head.insertAdjacentHTML('afterbegin', `<link type="text/css" rel="stylesheet" href="{{rooturl}}/api/v1/css/tenx-injection"/>`);

			// remove any `form-injection-noscript-banner` banners
			document.querySelectorAll(".form-injection-noscript-banner").forEach(e => e.remove());

			if (window.formconfig !== undefined) {
				formConfig = window.formconfig;
				// merge this config over top the base
				fields = deepMerge (fields, formConfig.fields);
			}

			ip.innerHTML = `
<form 
	id="Form-{{scriptcd}}" 
	data-bindingname="form"
>
	<div class="standard-element-container firstname-container">
		<label for="FirstName-{{scriptcd}}">{{label.FirstName}}</label>
		<input 
			type="text" 
			id="FirstName-{{scriptcd}}" 
			name="FirstName" 
			required="required" 
			minlength="2" 
			maxlength="20" 
			pattern="[a-zA-Z\s]{2,20}" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="given-name" 
			placeholder="{{label.FirstName}} *" 
			data-bindingname="firstName" 
			${(getFieldValue("firstName", "defaultValue") == null ? "" : `value="${getFieldValue("firstName", "defaultValue")}"`)}
		/>
	</div>
	<div class="standard-element-container lastname-container">
		<label for="LastName-{{scriptcd}}">{{label.LastName}}</label>
		<input 
			type="text" 
			id="LastName-{{scriptcd}}" 
			name="LastName" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="family-name" 
			placeholder="{{label.LastName}} *" 
			data-bindingname="lastName" 
			${(getFieldValue("lastName", "defaultValue") == null ? "" : `value="${getFieldValue("lastName", "defaultValue")}"`)}
		/>
	</div>
	<div class="standard-element-container company-container">
		<label for="CompanyName-{{scriptcd}}">{{label.CompanyName}}</label>
		<input 
			type="text" 
			id="CompanyName-{{scriptcd}}" 
			name="CompanyName" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="organization" 
			placeholder="{{label.CompanyName}} *" 
			data-bindingname="company"
		/>
	</div>
	<div class="standard-element-container state-container">
		<label for="StateCode-{{scriptcd}}">{{label.StateCode}}</label>
		<select 
			id="StateCode-{{scriptcd}}" 
			name="StateCode" 
			required="required" 
			autocomplete="address-level1" 
			data-bindingname="stateCode"
		>
			<option value="">{{label.StateCode}} *</option>
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CO">Colorado</option>
			<option value="CT">Connecticut</option>
			<option value="DE">Delaware</option>
			<option value="DC">District of Columbia</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="ZZ">Non-Designated</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
			<option value="WY">Wyoming</option>
		</select>
	</div>
	<div class="standard-element-container postal-container">
		<label for="PostalCode-{{scriptcd}}">{{label.PostalCode}}</label>
		<input 
			type="text" 
			id="PostalCode-{{scriptcd}}" 
			name="PostalCode" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="postal-code" 
			placeholder="{{label.PostalCode}} *" 
			data-bindingname="zipCode"
		/>
	</div>
	<div class="standard-element-container phone-container">
		<label for="PhoneNumber-{{scriptcd}}">{{label.PhoneNumber}}</label>
		<input 
			type="tel" 
			id="PhoneNumber-{{scriptcd}}" 
			name="PhoneNumber" 
			required="required" 
			pattern="[\d+\-\(\)\s]{4,20}" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="tel" 
			placeholder="{{label.PhoneNumber}} *" 
			data-bindingname="phone" 
		/>
	</div>
	<div class="standard-element-container email-container">
		<label for="EmailAddress-{{scriptcd}}">{{label.EmailAddress}}</label>
		<input 
			type="email" 
			id="EmailAddress-{{scriptcd}}" 
			name="EmailAddress" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="email" 
			placeholder="{{label.EmailAddress}} *" 
			data-bindingname="emailAddress" 
			${(getFieldValue("emailAddress", "defaultValue") == null ? "" : `value="${getFieldValue("emailAddress", "defaultValue")}"`)}
		/>
	</div>

	<input type="hidden" data-bindingname="optIntoSegments" data-strict-type="int" value="25"/>
	<input type="hidden" data-bindingname="formType" value="Sales"/>
	<input type="hidden" data-bindingname="campaignId" value=""/>
	<input type="hidden" data-bindingname="countryCode" value="USA"/>
	<input type="hidden" data-bindingname="brand" value="TenX"/>
	<input type="hidden" data-bindingname="leadSource" value="TenX"/>
	<input type="hidden" data-bindingname="_ga" value="" id="_ga"/>
	
	<div class="submit-container">
		<button type="submit">Schedule a Demo</button>
	</div>
</form>`;

			formElement = document.getElementById("Form-{{scriptcd}}");

			formElement.addEventListener("submit", standardInjection.formSubmit);

			injectionLoaded = true;
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "response-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .response-container`);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			let frm = Common.formObj.load(formElement.parentNode);

			frm = std.createPayloadFormatted(frm);

			console.log(frm);

			responseContainer.innerHTML = `${translations.submitting}...`;

			let response = await fetch ("{{rooturl}}/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {

				// the errors collection comes from fluent. if it's empty, take the current message and display that
				if (response.errors.length == 0) {
					responseContainer.innerHTML = `<div class="error"><ul><li>${response.message}</li></ul></div>`;
					return;
				}

				// for all errors, look up tokens which match fields.
				// when found, replace with the placeholder text of the input
				response.errors.forEach (function (el) {

					const regex = /\{\{(?<prop>[a-zA-Z]+)\}\}/;

					let propNameMatches = regex.exec(el.errorMessage);

					if (propNameMatches === null || propNameMatches.length === 0) {
						return;
					}

					if (propNameMatches.groups && propNameMatches.groups.prop) {
						// find the element with this data binding name and get the placeholder or label. placeholder first
						let inputElement = formElement.querySelector(`[data-bindingname=${propNameMatches.groups.prop}]`);

						if (inputElement) {
							let replacementValue = null;

							if (inputElement.hasAttribute("placeholder")) {
								replacementValue = inputElement.getAttribute("placeholder");
							}

							if (replacementValue === null) {
								// look for a label. it should have for="id-of-input"
								let label = formElement.querySelector(`label[for=${inputElement.id}]`);
								if (label) {
									replacementValue = label.innerText;
								}
							}

							el.errorMessage = el.errorMessage.replace(propNameMatches[0], replacementValue);
						}
					}
				});

				// was showing the preceeding message, but it's not localized yet. <p>${response.message}</p>
				responseContainer.innerHTML = `<div class="error"><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);

			if (successContainer && successContainer.style) {
				// just remove the "display:none;" from the style
				responseContainer.innerHTML = '';
				successContainer.style.removeProperty("display");
			} else {
				responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			}

			formElement.reset();
			// 2024-10-04 it was decided to also hide the form on success and just display the success
			formElement.style.setProperty("display", "none", "important");

			// if the config has a redirectUrl property, redirect to that url on success
			if (config.redirectUrl !== undefined) {
				location.href = config.redirectUrl;
			}
		}
	}

}("{{environment}}", '{{locale}}', '{{config}}');

window.addEventListener('DOMContentLoaded', () => {
	standardInjection.init('{{injectionPoint}}');
});

// an attempt to deal with this being loaded by react
window.addEventListener('readystatechange', () => {
	if (document.readyState === "complete" || document.readyState === "interactive") {
		standardInjection.init('{{injectionPoint}}');
	}
});

standardInjection.init('{{injectionPoint}}');