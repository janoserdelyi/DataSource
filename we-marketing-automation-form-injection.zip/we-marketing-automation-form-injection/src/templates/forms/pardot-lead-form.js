
import "{{rooturl}}/static/js/eventlisteners.js";
import * as Common from "{{rooturl}}/static/js/common.js";
import { standardFormUtils as std } from "{{rooturl}}/static/js/standard-form-functions.js";

// window.addEventListener("eventAdded", function (e) {
// 	let el = e.detail.element;
// 	console.log(`event type '${e.detail.eventType}' added to element ${el.nodeName}`);
// });

let standardLeadForm = function (
	env,
	locale,
	config
) {
	// it's coming in as a string
	if (config) {
		config = JSON.parse(config);
	}

	let formElement = null;
	let responseContainer = null;
	let translations = null;
	let countryCodeTranslation = {};

	function clearMessages () {
		if (responseContainer) {
			responseContainer.innerHTML = "";
		}
	}

	function setFormElement (injectionPoint) {
		formElement = document.querySelector(injectionPoint);

		if (formElement === undefined || formElement === null) {
			// if not found, look for any forms decorated with data-bindingname="form"
			formElement = document.querySelector("form[data-bindingname=form]");
		}
	}

	function getFieldCollection () {
		if (formElement == null) {
			return;
		}

		// look for all <p> elements with a classname of "form-field" and also a classname of "data-*" where "*" will be things like "firstName"
		// i agree, this is awful. thank you, pardot
		// class selectors like this don't work with multi-classing sadly
		//let ps = formElement.querySelectorAll("p[class=form-field][class^='data-']");
		let ps = formElement.querySelectorAll("p.form-field");

		let elems = [];
		ps.forEach(function(el) {
			// get the data-* value if it exists
			let classListDataValue = getClassListDataValue(el);
			if (classListDataValue == null) {
				return;
			}

			let input = el.querySelector("input, textarea, select, [contenteditable=true]");
			if (input) {
				// add the data attribute
				input.setAttribute("data-bindingName", classListDataValue);
				elems.push(input);
			}
		});

		let localeInput = formElement.querySelector(`input[data-bindingname=locale]`);
		if (localeInput) {
			elems.push(localeInput);
		}

		return elems;
	}

	// makes sure there is a "data-*" classname in the element. otherwise exit
	function getClassListDataValue (el) {
		let prefix = "data-";
		for (let i=0; i<el.classList.length; i++) {
			if (el.classList[i].startsWith(prefix)) {
				return el.classList[i].substring(prefix.length);
			}
		}

		return null;
	}

	return {
		init: function (injectionPoint) {
			console.log("formscript initialized");

			translations = "{{translations}}";

			setFormElement(injectionPoint);

			// still missing? show a banner
			if (formElement === undefined || formElement === null) {
				// todo: cover the page with a div and a message about what's missing?
				// for now in lower envs put a banner at the top of the page
				// but not in production
				if (env === "prd") {
					return;
				}
				std.showMissingFormBanner('{{rooturl}}');
				return;
			}

			// this will pass in prd as it's expected to have been evaluated in lower environments
			let inspection = (env === "prd") || standardLeadForm.formInspect();

			// pardot forms have script elements *within* the form element. wth! get rid of them
			formElement.querySelectorAll("script").forEach(e => e.remove());

			// add a locale field if it doesn't exist
			std.addLocaleField(formElement, locale);

			// some forms have overly restrictive input patterns (or just wrong). touch them up
			std.realignFieldConstraints(formElement);

			standardLeadForm.resetEvents(injectionPoint, inspection);

			// mapping custom select in pardot - based off https://go.demo.pardot.com/l/873701/2024-10-10/35mc
			// i bet this is just dvm/tsm and will need a mapping in PRD
			countryCodeTranslation = {};
			if (env === "prd") {
				countryCodeTranslation["1306085"] = "AFG"; // Afghanistan
				countryCodeTranslation["1306088"] = "ALB"; // Albania
				countryCodeTranslation["1306091"] = "DZA"; // Algeria
				countryCodeTranslation["1306094"] = "ASM"; // American Samoa
				countryCodeTranslation["1306097"] = "AND"; // Andorra
				countryCodeTranslation["1306100"] = "AGO"; // Angola
				countryCodeTranslation["1306103"] = "AIA"; // Anguilla
				countryCodeTranslation["1306106"] = "ATG"; // Antigua / Barbuda
				countryCodeTranslation["1306109"] = "ARG"; // Argentina
				countryCodeTranslation["1306112"] = "ARM"; // Armenia
				countryCodeTranslation["1306115"] = "ABW"; // Aruba
				countryCodeTranslation["1306118"] = "AUS"; // Australia
				countryCodeTranslation["1306121"] = "AUT"; // Austria
				countryCodeTranslation["1306124"] = "AZE"; // Azerbaijan
				countryCodeTranslation["1306127"] = "BHS"; // Bahamas
				countryCodeTranslation["1306130"] = "BHR"; // Bahrain
				countryCodeTranslation["1306133"] = "BGD"; // Bangladesh
				countryCodeTranslation["1306136"] = "BRB"; // Barbados
				countryCodeTranslation["1306139"] = "BLR"; // Belarus
				countryCodeTranslation["1306142"] = "BEL"; // Belgium
				countryCodeTranslation["1306145"] = "BLZ"; // Belize
				countryCodeTranslation["1306148"] = "BEN"; // Benin
				countryCodeTranslation["1306151"] = "BMU"; // Bermuda
				countryCodeTranslation["1306154"] = "BTN"; // Bhutan
				countryCodeTranslation["1306157"] = "BOL"; // Bolivia
				countryCodeTranslation["1306160"] = "BIH"; // Bosnia / Herzegovina
				countryCodeTranslation["1306163"] = "BWA"; // Botswana
				countryCodeTranslation["1306166"] = "BRA"; // Brazil
				countryCodeTranslation["1306169"] = "VGB"; // British Virgin Islands
				countryCodeTranslation["1306172"] = "BRN"; // Brunei
				countryCodeTranslation["1306175"] = "BGR"; // Bulgaria
				countryCodeTranslation["1306178"] = "BFA"; // Burkina Faso
				countryCodeTranslation["1306181"] = "BDI"; // Burundi
				countryCodeTranslation["1306184"] = "KHM"; // Cambodia
				countryCodeTranslation["1306187"] = "CMR"; // Cameroon
				countryCodeTranslation["1306190"] = "CAN"; // Canada
				countryCodeTranslation["1306193"] = "CPV"; // Cape Verde
				countryCodeTranslation["1306196"] = "CYM"; // Cayman Islands
				countryCodeTranslation["1306199"] = "CAF"; // Central African Republic
				countryCodeTranslation["1306202"] = "TCD"; // Chad
				countryCodeTranslation["1306205"] = "CHL"; // Chile
				countryCodeTranslation["1306208"] = "CHN"; // China
				countryCodeTranslation["1306211"] = "COL"; // Colombia
				countryCodeTranslation["1306214"] = "COM"; // Comoros
				countryCodeTranslation["1306217"] = "COK"; // Cook Islands
				countryCodeTranslation["1306220"] = "CRI"; // Costa Rica
				countryCodeTranslation["1306223"] = "CIV"; // Cote D`Ivoire
				countryCodeTranslation["1306226"] = "HRV"; // Croatia
				countryCodeTranslation["1306229"] = "CUB"; // Cuba
				countryCodeTranslation["1306232"] = "CUW"; // Curacao
				countryCodeTranslation["1306235"] = "CYP"; // Cyprus
				countryCodeTranslation["1306238"] = "CZE"; // Czech Republic
				countryCodeTranslation["1306241"] = "COD"; // Democratic Republic Of Congo
				countryCodeTranslation["1306244"] = "DNK"; // Denmark
				countryCodeTranslation["1306247"] = "DJI"; // Djibouti
				countryCodeTranslation["1306250"] = "DMA"; // Dominica
				countryCodeTranslation["1306253"] = "TLS"; // East Timor
				countryCodeTranslation["1306256"] = "ECU"; // Ecuador
				countryCodeTranslation["1306259"] = "SLV"; // El Salvador
				countryCodeTranslation["1306262"] = "GNQ"; // Equatorial Guinea
				countryCodeTranslation["1306265"] = "ERI"; // Eritrea
				countryCodeTranslation["1306268"] = "EST"; // Estonia
				countryCodeTranslation["1306271"] = "ETH"; // Ethiopia
				countryCodeTranslation["1306274"] = "FLK"; // Falkland Islands
				countryCodeTranslation["1306277"] = "FRO"; // Faroe Islands
				countryCodeTranslation["1306280"] = "FJI"; // Fiji
				countryCodeTranslation["1306283"] = "FIN"; // Finland
				countryCodeTranslation["1306286"] = "FRA"; // France
				countryCodeTranslation["1306289"] = "GUF"; // French Guiana
				countryCodeTranslation["1306292"] = "PYF"; // French Polynesia
				countryCodeTranslation["1306295"] = "GAB"; // Gabon
				countryCodeTranslation["1306298"] = "GMB"; // Gambia
				countryCodeTranslation["1306301"] = "GEO"; // Georgia
				countryCodeTranslation["1306304"] = "DEU"; // Germany
				countryCodeTranslation["1306307"] = "GHA"; // Ghana
				countryCodeTranslation["1306310"] = "GIB"; // Gibraltar
				countryCodeTranslation["1306313"] = "GRC"; // Greece
				countryCodeTranslation["1306316"] = "GRL"; // Greenland
				countryCodeTranslation["1306319"] = "GRD"; // Grenada
				countryCodeTranslation["1306322"] = "GLP"; // Guadeloupe
				countryCodeTranslation["1306325"] = "GUM"; // Guam
				countryCodeTranslation["1306328"] = "GTM"; // Guatemala
				countryCodeTranslation["1306331"] = "GIN"; // Guinea
				countryCodeTranslation["1306334"] = "GNB"; // Guinea-Bissau
				countryCodeTranslation["1306337"] = "GUY"; // Guyana
				countryCodeTranslation["1306340"] = "HTI"; // Haiti
				countryCodeTranslation["1306343"] = "HND"; // Honduras
				countryCodeTranslation["1306346"] = "HKG"; // Hong Kong SAR China
				countryCodeTranslation["1306349"] = "HUN"; // Hungary
				countryCodeTranslation["1306352"] = "ISL"; // Iceland
				countryCodeTranslation["1306355"] = "IND"; // India
				countryCodeTranslation["1306358"] = "IDN"; // Indonesia
				countryCodeTranslation["1306361"] = "IRN"; // Iran
				countryCodeTranslation["1306364"] = "IRQ"; // Iraq
				countryCodeTranslation["1306367"] = "IRL"; // Ireland
				countryCodeTranslation["1306370"] = "ISR"; // Israel
				countryCodeTranslation["1306373"] = "ITA"; // Italy
				countryCodeTranslation["1306376"] = "JAM"; // Jamaica
				countryCodeTranslation["1306379"] = "JPN"; // Japan
				countryCodeTranslation["1306382"] = "JOR"; // Jordan
				countryCodeTranslation["1306385"] = "KAZ"; // Kazakhstan
				countryCodeTranslation["1306388"] = "KEN"; // Kenya
				countryCodeTranslation["1306391"] = "KIR"; // Kiribati
				countryCodeTranslation["1306394"] = ""; // Kosovo
				countryCodeTranslation["1306397"] = "KWT"; // Kuwait
				countryCodeTranslation["1306400"] = "KGZ"; // Kyrgyzstan
				countryCodeTranslation["1306403"] = "LAO"; // Laos
				countryCodeTranslation["1306406"] = "LVA"; // Latvia
				countryCodeTranslation["1306409"] = "LBN"; // Lebanon
				countryCodeTranslation["1306412"] = "LSO"; // Lesotho
				countryCodeTranslation["1306415"] = "LBR"; // Liberia
				countryCodeTranslation["1306418"] = "LBY"; // Libya
				countryCodeTranslation["1306421"] = "LIE"; // Liechtenstein
				countryCodeTranslation["1306424"] = "LTU"; // Lithuania
				countryCodeTranslation["1306427"] = "LUX"; // Luxembourg
				countryCodeTranslation["1306430"] = "MAC"; // Macau SAR China
				countryCodeTranslation["1306433"] = "MKD"; // Macedonia
				countryCodeTranslation["1306436"] = "MDG"; // Madagascar
				countryCodeTranslation["1306439"] = "MWI"; // Malawi
				countryCodeTranslation["1306442"] = "MYS"; // Malaysia
				countryCodeTranslation["1306445"] = "MDV"; // Maldives
				countryCodeTranslation["1306448"] = "MLI"; // Mali
				countryCodeTranslation["1306451"] = "MLT"; // Malta
				countryCodeTranslation["1306454"] = "MHL"; // Marshall Islands
				countryCodeTranslation["1306457"] = "MTQ"; // Martinique
				countryCodeTranslation["1306460"] = "MRT"; // Mauritania
				countryCodeTranslation["1306463"] = "MUS"; // Mauritius
				countryCodeTranslation["1306466"] = "MEX"; // Mexico
				countryCodeTranslation["1306469"] = "FSM"; // Micronesia
				countryCodeTranslation["1306472"] = "MDA"; // Moldova
				countryCodeTranslation["1306475"] = "MCO"; // Monaco
				countryCodeTranslation["1306478"] = "MNG"; // Mongolia
				countryCodeTranslation["1306481"] = "MNE"; // Montenegro
				countryCodeTranslation["1306484"] = "MSR"; // Montserrat
				countryCodeTranslation["1306487"] = "MAR"; // Morocco
				countryCodeTranslation["1306490"] = "MOZ"; // Mozambique
				countryCodeTranslation["1306493"] = "MMR"; // Myanmar
				countryCodeTranslation["1306496"] = "NAM"; // Namibia
				countryCodeTranslation["1306499"] = "NRU"; // Nauru
				countryCodeTranslation["1306502"] = "NPL"; // Nepal
				countryCodeTranslation["1306505"] = "NLD"; // Netherlands
				countryCodeTranslation["1306508"] = ""; // Netherlands Antilles
				countryCodeTranslation["1306511"] = "NCL"; // New Caledonia
				countryCodeTranslation["1306514"] = "NZL"; // New Zealand
				countryCodeTranslation["1306517"] = "NIC"; // Nicaragua
				countryCodeTranslation["1306520"] = "NER"; // Niger
				countryCodeTranslation["1306523"] = "NGA"; // Nigeria
				countryCodeTranslation["1306526"] = "NIU"; // Niue
				countryCodeTranslation["1306529"] = "PRK"; // North Korea
				countryCodeTranslation["1306532"] = "MNP"; // Northern Mariana Islands
				countryCodeTranslation["1306535"] = "NOR"; // Norway
				countryCodeTranslation["1306538"] = "OMN"; // Oman
				countryCodeTranslation["1306541"] = "PAK"; // Pakistan
				countryCodeTranslation["1306544"] = "PLW"; // Palau
				countryCodeTranslation["1306547"] = "PAN"; // Panama
				countryCodeTranslation["1306550"] = "PNG"; // Papua New Guinea
				countryCodeTranslation["1306553"] = "PRY"; // Paraguay
				countryCodeTranslation["1306556"] = "PER"; // Peru
				countryCodeTranslation["1306559"] = "PHL"; // Philippines
				countryCodeTranslation["1306562"] = "POL"; // Poland
				countryCodeTranslation["1306565"] = "PRT"; // Portugal
				countryCodeTranslation["1306568"] = "PRI"; // Puerto Rico
				countryCodeTranslation["1306571"] = "QAT"; // Qatar
				countryCodeTranslation["1306574"] = "COD"; // Republic Of Congo
				countryCodeTranslation["1306577"] = "REU"; // Reunion
				countryCodeTranslation["1306580"] = "ROU"; // Romania
				countryCodeTranslation["1306583"] = "RUS"; // Russia
				countryCodeTranslation["1306586"] = "RWA"; // Rwanda
				countryCodeTranslation["1306589"] = "WSM"; // Samoa
				countryCodeTranslation["1306592"] = "SMR"; // San Marino
				countryCodeTranslation["1306595"] = "STP"; // Sao Tome / Principe
				countryCodeTranslation["1306598"] = "SAU"; // Saudi Arabia
				countryCodeTranslation["1306601"] = "SEN"; // Senegal
				countryCodeTranslation["1306604"] = "SRB"; // Serbia
				countryCodeTranslation["1306607"] = "SYB"; // Seychelles
				countryCodeTranslation["1306610"] = "SLE"; // Sierra Leone
				countryCodeTranslation["1306613"] = "SGP"; // Singapore
				countryCodeTranslation["1306616"] = "SVK"; // Slovakia
				countryCodeTranslation["1306619"] = "SLB"; // Solomon Islands
				countryCodeTranslation["1306622"] = "SOM"; // Somalia
				countryCodeTranslation["1306625"] = "ZAF"; // South Africa
				countryCodeTranslation["1306628"] = "KOR"; // South Korea
				countryCodeTranslation["1306631"] = "SSD"; // South Sudan
				countryCodeTranslation["1306634"] = "ESP"; // Spain
				countryCodeTranslation["1306637"] = "LKA"; // Sri Lanka
				countryCodeTranslation["1306640"] = "KNA"; // St Kitts / Nevis
				countryCodeTranslation["1306643"] = "LCA"; // St Lucia
				countryCodeTranslation["1306646"] = "VCT"; // St Vincent / the Grenadines
				countryCodeTranslation["1306649"] = "SDN"; // Sudan
				countryCodeTranslation["1306652"] = "SUR"; // Suriname
				countryCodeTranslation["1306655"] = "SWZ"; // Swaziland
				countryCodeTranslation["1306658"] = "SWE"; // Sweden
				countryCodeTranslation["1306661"] = "CHE"; // Switzerland
				countryCodeTranslation["1306664"] = "SYR"; // Syria
				countryCodeTranslation["1306667"] = "TWN"; // Taiwan (China)
				countryCodeTranslation["1306670"] = "TJK"; // Tajikistan
				countryCodeTranslation["1306673"] = "TZA"; // Tanzania
				countryCodeTranslation["1306676"] = "THA"; // Thailand
				countryCodeTranslation["1306679"] = "TGO"; // Togo
				countryCodeTranslation["1306682"] = "TON"; // Tonga
				countryCodeTranslation["1306685"] = "TTO"; // Trinidad / Tobago
				countryCodeTranslation["1306688"] = "TUN"; // Tunisia
				countryCodeTranslation["1306691"] = "TUR"; // Turkey
				countryCodeTranslation["1306694"] = "TKM"; // Turkmenistan
				countryCodeTranslation["1306697"] = "TCA"; // Turks / Caicos Islands
				countryCodeTranslation["1306700"] = "TUV"; // Tuvalu
				countryCodeTranslation["1306703"] = "UGA"; // Uganda
				countryCodeTranslation["1306706"] = "UKR"; // Ukraine
				countryCodeTranslation["1306709"] = "ARE"; // United Arab Emirates
				countryCodeTranslation["1306712"] = "GBR"; // United Kingdom
				countryCodeTranslation["1306715"] = "USA"; // United States
				countryCodeTranslation["1306718"] = "URY"; // Uruguay
				countryCodeTranslation["1306721"] = "VIR"; // US Virgin Islands
				countryCodeTranslation["1306724"] = "UZB"; // Uzbekistan
				countryCodeTranslation["1306727"] = "VUT"; // Vanuatu
				countryCodeTranslation["1306730"] = "VEN"; // Venezuela
				countryCodeTranslation["1306733"] = "VNM"; // Vietnam
				countryCodeTranslation["1306736"] = "YEM"; // Yemen
				countryCodeTranslation["1306739"] = "ZMB"; // Zambia
				countryCodeTranslation["1306742"] = "ZWE"; // Zimbabwe
			} else {
				countryCodeTranslation["392292"] = "";
				countryCodeTranslation["392295"] = "USA"; // United States
				countryCodeTranslation["392298"] = "CAN"; // Canada
				countryCodeTranslation["392301"] = "AFG"; // Afghanistan
				countryCodeTranslation["392304"] = "ALB"; // Albania
				countryCodeTranslation["392307"] = "DZA"; // Algeria
				countryCodeTranslation["392310"] = "ASM"; // American Samoa
				countryCodeTranslation["392313"] = "AND"; // Andorra
				countryCodeTranslation["392316"] = "AGO"; // Angola
				countryCodeTranslation["392319"] = "AIA"; // Anguilla
				countryCodeTranslation["392322"] = "ATA"; // Antarctica
				countryCodeTranslation["392325"] = "ATG"; // Antigua and Barbuda
				countryCodeTranslation["392328"] = "ARG"; // Argentina
				countryCodeTranslation["389353"] = "ARM"; // Armenia
				countryCodeTranslation["392334"] = "ABW"; // Aruba
				countryCodeTranslation["392337"] = "AUS"; // Australia
				countryCodeTranslation["392340"] = "AUT"; // Austria
				countryCodeTranslation["392343"] = "AZE"; // Azerbaijan
				countryCodeTranslation["392346"] = "BHS"; // Bahamas
				countryCodeTranslation["392349"] = "BHR"; // Bahrain
				countryCodeTranslation["392352"] = "BGD"; // Bangladesh
				countryCodeTranslation["392355"] = "BRB"; // Barbados
				countryCodeTranslation["392358"] = "BLR"; // Belarus
				countryCodeTranslation["392361"] = "BEL"; // Belgium
				countryCodeTranslation["392364"] = "BLZ"; // Belize
				countryCodeTranslation["392367"] = "BEN"; // Benin
				countryCodeTranslation["392370"] = "BMU"; // Bermuda
				countryCodeTranslation["392373"] = "BTN"; // Bhutan
				countryCodeTranslation["392376"] = "BOL"; // Bolivia
				countryCodeTranslation["392379"] = "BIH"; // Bosnia and Herzegovina
				countryCodeTranslation["392382"] = "BWA"; // Botswana
				countryCodeTranslation["392385"] = "BRA"; // Brazil
				countryCodeTranslation["392388"] = "IOT"; // British Indian Ocean Territory
				countryCodeTranslation["392391"] = "VGB"; // British Virgin Islands
				countryCodeTranslation["392394"] = "BRN"; // Brunei
				countryCodeTranslation["392397"] = "BGR"; // Bulgaria
				countryCodeTranslation["392400"] = "BFA"; // Burkina Faso
				countryCodeTranslation["392403"] = "BDI"; // Burundi
				countryCodeTranslation["392406"] = "KHM"; // Cambodia
				countryCodeTranslation["392409"] = "CMR"; // Cameroon
				countryCodeTranslation["392412"] = "CPV"; // Cape Verde
				countryCodeTranslation["392415"] = "CYM"; // Cayman Islands
				countryCodeTranslation["392418"] = "CAF"; // Central African Republic
				countryCodeTranslation["392421"] = "TCD"; // Chad
				countryCodeTranslation["392424"] = "CHL"; // Chile
				countryCodeTranslation["392427"] = "CHN"; // China
				countryCodeTranslation["392430"] = "CXR"; // Christmas Island
				countryCodeTranslation["392433"] = "CCK"; // Cocos (Keeling) Islands
				countryCodeTranslation["392436"] = "COL"; // Colombia
				countryCodeTranslation["392439"] = "COM"; // Comoros
				countryCodeTranslation["392442"] = "GOB"; // Congo
				countryCodeTranslation["392445"] = "COK"; // Cook Islands
				countryCodeTranslation["392448"] = "CRI"; // Costa Rica
				countryCodeTranslation["392451"] = "HRV"; // Croatia
				countryCodeTranslation["392454"] = "CUB"; // Cuba
				countryCodeTranslation["392457"] = "CUW"; // Curaçao
				countryCodeTranslation["392460"] = "CYP"; // Cyprus
				countryCodeTranslation["392463"] = "CZE"; // Czech Republic
				countryCodeTranslation["392466"] = "CIV"; // Côte d’Ivoire
				countryCodeTranslation["392469"] = "COD"; // Democratic Republic of the Congo
				countryCodeTranslation["392472"] = "DNK"; // Denmark
				countryCodeTranslation["392475"] = "DJI"; // Djibouti
				countryCodeTranslation["392478"] = "DMA"; // Dominica
				countryCodeTranslation["392481"] = "DOM"; // Dominican Republic
				countryCodeTranslation["392484"] = "ECU"; // Ecuador
				countryCodeTranslation["392487"] = "EGY"; // Egypt
				countryCodeTranslation["392490"] = "SLV"; // El Salvador
				countryCodeTranslation["392493"] = "GNQ"; // Equatorial Guinea
				countryCodeTranslation["392496"] = "ERI"; // Eritrea
				countryCodeTranslation["392499"] = "EST"; // Estonia
				countryCodeTranslation["392502"] = "ETH"; // Ethiopia
				countryCodeTranslation["392505"] = "FLK"; // Falkland Islands
				countryCodeTranslation["392508"] = "FRO"; // Faroe Islands
				countryCodeTranslation["392511"] = "FJI"; // Fiji
				countryCodeTranslation["392514"] = "FIN"; // Finland
				countryCodeTranslation["392517"] = "FRA"; // France
				countryCodeTranslation["392520"] = "GUF"; // French Guiana
				countryCodeTranslation["392523"] = "PYF"; // French Polynesia
				countryCodeTranslation["392526"] = "ATF"; // French Southern Territories
				countryCodeTranslation["392529"] = "GAB"; // Gabon
				countryCodeTranslation["392532"] = "GMB"; // Gambia
				countryCodeTranslation["392535"] = "GEO"; // Georgia
				countryCodeTranslation["392538"] = "DEU"; // Germany
				countryCodeTranslation["392541"] = "GHA"; // Ghana
				countryCodeTranslation["392544"] = "GIB"; // Gibraltar
				countryCodeTranslation["392547"] = "GRC"; // Greece
				countryCodeTranslation["392550"] = "GRL"; // Greenland
				countryCodeTranslation["392553"] = "GRD"; // Grenada
				countryCodeTranslation["392556"] = "GLP"; // Guadeloupe
				countryCodeTranslation["392559"] = "GUM"; // Guam
				countryCodeTranslation["392562"] = "GTM"; // Guatemala
				countryCodeTranslation["392565"] = "GGY"; // Guernsey
				countryCodeTranslation["392568"] = "GIN"; // Guinea
				countryCodeTranslation["392571"] = "GNB"; // Guinea-Bissau
				countryCodeTranslation["392574"] = "GUY"; // Guyana
				countryCodeTranslation["392577"] = "HTI"; // Haiti
				countryCodeTranslation["392580"] = "HND"; // Honduras
				countryCodeTranslation["392583"] = "HKG"; // Hong Kong S.A.R., China
				countryCodeTranslation["392586"] = "HUN"; // Hungary
				countryCodeTranslation["392589"] = "ISL"; // Iceland
				countryCodeTranslation["392592"] = "IND"; // India
				countryCodeTranslation["392595"] = "IDN"; // Indonesia
				countryCodeTranslation["392598"] = "IRN"; // Iran
				countryCodeTranslation["392601"] = "IRQ"; // Iraq
				countryCodeTranslation["392604"] = "IRL"; // Ireland
				countryCodeTranslation["392607"] = "IMN"; // Isle of Man
				countryCodeTranslation["392610"] = "ISR"; // Israel
				countryCodeTranslation["392613"] = "ITA"; // Italy
				countryCodeTranslation["392616"] = "JAM"; // Jamaica
				countryCodeTranslation["392619"] = "JPN"; // Japan
				countryCodeTranslation["392622"] = "JEY"; // Jersey
				countryCodeTranslation["392625"] = "JOR"; // Jordan
				countryCodeTranslation["392628"] = "KAZ"; // Kazakhstan
				countryCodeTranslation["392631"] = "KEN"; // Kenya
				countryCodeTranslation["392634"] = "KIR"; // Kiribati
				countryCodeTranslation["392637"] = "KWT"; // Kuwait
				countryCodeTranslation["392640"] = "KGZ"; // Kyrgyzstan
				countryCodeTranslation["392643"] = "LAO"; // Laos
				countryCodeTranslation["392646"] = "LVA"; // Latvia
				countryCodeTranslation["392649"] = "LBN"; // Lebanon
				countryCodeTranslation["392652"] = "LSO"; // Lesotho
				countryCodeTranslation["392655"] = "LBR"; // Liberia
				countryCodeTranslation["392658"] = "LBY"; // Libya
				countryCodeTranslation["392661"] = "LIE"; // Liechtenstein
				countryCodeTranslation["392664"] = "LTU"; // Lithuania
				countryCodeTranslation["392667"] = "LUX"; // Luxembourg
				countryCodeTranslation["392670"] = "MAC"; // Macao S.A.R., China
				countryCodeTranslation["392673"] = "MKD"; // Macedonia
				countryCodeTranslation["392676"] = "MDG"; // Madagascar
				countryCodeTranslation["392679"] = "MWI"; // Malawi
				countryCodeTranslation["392682"] = "MYS"; // Malaysia
				countryCodeTranslation["392685"] = "MDV"; // Maldives
				countryCodeTranslation["392688"] = "MLI"; // Mali
				countryCodeTranslation["392691"] = "MLT"; // Malta
				countryCodeTranslation["392694"] = "MHL"; // Marshall Islands
				countryCodeTranslation["392697"] = "MTQ"; // Martinique
				countryCodeTranslation["392700"] = "MRT"; // Mauritania
				countryCodeTranslation["392703"] = "MUS"; // Mauritius
				countryCodeTranslation["392706"] = "MYT"; // Mayotte
				countryCodeTranslation["392709"] = "MEX"; // Mexico
				countryCodeTranslation["392712"] = "FSM"; // Micronesia
				countryCodeTranslation["392715"] = "MDA"; // Moldova
				countryCodeTranslation["392718"] = "MCO"; // Monaco
				countryCodeTranslation["392721"] = "MNG"; // Mongolia
				countryCodeTranslation["392724"] = "MNE"; // Montenegro
				countryCodeTranslation["392727"] = "MSR"; // Montserrat
				countryCodeTranslation["392730"] = "MAR"; // Morocco
				countryCodeTranslation["392733"] = "MOZ"; // Mozambique
				countryCodeTranslation["392736"] = "MMR"; // Myanmar
				countryCodeTranslation["392739"] = "NAM"; // Namibia
				countryCodeTranslation["392742"] = "NRU"; // Nauru
				countryCodeTranslation["392745"] = "NPL"; // Nepal
				countryCodeTranslation["392748"] = "NLD"; // Netherlands
				countryCodeTranslation["392751"] = "NCL"; // New Caledonia
				countryCodeTranslation["392754"] = "NZL"; // New Zealand
				countryCodeTranslation["392757"] = "NIC"; // Nicaragua
				countryCodeTranslation["392760"] = "NER"; // Niger
				countryCodeTranslation["392763"] = "NGA"; // Nigeria
				countryCodeTranslation["392766"] = "NIU"; // Niue
				countryCodeTranslation["392769"] = "NFK"; // Norfolk Island
				countryCodeTranslation["392772"] = "PRK"; // North Korea
				countryCodeTranslation["392775"] = "MNP"; // Northern Mariana Islands
				countryCodeTranslation["392778"] = "NOR"; // Norway
				countryCodeTranslation["392781"] = "OMN"; // Oman
				countryCodeTranslation["392784"] = "PAK"; // Pakistan
				countryCodeTranslation["392787"] = "PLW"; // Palau
				countryCodeTranslation["392790"] = "PSE"; // Palestinian Territory
				countryCodeTranslation["392793"] = "PAN"; // Panama
				countryCodeTranslation["392796"] = "PNG"; // Papua New Guinea
				countryCodeTranslation["392799"] = "PRY"; // Paraguay
				countryCodeTranslation["392802"] = "PER"; // Peru
				countryCodeTranslation["392805"] = "PHL"; // Philippines
				countryCodeTranslation["392808"] = "PCN"; // Pitcairn
				countryCodeTranslation["392811"] = "POL"; // Poland
				countryCodeTranslation["392814"] = "PRT"; // Portugal
				countryCodeTranslation["392817"] = "PRI"; // Puerto Rico
				countryCodeTranslation["392820"] = "QAT"; // Qatar
				countryCodeTranslation["392823"] = "ROU"; // Romania
				countryCodeTranslation["392826"] = "RUS"; // Russia
				countryCodeTranslation["392829"] = "RWA"; // Rwanda
				countryCodeTranslation["392832"] = "REU"; // Réunion
				countryCodeTranslation["392835"] = "BLM"; // Saint Barthélemy
				countryCodeTranslation["392838"] = "SHN"; // Saint Helena
				countryCodeTranslation["392841"] = "KNA"; // Saint Kitts and Nevis
				countryCodeTranslation["392844"] = "LCA"; // Saint Lucia
				countryCodeTranslation["392847"] = "SPM"; // Saint Pierre and Miquelon
				countryCodeTranslation["392850"] = "VCT"; // Saint Vincent and the Grenadines
				countryCodeTranslation["392853"] = "WSM"; // Samoa
				countryCodeTranslation["392856"] = "SMR"; // San Marino
				countryCodeTranslation["392859"] = "STP"; // Sao Tome and Principe
				countryCodeTranslation["392862"] = "SAU"; // Saudi Arabia
				countryCodeTranslation["392865"] = "SEN"; // Senegal
				countryCodeTranslation["392868"] = "SRB"; // Serbia
				countryCodeTranslation["392871"] = "SYB"; // Seychelles
				countryCodeTranslation["392874"] = "SLE"; // Sierra Leone
				countryCodeTranslation["392877"] = "SGP"; // Singapore
				countryCodeTranslation["392880"] = "SVK"; // Slovakia
				countryCodeTranslation["392883"] = "SVN"; // Slovenia
				countryCodeTranslation["392886"] = "SLB"; // Solomon Islands
				countryCodeTranslation["392889"] = "SOM"; // Somalia
				countryCodeTranslation["392892"] = "ZAF"; // South Africa
				countryCodeTranslation["392895"] = "KOR"; // South Korea
				countryCodeTranslation["392898"] = "SSD"; // South Sudan
				countryCodeTranslation["392901"] = "ESP"; // Spain
				countryCodeTranslation["392904"] = "LKA"; // Sri Lanka
				countryCodeTranslation["392907"] = "SDN"; // Sudan
				countryCodeTranslation["392910"] = "SUR"; // Suriname
				countryCodeTranslation["392913"] = "SJM"; // Svalbard and Jan Mayen
				countryCodeTranslation["392916"] = "SWZ"; // Swaziland
				countryCodeTranslation["392919"] = "SWE"; // Sweden
				countryCodeTranslation["392922"] = "CHE"; // Switzerland
				countryCodeTranslation["392925"] = "SYR"; // Syria
				countryCodeTranslation["392928"] = "TWN"; // Taiwan
				countryCodeTranslation["392931"] = "TJK"; // Tajikistan
				countryCodeTranslation["392934"] = "TZA"; // Tanzania
				countryCodeTranslation["392937"] = "THA"; // Thailand
				countryCodeTranslation["392940"] = "TLS"; // Timor-Leste
				countryCodeTranslation["392943"] = "TGO"; // Togo
				countryCodeTranslation["392946"] = "TKL"; // Tokelau
				countryCodeTranslation["392949"] = "TON"; // Tonga
				countryCodeTranslation["392952"] = "TTO"; // Trinidad and Tobago
				countryCodeTranslation["392955"] = "TUN"; // Tunisia
				countryCodeTranslation["392958"] = "TUR"; // Turkey
				countryCodeTranslation["392961"] = "TKM"; // Turkmenistan
				countryCodeTranslation["392964"] = "TCA"; // Turks and Caicos Islands
				countryCodeTranslation["392967"] = "TUV"; // Tuvalu
				countryCodeTranslation["392970"] = "VIR"; // U.S. Virgin Islands
				countryCodeTranslation["392973"] = "UGA"; // Uganda
				countryCodeTranslation["392976"] = "UKR"; // Ukraine
				countryCodeTranslation["392979"] = "ARE"; // United Arab Emirates
				countryCodeTranslation["392982"] = "GBR"; // United Kingdom
				countryCodeTranslation["392985"] = "UMI"; // United States Minor Outlying Islands
				countryCodeTranslation["392988"] = "URY"; // Uruguay
				countryCodeTranslation["392991"] = "UZB"; // Uzbekistan
				countryCodeTranslation["392994"] = "VUT"; // Vanuatu
				countryCodeTranslation["392997"] = "VAT"; // Vatican
				countryCodeTranslation["393000"] = "VEN"; // Venezuela
				countryCodeTranslation["393003"] = "VNM"; // Viet Nam
				countryCodeTranslation["393006"] = "WLF"; // Wallis and Futuna
				countryCodeTranslation["393009"] = "ESH"; // Western Sahara
				countryCodeTranslation["393012"] = "YEM"; // Yemen
				countryCodeTranslation["393015"] = "ZMB"; // Zambia
				countryCodeTranslation["393018"] = "ZWE"; // Zimbabwe
			}
		},
		resetEvents: function (injectionPoint, inspection) {
			// this is brutish approach that i may need to take for pardot. replace the form with a deep clone of itself to strip all events
			formElement.replaceWith(formElement.cloneNode(true));
			// it's not taking on new events after the clone for some reason
			setFormElement(injectionPoint);

			// remove events and optionally disable the button(s)
			std.santizeSubmitButtons(formElement, inspection);

			formElement.addEventListener("submit", standardLeadForm.formSubmit);
			formElement.addEventListener("click", clearMessages);
		},
		formInspect: function () {
			std.addStylesheet('{{rooturl}}');

			// testing out structural elements. so let's load the form
			let frm = Common.formObj.loadObjectCollection(getFieldCollection(), true); // "true" will get values for checkboxes which are not checked. we just want all the elements. ignore the values

			console.log(frm);

			// just going to go quick and dirty on this here
			// we're looking for some specific properties to exist on the frm object. if they are undefined, the form does not have what it needs
			let requiredFields = new Array (
				{prop : "firstName", display : "First Name"},
				{prop : "lastName", display : "Last Name"},
				{prop : "company", display : "Company Name"},
				{prop : "emailAddress", display : "Email Address"},
				{prop : "countryCode", display : "Country Code"},
				{prop : "formType", display : "Form Type"}, // Marketing | Sales
				{prop : "leadSource", display : "Lead Source (MarketingCenter, LinkedIn, Google, etc)"},
				{prop : "campaignId", display : "Campaign Id"},
				{prop : "phone", display : "Phone Number"},
				{prop : "zipCode", display : "Zip/Postal code"}
				//"brand",
				//"sourceType", "Web (1)"
			);

			let errors = [];

			requiredFields.forEach(function (p) {
				if (frm[p.prop] === undefined) {
					let msg = `Missing ${p.display} field. <p class="instruction">Please be sure there is a field with the <span class="code">data-bindingname="${p.prop}"</span> attribute and value.</p>`;
					errors.push(msg);
				}
			});

			// 2024-10-11 pardot... hrrrgggggghh
			// if the countrycode is empty/missing, set it to USA
			if (frm.countryCode && frm.countryCode.value == "") {
				frm.countryCode.value = "USA";
			}

			// also must have either marketingOptIn or optIntoSegments[{segmentid, boolean}, {segmentid, boolean}, ...]
			if (frm["marketingOptIn"] === undefined && frm["optIntoSegments"] === undefined) {
				errors.push(`An Opt-in/out field must be provided.
					<p class="instruction">Use <span class="code">data-bindingname="marketingOptIn"</span> with a value of <span class="code">1</span> on a checkbox input for brand-level opt, or use <span class="code">data-bindingname="optIntoSegments"</span> passing in a value of SegmentId for each checkbox.</p>
					<p class="instruction">Add <span class="code">data-strict-type="boolean"</span> to coerce the value into an actual boolean value. (Turns "1" into <span class="code">true</span>)</p>
					<p class="instruction">Example : <span class="code">&lt;input type="checkbox" name="SomeFieldName" data-bindingname="marketingOptIn" data-strict-type="boolean" value="1" /&gt;</span></p>`);
			}

			// i think for some fields it's not enough to check that it exists. they should have values *if* they are hidden fields
			// an example would be CountryCode - if it's a select, it will start empty potentially. but if it's a hidden field, it needs to have a value
			if (frm.countryCode !== undefined) {
				let el = formElement.querySelector("input[type=hidden][data-bindingname=countryCode]");
				if (el && el.value == "") {
					errors.push(`Country Code must have a value. <p class="instruction">Because this is a hidden field, it is expected to have a value provided to it (hardcoded).</p><p class="instruction">This field should only use 3-letter ISO country code values.</p>`);
				}
			}

			if (frm.optIntoSegments !== undefined && Array.isArray(frm.optIntoSegments) == false) {
				errors.push(`Opt-In Segments is malformed.
					<p class="instruction">Be sure that all segment checkboxes have the same <span class="code">name</span> attribute.</p>
					<p class="instruction">Additionally, ensure each checkbox has the following attributes : <span class="code">data-bindingname="optIntoSegments" data-strict-type="int"</p>.</p>`);
			}

			// additionally we are going to require a success message element exist in the page so that the brands can control that
			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);
			if (successContainer === undefined || successContainer == null) {
				errors.push(`Missing Success Message container.
					<p class="instruction">Please ensure that you have a hidden element (div, span, p, etc) in the page with a success message.</p>
					<p class="instruction">It has two requirements : <span class="code">data-bindingname="successContainer"</span> and <span class="code">style="display:none;"</span></p>`);
			}

			errors.forEach(function(err) {
				console.log(err);
			});

			// inject a div into the form as the last element if it doesn't exist and push the messaging into that
			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "validation-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .validation-container`);
			}

			if (errors.length == 0) {
				// 2024-09-20 gene asked that the structural success message not show for tsm+
				if (!(env.startsWith('t') || env.startsWith('p'))) {
					std.addClass(responseContainer, "structural-validation-success");
					responseContainer.innerHTML = `<h3>This form passes all structural checks for <em>required</em> fields!</h3>
					<p>
						It is important to note that any fields which do not align with the field naming in
						<a href="https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint" target="_blank">The Wiki</a> will be put into the
						unstructured <span class="code">additionalData</span> field.
					</p>
					<p>Please add <span class="code">data-bindingname="fieldNameHere"</span> for any fields that you wish to collect in a structured manner. For example : add <span class="code">data-bindingname="stateCode"</span> to decorate a State select.</p>
					<p>An example payload from this form\'s elements: <div class="code json">${JSON.stringify(std.createPayloadFormatted(frm), null, 4)}</div></p>`;
				}

				// re-enable the submit button
				let submits = document.querySelectorAll(`#${formElement.id} input[type=submit], #${formElement.id} button[type=submit], #${formElement.id} button:not([type])`);

				if (submits) {
					submits.forEach(function(el) {
						console.log("submit : ");
						console.log(el);
						el.removeAttribute("disabled");
					});
				}

				return true;
			}

			std.addClass(responseContainer, "structural-validation-error");
			responseContainer.innerHTML = `<h3>Errors found with this form : </h3><p><ul>${(errors.map(function(el) { return `<li>${el}</li>` }).join(''))}</ul></p>`;
			return false;
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "response-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .response-container`);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			// this is the biggie where pardot differs from others - how the form elements are discovered
			// rahter than take a form element, we need to build the collection of fields differently
			// let frm = Common.formObj.load(formElement.parentNode);
			let frm = Common.formObj.loadObjectCollection(getFieldCollection());

			// translate the countryCode
			if (frm.countryCode != "") {
				if (countryCodeTranslation[frm.countryCode] === undefined || countryCodeTranslation[frm.countryCode] === null) {
					frm.countryCode = null;
				} else {
					frm.countryCode = countryCodeTranslation[frm.countryCode];
				}
			}

			frm = std.createPayloadFormatted(frm);

			console.log(frm);

			responseContainer.innerHTML = `${translations.submitting}...`;

			let response = await fetch ("{{rooturl}}/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {

				// for all errors, look up tokens which match fields.
				// when found, replace with the placeholder text of the input
				response.errors.forEach (function (el) {

					const regex = /\{\{(?<prop>[a-zA-Z]+)\}\}/;

					let propNameMatches = regex.exec(el.errorMessage);

					if (propNameMatches === null || propNameMatches.length === 0) {
						return;
					}

					if (propNameMatches.groups && propNameMatches.groups.prop) {
						// find the element with this data binding name and get the placeholder or label. placeholder first
						let inputElement = formElement.querySelector(`[data-bindingname=${propNameMatches.groups.prop}]`);

						if (inputElement) {
							let replacementValue = null;

							if (inputElement.hasAttribute("placeholder")) {
								replacementValue = inputElement.getAttribute("placeholder");
							}

							if (replacementValue === null) {
								// look for a label. it should have for="id-of-input"
								let label = formElement.querySelector(`label[for="${inputElement.id}"]`);
								if (label) {
									replacementValue = label.innerText;
								}
							}

							el.errorMessage = el.errorMessage.replace(propNameMatches[0], replacementValue);
						}
					}
				});

				responseContainer.innerHTML = `<div class="error"><p>${response.message}</p><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);

			if (successContainer && successContainer.style) {
				// just remove the "display:none;" from the style
				responseContainer.innerHTML = '';
				successContainer.style.removeProperty("display");
			} else {
				responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			}

			formElement.reset();

			// if the config has a redirectUrl property, redirect to that url on success
			if (config.redirectUrl !== undefined) {
				location.href = config.redirectUrl;
			}
		}
	}
}("{{environment}}", '{{locale}}', '{{config}}');

window.addEventListener('DOMContentLoaded', () => {
	standardLeadForm.init('{{injectionPoint}}');
});

// wait until everything is loaded before stripping events and adding new events
// window.document.onreadystatechange = function () {
// 	if (document.readyState == "complete") {
// 		standardLeadForm.resetEvents();
// 	}
// }