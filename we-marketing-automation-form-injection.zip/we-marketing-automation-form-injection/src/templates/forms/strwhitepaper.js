let formdef456 = function() {

	function getAttribution () {
		let url = new URL(window.location.href);
		let params = url.searchParams;
		//let attribution = params.get('utm_campaign_id'); // just for testing. my firefox instance cleans utm_* garbage from querystrings
		let attribution = params.get('campaignid');

		return attribution;
	}

	return {
		init: function (ip) {
			let injectionPoint = document.querySelector(ip);

			if (injectionPoint === undefined || injectionPoint === null) {
				return;
			}

			injectionPoint.innerHTML = `
<form id="Form-{{scriptcd}}">
	<div id="Form-FirstName-{{scriptcd}}" class="standard-element-container">
		<label for="FirstName-{{scriptcd}}" class="hide">First Name</label>
		<input type="text" id="FirstName-{{scriptcd}}" name="FirstName" required="required" autocorrect="false" autocapitalize="false" placeholder="First Name *"/>
	</div>
	<div id="Form-LastName-{{scriptcd}}" class="standard-element-container">
		<label for="LastName-{{scriptcd}}" class="hide">Last Name</label>
		<input type="text" id="LastName-{{scriptcd}}" name="LastName" required="required" autocorrect="false" autocapitalize="false" placeholder="Last Name *"/>
	</div>
	<div id="Form-EmailAddress-{{scriptcd}}" class="standard-element-container">
		<label for="EmailAddress-{{scriptcd}}" class="hide">Email Address</label>
		<input type="email" id="EmailAddress-{{scriptcd}}" name="EmailAddress" required="required" autocorrect="false" autocapitalize="false" placeholder="Email Address *"/>
	</div>
	<div id="Form-PhoneNumber-{{scriptcd}}" class="standard-element-container">
		<label for="PhoneNumber-{{scriptcd}}" class="hide">Phone Number</label>
		<input type="tel" id="PhoneNumber-{{scriptcd}}" name="PhoneNumber" required="required" autocorrect="false" autocapitalize="false" placeholder="Phone Numbers *"/>
	</div>
	<div id="Form-CompanyName-{{scriptcd}}" class="standard-element-container">
		<label for="CompanyName-{{scriptcd}}" class="hide">Company Name</label>
		<input type="text" id="CompanyName-{{scriptcd}}" name="CompanyName" required="required" autocorrect="false" autocapitalize="false" placeholder="Company *"/>
	</div>
	<div id="Form-CompanyType-{{scriptcd}}" class="standard-element-container">
		<label for="CompanyType-{{scriptcd}}" class="hide">Company Type</label>
		<select id="CompanyType-{{scriptcd}}" name="CompanyType" required="required">
			<option value="" selected="selected">Company Type *</option>
			<option value="3146851">Academia: Education and research programs for universities and professionals</option>
			<option value="3146854">Operator: Own, operate and/or manage properties</option>
			<option value="3146857">Industry Partners: Consultants, investors, developers, suppliers and other hospitality solution providers</option>
			<option value="3146860">Destination: City, regional and government organizations promoting tourism</option>
		</select>
	</div>
	<div id="Form-City-{{scriptcd}}" class="standard-element-container">
		<label for="City-{{scriptcd}}" class="hide">City</label>
		<input type="text" id="City-{{scriptcd}}" name="City" required="required" autocorrect="false" autocapitalize="false" placeholder="City *"/>
	</div>
	<div id="Form-Country-{{scriptcd}}" class="standard-element-container">
		<label for="Country-{{scriptcd}}" class="hide">Postal Code</label>
		<input type="text" id="Country-{{scriptcd}}" name="Country" required="required" autocorrect="false" autocapitalize="false" placeholder="Country *"/>
	</div>

	<div id="Form-OptIn-{{scriptcd}}" class="standard-element-container checkbox-container">
		<label for="OptIn-{{scriptcd}}">Yes, I would like to receive email updates about products, services, news and events from STR and its affiliates. </label>
		<input type="checkbox" id="OptIn-{{scriptcd}}" name="OptIn" value="yes"/>
	</div>

	<p id="Fineprint-{{scriptcd}}" class="fineprint">Your personal information will be handled in accordance with the <a href="https://www.costar.com/about/privacy-notice" target="_blank">CoStar Global Privacy Policy</a>.</p>

	<div id="Form-Submit-{{scriptcd}}">
		<button type="submit">Submit</button>
	</div>

	<div id="OptIn-{{scriptcd}}">

	</div>
</form>
<div id="Response-{{scriptcd}}"></div>
`;
			document.getElementById("Form-{{scriptcd}}").addEventListener("submit", formdef456.formSubmit);
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			responseContainer.innerHTML = "";

			let formIsValid = document.getElementById("Form-{{scriptcd}}").reportValidity();

			if (!formIsValid) {
				return;
			}

			responseContainer.innerHTML = "Submitting...";

			let response = await fetch ("/api/v1/whitepaper/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify({
					firstName: document.getElementById("FirstName-{{scriptcd}}").value,
					lastName: document.getElementById("LastName-{{scriptcd}}").value,
					emailAddress: document.getElementById("EmailAddress-{{scriptcd}}").value,
					phone: document.getElementById("PhoneNumber-{{scriptcd}}").value,
					zipCode: '00000', //document.getElementById("PostalCode-{{scriptcd}}").value,
					company: document.getElementById("CompanyName-{{scriptcd}}").value,
					countryCode : "USA",
					campaignAttribution: getAttribution()
				})
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {
				responseContainer.innerHTML = `<div class="error"><p>${response.message}</p><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			responseContainer.innerHTML = `<div class="success">${response.message}</div>`;

			if (response.downloadUrl !== undefined) {
				//location.href = response.downloadUrl;
				window.open (
					response.downloadUrl,
					'_blank'
				);
			}
		}
	}
}();

window.addEventListener('DOMContentLoaded', () => {
	formdef456.init('{{injectionPoint}}');
});