import "{{rooturl}}/api/v1/js/eventlisteners";
import * as Common from "{{rooturl}}/api/v1/js/common";
import { standardFormUtils as std } from "{{rooturl}}/api/v1/js/standard-form-functions";

// import "{{rooturl}}/static/js/eventlisteners.js";
// import * as Common from "{{rooturl}}/static/js/common.js";
// import { standardFormUtils as std } from "{{rooturl}}/static/js/standard-form-functions.js";

// window.addEventListener("eventAdded", function (e) {
// 	let el = e.detail.element;
// 	console.log(`event type '${e.detail.eventType}' added to element ${el.nodeName}`);
// });

let standardLeadForm = function (
	env,
	locale,
	config
) {
	// it's coming in as a string
	if (config) {
		config = JSON.parse(config);
	}

	let formElement = null;
	let responseContainer = null;
	let translations = null;

	function clearMessages () {
		if (responseContainer) {
			responseContainer.innerHTML = "";
		}
	}

	function loadUtms () {
		let utms = std.getUtms();
		let campaignField = document.querySelector("[data-bindingname=campaignId]");

		if (campaignField) {
			if (utms.campaignId) {
				campaignField.value = utms.campaignId;
				window.sessionStorage.setItem("campaignId", utms.campaignId);
				//console.log(`campaign id value '${utms.campaignId}' found in the querystring. setting input value and sessionStorage`);
				return;
			}

			let sessionCampaignId = window.sessionStorage.getItem("campaignId");

			if (sessionCampaignId) {
				//console.log(`campaign id value '${sessionCampaignId}' found in sessionStorage. setting input value`);
				campaignField.value = sessionCampaignId;
			}
		}
	}

	function loadEcid () {
		if (!formElement) {
			return;
		}

		let url = new URL(window.location.href);
		let params = url.searchParams;
		let ecid = params.get("ecid");

		if (ecid == null) {
			return;
		}

		var ecidinput = document.getElementById("ecid");

		if (!ecidinput) {
			let d = document.createElement("input");
			d.id = "ecid";
			d.setAttribute("name", "ecid");
			d.setAttribute("type", "hidden");
			formElement.append(d);
		}

		ecidinput = document.getElementById("ecid");
		ecidinput.setAttribute("value", ecid);
	}

	// 2025-07-25. gene asked that unchecked checkboxes submit a false
	// this violates explicit versus implicit actions (though this is due to costar using checkboxes for opts which is simply the wrong form element to use)
	// was waiting on legal to hash this out but gene would like it done now
	// so here we are
	// only handling optIntoSegments for now, not the deprecated brand-based opt type
	function courseCorrectOptChecks (payload) {
		if (payload.optIntoSegments === undefined || Array.isArray(payload.optIntoSegments) == false) {
			return payload;
		}

		let newSegments = [];

		// loop the segments, looking for a match on binding name and value and look for checked state
		payload.optIntoSegments.forEach(function(el) {
			let checkboxEls = document.querySelectorAll("[data-bindingname=optIntoSegments]");

			if (!checkboxEls) {
				return;
			}

			// find the one with the matching value
			let checkboxEl = [...checkboxEls].find((cb) => cb.value == el.segment);

			if (!checkboxEl) {
				return;
			}

			// these can be hidden fields and not checkboxes. if hidden, assume "true" for the pref
			// set the optInPref to match the checked state
			let newEl = el;
			newEl.optInPref = checkboxEl.type == "hidden" || checkboxEl.checked;

			newSegments.push(newEl);
		});

		payload.optIntoSegments = newSegments;

		return payload;
	}

	// 2025-10-13 laying in the pieces to deal with split vs bundled consent
	// it's all country dependent
	// the default is bundled consent, so we're really just looking for countries with split consent
	function countryCodeChange (evt) {
		console.log(evt);
		let val = evt.target.value;

		// first let's see if the containers exist. otherwise this is pointless
		let bundleContainer = document.querySelector("[data-bindingname=consent-container-bundle]");
		let splitContainer = document.querySelector("[data-bindingname=consent-container-split]");

		if (!bundleContainer || !splitContainer) {
			return;
		}

		if (val === "") {
			// hide and exit
			bundleContainer.style.setProperty("display", "none", "important");
			splitContainer.style.setProperty("display", "none", "important");
			return;
		}

		if (isSplitConsent(val)) {
			bundleContainer.style.setProperty("display", "none", "important");
			splitContainer.style.removeProperty("display");
			return;
		}

		// show bundled
		splitContainer.style.setProperty("display", "none", "important");
		bundleContainer.style.removeProperty("display");
	}

	function isSplitConsent (countryCode) {
		return countryCode === "USA";
	}

	async function checkForSession () {
		try {
			let ecidel = document.getElementById("ecid");
			let _gael = document.getElementById("_ga");

			if (!ecidel || !_gael) {
				return;
			}

			let ecid = ecidel.value;
			let _ga = _gael.value;

			if (ecid == "" || _ga == "") {
				return;
			}

			let response = await fetch ("{{rooturl}}/api/v1/gasession", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify({"ecid":ecid, "sessionId":_ga})
			});
			//.then(response => response.json());
			// console.log(response);
		} catch (oops) {
			console.log("error checking for session");
			console.log(oops);
		}
	}

	return {
		init: function (injectionPoint) {
			console.log("formscript initialized");

			translations = "{{translations}}";

			formElement = document.querySelector(injectionPoint);

			if (formElement === undefined || formElement === null) {
				// if not found, look for any forms decorated with data-bindingname="form"
				formElement = document.querySelector('form[data-bindingname="form"]');
			}

			// still missing? show a banner
			if (formElement === undefined || formElement === null) {
				// todo: cover the page with a div and a message about what's missing?
				// for now in lower envs put a banner at the top of the page
				// but not in production
				if (env === "prd") {
					return;
				}
				std.showMissingFormBanner('{{rooturl}}');
				return;
			}

			loadUtms();
			loadEcid();

			// this will pass in prd as it's expected to have been evaluated in lower environments
			let inspection = (env === "prd") || standardLeadForm.formInspect();

			// pardot forms have script elements *within* the form element. wth! get rid of them
			formElement.querySelectorAll("script").forEach(e => e.remove());

			// add a locale field if it doesn't exist
			std.addLocaleField(formElement, locale);
			// and a honeypot field
			std.addAdditionalValuesField(formElement);

			// some forms have overly restrictive input patterns (or just wrong). touch them up
			std.realignFieldConstraints(formElement);

			// remove any `form-injection-noscript-banner` banners
			document.querySelectorAll(".form-injection-noscript-banner").forEach(e => e.remove());

			standardLeadForm.resetEvents(inspection);

			// check for ecid/_ga combo
			window.setTimeout(checkForSession, 1500);
		},
		resetEvents: function (inspection) {

			// this is just about taking control over the form submission
			formElement.removeEventListenersByType("input");
			formElement.removeEventListenersByType("change");
			formElement.removeEventListenersByType("submit");

			// roll through all child elements and remove some events
			std.unEventChildrenRecurse(formElement);

			// remove events and optionally disable the button(s)
			std.santizeSubmitButtons(formElement, inspection);

			formElement.addEventListener("submit", standardLeadForm.formSubmit);
			formElement.addEventListener("click", clearMessages);

			// add a change event to the country code
			formElement.querySelector("[data-bindingname=countryCode]").addEventListener("change", countryCodeChange);
		},
		formInspect: function () {
			std.addStylesheet('{{rooturl}}');

			// testing out structural elements. so let's load the form
			let frm = Common.formObj.load(formElement.parentNode, true); // "true" will get values for checkboxes which are not checked. we just want all the elements. ignore the values

			//console.log(frm);

			// just going to go quick and dirty on this here
			// we're looking for some specific properties to exist on the frm object. if they are undefined, the form does not have what it needs
			let requiredFields = new Array (
				{prop : "firstName", display : "First Name"},
				{prop : "lastName", display : "Last Name"},
				{prop : "company", display : "Company Name"},
				{prop : "emailAddress", display : "Email Address"},
				{prop : "countryCode", display : "Country Code"},
				{prop : "formType", display : "Form Type"}, // Marketing | Sales
				{prop : "leadSource", display : "Lead Source (MarketingCenter, LinkedIn, Google, etc)"},
				{prop : "campaignId", display : "Campaign Id"},
				{prop : "phone", display : "Phone Number"},
				{prop : "zipCode", display : "Zip/Postal code"}
				//"brand",
				//"sourceType", "Web (1)"
			);

			let errors = [];

			requiredFields.forEach(function (p) {
				if (frm[p.prop] === undefined) {
					let msg = `Missing ${p.display} field. <p class="instruction">Please be sure there is a field with the <span class="code">data-bindingname="${p.prop}"</span> attribute and value.</p>`;
					errors.push(msg);
				}
			});

			if (frm["marketingOptIn"] !== undefined) {
				errors.push(`<span class="code">marketingOptIn</span> is being deprecated.
					<p class="instruction">Use checkboxes or radios with <span class="code">data-bindingname="optIntoSegments" data-strict-type="int"</span> instead.</p>
					<p class="instruction">If you're not sure what your Segment/Preference Id's are, please contact the Marketing Automation team.</p>`);
			}

			// also must have either marketingOptIn or optIntoSegments[{segmentid, boolean}, {segmentid, boolean}, ...]
			if (frm["marketingOptIn"] === undefined && frm["optIntoSegments"] === undefined) {
				errors.push(`An Opt-in/out field must be provided.
					<p class="instruction">Use <span class="code">data-bindingname="optIntoSegments"</span> passing in a value of SegmentId for each checkbox.</p>
					<p class="instruction">Any number of Segments/Preferences can be provided, just ensure that the <span class="code">name="SomeFieldName"</span> attributes have the same value so that the opts are grouped.</p>
					<p class="instruction">Example : <span class="code">&lt;input type="checkbox" name="SomeFieldName" data-bindingname="optIntoSegments" data-strict-type="int" value="9" /&gt;</span></p>
					<p class="instruction">Contact the Marketing Automation team if you are unsure which Segment/Preference Id values to use.<p>`);
			}

			// i think for some fields it's not enough to check that it exists. they should have values *if* they are hidden fields
			// an example would be CountryCode - if it's a select, it will start empty potentially. but if it's a hidden field, it needs to have a value
			if (frm.countryCode !== undefined) {
				let el = formElement.querySelector("input[type=hidden][data-bindingname=countryCode]");
				if (el && el.value == "") {
					errors.push(`Country Code must have a value. <p class="instruction">Because this is a hidden field, it is expected to have a value provided to it (hardcoded).</p><p class="instruction">This field should only use 3-letter ISO country code values.</p>`);
				}
			}

			// optIntoSegments can be an array of values, or a non-array single value
			// if single, make it an array since it's expected
			if (frm.optIntoSegments !== undefined) {
				if (Array.isArray(frm.optIntoSegments) == false) {
					let optvalue = frm.optIntoSegments;

					// change this into an array with the value
					frm.optIntoSegments = [];
					frm.optIntoSegments.push(optvalue);
				}
			}

			if (frm.optIntoSegments !== undefined && Array.isArray(frm.optIntoSegments) == false) {
				errors.push(`Opt-In Segments is malformed.
					<p class="instruction">Be sure that all segment checkboxes have the same <span class="code">name</span> attribute.</p>
					<p class="instruction">Additionally, ensure each checkbox has the following attributes : <span class="code">data-bindingname="optIntoSegments" data-strict-type="int"</span>.</p>`);
			}

			// additionally we are going to require a success message element exist in the page so that the brands can control that
			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);
			if (successContainer === undefined || successContainer == null) {
				errors.push(`Missing Success Message container.
					<p class="instruction">Please ensure that you have a hidden element (div, span, p, etc) in the page with a success message.</p>
					<p class="instruction">It has two requirements : <span class="code">data-bindingname="successContainer"</span> and <span class="code">style="display:none;"</span></p>`);
			}

			errors.forEach(function(err) {
				console.log(err);
			});

			// inject a div into the form as the last element if it doesn't exist and push the messaging into that
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "validation-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .validation-container`);
			}

			if (errors.length == 0) {

				// 2024-09-20 gene asked that the structural success message not show for tsm+
				// 2024-10-24 getting close to full deployment. brands need to see this in TSM
				//if (!(env.startsWith('t') || env.startsWith('p'))) {
				if (env !== "prd") {
					let payload = std.createPayloadFormatted(frm);
					payload = courseCorrectOptChecks(payload);

					std.addClass(responseContainer, "structural-validation-success");
					responseContainer.innerHTML = `<h3>This form passes all structural checks for <em>required</em> fields!</h3>
					<p>
						It is important to note that any fields which do not align with the field naming in
						<a href="https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint" target="_blank">The Wiki</a> will be put into the
						unstructured <span class="code">additionalData</span> field.
					</p>
					<p>Please add <span class="code">data-bindingname="fieldNameHere"</span> for any fields that you wish to collect in a structured manner. For example : add <span class="code">data-bindingname="stateCode"</span> to decorate a State select.</p>
					<p>An example payload from this form\'s elements: <div class="code json">${JSON.stringify(payload, null, 4)}</div></p>`;
				}

				// re-enable the submit button
				let submits = document.querySelectorAll(`#${formElement.id} input[type=submit], #${formElement.id} button[type=submit], #${formElement.id} button:not([type])`);

				if (submits) {
					submits.forEach(function(el) {
						console.log("submit : ");
						console.log(el);
						el.removeAttribute("disabled");
					});
				}

				return true;
			}

			std.addClass(responseContainer, "structural-validation-error");
			responseContainer.innerHTML = `<h3>Errors found with this form : </h3><p><ul>${(errors.map(function(el) { return `<li>${el}</li>` }).join(''))}</ul></p>`;
			return false;
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "response-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .response-container`);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			let frm = Common.formObj.load(formElement.parentNode, true);

			frm = std.createPayloadFormatted(frm);
			frm = courseCorrectOptChecks(frm);

			console.log(frm);

			if (window["formInjectionSubmitWait"] && typeof(window["formInjectionSubmitWait"]) === "function") {
				window.formInjectionSubmitWait(translations.submitting);
			} else {
				responseContainer.innerHTML = `${translations.submitting}...`;
			}

			let response = await fetch ("{{rooturl}}/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {

				// the errors collection comes from fluent. if it's empty, take the current message and display that
				if (response.errors.length == 0) {
					responseContainer.innerHTML = `<div class="error"><ul><li>${response.message}</li></ul></div>`;
					return;
				}

				if (window["formInjectionSubmitResponseError"] && typeof(window["formInjectionSubmitResponseError"]) === "function") {
					window.formInjectionSubmitResponseError(response.errors);
					return;
				}

				// for all errors, look up tokens which match fields.
				// when found, replace with the placeholder text of the input
				response.errors.forEach (function (el) {

					const regex = /\{\{(?<prop>[a-zA-Z]+)\}\}/;

					let propNameMatches = regex.exec(el.errorMessage);

					if (propNameMatches === null || propNameMatches.length === 0) {
						return;
					}

					if (propNameMatches.groups && propNameMatches.groups.prop) {
						// find the element with this data binding name and get the placeholder or label. placeholder first
						let inputElement = formElement.querySelector(`[data-bindingname=${propNameMatches.groups.prop}]`);

						if (inputElement) {
							let replacementValue = null;

							if (inputElement.hasAttribute("placeholder")) {
								replacementValue = inputElement.getAttribute("placeholder");
							}

							if (replacementValue === null) {
								// look for a label. it should have for="id-of-input"
								let label = formElement.querySelector(`label[for=${inputElement.id}]`);
								if (label) {
									replacementValue = label.innerText;
								}
							}

							el.errorMessage = el.errorMessage.replace(propNameMatches[0], replacementValue);
						}
					}
				});

				// was showing the preceeding message, but it's not localized yet. <p>${response.message}</p>
				responseContainer.innerHTML = `<div class="error"><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			if (window["formInjectionSubmitResponseSuccess"] && typeof(window["formInjectionSubmitResponseSuccess"]) === "function") {
				window.formInjectionSubmitResponseSuccess(response, config);
				return;
			}

			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);

			if (successContainer && successContainer.style) {
				// just remove the "display:none;" from the style
				responseContainer.innerHTML = '';
				successContainer.style.removeProperty("display");
			} else {
				responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			}

			formElement.reset();
			// 2024-10-04 it was decided to also hide the form on success and just display the success
			formElement.style.setProperty("display", "none", "important");

			// if the config has a redirectUrl property, redirect to that url on success
			if (config.redirectUrl !== undefined) {
				location.href = config.redirectUrl;
			}
		}
	}
}("{{environment}}", '{{locale}}', '{{config}}');

window.addEventListener('DOMContentLoaded', () => {
	standardLeadForm.init('{{injectionPoint}}');
});

// wait until everything is loaded before stripping events and adding new events
// window.document.onreadystatechange = function () {
// 	if (document.readyState == "complete") {
// 		standardLeadForm.resetEvents();
// 	}
// }