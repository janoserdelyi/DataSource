import "{{rooturl}}/api/v1/js/eventlisteners";
import * as Common from "{{rooturl}}/api/v1/js/common";
import { standardFormUtils as std } from "{{rooturl}}/api/v1/js/standard-form-functions";

let standardInjection = function (
	env,
	locale,
	config
) {
	// it's coming in as a string
	if (config) {
		config = JSON.parse(config);
	}

	let ip = null;
	let formElement = null;
	let responseContainer = null;
	let translations = null;
	let formConfig = null; // this is configuration that the page owner can directly provide via window.formconfig. it allows overriding base values

	let fields = {};
	fields["firstName"] = {
		type: "text",
		name: "FirstName",
		required: "required",
		minlength: 2,
		maxlength: 20,
		pattern: "[a-zA-Z\s]{2,20}",
		autocorrect: false,
		autocapitalize: false,
		autocomplete: "given-name",
		placeholder: "{{label.FirstName}}",
		bindingname: "firstName"
	};

	function renderField (fieldObj) {

	}

	function isObject (item) {
		return (item && typeof item === 'object' && !Array.isArray(item));
	}

	function deepMerge (target, ...sources) {
		if (!sources.length) {
			return target;
		}
		const source = sources.shift();

		if (isObject(target) && isObject(source)) {
			for (const key in source) {
				if (isObject(source[key])) {
					if (!target[key]) {
						Object.assign(target, { [key]: {} });
					}
					deepMerge(target[key], source[key]);
				} else {
					Object.assign(target, { [key]: source[key] });
				}
			}
		}
		return deepMerge(target, ...sources);
	}

	function getFieldValue (
		fieldName,
		fieldPropertyName
	) {
		if (fields[fieldName] === undefined || fields[fieldName][fieldPropertyName] === undefined) {
			return null;
		}
		return fields[fieldName][fieldPropertyName];
	}

	function clearMessages () {
		if (responseContainer) {
			responseContainer.innerHTML = "";
		}
	}

	function loadUtms () {
		let utms = std.getUtms();
		let campaignField = document.querySelector("[data-bindingname=campaignId]");

		if (campaignField) {
			if (utms.campaignId) {
				campaignField.value = utms.campaignId;
				window.sessionStorage.setItem("campaignId", utms.campaignId);
				//console.log(`campaign id value '${utms.campaignId}' found in the querystring. setting input value and sessionStorage`);
				return;
			}

			let sessionCampaignId = window.sessionStorage.getItem("campaignId");

			if (sessionCampaignId) {
				//console.log(`campaign id value '${sessionCampaignId}' found in sessionStorage. setting input value`);
				campaignField.value = sessionCampaignId;
			}
		}
	}

	return {
		init: function (injectionPoint) {
			console.log("formscript initialized");

			translations = "{{translations}}";

			ip = document.querySelector(injectionPoint);

			if (ip === undefined || ip === null) {
				console.log("no injection point found");
				return;
			}

			// ensure there is a success container

			loadUtms();

			if (window.formconfig !== undefined) {
				formConfig = window.formconfig;
				// merge this config over top the base
				fields = deepMerge (fields, formConfig.fields);
			}

			ip.innerHTML = `
<form 
	id="Form-{{scriptcd}}" 
	data-bindingname="form"
>
	<div class="standard-element-container firstname-container">
		<label for="FirstName-{{scriptcd}}">{{label.FirstName}}</label>
		<input 
			type="text" 
			id="FirstName-{{scriptcd}}" 
			name="FirstName" 
			required="required" 
			minlength="2" 
			maxlength="20" 
			pattern="[a-zA-Z\s]{2,20}" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="given-name" 
			placeholder="{{label.FirstName}}" 
			data-bindingname="firstName" 
			${(getFieldValue("firstName", "defaultValue") == null ? "" : `value="${getFieldValue("firstName", "defaultValue")}"`)}
		/>
	</div>
	<div class="standard-element-container lastname-container">
		<label for="LastName-{{scriptcd}}">{{label.LastName}}</label>
		<input 
			type="text" 
			id="LastName-{{scriptcd}}" 
			name="LastName" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="family-name" 
			placeholder="{{label.LastName}}" 
			data-bindingname="lastName" 
			${(getFieldValue("lastName", "defaultValue") == null ? "" : `value="${getFieldValue("lastName", "defaultValue")}"`)}
		/>
	</div>
	<div class="standard-element-container email-container">
		<label for="EmailAddress-{{scriptcd}}">{{label.EmailAddress}}</label>
		<input 
			type="email" 
			id="EmailAddress-{{scriptcd}}" 
			name="EmailAddress" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="email" 
			placeholder="{{label.EmailAddress}}" 
			data-bindingname="emailAddress" 
			${(getFieldValue("emailAddress", "defaultValue") == null ? "" : `value="${getFieldValue("emailAddress", "defaultValue")}"`)}
		/>
	</div>
	<div class="standard-element-container country-container">
		<label for="CountryCode-{{scriptcd}}">{{label.CountryCode}}</label>
		<select 
			id="CountryCode-{{scriptcd}}" 
			name="CountryCode" 
			required="required" 
			autocomplete="country" 
			data-bindingname="countryCode"
		>
			<option value="">{{label.SelectOne}}</option>
			<option value="USA">United States</option>
			<option value="CAN">Canada</option>
			<option value="GBR">Great Britain</option>
			<option value="AUT">Austria</option>
			<option value="BEL">Belgium</option>
			<option value="BGR">Bulgaria</option>
			<option value="HRV">Croatia</option>
			<option value="CYP">Cyprus</option>
			<option value="CZE">Czech Republic</option>
			<option value="DNK">Denmark</option>
			<option value="EST">Estonia</option>
			<option value="FIN">Finland</option>
			<option value="FRA">France</option>
			<option value="DEU">Germany</option>
			<option value="GRC">Greece</option>
			<option value="HUN">Hungary</option>
			<option value="IRL">Ireland</option>
			<option value="ITA">Italy</option>
			<option value="LVA">Latvia</option>
			<option value="LTU">Lithuania</option>
			<option value="LUX">Luxembourg</option>
			<option value="MLT">Malta</option>
			<option value="NLD">Netherlands</option>
			<option value="POL">Poland</option>
			<option value="PRT">Portugal</option>
			<option value="ROU">Romania</option>
			<option value="SVK">Slovakia</option>
			<option value="SVN">Slovenia</option>
			<option value="ESP">Spain</option>
			<option value="SWE">Sweden</option>
			<option value="CHE">Switzerland</option>
		</select>
	</div>
	<div class="standard-element-container phone-container">
		<label for="PhoneNumber-{{scriptcd}}">{{label.PhoneNumber}}</label>
		<input 
			type="tel" 
			id="PhoneNumber-{{scriptcd}}" 
			name="PhoneNumber" 
			required="required" 
			pattern="[\d+\-\(\)\s]{4,20}" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="tel" 
			placeholder="{{label.PhoneNumber}}" 
			data-bindingname="phone"
		/>
	</div>
	<div class="standard-element-container postal-container">
		<label for="PostalCode-{{scriptcd}}">{{label.PostalCode}}</label>
		<input 
			type="text" 
			id="PostalCode-{{scriptcd}}" 
			name="PostalCode" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="postal-code" 
			placeholder="{{label.PostalCode}}" 
			data-bindingname="zipCode"
		/>
	</div>
	<div class="standard-element-container company-container">
		<label for="CompanyName-{{scriptcd}}">{{label.CompanyName}}</label>
		<input 
			type="text" 
			id="CompanyName-{{scriptcd}}" 
			name="CompanyName" 
			required="required" 
			autocorrect="false" 
			autocapitalize="false" 
			autocomplete="organization" 
			placeholder="{{label.CompanyName}}" 
			data-bindingname="company"
		/>
	</div>

	<div class="standard-element-container brand-container">
		<label for="Brand-{{scriptcd}}">{{label.Brand}}</label>
		<select 
			id="Brand-{{scriptcd}}" 
			name="Brand" 
			required="required" 
			autocomplete="none" 
			data-bindingname="brand" 
		>
			<option value="">{{label.SelectOne}}</option>
			<option value="CoStar">CoStar</option>
			<option value="LoopNet">LoopNet</option>
			<option value="Apartments">Apartments</option>
			<option value="Ten-X">Ten-X</option>
			<option value="STR">STR</option>
			<option value="Homes">Homes</option>
			<option value="BusinessImmo">Business Immo</option>
			<option value="REM">Real Estate Manager</option>

		</select>
	</div>

	<input type="hidden" data-bindingname="marketingOptIn" data-strict-type="boolean" value="1"/>
	<input type="hidden" data-bindingname="formType" value="Sales"/>
	<input type="hidden" data-bindingname="leadSource" value="${(getFieldValue("leadSource", "defaultValue") == null ? "" : getFieldValue("leadSource", "defaultValue"))}"/>
	<input type="hidden" data-bindingname="campaignId" value=""/>

	<div class="submit-container">
		<button type="submit">Submit</button>
	</div>

	<p class="fineprint note-container">* {{label.Required}}</p>
</form>`;

			formElement = document.getElementById("Form-{{scriptcd}}");

			formElement.addEventListener("submit", standardInjection.formSubmit);
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "response-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .response-container`);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			let frm = Common.formObj.load(formElement.parentNode);

			frm = std.createPayloadFormatted(frm);

			console.log(frm);

			responseContainer.innerHTML = `${translations.submitting}...`;

			let response = await fetch ("{{rooturl}}/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {

				// the errors collection comes from fluent. if it's empty, take the current message and display that
				if (response.errors.length == 0) {
					responseContainer.innerHTML = `<div class="error"><ul><li>${response.message}</li></ul></div>`;
					return;
				}

				// for all errors, look up tokens which match fields.
				// when found, replace with the placeholder text of the input
				response.errors.forEach (function (el) {

					const regex = /\{\{(?<prop>[a-zA-Z]+)\}\}/;

					let propNameMatches = regex.exec(el.errorMessage);

					if (propNameMatches === null || propNameMatches.length === 0) {
						return;
					}

					if (propNameMatches.groups && propNameMatches.groups.prop) {
						// find the element with this data binding name and get the placeholder or label. placeholder first
						let inputElement = formElement.querySelector(`[data-bindingname=${propNameMatches.groups.prop}]`);

						if (inputElement) {
							let replacementValue = null;

							if (inputElement.hasAttribute("placeholder")) {
								replacementValue = inputElement.getAttribute("placeholder");
							}

							if (replacementValue === null) {
								// look for a label. it should have for="id-of-input"
								let label = formElement.querySelector(`label[for=${inputElement.id}]`);
								if (label) {
									replacementValue = label.innerText;
								}
							}

							el.errorMessage = el.errorMessage.replace(propNameMatches[0], replacementValue);
						}
					}
				});

				// was showing the preceeding message, but it's not localized yet. <p>${response.message}</p>
				responseContainer.innerHTML = `<div class="error"><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);

			if (successContainer && successContainer.style) {
				// just remove the "display:none;" from the style
				responseContainer.innerHTML = '';
				successContainer.style.removeProperty("display");
			} else {
				responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			}

			formElement.reset();
			// 2024-10-04 it was decided to also hide the form on success and just display the success
			formElement.style.setProperty("display", "none", "important");

			// if the config has a redirectUrl property, redirect to that url on success
			if (config.redirectUrl !== undefined) {
				location.href = config.redirectUrl;
			}
		}
	}

}("{{environment}}", '{{locale}}', '{{config}}');

window.addEventListener('DOMContentLoaded', () => {
	standardInjection.init('{{injectionPoint}}');
});