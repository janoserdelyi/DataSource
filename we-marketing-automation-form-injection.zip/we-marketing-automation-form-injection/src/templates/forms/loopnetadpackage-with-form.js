import "/static/js/eventlisteners.js";
import * as Common from "/static/js/common.js";

// window.addEventListener("eventAdded", function (e) {
// 	let el = e.detail.element;
// 	console.log(`event type '${e.detail.eventType}' added to element ${el.nodeName}`);
// });

let formloopnetadpackageformonly = function() {

	let formElement = null;

	function getUtms () {
		let url = new URL(window.location.href);
		let params = url.searchParams;

		return {
			campaignId : params.get("utm_campaign_id"),
			campaign : params.get("utm_campaign"),
			medium : params.get("utm_medium"),
			source : params.get("utm_source"),
			content : params.get("utm_content")
		};
	}

	function unEventChildrenRecurse (node) {
		let children = node.childNodes;

		if (!children || children.length == 0) {
			return;
		}

		children.forEach(function (child) {
			if (child.nodeType != 1) {
				return;
			}
			child.removeEventListenersByType("submit");
			child.removeEventListenersByType("click");
			child.removeEventListenersByType("keypress");
			child.removeEventListenersByType("mousedown");
			unEventChildrenRecurse (child);
		});
	}

	function addClass (el, className) {
		if (!el.classList.contains(className)) {
			el.classList.add(className);
		}
	}

	return {
		init: function (ip) {
			console.log("formscript initialized");

			formElement = document.querySelector(ip);

			if (formElement === undefined || formElement === null) {
				return;
			}

			// this should be dynamically injected depending on the environment
			let inspection = formloopnetadpackageformonly.formInspect();

			if (inspection == false) {
				// there's no point in wiring up submission if this fails
				//return;
			}

			// roll through the form and strip it of events
			// for now just looking at the <form> element itself and the submit button
			// the submit button could be <submit/> or <input type="submit"/>

			// since this is just about taking control over the form submission, the injectionpoint is really just identifying the form
			formElement.removeEventListenersByType("input");
			formElement.removeEventListenersByType("change");
			formElement.removeEventListenersByType("submit");

			// roll through all child elements and remove submit events
			unEventChildrenRecurse(formElement);

			formElement.addEventListener("submit", formloopnetadpackageformonly.formSubmit);

			// find submits
			let submits = document.querySelectorAll(`#${formElement.id} input[type=submit]`);

			if (submits) {
				submits.forEach(function(el) {
					el.removeEventListenersByType("click");
					el.removeEventListenersByType("keypress");
					el.removeEventListenersByType("mousedown");
				});
			}

			console.log(submits);
		},
		formInspect: function () {
			document.head.insertAdjacentHTML('afterbegin', `<link type="text/css" rel="stylesheet" href="/static/css/structural-validation.css"/>`)

			// testing out structural elements. so let's load the form
			let frm = Common.formObj.load(formElement.parentNode, true); // "true" will get values for checkboxes which are not checked. we just want all the elements. ignore the values

			console.log(frm);

			// just going to go quick and dirty on this here
			// we're looking for some specific properties to exist on the frm object. if they are undefined, the form does not have what it needs
			let requiredFields = new Array (
				{prop : "firstName", display : "First Name"},
				{prop : "lastName", display : "Last Name"},
				//"brand",
				{prop : "company", display : "Company Name"},
				{prop : "emailAddress", display : "Email Address"},
				{prop : "countryCode", display : "Country Code"},
				{prop : "formType", display : "Form Type"}, // Marketing | Sales
				{prop : "leadSource", display : "Lead Source (MarketingCenter, LinkedIn, Google, etc)"},
				//"sourceType", "Web (1)"
				{prop : "campaignId", display : "Campaign Id"},
				{prop : "phone", display : "Phone Number"}
			);

			let errors = [];

			requiredFields.forEach(function (p) {
				if (frm[p.prop] === undefined) {
					let msg = `Missing ${p.display} field. <p class="instruction">Please be sure there is a field with the <span class="code">data-bindingname="${p.prop}"</span> attribute and value.</p>`;
					errors.push(msg);
				}
			});

			// also must have either marketingOptIn or optIntoSegments[{segmentid, boolean}, {segmentid, boolean}, ...]
			if (frm["marketingOptIn"] === undefined && frm["optIntoSegments"] === undefined) {
				errors.push(`An Opt-in/out field must be provided.
					<p class="instruction">Use <span class="code">marketingOptIn</span> with a boolean value for brand-level opt, or use <span class="code">optIntoSegments</span> passing in a value of SegmentId for each checkbox.</p>
					<p class="instruction">Add <span class="code">data-strict-type="boolean"</span> to coerce the value into an actual boolean value. (Turns "1" into <span class="code">true</span>)</p>`);
			}

			// i think for some fields it's not enough to check that it exists. they should have values *if* they are hidden fields
			// an example would be CountryCode - if it's a select, it will start empty potentially. but if it's a hidden field, it needs to have a value
			if (frm.countryCode !== undefined) {
				let el = formElement.querySelector("input[type=hidden][data-bindingname=countryCode]");
				if (el && el.value == "") {
					errors.push(`Country Code must have a value. <p class="instruction">Because this is a hidden field, it is expected to have a value provided to it (hardcoded).</p><p class="instruction">This field should only use 3-letter ISO country code values.</p>`);
				}
			}

			if (frm.optIntoSegments !== undefined && Array.isArray(frm.optIntoSegments) == false) {
				errors.push(`Opt-In Segments is malformed.
					<p class="instruction">Be sure that all segment checkboxes have the same <span class="code">name</span> attribute.</p>
					<p class="instruction">Additionally, ensure each checkbox has the following attributes : <span class="code">data-bindingname="optIntoSegments" data-strict-type="int"</p>.</p>`);
			}

			errors.forEach(function(err) {
				console.log(err);
			});

			// inject a div into the form as the last element if it doesn't exist and push the messaging into that
			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				addClass(d, "validation-container");
				responseContainer = formElement.appendChild(d);
			}

			if (errors.length == 0) {
				addClass(responseContainer, "structural-validation-success");
				responseContainer.innerHTML = `<p>This form passes all structural checks for <em>required</em> fields!</p>
				<p>
					It is important to note that any fields which do not align with the field naming in
					<a href="https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint" target="_blank">The Wiki</a> will be put into the
					unstructured <span class="code">additionalData</span>.
				</p>
				<p>Please add <span class="code">data-bindingname="fieldNameHere"</span> for any fields that you wish to collect in a structured manner. For example : add <span class="code">data-bindingname="stateCode"</span> to decorate a State select.</p>`;
				return true;
			}

			addClass(responseContainer, "structural-validation-error");
			responseContainer.innerHTML = `<p>Errors found with this form : <ul>${(errors.map(function(el) { return `<li>${el}</li>` }).join(''))}</ul></p>`;
			return false;
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				responseContainer = formElement.appendChild(d);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			let frm = Common.formObj.load(formElement.parentNode);

			console.log(frm);

			// need to enumerate all the possible legit fields
			// the rest get pushed into "addtionalData"
			let realFields = new Array (
				"firstName",
				"lastName",
				"company",
				"zipCode",
				"phone",
				"emailAddress",
				"countryCode",
				"formType",
				"leadSource",
				"sourceType",
				"contactId",
				"brand",
				"city",
				"stateCode",
				"notes",
				"productLineCode",
				"productName",
				"campaignId",
				"language",
				"sourceUrl",
				"businessType",
				"businessSubType",
				"sfLeadOrContactId",
				"sfOutBoundCampaignId",
				"marketingOptIn",
				"optIntoSegments"
			);

			let frmProps = Object.getOwnPropertyNames(frm);

			// add the additionalData property to the frm
			if (frm.additionalData === undefined) {
				frm.additionalData = {};
			}

			frmProps.forEach(function (prop) {
				if (realFields.includes(prop) == false) {
					frm.additionalData[prop] = frm[prop];
					delete frm[prop];
				}
			});

			// optIntoSegments needs a little extra massaging. it should come in as an array of numbers. if a value is there, it means it's true
			if (frm.optIntoSegments !== undefined) {
				// if it's not an array, something is wrong. shove it into additionalData to prevent errors, but to keep the data
				if (Array.isArray(frm.optIntoSegments) == false) {
					frm.additionalData["optIntoSegments"] = frm.optIntoSegments;
					delete frm.optIntoSegments;
				} else {
					frm.optIntoSegments = frm.optIntoSegments.map(function(el) {
						return {
							Segment: el,
							optInPref: true
						};
					});
				}
			}

			console.log(frm);

			/*
			responseContainer.innerHTML = "Submitting...";

			let response = await fetch ("/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {
				responseContainer.innerHTML = `<div class="error"><p>${response.message}</p><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			document.getElementById("Form-{{scriptcd}}").reset();
			*/
		}
	}
}();

window.addEventListener('DOMContentLoaded', () => {
	formloopnetadpackageformonly.init('{{injectionPoint}}');
});
