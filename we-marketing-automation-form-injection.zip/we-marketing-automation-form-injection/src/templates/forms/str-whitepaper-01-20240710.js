let formdef456 = function() {

	function getAttribution () {
		let url = new URL(window.location.href);
		let params = url.searchParams;
		//let attribution = params.get('utm_campaign_id'); // just for testing. my firefox instance cleans utm_* garbage from querystrings
		let attribution = params.get('campaignid');

		return attribution;
	}

	return {
		init: function (ip) {
			let injectionPoint = document.querySelector(ip);

			if (injectionPoint === undefined || injectionPoint === null) {
				return;
			}

			injectionPoint.innerHTML = `
<h2>Get your whitepaper!</h2>
<p>Trust me, it's <em>that</em> good</p>

<form id="Form-{{scriptcd}}">
	<div id="Form-FirstName-{{scriptcd}}" class="standard-element-container">
		<label for="FirstName-{{scriptcd}}">First Name</label>
		<input type="text" id="FirstName-{{scriptcd}}" name="FirstName" required="required" autocorrect="false" autocapitalize="false" placeholder="First Name*"/>
	</div>
	<div id="Form-LastName-{{scriptcd}}" class="standard-element-container">
		<label for="LastName-{{scriptcd}}">Last Name</label>
		<input type="text" id="LastName-{{scriptcd}}" name="LastName" required="required" autocorrect="false" autocapitalize="false" placeholder="Last Name*"/>
	</div>
	<div id="Form-EmailAddress-{{scriptcd}}" class="standard-element-container">
		<label for="EmailAddress-{{scriptcd}}">Email Address</label>
		<input type="email" id="EmailAddress-{{scriptcd}}" name="EmailAddress" required="required" autocorrect="false" autocapitalize="false" placeholder="Email Address*"/>
	</div>
	<div id="Form-PhoneNumber-{{scriptcd}}" class="standard-element-container">
		<label for="PhoneNumber-{{scriptcd}}">Phone Number</label>
		<input type="tel" id="PhoneNumber-{{scriptcd}}" name="PhoneNumber" required="required" autocorrect="false" autocapitalize="false" placeholder="Phone Numbers*"/>
	</div>
	<div id="Form-PostalCode-{{scriptcd}}" class="standard-element-container">
		<label for="PostalCode-{{scriptcd}}">Postal Code</label>
		<input type="text" id="PostalCode-{{scriptcd}}" name="PostalCode" required="required" autocorrect="false" autocapitalize="false" placeholder="Postal Code*"/>
	</div>
	<div id="Form-PropertyManagementCompanyName-{{scriptcd}}" class="standard-element-container">
		<label for="PropertyManagementCompanyName-{{scriptcd}}">Property Management Company Name</label>
		<input type="text" id="PropertyManagementCompanyName-{{scriptcd}}" name="PropertyManagementCompanyName" required="required" autocorrect="false" autocapitalize="false" placeholder="Property Management Company Name*"/>
	</div>

	<div id="Form-Submit-{{scriptcd}}">
		<button type="submit">Submit</button>
	</div>

	<p id="Fineprint-{{scriptcd}}" class="fineprint">* all fields required</p>

	<div id="OptIn-{{scriptcd}}">

	</div>
</form>
<div id="Response-{{scriptcd}}"></div>
`;
			document.getElementById("Form-{{scriptcd}}").addEventListener("submit", formdef456.formSubmit);
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			responseContainer.innerHTML = "";

			let formIsValid = document.getElementById("Form-{{scriptcd}}").reportValidity();

			if (!formIsValid) {
				return;
			}

			responseContainer.innerHTML = "Submitting...";

			let response = await fetch ("/api/v1/whitepaper/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify({
					firstName: document.getElementById("FirstName-{{scriptcd}}").value,
					lastName: document.getElementById("LastName-{{scriptcd}}").value,
					emailAddress: document.getElementById("EmailAddress-{{scriptcd}}").value,
					phone: document.getElementById("PhoneNumber-{{scriptcd}}").value,
					zipCode: document.getElementById("PostalCode-{{scriptcd}}").value,
					company: document.getElementById("PropertyManagementCompanyName-{{scriptcd}}").value,
					countryCode : "USA",
					campaignAttribution: getAttribution()
				})
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {
				responseContainer.innerHTML = `<div class="error"><p>${response.message}</p><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			responseContainer.innerHTML = `<div class="success">${response.message}</div>`;

			if (response.downloadUrl !== undefined) {
				//location.href = response.downloadUrl;
				window.open (
					response.downloadUrl,
					'_blank'
				);
			}
		}
	}
}();

window.addEventListener('DOMContentLoaded', () => {
	formdef456.init('{{injectionPoint}}');
});