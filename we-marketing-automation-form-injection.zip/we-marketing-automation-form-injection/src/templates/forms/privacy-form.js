import "{{rooturl}}/api/v1/js/eventlisteners";
import * as Common from "{{rooturl}}/api/v1/js/common";
import { standardFormUtils as std } from "{{rooturl}}/api/v1/js/standard-form-functions";

let privacyForm = function (
	env,
	locale,
	config
) {
	// it's coming in as a string
	if (config) {
		config = JSON.parse(config);
	}

	let formElement = null;
	let responseContainer = null;
	let translations = null;

	function clearMessages () {
		if (responseContainer) {
			responseContainer.innerHTML = "";
		}
	}

	function loadUtms () {
		let utms = std.getUtms();
		let campaignField = document.querySelector("[data-bindingname=campaignId]");

		if (campaignField) {
			if (utms.campaignId) {
				campaignField.value = utms.campaignId;
				window.sessionStorage.setItem("campaignId", utms.campaignId);
				//console.log(`campaign id value '${utms.campaignId}' found in the querystring. setting input value and sessionStorage`);
				return;
			}

			let sessionCampaignId = window.sessionStorage.getItem("campaignId");

			if (sessionCampaignId) {
				//console.log(`campaign id value '${sessionCampaignId}' found in sessionStorage. setting input value`);
				campaignField.value = sessionCampaignId;
			}
		}
	}

	return {
		init: function (injectionPoint) {
			console.log("formscript initialized");

			translations = "{{translations}}";

			formElement = document.querySelector(injectionPoint);

			if (formElement === undefined || formElement === null) {
				// if not found, look for any forms decorated with data-bindingname="form"
				formElement = document.querySelector('form[data-bindingname="form"]');
			}

			// still missing? show a banner
			if (formElement === undefined || formElement === null) {
				// todo: cover the page with a div and a message about what's missing?
				// for now in lower envs put a banner at the top of the page
				// but not in production
				if (env === "prd") {
					return;
				}
				std.showMissingFormBanner('{{rooturl}}');
				return;
			}

			loadUtms();

			// this will pass in prd as it's expected to have been evaluated in lower environments
			let inspection = (env === "prd") || privacyForm.formInspect();

			// pardot forms have script elements *within* the form element. wth! get rid of them
			formElement.querySelectorAll("script").forEach(e => e.remove());

			// add a locale field if it doesn't exist
			std.addLocaleField(formElement, locale);
			// and a honeypot field
			std.addAdditionalValuesField(formElement);

			// some forms have overly restrictive input patterns (or just wrong). touch them up
			std.realignFieldConstraints(formElement);

			// remove any `form-injection-noscript-banner` banners
			document.querySelectorAll(".form-injection-noscript-banner").forEach(e => e.remove());

			privacyForm.resetEvents(inspection);

			// loadUtms();
		},
		resetEvents: function (inspection) {

			// this is just about taking control over the form submission
			formElement.removeEventListenersByType("input");
			formElement.removeEventListenersByType("change");
			formElement.removeEventListenersByType("submit");

			// roll through all child elements and remove some events
			std.unEventChildrenRecurse(formElement);

			// remove events and optionally disable the button(s)
			std.santizeSubmitButtons(formElement, inspection);

			formElement.addEventListener("submit", privacyForm.formSubmit);
			formElement.addEventListener("click", clearMessages);
		},
		formInspect: function () {
			std.addStylesheet('{{rooturl}}');

			// testing out structural elements. so let's load the form
			let frm = Common.formObj.load(formElement.parentNode, true); // "true" will get values for checkboxes which are not checked. we just want all the elements. ignore the values

			//console.log(frm);

			// just going to go quick and dirty on this here
			// we're looking for some specific properties to exist on the frm object. if they are undefined, the form does not have what it needs
			let requiredFields = new Array (
				{prop : "firstName", display : "First Name"},
				{prop : "lastName", display : "Last Name"},
				{prop : "company", display : "Company Name"},
				{prop : "emailAddress", display : "Email Address"},
				{prop : "countryCode", display : "Country Code"},
				{prop : "formType", display : "Form Type"}, // Marketing | Sales
				{prop : "leadSource", display : "Lead Source (MarketingCenter, LinkedIn, Google, etc)"},
				{prop : "campaignId", display : "Campaign Id"},
				{prop : "phone", display : "Phone Number"},
				{prop : "zipCode", display : "Zip/Postal code"},
				{prop : "address", display : "Address"},
				{prop : "relationship", display : "Relationship/Making request as"}
			);

			let errors = [];

			requiredFields.forEach(function (p) {
				if (frm[p.prop] === undefined) {
					let msg = `Missing ${p.display} field. <p class="instruction">Please be sure there is a field with the <span class="code">data-bindingname="${p.prop}"</span> attribute and value.</p>`;
					errors.push(msg);
				}
			});

			// i think for some fields it's not enough to check that it exists. they should have values *if* they are hidden fields
			// an example would be CountryCode - if it's a select, it will start empty potentially. but if it's a hidden field, it needs to have a value
			if (frm.countryCode !== undefined) {
				let el = formElement.querySelector("input[type=hidden][data-bindingname=countryCode]");
				if (el && el.value == "") {
					errors.push(`Country Code must have a value. <p class="instruction">Because this is a hidden field, it is expected to have a value provided to it (hardcoded).</p><p class="instruction">This field should only use 3-letter ISO country code values.</p>`);
				}
			}

			// additionally we are going to require a success message element exist in the page so that the brands can control that
			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);
			if (successContainer === undefined || successContainer == null) {
				errors.push(`Missing Success Message container.
					<p class="instruction">Please ensure that you have a hidden element (div, span, p, etc) in the page with a success message.</p>
					<p class="instruction">It has two requirements : <span class="code">data-bindingname="successContainer"</span> and <span class="code">style="display:none;"</span></p>`);
			}

			errors.forEach(function(err) {
				console.log(err);
			});

			// inject a div into the form as the last element if it doesn't exist and push the messaging into that
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "validation-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .validation-container`);
			}

			if (errors.length == 0) {

				// 2024-09-20 gene asked that the structural success message not show for tsm+
				// 2024-10-24 getting close to full deployment. brands need to see this in TSM
				//if (!(env.startsWith('t') || env.startsWith('p'))) {
				if (env !== "prd") {
					let payload = std.createPayloadFormatted(frm);

					std.addClass(responseContainer, "structural-validation-success");
					responseContainer.innerHTML = `<h3>This form passes all structural checks for <em>required</em> fields!</h3>
					<p>
						It is important to note that any fields which do not align with the field naming in
						<a href="https://costar-group-prod-dev.atlassian.net/wiki/spaces/CRM/pages/209028498/Marketing+Sales+Endpoint" target="_blank">The Wiki</a> will be put into the
						unstructured <span class="code">additionalData</span> field.
					</p>
					<p>Please add <span class="code">data-bindingname="fieldNameHere"</span> for any fields that you wish to collect in a structured manner. For example : add <span class="code">data-bindingname="stateCode"</span> to decorate a State select.</p>
					<p>An example payload from this form\'s elements: <div class="code json">${JSON.stringify(payload, null, 4)}</div></p>`;
				}

				// re-enable the submit button
				let submits = document.querySelectorAll(`#${formElement.id} input[type=submit], #${formElement.id} button[type=submit], #${formElement.id} button:not([type])`);

				if (submits) {
					submits.forEach(function(el) {
						console.log("submit : ");
						console.log(el);
						el.removeAttribute("disabled");
					});
				}

				return true;
			}

			std.addClass(responseContainer, "structural-validation-error");
			responseContainer.innerHTML = `<h3>Errors found with this form : </h3><p><ul>${(errors.map(function(el) { return `<li>${el}</li>` }).join(''))}</ul></p>`;
			return false;
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			// establish an element where we will push in messaging
			// we can append right after the form
			responseContainer = document.getElementById("Response-{{scriptcd}}");

			if (responseContainer == null) {
				let d = document.createElement("div");
				d.id = "Response-{{scriptcd}}";
				std.addClass(d, "response-container");
				// this was originally 'appendChild' but it can interfere with some form styled dramatically
				// responseContainer = formElement.appendChild(d);
				// unlike 'appendChild', 'after' does not return anything :/
				formElement.after(d);
				responseContainer = document.querySelector(`#${formElement.id} + .response-container`);
			}

			responseContainer.innerHTML = "";

			let formIsValid = formElement.reportValidity();

			if (!formIsValid) {
				return;
			}

			let frm = Common.formObj.load(formElement.parentNode, false);

			frm = std.createPayloadFormatted(frm);

			console.log(frm);

			if (window["formInjectionSubmitWait"] && typeof(window["formInjectionSubmitWait"]) === "function") {
				window.formInjectionSubmitWait(translations.submitting);
			} else {
				responseContainer.innerHTML = `${translations.submitting}...`;
			}

			let response = await fetch ("{{rooturl}}/api/v1/privacy/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify(frm)
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {

				// the errors collection comes from fluent. if it's empty, take the current message and display that
				if (response.errors.length == 0) {
					responseContainer.innerHTML = `<div class="error"><ul><li>${response.message}</li></ul></div>`;
					return;
				}

				if (window["formInjectionSubmitResponseError"] && typeof(window["formInjectionSubmitResponseError"]) === "function") {
					window.formInjectionSubmitResponseError(response.errors);
					return;
				}

				// for all errors, look up tokens which match fields.
				// when found, replace with the placeholder text of the input
				response.errors.forEach (function (el) {

					const regex = /\{\{(?<prop>[a-zA-Z]+)\}\}/;

					let propNameMatches = regex.exec(el.errorMessage);

					if (propNameMatches === null || propNameMatches.length === 0) {
						return;
					}

					if (propNameMatches.groups && propNameMatches.groups.prop) {
						// find the element with this data binding name and get the placeholder or label. placeholder first
						let inputElement = formElement.querySelector(`[data-bindingname=${propNameMatches.groups.prop}]`);

						if (inputElement) {
							let replacementValue = null;

							if (inputElement.hasAttribute("placeholder")) {
								replacementValue = inputElement.getAttribute("placeholder");
							}

							if (replacementValue === null) {
								// look for a label. it should have for="id-of-input"
								let label = formElement.querySelector(`label[for=${inputElement.id}]`);
								if (label) {
									replacementValue = label.innerText;
								}
							}

							el.errorMessage = el.errorMessage.replace(propNameMatches[0], replacementValue);
						}
					}
				});

				// was showing the preceeding message, but it's not localized yet. <p>${response.message}</p>
				responseContainer.innerHTML = `<div class="error"><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			if (window["formInjectionSubmitResponseSuccess"] && typeof(window["formInjectionSubmitResponseSuccess"]) === "function") {
				window.formInjectionSubmitResponseSuccess(response, config);
				return;
			}

			let successContainer = document.querySelector(`body [data-bindingname=successContainer]`);

			if (successContainer && successContainer.style) {
				// just remove the "display:none;" from the style
				responseContainer.innerHTML = '';
				successContainer.style.removeProperty("display");
			} else {
				responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			}

			formElement.reset();
			// 2024-10-04 it was decided to also hide the form on success and just display the success
			formElement.style.setProperty("display", "none", "important");

			// if the config has a redirectUrl property, redirect to that url on success
			if (config.redirectUrl !== undefined) {
				location.href = config.redirectUrl;
			}
		}
	}
}("{{environment}}", '{{locale}}', '{{config}}');

window.addEventListener('DOMContentLoaded', () => {
	privacyForm.init('{{injectionPoint}}');
});