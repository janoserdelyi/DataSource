let formloopnetadpackage = function() {

	function getAttribution () {
		let url = new URL(window.location.href);
		let params = url.searchParams;
		//let attribution = params.get('utm_campaign_id'); // just for testing. my firefox instance cleans utm_* params from querystrings
		let attribution = params.get('campaignid');

		return attribution;
	}

	return {
		init: function (ip) {
			let injectionPoint = document.querySelector(ip);

			if (injectionPoint === undefined || injectionPoint === null) {
				return;
			}

			injectionPoint.innerHTML = `
<form id="Form-{{scriptcd}}">
	<div id="Form-FirstName-{{scriptcd}}" class="standard-element-container">
		<label for="FirstName-{{scriptcd}}" class="visually-hidden">First Name</label>
		<input type="text" id="FirstName-{{scriptcd}}" name="FirstName" required="required" autocorrect="false" autocapitalize="false" placeholder="First Name" maxlength="16"/>
		<span class="field-suffix">*</span>
	</div>
	<div id="Form-LastName-{{scriptcd}}" class="standard-element-container">
		<label for="LastName-{{scriptcd}}" class="visually-hidden">Last Name</label>
		<input type="text" id="LastName-{{scriptcd}}" name="LastName" required="required" autocorrect="false" autocapitalize="false" placeholder="Last Name"/>
		<span class="field-suffix">*</span>
	</div>
	<div id="Form-EmailAddress-{{scriptcd}}" class="standard-element-container">
		<label for="EmailAddress-{{scriptcd}}" class="visually-hidden">Email Address</label>
		<input type="email" id="EmailAddress-{{scriptcd}}" name="EmailAddress" required="required" autocorrect="false" autocapitalize="false" placeholder="Email"/>
		<span class="field-suffix">*</span>
	</div>
	<div id="Form-PhoneNumber-{{scriptcd}}" class="standard-element-container">
		<label for="PhoneNumber-{{scriptcd}}" class="visually-hidden">Phone Number</label>
		<input type="tel" id="PhoneNumber-{{scriptcd}}" name="PhoneNumber" required="required" autocorrect="false" autocapitalize="false" placeholder="Phone Number"/>
		<span class="field-suffix">*</span>
	</div>
	<div id="Form-PostalCode-{{scriptcd}}" class="standard-element-container">
		<label for="PostalCode-{{scriptcd}}" class="visually-hidden">Postal Code</label>
		<input type="text" id="PostalCode-{{scriptcd}}" name="PostalCode" required="required" autocorrect="false" autocapitalize="false" placeholder="Zip Code*"/>
		<span class="field-suffix">*</span>
	</div>
	<div id="Form-PropertyManagementCompanyName-{{scriptcd}}" class="standard-element-container">
		<label for="PropertyManagementCompanyName-{{scriptcd}}" class="visually-hidden">Property Management Company Name</label>
		<input type="text" id="PropertyManagementCompanyName-{{scriptcd}}" name="PropertyManagementCompanyName" required="required" autocorrect="false" autocapitalize="false" placeholder="Company"/>
		<span class="field-suffix">*</span>
	</div>

	<div id="Form-Submit-{{scriptcd}}">
		<button type="submit">Get More Information</button>
	</div>

	<input type="hidden" id="AdditionalValues-{{scriptcd}}" name="AdditionalValues" value=""/>
</form>
<div id="Response-{{scriptcd}}"></div>
`;
			document.getElementById("Form-{{scriptcd}}").addEventListener("submit", formloopnetadpackage.formSubmit);
		},
		formSubmit: async function (e) {
			if (e) {
				e.preventDefault();
			}

			let responseContainer = document.getElementById("Response-{{scriptcd}}");

			responseContainer.innerHTML = "";

			let formIsValid = document.getElementById("Form-{{scriptcd}}").reportValidity();

			if (!formIsValid) {
				return;
			}

			responseContainer.innerHTML = "Submitting...";

			let response = await fetch ("/api/v1/script/{{scriptcd}}", {
				method: "POST",
				headers : { "Content-Type" : "application/json" },
				body: JSON.stringify({
					firstName: document.getElementById("FirstName-{{scriptcd}}").value,
					lastName: document.getElementById("LastName-{{scriptcd}}").value,
					emailAddress: document.getElementById("EmailAddress-{{scriptcd}}").value,
					phone: document.getElementById("PhoneNumber-{{scriptcd}}").value,
					zipCode: document.getElementById("PostalCode-{{scriptcd}}").value,
					company: document.getElementById("PropertyManagementCompanyName-{{scriptcd}}").value,
					countryCode : "USA",
					campaignAttribution: getAttribution(),
					additionalValues: document.getElementById("AdditionalValues-{{scriptcd}}").value
				})
			})
			.then(response => response.json());

			console.log(response);

			if (response.success == false) {
				responseContainer.innerHTML = `<div class="error"><p>${response.message}</p><ul>${response.errors.map(function(el){
					return `<li>${el.errorMessage}</li>`
				}).join('')}</ul></div>`;
				return;
			}

			responseContainer.innerHTML = `<div class="success">${response.message}</div>`;
			document.getElementById("Form-{{scriptcd}}").reset();
		}
	}
}();

window.addEventListener('DOMContentLoaded', () => {
	formloopnetadpackage.init('{{injectionPoint}}');
});