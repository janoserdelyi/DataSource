using WeMarketingAutomationFormInjection.Filters;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using WeMarketingAutomationFormInjection.Models;
using Microsoft.Extensions.Configuration;
using FluentValidation;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Localization;

namespace WeMarketingAutomationFormInjection;

public class EmailPreferenceModule : CarterModule
{

	private readonly HttpClient httpClient;
	private readonly IConfiguration config;
	private readonly IWebHostEnvironment env;
	public required string EnvironmentName;
	private readonly Microsoft.Extensions.Logging.ILogger<EmailPreferenceModule> logger;
	private readonly IOpenSearchClient openSearchClient;
	private readonly IStringLocalizer stringLocalizer;

	public EmailPreferenceModule (
		IWebHostEnvironment env,
		IConfiguration config,
		Microsoft.Extensions.Logging.ILogger<EmailPreferenceModule> logger,
		IHttpClientFactory httpClientFactory,
		IOpenSearchClient openSearchClient
	) : base () {
		this.config = config;
		this.logger = logger;
		this.httpClient = httpClientFactory.CreateClient ();
		this.env = env;
		EnvironmentName = env.SanitizedEnvironment ();
		this.openSearchClient = openSearchClient;
		this.stringLocalizer = new JsonStringLocalizer (env);
	}

	public override void AddRoutes (
		IEndpointRouteBuilder app
	) {
		app.MapPost ("/api/v{version:int}/emailpreference", submitEmailPreference).AddEndpointFilter<SourceIpAddressFilter> ().RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		app.MapGet ("/api/v{version:int}/emailpreferences/{emailaddress}", getEmailPreferencesForEmailAddress).AddEndpointFilter<SourceIpAddressFilter> ().RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		app.MapGet ("/api/v{version:int}/emailpreference/{emailaddress}/{segmentid:int}", getEmailPreferencesForEmailAddressAndSegmentId).AddEndpointFilter<SourceIpAddressFilter> ().RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		app.MapGet ("/api/v{version:int}/emailpreferences/{emailaddress}/{brandid:int}", getEmailPreferencesForEmailAddressAndBrandId).AddEndpointFilter<SourceIpAddressFilter> ().RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
	}

	private async Task submitEmailPreference (
		HttpContext ctx,
		int version,
		Models.EmailPreference emailPreference,
		IDynamoClient dynamoClient
	) {
		// currently only supporting v1
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			await ctx.Response.AsJson (new { Success = false, Message = "Invalid version" });
			return;
		}

		var resp = await submitEmailPreferenceInnards (config, emailPreference, httpClient, dynamoClient, stringLocalizer, EnvironmentName);

		await ctx.Response.AsJson (resp);

	}

	private async Task getEmailPreferencesForEmailAddress (
		HttpContext ctx,
		int version,
		string emailaddress
	) {

		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		Models.OpenSearch.EmailPreference? emailPreference = null;

		try {
			emailPreference = await openSearchClient.GetAllEmailPreferences (emailaddress);
		} catch (Exception oops) {
			await ctx.Response.WriteAsync (oops.Message);
			ctx.Response.StatusCode = 404;
			return;
		}

		if (emailPreference == null) {
			await ctx.Response.AsJson (new { Success = false, Message = "No preferences found" });
			return;
		}

		await ctx.Response.AsJson (new { Success = true, Preferences = emailPreference! });
	}

	private async Task getEmailPreferencesForEmailAddressAndSegmentId (
		HttpContext ctx,
		int version,
		string emailaddress,
		int segmentid
	) {

		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		Models.OpenSearch.EmailPreference? emailPreference = null;

		try {
			emailPreference = await openSearchClient.GetAllEmailPreferences (emailaddress);
		} catch (Exception oops) {
			await ctx.Response.WriteAsync (oops.Message);
			ctx.Response.StatusCode = 404;
			return;
		}

		if (emailPreference == null) {
			ctx.Response.StatusCode = 404;
			return;
		}

		if (emailPreference.BrandPreferences == null || emailPreference.BrandPreferences.Count == 0) {
			await ctx.Response.AsJson (new Models.OpenSearch.SegmentPreferenceResponse { Success = false, Message = "No brand-level preferences found" });
			return;
		}

		foreach (var brandPreference in emailPreference.BrandPreferences) {
			foreach (var segmentPreference in brandPreference.SegmentPreferences) {
				if (segmentPreference.Id == segmentid) {
					await ctx.Response.AsJson (new Models.OpenSearch.SegmentPreferenceResponse { Success = true, SegmentPreference = segmentPreference });
					return;
				}
			}
		}

		await ctx.Response.AsJson (new Models.OpenSearch.SegmentPreferenceResponse { Success = false, Message = "No brand segment preference found" });
	}

	private async Task getEmailPreferencesForEmailAddressAndBrandId (
		HttpContext ctx,
		int version,
		string emailaddress,
		int brandid
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		Models.OpenSearch.EmailPreference? emailPreference = null;

		try {
			emailPreference = await openSearchClient.GetAllEmailPreferences (emailaddress);
		} catch (Exception oops) {
			await ctx.Response.WriteAsync (oops.Message);
			ctx.Response.StatusCode = 404;
			return;
		}

		if (emailPreference == null) {
			ctx.Response.StatusCode = 404;
			return;
		}

		if (emailPreference.BrandPreferences == null || emailPreference.BrandPreferences.Count == 0) {
			await ctx.Response.AsJson (new Models.OpenSearch.BrandPreferenceResponse { Success = false, Message = "No brand-level preferences found" });
			return;
		}

		foreach (var brandPreference in emailPreference.BrandPreferences) {
			if (brandPreference.Id == brandid) {
				await ctx.Response.AsJson (new Models.OpenSearch.BrandPreferenceResponse { Success = true, BrandPreference = brandPreference });
				return;
			}
		}

		await ctx.Response.AsJson (new Models.OpenSearch.BrandPreferenceResponse { Success = false, Message = "No brand preference found" });
	}

	// i need a better name
	internal static async Task<SubmitEmailPreferenceResponse> submitEmailPreferenceInnards (
		IConfiguration configuration,
		Models.EmailPreference emailPreference,
		HttpClient httpClient,
		IDynamoClient dynamoClient,
		IStringLocalizer stringLocalizer,
		string environmentName
	) {

		var preferenceContext = new ValidationContext<WeMarketingAutomationFormInjection.Models.EmailPreference> (emailPreference);
		preferenceContext.RootContextData["EnvironmentName"] = environmentName;
		var preferenceValidator = new EmailPreferenceValidator (dynamoClient, stringLocalizer!, emailPreference.ValidateAddress);
		var validationResult = preferenceValidator.Validate (preferenceContext);

		if (validationResult.IsValid == false) {
			return new SubmitEmailPreferenceResponse () {
				Success = false,
				Message = "Errors have been found",
				ValidationErrors = validationResult.Errors
			};
		}

		var endpointUrl = configuration.GetSection ("EmailPreferenceEndpoint").Get<string> ()!;
		var securityKey = configuration.GetSection ("EmailPreferenceSecurityKey").Get<string> ()!;

		try {
			// just expanded here for debugging purposes
			var serializedBody = JsonConvert.SerializeObject (emailPreference, NewtonsoftCustomResponseNegotiator.Serializer);

			var requestMessage = new HttpRequestMessage {
				Method = HttpMethod.Post,
				RequestUri = new Uri (endpointUrl),
				Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
			};

			var token = Utils.CreateRsaJwt (
				securityKey,
				DateTime.UtcNow.AddMinutes (5)
			);

			requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("Bearer", token);

			var response = await httpClient.SendAsync (requestMessage);

			if (response.IsSuccessStatusCode == false) {
				return new SubmitEmailPreferenceResponse () {
					Success = false,
					Message = $"Error, {response.ReasonPhrase}",
					StatusCode = response.StatusCode
				};
			}
		} catch (Exception oops) {
			// logger.LogError (oops, $"Error submitting to email preference endpoint {oops.Message} from {Environment.MachineName}");
			return new SubmitEmailPreferenceResponse () {
				Success = false,
				Message = oops.Message,
				FullMessage = oops.ToString ()
			};
		}

		return new SubmitEmailPreferenceResponse () {
			Success = true,
			Message = "Thank you!"
		};
	}
}