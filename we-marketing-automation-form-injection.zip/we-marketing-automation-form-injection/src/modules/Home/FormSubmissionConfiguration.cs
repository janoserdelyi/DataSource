using WeMarketingAutomationFormInjection.Models;

namespace WeMarketingAutomationFormInjection;

public class FormSubmissionConfiguration
{
	public required string HomesBookADemoSecret { get; set; }
	public required CacheDurationMinutes CacheDurations { get; set; }
	public required int[] DemoKillSwitchers { get; set; }
}


