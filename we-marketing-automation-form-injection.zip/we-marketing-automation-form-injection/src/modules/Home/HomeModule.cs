﻿using WeMarketingAutomationFormInjection.Filters;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using WeMarketingAutomationFormInjection.Models;
using Microsoft.Extensions.Configuration;
using FluentValidation;
using System.Net.Http;
using System.Text;
using System.Globalization;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System.Linq;
using Microsoft.CodeAnalysis;
using System.Security.Cryptography;
using Microsoft.Extensions.Primitives;
using StackExchange.Redis;
using System.Web;

namespace WeMarketingAutomationFormInjection;

public class HomeModule : CarterModule
{
	private readonly string templateDir;
	private readonly HttpClient httpClient;
	private readonly IAmazonS3 s3client;
	private readonly IDynamoClient dynamoClient;
	private readonly IConfiguration config;
	private readonly IWebHostEnvironment env;
	public required string EnvironmentName;
	private readonly ITranslationClient translationClient;
	private readonly TranslationManager translationManager;
	private readonly IOpenSearchClient openSearchClient;
	private static IStringLocalizer? stringLocalizer;
	private readonly Microsoft.Extensions.Logging.ILogger<HomeModule> logger;
	private readonly ILeadSubmissionService leadSubmissionService;
	private FormSubmissionConfiguration bookADemoFormConfigs;
	private readonly string encryptedContactKey;

	public HomeModule (
		IWebHostEnvironment env,
		IConfiguration config,
		Microsoft.Extensions.Logging.ILogger<HomeModule> logger,
		IHttpClientFactory httpClientFactory,
		IAmazonS3 amazonS3,
		IDynamoClient dynamoClient,
		ITranslationClient translationClient,
		IOpenSearchClient openSearchClient
	) : base () {

		templateDir = Path.Combine (env.WebRootPath, "templates");
		this.config = config;
		this.logger = logger;
		this.httpClient = httpClientFactory.CreateClient ();
		this.s3client = amazonS3;
		this.dynamoClient = dynamoClient;
		this.translationClient = translationClient;
		this.env = env;
		EnvironmentName = env.SanitizedEnvironment ();
		translationManager = new TranslationManager (env, translationClient);
		this.openSearchClient = openSearchClient;
		stringLocalizer = new JsonStringLocalizer (env);
		leadSubmissionService = new LeadSubmissionService (httpClient, logger, config, dynamoClient, stringLocalizer, EnvironmentName);

		bookADemoFormConfigs = new FormSubmissionConfiguration () {
			CacheDurations = config.GetSection (Models.CacheDurationMinutes.SectionName).Get<CacheDurationMinutes> ()!,
			HomesBookADemoSecret = VaultKeyProvider.GetKeyContents (VaultKeys.BookADemo),
			DemoKillSwitchers = config.GetSection ("DemoKillSwitchers").Get<int[]> ()!
		};

		encryptedContactKey = VaultKeyProvider.GetKeyContents (VaultKeys.ContactEncryption);

		// just a test
		// var contactIdToEncrypt = "207444921";
		// var contactIdEncrypted = Utils.Encrypt (contactIdToEncrypt, encryptedContactKey);
		// var contactIdDecrypted = Utils.Decrypt (contactIdEncrypted, encryptedContactKey);
	}

	public override void AddRoutes (
		IEndpointRouteBuilder app
	) {

		// initial intent routes. marketing and sales leads
		app.MapGet ("/api/v{version:int}/script/{formcd}", getForm);
		app.MapPost ("/api/v{version:int}/script/{formcd}", submitForm).RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);

		// Book-A-Demo
		app.MapPost ("/api/v{version:int}/demo/{formcd}", submitDemo).RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		app.MapGet ("/api/v{version:int}/demo-switch", getDemoKillSwitch).AddEndpointFilter<PublicProductionFilter> (); // global kill switch for Book A Demo
		app.MapGet ("/api/v{version:int}/demo-switch/brand/{brandmappingid:int}", getDemoKillSwitchForBrand).AddEndpointFilter<PublicProductionFilter> (); // brand-level kill switch for Book A Demo
		app.MapGet ("/api/v{version:int}/demo-switch/brand/{brandmappingid:int}/{route}", getDemoKillSwitchForBrandRoute).AddEndpointFilter<PublicProductionFilter> (); // brand-level kill switch for Book A Demo. also match for the route
		app.MapGet ("/api/v{version:int}/demo-switch/form/{formcd}", getDemoKillSwitchForForm).AddEndpointFilter<PublicProductionFilter> (); // form-level kill switch for Book A Demo
		app.MapGet ("/api/v{version:int}/demo-switch/form/{formcd}/{locale}", getDemoKillSwitchForFormAndLocale).AddEndpointFilter<PublicProductionFilter> (); // specific form and locale kill switch for Book A Demo
		app.MapPost ("/api/v{version:int}/demo-switch", submitDemoKillSwitch).AddEndpointFilter<PublicProductionFilter> ();

		// costar group data privacy portal. there's just enough difference in models that i'd rather separate this
		app.MapPost ("/api/v{version:int}/privacy/{formcd}", submitPrivacy).RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		//.AddEndpointFilter<SourceIpAddressFilter> ()

		// begin capturing ga session id assoications with contact ids
		app.MapPost ("/api/v{version:int}/gasession", submitGaSession).RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);
		//.AddEndpointFilter<SourceIpAddressFilter> ()

		// supporting resources
		app.MapGet ("/api/v{version:int}/css/{filename}", getStylesheet);
		app.MapGet ("/api/v{version:int}/js/{filename}", getJavascript);

		#region tbd
		// app.MapGet ("/api/v{version:int}/whitepaper/{formcd}", getWhitepaper);
		// app.MapPost ("/api/v{version:int}/whitepaper/{formcd}", submitWhitepaper);

		// stats logging endpoints
		// no need for a load stat endpoint since we can log that on request
		// same with submission
		app.MapPost ("/api/v{version:int}/scriptactivity/{scriptcd}", submitScriptActivity);
		#endregion
	}

	private async Task getForm (
		HttpContext ctx,
		ITranslationClient translationClient,
		int version,
		string formcd
	) {
		// currently only supporting v1
		if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
			ctx.Response.StatusCode = 404;
			return;
		}

		// temp
		var timer = new System.Diagnostics.Stopwatch ();

		string locale = Utils.GetLocaleCd (ctx);

		if (ctx.Request.QueryString.HasValue && ctx.Request.Query.ContainsKey ("locale") && !string.IsNullOrEmpty (ctx.Request.Query["locale"])) {
			locale = ctx.Request.Query["locale"]!;
		}

		setupCulture (locale);

		int formMismatchRetryCount = 0;

	getForm:

		Models.Form? form = null;

		try {
			form = await dynamoClient.GetForm (formcd, locale);
		} catch (Exception oops) {
			Console.WriteLine ($"error getting form '{formcd}', '{locale}' : {oops.Message}");
			await ctx.Response.AsJson (new { Success = false, Message = oops.Message });
			ctx.Response.StatusCode = 404;
			return;
		}

		if (form == null) {
			Console.WriteLine ($"error getting form '{formcd}', '{locale}'. nothing found");
			ctx.Response.StatusCode = 404;
			return;
		}

		if (form.Active == false) {
			Console.WriteLine ($"error getting form '{formcd}', '{locale}'. inactive");
			ctx.Response.StatusCode = 404;
			return;
		}

		#region some debugging
		// trying to debug something - costar is having an issue where the form requested does not match the form code actually being requested
		if (formcd != form.Cd || locale != form.Locale) {
			// yes this is messed up
			// a little worried about an infinite loop, but i'll let it give a solid try
			if (formMismatchRetryCount > 20) {
				Console.WriteLine ($"error requesting form code {formcd} locale {locale}. too many failures");
			}

			Console.WriteLine ($"error requesting form code {formcd} locale {locale}. instead returned {form.Cd} {form.Locale}");

			formMismatchRetryCount++;
			goto getForm;
		}
		#endregion

		// if a host other than the host this form was made for requests it, log
		// string requestingHost = ctx.Request.Host.Value.ToLower ();

		// some resources could be in the local filesystem
		if (form.FormTemplatePath.StartsWith ("s3://") == false) {
			string formscriptpath = Path.Combine (templateDir, form.FormTemplatePath);

			if (File.Exists (formscriptpath) == false) {
				ctx.Response.StatusCode = 404;
				return;
			}

			form.FormTemplatePath = formscriptpath;
		}

		// not necessary, but if you want to test locally on the forms javascript files rather than pushing them up to s3 every time....
		if (EnvironmentName == "local") {
			if (form.FormTemplatePath.StartsWith ("s3://") && form.FormTemplatePath.Contains ("/forms/")) {
				form.FormTemplatePath = Path.Combine (env.WebRootPath, $"templates{(form.FormTemplatePath.Substring (form.FormTemplatePath.IndexOf ("/forms/")))}.js").Replace ('\\', '/');
			}
		}

		// this default caches for 60 seconds when the template source is s3
		// string? scriptContents = Utils.GetTemplateContents (
		// 	form.FormTemplatePath,
		// 	reduceContent: EnvironmentName == "prd",
		// 	s3client
		// );
		// timer.Reset ();
		// timer.Start ();
		string? scriptContents = Utils.GetProcessedTemplate (
			form.FormTemplatePath,
			env,
			form,
			s3client,
			translationManager
		);
		// timer.Stop ();
		// Console.WriteLine ($"Utils.GetProcessedTemplate time taken for {formcd} {locale} : {timer.Elapsed.ToString (@"m\:ss\.fff")}");

		// temporary for local testing
		// if (env.IsLocal () && form.FormTemplatePath.Contains ("tenx-injection")) {
		// 	form.FormTemplatePath = "c:/Users/jerdelyi/projects/costar/we-marketing-automation-form-injection/src/templates/forms/tenx-injection.js";
		// 	scriptContents = File.ReadAllText (form.FormTemplatePath);
		// 	scriptContents = scriptContents.Replace ("{{rooturl}}", Program.RootUrl);
		// }

		if (scriptContents == null) {
			Console.WriteLine ($"error getting form contents '{formcd}', '{locale}'");
			ctx.Response.StatusCode = 404;
			return;
		}

		ctx.Response.StatusCode = 200;
		ctx.Response.ContentType = "text/javascript";
		await ctx.Response.WriteAsync (scriptContents);
	}

	private static Models.ReservationCreationRequest createReservationCreationModel (
		HttpContext ctx,
		Models.Lead lead,
		string requestTrackerId
	) {
		var reservationRequest = new Models.ReservationCreationRequest () {
			TrackerId = requestTrackerId,
			SourceArea = lead.SourceArea ?? lead.SourceUrl ?? "",
			LeadSource = lead.LeadSource!,
			Brand = lead.Brand!,
			RequestType = "Demo",
			Locale = lead.Locale!,
			Prospect = new ReservationProspect () {
				FirstName = lead.FirstName!.Trim (),
				LastName = lead.LastName!.Trim (),
				EmailAddress = lead.EmailAddress!.Trim ().ToLower (),
				PhoneNumber = Utils.DeformatPhoneNumber (lead.PhoneNumber!),
				CompanyName = lead.CompanyName!.Trim (),
				CountryCode = lead.CountryCode!.ToUpper (),
				PostalCode = lead.PostalCode!,
				CompanyType = lead.AdditionalData.TryGetValue ("companyType", out string? companyType) ? companyType : null,
				Locale = lead.Locale!
			}
		};

		foreach (var kvp in lead.AdditionalData.Where (x => x.Value != null)) {
			reservationRequest.AdditionalData.Add (kvp.Key, kvp.Value);
		}
		reservationRequest.AdditionalData.Add ("IpAddress", ctx.SessionStorage ().SourceIp!.ToString ());
		reservationRequest.AdditionalData.Add ("UserAgent", ctx.SessionStorage ().UserAgent!);
		if (string.IsNullOrEmpty (lead.ProductLineCode) == false) {
			reservationRequest.AdditionalData.Add ("ProductLineCode", lead.ProductLineCode);
		}

		if (!string.IsNullOrEmpty (lead.CampaignId) && reservationRequest.AdditionalData["CampaignId"] == null) {
			reservationRequest.AdditionalData.Add ("CampaignId", lead.CampaignId);
		}

		return reservationRequest;
	}

	// documentation about the api gateway requirements:
	// https://tfs.prd.costargroup.com/CoStarCollection/CoStar%20One/_git/we-marketing-automation-services?path=/publish/ma_apigw_to_createlead.tf
	private async Task submitForm (
		HttpContext ctx,
		int version,
		string formcd,
		Models.Lead lead
	) {
		// 1. Early validation
		if (!isValidVersion (version)) { await ctx.RespondWithFailure ("Invalid form", $"No form version '{version}' found", new List<FluentValidation.Results.ValidationFailure> ()); return; }
		if (isHoneypotTriggered (lead)) { await ctx.RespondWithSuccess ("Thank you!"); return; }

		// 2. Setup and logging
		lead.Locale ??= Utils.GetLocaleCd (ctx);
		setupCulture (lead.Locale);

		// storing all submissions for better or worse. might change this
		// 2025-05-05 changing this to be updatable, so i need the formlog so that i may reference it later.
		// i wish to update whether or not the submission succeeded
		// var requestlog = FormRequestLog.BuildLog (ctx, formcd, locale);
		// await dynamoClient.InsertLog (requestlog);
		// changing to opensearch for this
		var formLogRecord = FormLogRecord.BuildLog (ctx, formcd, lead.Locale);
		await openSearchClient.LogFormRequest (formLogRecord);

		// var translations = await translationManager.Get (locale);

		// 3. Validation
		var (isValid, validationResult, countryCode) = await validateLead (dynamoClient, openSearchClient, stringLocalizer!, lead, EnvironmentName);
		if (!isValid) {
			await ctx.RespondWithFailure ("Errors have been found", errors: validationResult.Errors);

			// requestlog.RequestSucceeded = false;
			// requestlog.RequestErrors = validationResult.Errors.Select (e => e.PropertyName).ToList ();
			// await dynamoClient.InsertLog (requestlog); // update the log with the failure

			formLogRecord.RequestSucceeded = false;
			formLogRecord.RequestErrors = validationResult.Errors.Select (e => e.PropertyName).ToList ();
			await openSearchClient.LogFormRequest (formLogRecord);

			return;
		}

		// 4. Form retrieval and validation
		var form = await dynamoClient.GetForm (formcd, lead.Locale);

		if (form == null) {
			await ctx.RespondWithFailure ("Invalid form", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}
		if (form.Active == false) {
			await ctx.RespondWithFailure ("Invalid form.", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}

		if (isProductionCoStarAlternateDomainTest (ctx, env)) { await ctx.RespondWithSuccess ("Thank you!", fullMessage: $"no-op. no lead submitted from this hostname"); return; }

		// 5. Data processing
		LeadDataProcessor.ProcessLeadData (lead, form, ctx);

		// 6. a diversion into a possible Case submission
		if (EnvironmentName != "prd" && isCoStarGreatBritainEducationCase (lead)) {
			var casePayload = new Models.Case {
				CaseWith = 1,
				Subject = "Student Declaration Form",
				Description = "Student Declaration Form",
				CreatedByContactId = FormSubmissionConstants.MARKETING_CONTACT_ID,
				SourceReferenceKey = Guid.NewGuid ().ToString (),
				SourceType = "costar-suite-lead-student", // CaseSourceArea = "Marketing Automation Forms"
				SubmitDate = DateTimeOffset.Now,
				Priority = 3,
				Topic = 329, // Student Declaration Form
				AdditionalData = new NameValueCollectionKeyValue {
					{ "FirstName", lead.FirstName },
					{ "LastName", lead.LastName },
					{ "EmailAddress", lead.EmailAddress },
					{ "PostalCode", lead.PostalCode },
					{ "CountryCode", lead.CountryCode },
					{ "PhoneNumber", lead.PhoneNumber },
					{ "CompanyName", lead.CompanyName },
					{ "BusinessType", lead.BusinessType ?? "" },
					{ "RequestType", lead.AdditionalData["request_type"] ?? "" },
					{ "Brand", lead.Brand! },
					{ "SourceArea", lead.SourceArea ?? lead.SourceUrl ?? "" }
				}
			};

			var caseresult = await leadSubmissionService.SubmitCaseAsync (casePayload, lead, form);

			if (caseresult.Success == false) {
				await ctx.RespondWithFailure (caseresult.Message, caseresult.FullMessage, new List<FluentValidation.Results.ValidationFailure> ());
				return;
			}

			await ctx.RespondWithSuccess ("Thank you");
			return;
		}

		// 7. Lead submission
		var result = await leadSubmissionService.SubmitLeadAsync (lead, form);

		// 8. Response handling
		if (result.Success == false) {
			await ctx.RespondWithFailure (result.Message, result.FullMessage, new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}

		// requestlog.RequestSucceeded = true;
		// await dynamoClient.InsertLog (requestlog); // update the log with the success
		formLogRecord.RequestSucceeded = true;
		await openSearchClient.LogFormRequest (formLogRecord);

		// i don't want to reveal too much in PRD. though i may allow this on requests to PRD hitting internal DNS
		if (EnvironmentName != "prd") {
			await ctx.RespondWithSuccess ("Thank you", fullMessage: JsonConvert.SerializeObject (result.Data));
			return;
		}
		await ctx.RespondWithSuccess ("Thank you");
	}

	// documentation about the api gateway requirements:
	// https://crm.tsm.costar.com/enterprise-booking-orchestration-service/swagger/index.html
	// this is still taking the standard lead payload, but it will transform it into what this endpoint expects
	private async Task submitDemo (
		HttpContext ctx,
		int version,
		string formcd,
		Models.Lead lead,
		IValkeyClient valkeyClient
	) {

		// 1. Early validation
		if (!isValidVersion (version)) { await ctx.RespondWithFailure ("Invalid form", $"No form version '{version}' found", new List<FluentValidation.Results.ValidationFailure> ()); return; }
		if (isHoneypotTriggered (lead)) { await ctx.RespondWithSuccess ("Thank you!"); return; }

		// 2. Generate a request tracker id for downstream consumers
		string requestTrackerId = Guid.NewGuid ().ToString ();

		// 3. Set up locale a culture
		lead.Locale ??= Utils.GetLocaleCd (ctx);
		setupCulture (lead.Locale);

		// 4. first kill switch
		if (await bookingIsKillSwitched (valkeyClient, formcd, lead.Locale)) {
			formcd += "_dfb"; // dfb = Demo FallBack
			await submitForm (ctx, version, formcd, lead);
			return;
		}

		// 5. Request logging
		// storing all submissions for better or worse. might change this
		// 2025-05-05 changing this to be updatable, so i need the formlog so that i may reference it later.
		// i wish to update whether or not the submission succeeded
		// var requestlog = FormRequestLog.BuildLog (ctx, formcd, locale);
		// await dynamoClient.InsertLog (requestlog);
		// changing to opensearch for this
		var formLogRecord = FormLogRecord.BuildLog (ctx, formcd, lead.Locale);
		await openSearchClient.LogFormRequest (formLogRecord);

		// changing logging to elastic a different format for this
		var logRecord = new Models.BookingLogRecord () {
			TrackingId = requestTrackerId,
			SubmitDate = DateTimeOffset.Now,
			FormCd = formcd,
			Locale = lead.Locale,
			RawHeaders = new HeaderDictionary (ctx.Request.Headers.ToDictionary<string, StringValues> ()),
			OriginalLead = lead,
			IpAddress = ctx.SessionStorage ().SourceIp!.ToString (),
			UserAgent = ctx.SessionStorage ().UserAgent
		};
		await openSearchClient.LogBookingRequest (logRecord);

		// 6. Validation
		var (isValid, validationResult, countryCode) = await validateLead (dynamoClient, openSearchClient, stringLocalizer!, lead, EnvironmentName);
		if (!isValid) {
			await ctx.RespondWithFailure ("Errors have been found", errors: validationResult.Errors);

			formLogRecord.RequestSucceeded = false;
			formLogRecord.RequestErrors = validationResult.Errors.Select (e => e.PropertyName).ToList ();
			await openSearchClient.LogFormRequest (formLogRecord);

			logRecord.Errors = formLogRecord.RequestErrors;
			await openSearchClient.LogBookingRequest (logRecord);

			return;
		}

		// 7. New! If the quality of the first name and last name fields are too bad, create a regular sales lead. don't expose booking to bad actors
		var result = new InputQuality (lead.FirstName!.Trim () + lead.LastName!.Trim ());
		var score = result.CalculateScore ();
		// for now, don't block. i just want to log for a while
		lead.NameScore = score;

		// 8. Form retrieval and validation
		var form = await dynamoClient.GetForm (formcd, lead.Locale);

		if (form == null) {
			await ctx.RespondWithFailure ("Invalid form", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}
		if (form.Active == false) {
			await ctx.RespondWithFailure ("Invalid form.", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}

		// check again for killswitch, but just for the brand. we had to wait until now to check since we didn't have the value earlier
		if (await bookingIsKillSwitched (valkeyClient, form.MarketingBrandId, lead.SourceUrl)) {
			formcd += "_dfb"; // dfb = Demo FallBack
			await submitForm (ctx, version, formcd, lead);
			return;
		}

		// similar to a kill switch, but (as of this writing) for USA LoopNet in specific regions, continue but otherwise kick out to a standard lead form
		// derek will be providing an endpoint. in the meantime i will fake it in
		if (await isLoopNetBookADemoTestRegion (httpClient, lead) == false) {
			formcd += "_dfb"; // dfb = Demo FallBack
			await submitForm (ctx, version, formcd, lead);
			return;
		}

		// 9. Data processing
		LeadDataProcessor.ProcessLeadData (lead, form, ctx);

		// 10. Create the type of object he Booking Orchestrator needs
		var reservationRequest = createReservationCreationModel (ctx, lead, requestTrackerId);

		// 11. hash the request
		var requestHash = hashDemoRequest (ctx, reservationRequest);

		logRecord.RequestHash = requestHash;
		logRecord.Prospect = reservationRequest.Prospect;
		logRecord.SourceArea = reservationRequest.SourceArea;
		await openSearchClient.LogBookingRequest (logRecord);

		// 11. check valkey for the hash. if it exists, return the response to prevent re-submissions in a short period
		var cachedReservationResponse = await valkeyClient.GetString (requestHash);

		if (cachedReservationResponse.HasValue) {

			var payload = JsonConvert.DeserializeObject<Models.ReservationConfirmation> (cachedReservationResponse.ToString ()!);

			logRecord.BookingId = payload?.BookingId;
			logRecord.CachedResponse = true;
			await openSearchClient.LogBookingRequest (logRecord);

			await ctx.Response.AsJson (new { Success = true, Message = "Thank you", Payload = payload });
			return;
		}

		List<Models.ReservationConfirmation>? responseObject = null;

		try {
			// just expanded here for debugging purposes
			var serializedBody = JsonConvert.SerializeObject (new List<ReservationCreationRequest> () { reservationRequest }, NewtonsoftCustomResponseNegotiator.Serializer);

			var requestMessage = new HttpRequestMessage {
				Method = HttpMethod.Post,
				RequestUri = new Uri (form.SubmissionEndpoint),
				Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
			};

			// no auth for this currently. secured within AWS's subnets for access
			// var token = Utils.CreateRsaJwt (
			// 	form.SecurityKey,
			// 	DateTime.UtcNow.AddMinutes (5)
			// );

			// requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("Bearer", token);
			requestMessage.Headers.Add ("x-auth", bookADemoFormConfigs.HomesBookADemoSecret);

			var response = await httpClient.SendAsync (requestMessage);

			if (response.IsSuccessStatusCode == false) {

				// this type of error still has a body (i don't know about always, hence the try..catch)
				var errorReason = response.ReasonPhrase;

				try {
					errorReason = await response.Content.ReadAsStringAsync ();
				} catch {

				}

				logger.LogError (new Exception ($"{response.StatusCode}, {errorReason}"), $"Error submitting to demo endpoint : {response.StatusCode}, {response.ReasonPhrase} from {Environment.MachineName}");
				await ctx.Response.AsJson (new { Success = false, Message = $"Error, {errorReason}", StatusCode = response.StatusCode, Errors = new List<string> () });

				logRecord.Errors = [$"Error submitting to demo endpoint : {response.StatusCode}, {response.ReasonPhrase} from {Environment.MachineName}"];
				await openSearchClient.LogBookingRequest (logRecord);
				return;
			}

			var responseString = await response.Content.ReadAsStringAsync ();

			if (string.IsNullOrEmpty (responseString)) {
				logRecord.Errors = [$"Unknown error, no response message from server"];
				await openSearchClient.LogBookingRequest (logRecord);
				await ctx.Response.AsJson (new { Success = false, Message = "Unknown error, no response message from server", Errors = new List<string> () });
				return;
			}

			responseObject = JsonConvert.DeserializeObject<List<Models.ReservationConfirmation>> (responseString);

			if (responseObject == null) {
				logRecord.Errors = [$"Unknown error, malformed response message from server"];
				await openSearchClient.LogBookingRequest (logRecord);
				await ctx.Response.AsJson (new { Success = false, Message = "Unknown error, malformed response message from server", Errors = new List<string> () });
				return;
			}

			if (responseObject.Count == 0) {
				logRecord.Errors = [$"Unknown error, empty response message from server"];
				await openSearchClient.LogBookingRequest (logRecord);
				await ctx.Response.AsJson (new { Success = false, Message = "Unknown error, empty response message from server", Errors = new List<string> () });
				return;
			}

			if (string.IsNullOrEmpty (responseObject[0].BookingId) || string.IsNullOrEmpty (responseObject[0].ReservationLink)) {
				logRecord.Errors = [$"Error with response contents. No booking id or reserveration link returned"];
				await openSearchClient.LogBookingRequest (logRecord);
				await ctx.Response.AsJson (new { Success = false, Message = "Error with response contents", Errors = new List<string> () });
				return;
			}

		} catch (Exception oops) {
			logRecord.Errors = [$"Error submitting to demo endpoint : {oops.Message} from {Environment.MachineName}"];
			await openSearchClient.LogBookingRequest (logRecord);
			logger.LogError (oops, $"Error submitting to demo endpoint : {oops.Message} from {Environment.MachineName}");
			await ctx.Response.AsJson (new { Success = false, Message = oops.Message, FullMessage = oops.ToString (), Errors = new List<string> () });
			return;
		}

		// it turns out that the booking orchestrator is *not* hitting our create-lead endpoint, so preferences will get lost if i don't handle them
		// this should not cause the enire process to fail if it fails however.
		// i'm only going to handle the newer segment-based opts
		if (lead.OptIntoSegments != null && lead.OptIntoSegments.Count > 0) {

			var prefResponse = await EmailPreferenceModule.submitEmailPreferenceInnards (
				config,
				new Models.EmailPreference () {
					EmailAddress = reservationRequest.Prospect.EmailAddress,
					Brand = new List<string> { lead.Brand! },
					CountryCode = reservationRequest.Prospect.CountryCode,
					OptIntoSegments = lead.OptIntoSegments
				},
				httpClient,
				dynamoClient,
				stringLocalizer!,
				EnvironmentName
			);

			if (prefResponse.Success == false) {
				Console.WriteLine ($"Error setting preference for : {lead.EmailAddress} segments : {JsonConvert.SerializeObject (lead.OptIntoSegments)} response : {JsonConvert.SerializeObject (prefResponse)}");
			}

		}

		// requestlog.RequestSucceeded = true;
		// await dynamoClient.InsertLog (requestlog); // update the log with the success
		formLogRecord.RequestSucceeded = true;
		await openSearchClient.LogFormRequest (formLogRecord);

		// store the Reservation response in valkey for 5 minutes to prevent dupes in that timeframe
		var reservationResponse = responseObject[0];

		// 2025-09-05 added by cody/jc. they have a circuit breaker in place. anything but 1 is bad, so send this through the regualr form process
		if (reservationResponse.Status != null && reservationResponse.Status.Value != 1) {
			formcd += "_dfb"; // dfb = Demo FallBack
			await submitForm (ctx, version, formcd, lead);
			return;
		}

		int cacheDuration = bookADemoFormConfigs.CacheDurations.DemoForm; // cacheDurationMinutes.DemoForm;
		if (reservationResponse.ExpirationDate != null) {
			var expirationDt = reservationResponse.ExpirationDate.Value;

			// let's be sure the Expiration Date is later than now
			if (expirationDt > DateTimeOffset.Now) {
				var timespan = expirationDt - DateTimeOffset.Now;
				cacheDuration = Convert.ToInt32 (timespan.TotalMinutes);
			}
		}

		var cacheResponse = await valkeyClient.SetString (requestHash, JsonConvert.SerializeObject (reservationResponse), new TimeSpan (0, cacheDuration, 0));

		logRecord.BookingId = reservationResponse.BookingId;
		await openSearchClient.LogBookingRequest (logRecord);

		await ctx.Response.AsJson (new { Success = true, Message = "Thank you", Payload = reservationResponse });
		return;
	}

	public async Task getDemoKillSwitch (
		HttpContext ctx,
		IValkeyClient valkeyClient
	) {
		// this is just looking for a valkey value. absense of the key also means the kill switch is not in effect
		// as for values, i'm just looking for "0" and "1"
		// "0" also means kill switch not in effect
		var killswitchValue = await valkeyClient.GetString (FormSubmissionConstants.DEMO_KILL_SWITCH_KEY);

		await ctx.Response.WriteAsync ((killswitchValue.HasValue == false || killswitchValue.IsNullOrEmpty || killswitchValue.ToString () == "0") ? "0" : killswitchValue.ToString ());

		return;
	}

	public async Task getDemoKillSwitchForBrand (
		HttpContext ctx,
		IValkeyClient valkeyClient,
		int brandmappingid
	) {
		// this is just looking for a valkey value. absense of the key also means the kill switch is not in effect
		// as for values, i'm just looking for "0" and "1"
		// "0" also means kill switch not in effect
		var killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{brandmappingid}");

		await ctx.Response.WriteAsync ((killswitchValue.HasValue == false || killswitchValue.IsNullOrEmpty || killswitchValue.ToString () == "0") ? "0" : killswitchValue.ToString ());

		return;
	}

	public async Task getDemoKillSwitchForBrandRoute (
		HttpContext ctx,
		IValkeyClient valkeyClient,
		int brandmappingid,
		string route
	) {
		route = HttpUtility.UrlDecode (route);
		// this is just looking for a valkey value. absense of the key also means the kill switch is not in effect
		// as for values, i'm just looking for "0" and "1"
		// "0" also means kill switch not in effect
		var killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{brandmappingid}:route:{route}");

		await ctx.Response.WriteAsync ((killswitchValue.HasValue == false || killswitchValue.IsNullOrEmpty || killswitchValue.ToString () == "0") ? "0" : killswitchValue.ToString ());

		return;
	}

	public async Task getDemoKillSwitchForForm (
		HttpContext ctx,
		IValkeyClient valkeyClient,
		string formcd
	) {
		// this is just looking for a valkey value. absense of the key also means the kill switch is not in effect
		// as for values, i'm just looking for "0" and "1"
		// "0" also means kill switch not in effect
		var killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{formcd}");

		await ctx.Response.WriteAsync ((killswitchValue.HasValue == false || killswitchValue.IsNullOrEmpty || killswitchValue.ToString () == "0") ? "0" : killswitchValue.ToString ());

		return;
	}

	public async Task getDemoKillSwitchForFormAndLocale (
		HttpContext ctx,
		IValkeyClient valkeyClient,
		string formcd,
		string locale
	) {
		// this is just looking for a valkey value. absense of the key also means the kill switch is not in effect
		// as for values, i'm just looking for "0" and "1"
		// "0" also means kill switch not in effect
		var killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{formcd}:locale:{locale}");

		await ctx.Response.WriteAsync ((killswitchValue.HasValue == false || killswitchValue.IsNullOrEmpty || killswitchValue.ToString () == "0") ? "0" : killswitchValue.ToString ());

		return;
	}

	public async Task submitDemoKillSwitch (
		HttpContext ctx,
		IValkeyClient valkeyClient,
		Models.DemoKillSwitchRequest demoKillSwitchRequest
	) {
		var allowedKillers = bookADemoFormConfigs.DemoKillSwitchers;

		if (allowedKillers == null) {
			await ctx.Response.WriteAsync ("no allow list found");
			return;
		}

		if (allowedKillers.Length == 0) {
			await ctx.Response.WriteAsync ("allow list found, but it is empty");
			return;
		}

		if (allowedKillers.Any (x => x == demoKillSwitchRequest.Requestor) == false) {
			await ctx.Response.WriteAsync ("you are not in the allowlist");
			return;
		}

		// only 0 and 1 are allowed values
		if (!(demoKillSwitchRequest.Value == "0" || demoKillSwitchRequest.Value == "1")) {
			await ctx.Response.WriteAsync ($"'{demoKillSwitchRequest.Value}' is not a valid value. allowed values : [0|1]");
			return;
		}

		// set a key based on incoming data
		string killKey = FormSubmissionConstants.DEMO_KILL_SWITCH_KEY;

		if (demoKillSwitchRequest.BrandMappingId != null) {
			killKey = $"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{demoKillSwitchRequest.BrandMappingId}";

			if (demoKillSwitchRequest.Route != null) {
				killKey = $"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{demoKillSwitchRequest.BrandMappingId}:route:{demoKillSwitchRequest.Route}";
			}
		}

		if (demoKillSwitchRequest.FormCd != null) {
			killKey = $"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{demoKillSwitchRequest.FormCd}";

			if (demoKillSwitchRequest.Locale != null) {
				killKey = $"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{demoKillSwitchRequest.FormCd}:locale:{demoKillSwitchRequest.Locale}";
			}
		}

		var valueSet = await valkeyClient.SetString (killKey, demoKillSwitchRequest.Value);

		if (valueSet == false) {
			await ctx.Response.WriteAsync ("unknown error - value not set");
			return;
		}

		await ctx.Response.WriteAsync ($"value set : {demoKillSwitchRequest.Value}");
		return;
	}

	private async Task submitPrivacy (
		HttpContext ctx,
		int version,
		string formcd,
		Models.PrivacyLead lead
	) {
		// 1. Early validation
		if (!isValidVersion (version)) { await ctx.RespondWithFailure ("Invalid form", $"No form version '{version}' found", new List<FluentValidation.Results.ValidationFailure> ()); return; }
		if (isHoneypotTriggered (lead)) { await ctx.RespondWithSuccess ("Thank you!"); return; }

		// 2. Setup and logging
		lead.Locale ??= Utils.GetLocaleCd (ctx);
		setupCulture (lead.Locale);

		// storing all submissions for better or worse. might change this
		// 2025-05-05 changing this to be updatable, so i need the formlog so that i may reference it later.
		// i wish to update whether or not the submission succeeded
		// var requestlog = FormRequestLog.BuildLog (ctx, formcd, locale);
		// await dynamoClient.InsertLog (requestlog);
		// changing to opensearch for this
		var formLogRecord = FormLogRecord.BuildLog (ctx, formcd, lead.Locale);
		await openSearchClient.LogFormRequest (formLogRecord);

		// var translations = await translationManager.Get (locale);

		// 3. Validation
		var (isValid, validationResult, countryCode) = await validateLead (dynamoClient, openSearchClient, stringLocalizer!, lead, EnvironmentName);
		if (!isValid) {
			await ctx.RespondWithFailure ("Errors have been found", errors: validationResult.Errors);

			formLogRecord.RequestSucceeded = false;
			formLogRecord.RequestErrors = validationResult.Errors.Select (e => e.PropertyName).ToList ();
			await openSearchClient.LogFormRequest (formLogRecord);

			return;
		}

		// 4. Form retrieval and validation
		var form = await dynamoClient.GetForm (formcd, lead.Locale);

		if (form == null) {
			await ctx.RespondWithFailure ("Invalid form", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}
		if (form.Active == false) {
			await ctx.RespondWithFailure ("Invalid form.", fullMessage: $"No form '{formcd}' with locale '{lead.Locale}' found", errors: new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}

		// 5. Data processing
		LeadDataProcessor.ProcessLeadData (lead, form, ctx);

		// 6. attempt to look up the contact to supply values for the case payload
		var contactMatch = await openSearchClient.GetContact (
			lead.EmailAddress!,
			lead.FirstName!,
			lead.LastName!,
			lead.PhoneNumber!
		);

		// 7. Case submission
		string requestType = lead.AdditionalData.TryGetValue ("request-type", out string? rt) ? rt : "";
		string additionalDetails = lead.AdditionalData.TryGetValue ("additional-details", out string? ad) ? ad : "";
		string? countryName = null;
		try {
			var c3to2 = await dynamoClient.GetCountry3to2 (lead.CountryCode!);
			countryName = c3to2?.Name;
		} catch (Exception oops) {
			Console.WriteLine ($"non-fatal error getting country name for country code '{lead.CountryCode}' : {oops.Message}");
		}

		var casePayload = new Models.Case {
			SourceType = "marketing-cloud-privacy-form",
			SourceReferenceKey = Guid.NewGuid ().ToString (),
			CaseWith = 14,
			Topic = 514,
			Subject = $"Privacy Information Removal Request - {lead.FirstName} {lead.LastName}",
			Description = $"Brand: {lead.Brand!}<br/><br/>Request Type: {requestType}<br/><br/>Making this request as: {lead.Relationship}<br/><br/>First Name: {lead.FirstName}<br/><br/>Last Name: {lead.LastName}<br/><br/>Phone Number: {lead.PhoneNumber}<br/><br/>Email Address: {lead.EmailAddress}<br/><br/>Country Code: {lead.CountryCode}<br/><br/>Country Name: {countryName}<br/><br/>Address: {lead.Address}<br/><br/>State Code: {lead.StateCode}<br/><br/>Postal Code: {lead.PostalCode}<br/><br/>Submitted From: {lead.SourceArea ?? lead.SourceUrl ?? ""}<br/><br/>",
			Priority = 1,
			SubmitDate = DateTimeOffset.Now,
			CaseContactId = contactMatch?.ContactId,
			CreatedByContactId = contactMatch?.ContactId,
			CompanyId = contactMatch?.LocationId,
			AdditionalData = new NameValueCollectionKeyValue {
				{ "FirstName", lead.FirstName },
				{ "LastName", lead.LastName },
				{ "EmailAddress", lead.EmailAddress },
				{ "PostalCode", lead.PostalCode },
				{ "CountryCode", lead.CountryCode },
				{ "PhoneNumber", lead.PhoneNumber },
				{ "CompanyName", lead.CompanyName },
				{ "RequestType", requestType },
				{ "AdditionalDetails", additionalDetails },
				{ "Brand", lead.Brand! },
				{ "SourceArea", lead.SourceArea ?? lead.SourceUrl ?? "" },
				{ "Relationship", lead.Relationship },
				{ "Address", lead.Address },
				{ "StateCode", lead.StateCode}
			}
		};

		var caseresult = await leadSubmissionService.SubmitCaseAsync (casePayload, lead, form);

		if (caseresult.Success == false) {
			await ctx.RespondWithFailure (caseresult.Message, caseresult.FullMessage, new List<FluentValidation.Results.ValidationFailure> ());
			return;
		}

		await ctx.RespondWithSuccess ("Thank you");
		return;
	}

	// this needs to be very error tolerant. it shouldn't cause the client problems.
	private async Task submitGaSession (
		HttpContext ctx,
		Models.OpenSearch.ContactGaSession bound
	) {

		if (string.IsNullOrWhiteSpace (bound.Ecid) || string.IsNullOrWhiteSpace (bound.SessionId)) {
			ctx.Response.StatusCode = 200;
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = "missing ecid or session id" });
			return;
		}

		string? contactIdString = null;
		int? contactId = null;

		try {
			contactIdString = Utils.Decrypt (bound.Ecid, encryptedContactKey);
		} catch (Exception oops) {
			Console.WriteLine ($"error decrypting contactid : {oops.Message}");
			ctx.Response.StatusCode = 200;
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = $"error decrypting contactid : {oops.Message}" });
			return;
		}

		// this should not be possible, but...
		if (contactIdString == null) {
			Console.WriteLine ("error, decrypted contactid is somehow null");
			ctx.Response.StatusCode = 200;
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = "error, decrypted contactid is somehow null" });
			return;
		}

		try {
			contactId = Convert.ToInt32 (contactIdString);
		} catch (Exception oops) {
			Console.WriteLine ($"error converting contactid {contactIdString} to an int32 : {oops.Message}");
			ctx.Response.StatusCode = 200;
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = $"error converting contactid {contactIdString} to an int32 : {oops.Message}" });
			return;
		}

		// this should not be possible, but...
		if (contactId == null) {
			Console.WriteLine ("error, converted contactid is somehow null");
			ctx.Response.StatusCode = 200;
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = "error, converted contactid is somehow null" });
			return;
		}

		try {
			var result = await openSearchClient.WriteContactGaSession (new Models.OpenSearch.ContactGaSessions () {
				ContactId = contactId.Value,
				GaSessionIds = [bound.SessionId]
			});

			if (result == false) {
				Console.WriteLine ($"Unknown error writing {contactId.Value}, {bound.SessionId} to the contact GA session elastic index");
				await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = $"Unknown error writing {contactId.Value}, {bound.SessionId} to the contact GA session elastic index" });
			}

		} catch (Exception oops) {
			Console.WriteLine ($"error saving contactid/gasessionid combo : {oops.Message}");
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = $"error saving contactid/gasessionid combo : {oops.Message}" });
		}

		ctx.Response.StatusCode = 200;
		return;
	}


	private async Task getStylesheet (
		HttpContext ctx,
		int version,
		string filename
	) {

		if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string? styleContents = null;

		// if the file has a file extension, look in the local file system. otherwise check s3
		if (filename.EndsWith (".css")) {
			string filepath = Path.Combine (templateDir, $"css/{filename}");

			if (File.Exists (filepath) == false) {
				ctx.Response.StatusCode = 404;
				return;
			}

			styleContents = File.ReadAllText (filepath);
		} else {
			string filepath = $"s3://{config.GetSection ("AwsS3Bucket").Get<string> ()}/form-injection/css/{filename}";
			try {
				styleContents = Utils.GetTemplateContentsFromS3 (s3client, filepath, reduceContent: true);
			} catch (ArgumentOutOfRangeException) {
				styleContents = null;
			}
		}

		if (styleContents == null) {
			ctx.Response.StatusCode = 404;
			return;
		}

		styleContents = styleContents.Replace ("{{rooturl}}", Program.RootUrl);

		// not going to make this conditional based on the environment for CSS. it's pretty clean and readable after this reduction
		//styleContents = Utils.ReduceCss (styleContents);

		ctx.Response.StatusCode = 200;
		ctx.Response.ContentType = "text/css";
		await ctx.Response.WriteAsync (styleContents);
	}

	private async Task getJavascript (
		HttpContext ctx,
		int version,
		string filename
	) {

		if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string? scriptContents = null;
		string? failureReason = null;

		// this makes local testing easier. comment this all out though if you want to test pulling fomr s3, minifying, etc
		// it pulls from local files instead of s3
		if (EnvironmentName == "local") {
			var staticfilePath = Path.Combine (env.WebRootPath, "staticfiles");
			filename = Path.Combine (staticfilePath, $"js/{filename}.js");
			scriptContents = File.ReadAllText (filename);
			ctx.Response.StatusCode = 200;
			ctx.Response.ContentType = "text/javascript";
			await ctx.Response.WriteAsync (scriptContents);
			return;
		}

		// minify in tsm+
		var reduceContent = !(EnvironmentName == "local" || EnvironmentName == "dev.main");

		// if the file has a file extension, look in the local file system. otherwise check s3
		if (filename.EndsWith (".js")) {
			string filepath = Path.Combine (templateDir, $"js/{filename}");

			if (File.Exists (filepath) == false) {
				ctx.Response.Headers.TryAdd ("x-machinename", Environment.MachineName);
				ctx.Response.Headers.TryAdd ("x-fail-reason", "local file reference failed");
				ctx.Response.StatusCode = 404;
				return;
			}

			scriptContents = File.ReadAllText (filepath);
		} else {
			string filepath = $"s3://{config.GetSection ("AwsS3Bucket").Get<string> ()}/form-injection/js/{filename}";
			try {
				scriptContents = Utils.GetTemplateContentsFromS3 (s3client, filepath, reduceContent: reduceContent);
			} catch (AmazonS3Exception oops) {
				Console.WriteLine ($"error getting javascript file '{filename}' : {oops.Message}");
				scriptContents = null;
				failureReason = $"Exception - {oops.Message}";
			} catch (ArgumentOutOfRangeException oops) {
				Console.WriteLine ($"error getting javascript file '{filename}' : {oops.Message}");
				scriptContents = null;
				failureReason = $"ArgumentOutOfRangeException - {oops.Message}";
			} catch (Exception oops) {
				Console.WriteLine ($"error getting javascript file '{filename}' : {oops.Message}");
				scriptContents = null;
				if (oops.Message.ToLower ().Contains ("specified key does not exist")) {
					failureReason = $"Exception - {oops.Message}";
				} else {
					failureReason = $"Exception - generic exception - unable to find remote file {oops.Message}";
				}
			}
		}

		if (scriptContents == null) {
			ctx.Response.Headers.TryAdd ("x-machinename", Environment.MachineName);
			ctx.Response.Headers.TryAdd ("x-fail-reason", (failureReason == null ? "remote file reference failed" : failureReason));
			ctx.Response.StatusCode = 404;
			return;
		}

		scriptContents = scriptContents.Replace ("{{rooturl}}", Program.RootUrl);

		// if (env.IsLocal () == false) {
		// 	scriptContents = Utils.ReduceJavascript (scriptContents);
		// }

		ctx.Response.StatusCode = 200;
		ctx.Response.ContentType = "text/javascript";
		await ctx.Response.WriteAsync (scriptContents);
	}

	#region whitepaper/file-download example
	// private async Task submitWhitepaper (
	// 	HttpContext ctx,
	// 	int version,
	// 	string formcd,
	// 	Models.Lead lead
	// ) {

	// 	// currently only supporting v1
	// 	if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
	// 		ctx.Response.StatusCode = 404;
	// 		return;
	// 	}

	// 	var validationResult = ctx.Request.Validate<Lead> (lead);

	// 	if (validationResult.IsValid == false) {
	// 		await ctx.Response.AsJson (new { Success = false, Message = "You have errors", Errors = validationResult.Errors });
	// 		return;
	// 	}

	// 	string locale = lead.Locale ?? Utils.GetLocaleCd (ctx);

	// 	var form = await dynamoClient.GetForm (formcd, locale);

	// 	if (form == null) {
	// 		ctx.Response.StatusCode = 404;
	// 		return;
	// 	}

	// 	lead.LeadSource ??= form.FormLeadSource;
	// 	lead.Brand ??= form.MarketingBrand;
	// 	lead.SourceType = form.FormSourceType;
	// 	lead.FormType = form.FormType;
	// 	lead.CampaignId ??= form.InboundExternalCampaignId;

	// 	// try {
	// 	// 	var requestMessage = new HttpRequestMessage {
	// 	// 		Method = HttpMethod.Post,
	// 	// 		RequestUri = new Uri(formData.SubmissionEndpoint),
	// 	// 		Content =  new StringContent(JsonConvert.SerializeObject(lead), Encoding.UTF8, "application/json")
	// 	// 	};

	// 	// 	var token = Utils.CreateRsaJwt (
	// 	// 		formData.SecurityKey,
	// 	// 		DateTime.UtcNow.AddMinutes(5)
	// 	// 	);

	// 	// 	requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("Bearer", token);

	// 	// 	var response = await httpClient.SendAsync(requestMessage);

	// 	// 	if (response.IsSuccessStatusCode == false) {
	// 	// 		await ctx.Response.AsJson(new {Success = false, Message = $"Error, {response.ReasonPhrase}", Errors = new List<string>()});
	// 	// 		return;
	// 	// 	}
	// 	// } catch (Exception oops) {
	// 	// 	await ctx.Response.AsJson(new {Success = false, Message = oops.Message, FullMessage = oops.ToString(), Errors = new List<string>()});
	// 	// 	return;
	// 	// }

	// 	await ctx.Response.AsJson (new { Success = true, Message = "Thank you! Your file download should start soon", DownloadUrl = $"/api/v1/whitepaper/{formcd}" });
	// 	return;
	// }

	// private async Task getWhitepaper (
	// 	HttpContext ctx,
	// 	int version,
	// 	string formcd
	// ) {

	// 	// currently only supporting v1
	// 	if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
	// 		ctx.Response.StatusCode = 404;
	// 		return;
	// 	}

	// 	// some sort of auth header to get the file. or some other mechanism
	// 	var form = await dynamoClient.GetForm (formcd, Utils.GetLocaleCd (ctx));

	// 	if (form == null) {
	// 		ctx.Response.StatusCode = 404;
	// 		return;
	// 	}

	// 	var provider = new PhysicalFileProvider (Path.Combine (templateDir, "whitepapers"));
	// 	var fi = provider.GetFileInfo ("running-containerized-microservices.pdf");

	// 	if (fi.Exists == false) {
	// 		await ctx.Response.AsJson (new { Success = false, Message = $"Error, file not found", Errors = new List<string> () });
	// 		return;
	// 	}

	// 	ContentDisposition cd = new ContentDisposition () {
	// 		FileName = "Whitepaper.pdf",
	// 		DispositionType = DispositionTypeNames.Attachment
	// 	};

	// 	ctx.Response.Clear ();
	// 	ctx.Response.Headers.Append ("Content-Disposition", cd.ToString ());
	// 	ctx.Response.Headers.Append ("Content-Type", "application/pdf; charset=utf-8");
	// 	ctx.Response.Headers.Append ("Content-Length", fi.Length.ToString ());
	// 	ctx.Response.Headers.Append ("Content-Transfer-Encoding", "binary");
	// 	await ctx.Response.SendFileAsync (fi);

	// 	// var provider = new PhysicalFileProvider(Path.Combine(templateDir, "whitepapers"));
	// 	// var fi = provider.GetFileInfo("WhitePaper01.txt");

	// 	// if (fi.Exists == false) {
	// 	// 	await ctx.Response.AsJson(new {Success = false, Message = $"Error, file not found", Errors = new List<string>()});
	// 	// 	return;
	// 	// }

	// 	// ContentDisposition cd = new ContentDisposition() {
	// 	// 	FileName = "WhitePaper.txt",
	// 	// 	//DispositionType = DispositionTypeNames.Attachment
	// 	// 	Inline = true
	// 	// };

	// 	// ctx.Response.Clear();
	// 	// ctx.Response.Headers.Append("Content-Disposition", cd.ToString());
	// 	// ctx.Response.Headers.Append("Content-Type", "text/plain; charset=utf-8");
	// 	// ctx.Response.Headers.Append("Content-Length", fi.Length.ToString());
	// 	// ctx.Response.Headers.Append("Content-Transfer-Encoding", "binary");
	// 	// await ctx.Response.SendFileAsync(fi);
	// }
	#endregion

	private async Task submitScriptActivity (
		HttpContext ctx,
		int version,
		string scriptcd
	) {
		// contract TBD

		ctx.Response.StatusCode = 200;
		await Task.CompletedTask;
		return;
	}

	private static bool isValidVersion (
		int version
	) {
		if (version != FormSubmissionConstants.SUPPORTED_VERSION) {
			return false;
		}
		return true;
	}

	// honeypot field. if this has a value, this is not a normal human interaction.
	// exit with a 200 to not tip off abusers
	private static bool isHoneypotTriggered (
		Models.Lead lead
	) {
		if (!string.IsNullOrEmpty (lead.NeverFill)) {
			return true;
		}
		return false;
	}

	private static bool isTestHostname (
		HttpContext ctx
	) {
		return false;
	}

	private static bool isCoStarGreatBritainEducationCase (
		Models.Lead lead
	) {
		return
			lead.Brand?.ToLower () == "costar" &&
			lead.CountryCode == "GBR" &&
			(
				(lead.AdditionalData.ContainsKey ("request_type") && lead.AdditionalData["request_type"] == "Professors and Students") ||
				(lead.EmailAddress != null && lead.EmailAddress.EndsWith (".ac.uk"))
			);
	}

	// adding a kill switch. the intent here is to divert traffic to the original lead creation flow if this route is "killed"
	private static async Task<bool> bookingIsKillSwitched (
		IValkeyClient valkeyClient,
		string formCd,
		string locale
	) {
		var killswitchValue = await valkeyClient.GetString (FormSubmissionConstants.DEMO_KILL_SWITCH_KEY);

		if (isKilled (killswitchValue)) {
			return true;
		}

		// test form code and locale (start with the most specific test)
		killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{formCd}:locale:{locale}");

		if (isKilled (killswitchValue)) {
			return true;
		}

		// now test the form code
		killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:formcd:{formCd}");

		if (isKilled (killswitchValue)) {
			return true;
		}

		return false;
	}

	// a version just for the brand mapping id
	private static async Task<bool> bookingIsKillSwitched (
		IValkeyClient valkeyClient,
		int brandMappingId,
		string? sourceUrl
	) {
		RedisValue killswitchValue;

		// start with more specific, which is brand + route
		if (string.IsNullOrEmpty (sourceUrl) == false) {
			// extract the path from the sourceUrl
			Uri.TryCreate (sourceUrl, UriKind.RelativeOrAbsolute, out Uri? sourceUri);

			if (sourceUri != null) {
				string route = sourceUri.AbsolutePath.TrimEnd ('/').ToLower (); // trim off trailing slashes. just looking for consistency

				killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{brandMappingId}:route:{route}");

				if (isKilled (killswitchValue)) {
					return true;
				}
			}
		}

		killswitchValue = await valkeyClient.GetString ($"{FormSubmissionConstants.DEMO_KILL_SWITCH_KEY}:brandmappingid:{brandMappingId}");

		if (isKilled (killswitchValue)) {
			return true;
		}

		return false;
	}

	private static bool isKilled (
		RedisValue killswitchValue
	) {
		return (killswitchValue.HasValue && killswitchValue.IsNullOrEmpty == false && killswitchValue.ToString () == "1");
	}

	private static async Task<bool> isLoopNetBookADemoTestRegion (
		HttpClient httpClient,
		Models.Lead lead
	) {
		return true;
	}

	private static void setupCulture (string locale) {
		// change the current thread's culture
		var culture = new CultureInfo (locale);
		// this appears to be what really alters the localization for fluent
		CultureInfo.CurrentUICulture = culture;
		// i'm setting this because the stringlocalizer listens for it
		System.Threading.Thread.CurrentThread.CurrentCulture = culture;
	}

	// 2025-06-30 janos. suji hong requested two "production" hostnames be added to CORS to allow testing, but not actually submit
	// this submission should emulate a success response
	private static bool isProductionCoStarAlternateDomainTest (
		HttpContext ctx,
		IWebHostEnvironment env
	) {
		// Console.WriteLine ($"requesting host : {ctx.Request.Host.Host.ToLower ()}");
		// Console.WriteLine ($"requestng headers : {string.Join (',', ctx.Request.Headers)}");
		// it appears that it is the Origin header that i want
		if (env.IsProduction ()) {
			string? requestingHost = null;

			string? origin = ctx.Request.Headers.TryGetValue ("Origin", out var originValues) && originValues.Count > 0
				? originValues[0]
				: null;

			if (origin != null && Uri.TryCreate (origin, UriKind.Absolute, out Uri? originUri)) {
				if (originUri != null) {
					requestingHost = originUri.Host.ToLower ();
				}
			}

			// requestingHost = ctx.Request.Host.Host.ToLower ();

			if (
				requestingHost != null &&
				(
					requestingHost == "costar-na-prod.acquia.dshrp.com" ||
					requestingHost == "costar-uk-prod.acquia.dshrp.com"
				)
			) {
				return true;
			}
		}

		return false;
	}

	private static string hashDemoRequest (
		HttpContext ctx,
		Models.ReservationCreationRequest reservation
	) {
		// nothing fancy here.
		// looking the following for uniqueness :
		// - ip address
		// - user agent
		// - sanitized source area/url (lowercased, just hostname)
		// - email address
		// - country code
		// - phone number
		// - postal code
		//
		// just going to concat these, then compute sha256 hash for consistent sizes of the keys

		var sourceDomain = getDomain (reservation.SourceArea);
		// var sourceUrl = reservation.SourceArea.ToLower ();

		// var input = $"{ctx.SessionStorage ().SourceIp}{ctx.SessionStorage ().UserAgent}{sourceUrl}{reservation.Prospect.EmailAddress}{reservation.Prospect.CountryCode}{reservation.Prospect.PhoneNumber}{reservation.Prospect.PostalCode}";

		// 2025-09-05 it was requested that the dupe check be reduced to email address, phone, and hostname
		var input = $"{reservation.Prospect.EmailAddress}{reservation.Prospect.PhoneNumber}{sourceDomain}";

		using (SHA256 sha256 = SHA256.Create ()) {
			var bytes = sha256.ComputeHash (Encoding.UTF8.GetBytes (input));
			return BitConverter.ToString (bytes);
		}
	}

	private static string getDomain (
		string urlstring
	) {
		try {
			return new Uri (urlstring).Host.ToLower ()!;
		} catch (Exception oops) {
			Console.WriteLine ($"error parsing {urlstring} to url/host. {oops.Message}");
			return "";
		}
	}

	private static async Task<(bool IsValid, FluentValidation.Results.ValidationResult Result, string? TwoCharCountryCode)> validateLead (
		IDynamoClient dynamoClient,
		IOpenSearchClient openSearchClient,
		IStringLocalizer stringLocalizer,
		Lead lead,
		string environmentName
	) {
		var twoCharacterCountryCode = await getTwoCharacterCountryCodeAsync (dynamoClient, lead.CountryCode);
		lead.CountryCodeIso2 = twoCharacterCountryCode;

		var leadContext = new ValidationContext<Lead> (lead);
		leadContext.RootContextData["EnvironmentName"] = environmentName;
		leadContext.RootContextData["CountryCodeTwoChar"] = twoCharacterCountryCode;

		var leadValidator = new LeadIngestionValidator (dynamoClient, openSearchClient, stringLocalizer);
		var validationResult = leadValidator.Validate (leadContext);

		return (validationResult.IsValid, validationResult, twoCharacterCountryCode);
	}

	private static async Task<string?> getTwoCharacterCountryCodeAsync (
		IDynamoClient dynamoClient,
		string? countryCode
	) {
		if (string.IsNullOrEmpty (countryCode)) {
			return null;
		}

		var upperCode = countryCode.ToUpper ();

		// Check cache first
		lock (countrycachelock) {
			if (countrycache.TryGetValue (upperCode, out var cached)) {
				return cached.Two;
			}
		}

		var country3to2 = await dynamoClient.GetCountry3to2 (upperCode);

		if (country3to2 != null) {
			lock (countrycachelock) {
				countrycache[upperCode] = country3to2;
			}
			return country3to2.Two;
		}

		// Fallback logic
		return getCountryCodeFallback (countryCode.Trim ().ToUpper ());
	}

	private static readonly Dictionary<string, Country3to2> countrycache = [];
	private static readonly object countrycachelock = new ();

	private static string? getCountryCodeFallback (
		string countryCode
	) {
		if (countryCode.Length != 3) return null;

		return countryCode switch {
			"USA" => "US",
			"CAN" => "CA",
			"GBR" => "GB",
			"FRA" => "FR",
			"ESP" => "ES",
			"DEU" => "DE",
			_ => null
		};
	}
}

public class ApiResponse<T>
{
	public bool Success { get; set; }
	public string Message { get; set; } = string.Empty;
	public string? FullMessage { get; set; }
	public T? Data { get; set; }
	public int? StatusCode { get; set; }
	public List<string> Errors { get; set; } = new ();

	public static ApiResponse<T> IsSuccess (
		T data,
		string message = "Success"
	) {
		return new ApiResponse<T> { Success = true, Message = message, Data = data };
	}

	public static ApiResponse<T> IsFailure (
		string message,
		int? statusCode = null,
		string? fullMessage = null
	) {
		return new ApiResponse<T> {
			Success = false,
			Message = message,
			StatusCode = statusCode,
			FullMessage = fullMessage
		};
	}
}

// LeadDataCleaner, LeadTransfomer?
public class LeadDataProcessor
{
	public static void ProcessLeadData (
		Lead lead,
		Form form,
		HttpContext context
	) {
		ProcessCommonLeadData (lead, form, context);
	}

	public static void ProcessLeadData (
		PrivacyLead lead,
		Form form,
		HttpContext context
	) {
		ProcessCommonLeadData (lead, form, context);
		ProcessPrivacyLeadData (lead);
	}

	private static void ProcessCommonLeadData (
		Lead lead,
		Form form,
		HttpContext context
	) {
		// Normalize some values
		lead.LeadSource = lead.LeadSource.NullIfEmpty ();
		lead.Brand = lead.Brand.NullIfEmpty ();
		lead.CampaignId = lead.CampaignId.NullIfEmpty ();
		lead.EmailAddress = lead.EmailAddress.NullIfEmpty ();

		// Set default values from form
		lead.LeadSource ??= form.FormLeadSource;
		lead.Brand ??= form.MarketingBrand;
		lead.SourceType = form.FormSourceType;
		lead.FormType = form.FormType;
		lead.CampaignId ??= form.InboundExternalCampaignId;

		// Clean and format data
		lead.PhoneNumber = Utils.DeformatPhoneNumber (lead.PhoneNumber!);
		lead.EmailAddress = lead.EmailAddress!.Trim ().ToLower ();
		lead.FirstName = lead.FirstName!.Trim ();
		lead.LastName = lead.LastName!.Trim ();
		lead.CompanyName = lead.CompanyName!.Trim ();

		// Add request metadata
		AddRequestMetadata (lead, context);
	}

	private static void ProcessPrivacyLeadData (PrivacyLead privacyLead) {
		// Clean and trim PrivacyLead-specific fields
		privacyLead.Relationship = privacyLead.Relationship?.Trim ();
		privacyLead.Address = privacyLead.Address?.Trim ();

		// Add PrivacyLead-specific data to AdditionalData
		// if (!string.IsNullOrEmpty (privacyLead.Relationship)) {
		// 	privacyLead.AdditionalData.TryAdd ("Relationship", privacyLead.Relationship);
		// }
		// if (!string.IsNullOrEmpty (privacyLead.Address)) {
		// 	privacyLead.AdditionalData.TryAdd ("Address", privacyLead.Address);
		// }
	}

	private static void AddRequestMetadata (
		Lead lead,
		HttpContext context
	) {
		lead.AdditionalData.TryAdd ("requestingHost", context.Request.Host.Value);
		lead.AdditionalData.TryAdd ("requestingPath", context.Request.Path.Value ?? "");
	}
}


