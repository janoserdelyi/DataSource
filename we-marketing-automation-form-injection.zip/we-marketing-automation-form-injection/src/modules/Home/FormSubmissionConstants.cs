namespace WeMarketingAutomationFormInjection;

public static class FormSubmissionConstants
{
	public const int SUPPORTED_VERSION = 1;
	public const int MARKETING_CONTACT_ID = 1449;
	public const string DEMO_KILL_SWITCH_KEY = "demo-kill-switch";
}


