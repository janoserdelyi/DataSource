using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Security.Claims;
using System.Text;
using Amazon.Runtime.CredentialManagement;
using Amazon.IdentityManagement;
using Amazon.IdentityManagement.Model;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using WeMarketingAutomationFormInjection.Filters;

namespace WeMarketingAutomationFormInjection;

public class HealthCheckModule : CarterModule
{
	private readonly string templateDir;
	private readonly IConfiguration config;
	private readonly IWebHostEnvironment env;
	private readonly string EnvironmentName;
	private readonly IAmazonS3 amazonS3;
	private readonly IDynamoDBContext dynamoContext;
	private readonly IDynamoClient dynamoClient;
	private readonly IOpenSearchClient openSearchClient;
	private readonly IValkeyClient valkeyClient;

	public HealthCheckModule (
		IWebHostEnvironment env,
		IConfiguration config,
		IHttpClientFactory httpClientFactory,
		IAmazonS3 amazonS3,
		IDynamoDBContext dynamoContext,
		IDynamoClient dynamocClient,
		IOpenSearchClient openSearchClient,
		IValkeyClient valkeyClient
	) : base () {

		this.templateDir = Path.Combine (env.WebRootPath, "templates");
		this.config = config;
		this.env = env;
		this.EnvironmentName = env.SanitizedEnvironment ();
		this.amazonS3 = amazonS3;
		this.dynamoContext = dynamoContext;
		this.dynamoClient = dynamocClient;
		this.openSearchClient = openSearchClient;
		this.valkeyClient = valkeyClient;
	}

	public override void AddRoutes (
		IEndpointRouteBuilder app
	) {
		// health checks
		app.MapGet ("/health-check", getHealthCheck);
		app.MapGet ("/ping", () => "pong");
		app.MapGet ("/diag", (Delegate)getDiagnostics).AddEndpointFilter<PublicProductionFilter> ();
		app.MapGet ("/diag.json", (Delegate)getDiagnostics).AddEndpointFilter<PublicProductionFilter> ();
	}

	// https://dev.azure.com/costargroup/DotNetExtensions/_git/DotNetExtensions?path=%2FDiagnostics.HealthChecks.AspNetCore
	// output format based on https://costar-group-prod-dev.atlassian.net/wiki/spaces/EFPT/pages/203461571/Health+Check+Extension
	private async Task getHealthCheck (
		HttpContext ctx
	) {
		ctx.Response.ContentType = "application/health+json";

		const string GOOD = "Healthy";
		const string BAD = "Unhealthy";

		bool overallHhealthy = true;
		bool s3Healthy = false;
		string s3Reason = "success";
		bool dynamoHealthy = false;
		string dynamoReason = "success";
		bool openSearchHealthy = false;
		string openSearchReason = "success";
		bool valkeyHealthy = false;
		string valkeyReason = "success";

		var sw = new System.Diagnostics.Stopwatch ();

		sw.Start ();
		// verify s3 access
		try {
			var keyrequest = new ListObjectsV2Request () {
				BucketName = config.GetSection ("AwsS3Bucket").Get<string> (),
				MaxKeys = 10
			};

			var keyresponse = await amazonS3.ListObjectsV2Async (keyrequest);

			// i don't need to do anything with the values. just not throw an exception
			s3Healthy = true;
		} catch (Exception oops) {
			s3Reason = oops.Message;
			overallHhealthy = false;
		}
		sw.Stop ();
		var s3sw = sw.Elapsed;

		sw.Restart ();
		try {
			var test = await dynamoClient.GetForm ("marketingcloudformonly", "en-US");

			// i don't need to do anything with the values. just not throw an exception
			dynamoHealthy = true;
		} catch (Exception oops) {
			dynamoReason = oops.Message;
			overallHhealthy = false;
		}
		sw.Stop ();
		var dynamosw = sw.Elapsed;

		sw.Restart ();
		try {
			var test = await openSearchClient.IsRealPostalCode ("USA", "23114");

			// i don't need to do anything with the values. just not throw an exception
			openSearchHealthy = true;
		} catch (Exception oops) {
			openSearchReason = oops.Message;
			overallHhealthy = false;
		}
		sw.Stop ();
		var opensearchsw = sw.Elapsed;

		sw.Restart ();
		try {
			var setvalkey = await valkeyClient.SetString ("janos", "test", expiry: new TimeSpan (0, 0, 10));
			var getvalkey = await valkeyClient.GetString ("janos");

			valkeyHealthy = true;
		} catch (Exception oops) {
			valkeyReason = oops.Message;
			overallHhealthy = false;
		}
		sw.Stop ();
		var valkeysw = sw.Elapsed;


		ctx.Response.StatusCode = overallHhealthy ? 200 : 503;

		await ctx.Response.AsJson (new {
			Status = overallHhealthy ? GOOD : BAD,
			HealthChecks = new object[] {
				new {
					Component = "AWS S3 Read",
					Status = s3Healthy ? GOOD : BAD,
					Reason = s3Reason,
					Desc = "AWS S3 read access",
					Duration = s3sw.ToString("G")
				},
				new {
					Component = "DynamoDB Read",
					Status = dynamoHealthy? GOOD : BAD,
					Reason = dynamoReason,
					Desc = "DynamoDB read access",
					Duration = dynamosw.ToString("G")
				},
				new {
					Component = "OpenSearch Read",
					Status = openSearchHealthy? GOOD : BAD,
					Reason = openSearchReason,
					Desc = "OpenSearch read access",
					Duration = opensearchsw.ToString("G")
				},
				new {
					Component = "Valkey Read/Write",
					Status = valkeyHealthy? GOOD : BAD,
					Reason = valkeyReason,
					Desc = "Valkey read and write access",
					Duration = valkeysw.ToString("G")
				}
			}
		});
	}

	private async Task getDiagnostics (
		HttpContext ctx,
		IValkeyClient valkey
	) {
		var diaginstance = new Models.Diagnostics.Instance (
			Program.StartTime,
			env,
			ctx,
			amazonS3,
			config
		);

		if (string.IsNullOrEmpty (ctx.Request.Path.Value) == false && ctx.Request.Path.Value.EndsWith (".json")) {
			await ctx.Response.Negotiate<Models.Diagnostics.Instance> (diaginstance);
			return;
		}

		var sb = new StringBuilder ();
		sb.AppendLine ($"Instance start time : {diaginstance.StartTime.ToString ()}");
		sb.AppendLine ($"Instance current time : {diaginstance.CurrentTime.ToString ()}");
		sb.AppendLine ($"Instance up time : {diaginstance.Uptime.ToString ()}");
		sb.AppendLine ();

		// attempt to write out the current AWS role being used
		sb.AppendLine ("AWS Credential store : ");
		try {
			var chain = new CredentialProfileStoreChain ();
			if (chain.ListProfiles () != null && chain.ListProfiles ().Count > 0) {
				foreach (var profile in chain.ListProfiles ()) {
					sb.AppendLine (profile.Name);
				}
			} else {
				sb.AppendLine ("no profiles found in the credential profile store chain");
			}
		} catch (Exception oops) {
			sb.AppendLine ("Error retrieving credential store");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();

		try {
			sb.AppendLine ($"AWS Region : {amazonS3.Config.RegionEndpoint.SystemName}");
			sb.AppendLine ();
		} catch (Exception oops) {
			sb.AppendLine ("Error retrieving current AWS region");
			sb.AppendLine (oops.ToString ());
		}

		if (env.IsLocal () == false) {
			sb.AppendLine ("Current AWS Role maybe? : ");
			try {
				var iamClient = new AmazonIdentityManagementServiceClient ();

				if (iamClient == null) {
					sb.AppendLine ("unable to retrieve IAM client");
				} else {
					sb.AppendLine ($"{iamClient}");

					if (iamClient.Config != null && iamClient.Config.Profile != null) {
						sb.AppendLine ($"config profile name : {iamClient.Config.Profile.Name}");
					}

					GetUserResponse? userResponse = null;

					try {
						userResponse = await iamClient.GetUserAsync ();
					} catch (Exception oops) {
						sb.AppendLine ($"Error getting user response : {oops.Message}");
					}

					if (userResponse == null) {
						sb.AppendLine ("unable to retrieve current user");
					} else {
						if (userResponse.User == null) {
							sb.AppendLine ("unable to retrieve current user User object");
						} else {
							sb.AppendLine ($"current user ToString() : {userResponse.User.ToString ()}");
							sb.AppendLine ($"current user ARN : {userResponse.User.Arn}");
							sb.AppendLine ($"current user Username : {userResponse.User.UserName}");
							sb.AppendLine ($"current user Id : {userResponse.User.UserId}");
						}
					}
				}

				// var listPoliciesPaginator = iamClient.Paginators.ListPolicies (new ListPoliciesRequest ());
				// var policies = new List<ManagedPolicy> ();

				// await foreach (var response in listPoliciesPaginator.Responses) {
				// 	policies.AddRange (response.Policies);
				// }

				// sb.AppendLine ("Here are the policies defined for your account:\n");
				// policies.ForEach (policy => {
				// 	sb.AppendLine ($"Created: {policy.CreateDate}\t{policy.PolicyName}\t{policy.Description}");
				// });
			} catch (Amazon.IdentityManagement.AmazonIdentityManagementServiceException oops) {
				var match = System.Text.RegularExpressions.Regex.Match (oops.Message, "(?<stuff>arn\\:[^\\s]+)");
				if (match.Success && match.Groups["stuff"] != null) {
					sb.AppendLine (match.Groups["stuff"].Value);
				} else {
					sb.AppendLine ("Unknown");
				}
			} catch (Exception oops) {
				sb.AppendLine ("Error retrieving current AWS role");
				sb.AppendLine (oops.ToString ());
			}
			sb.AppendLine ();
		}

		sb.AppendLine ($"Machine Name : {diaginstance.Machine.MachineName}");
		sb.AppendLine ($"Processor Count : {diaginstance.Machine.ProcessorCount}");
		sb.AppendLine ($"System Page Size : {diaginstance.Machine.SystemPageSize}");
		sb.AppendLine ($"Working Set : {diaginstance.Machine.WorkingSet}");
		sb.AppendLine ($".Net version : {diaginstance.Environment.DotnetVersion}");
		sb.AppendLine ($"Runtime version : {diaginstance.Environment.FrameworkDescription}");
		sb.AppendLine ($"OS Description : {diaginstance.Environment.OsDescription}");
		sb.AppendLine ($"Environment Name : {diaginstance.Environment.Name}");
		sb.AppendLine ($"Is production? {(diaginstance.Environment.IsProduction ? "yes" : "no")}");
		sb.AppendLine ($"Environment WebRootPath : {diaginstance.Environment.WebRootPath}");
		sb.AppendLine ($"Current culture Ietf Language Tag : {diaginstance.Culture.IetfLanguageTag}");
		sb.AppendLine ($"System.Globalization.CultureInfo.CurrentCulture : {diaginstance.Culture.CurrentCulture}");
		sb.AppendLine ($"System.Threading.Thread.CurrentThread.CurrentCulture : {diaginstance.Culture.ThreadCulture}");
		sb.AppendLine ($"ctx.GetCurrentCulture () : {diaginstance.Culture.ContextCulture}");
		sb.AppendLine ($"Accept-Language header : {diaginstance.Culture.AcceptLanguageHeader}");
		sb.AppendLine ($"Utils.GetLocaleCd (...) : {diaginstance.Culture.GetLocaleCode}");
		sb.AppendLine ();

		sb.AppendLine ($"Requesting IP Address : {diaginstance.Request.Address}");
		sb.AppendLine ($"Requesting User-Agent : {diaginstance.Request.UserAgent}");
		sb.AppendLine ($"Requesting Hostname : {diaginstance.Request.Hostname}");
		sb.AppendLine ();
		sb.AppendLine ("Request headers : ");
		foreach (var header in diaginstance.Request.Headers) {
			sb.AppendLine ($"\tHeader: {header.Key}: {header.Value}");
		}
		sb.AppendLine ();
		sb.AppendLine ("Response headers : ");
		foreach (var header in ctx.Response.Headers) {
			sb.AppendLine ($"\tHeader: {header.Key}: {header.Value}");
		}
		sb.AppendLine ();

		// enumerate the files in /vault/secrets
		if (diaginstance.Environment.VaultSecretKeys.Count == 0) {
			sb.AppendLine ("no /vault/secrets found");
		} else {
			sb.AppendLine ("vault secrets found : ");
			foreach (var secret in diaginstance.Environment.VaultSecretKeys) {
				sb.AppendLine (secret);
			}
		}
		sb.AppendLine ();

		try {
			var token = Utils.CreateRsaJwt (
			"2dfa028d8478164fd111897044b728fbe2f4a914",
			DateTime.UtcNow.AddMinutes (5),
			claims: [
				new Claim(ClaimTypes.Name, "Janos Erdelyi"),
				new Claim(ClaimTypes.Role, "admin")
			]
		);
			sb.AppendLine ("Example JWT : " + token);
		} catch (Exception oops) {
			sb.AppendLine ("Error generating JWT : ");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();

		var keyrequest = new ListObjectsV2Request () {
			BucketName = config.GetSection ("AwsS3Bucket").Get<string> (),
			MaxKeys = 10
		};

		try {
			var keyresponse = await amazonS3.ListObjectsV2Async (keyrequest);

			if (keyresponse == null || keyresponse.S3Objects == null || keyresponse.S3Objects.Count == 0) {
				sb.AppendLine ("no objects found");
			} else {
				sb.AppendLine ("top 10 objects found : ");
				foreach (var key in keyresponse.S3Objects) {
					sb.AppendLine (key.Key);
				}
			}
		} catch (Exception oops) {
			sb.AppendLine ("error testing out S3");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();

		// let's try a raw client
		// try {
		// 	var raws3client = new AmazonS3Client ();

		// 	var keyresponse = await raws3client.ListObjectsV2Async (keyrequest);

		// 	if (keyresponse == null || keyresponse.S3Objects == null || keyresponse.S3Objects.Count == 0) {
		// 		sb.AppendLine ("no objects found");
		// 	} else {
		// 		sb.AppendLine ("top 10 objects found : ");
		// 		foreach (var key in keyresponse.S3Objects) {
		// 			sb.AppendLine (key.Key);
		// 		}
		// 	}
		// } catch (Exception oops) {
		// 	sb.AppendLine ("error testing out raw S3 client");
		// 	sb.AppendLine (oops.ToString ());
		// }
		// sb.AppendLine ();

		// let's see if valkey is working!
		sb.AppendLine ("valkey set 'janos':'test' : ");
		try {
			var setvalkey = await valkey.SetString ("janos", "test");
			sb.AppendLine ($"valkey.SetString worked? {setvalkey}");
		} catch (Exception oops) {
			sb.AppendLine ($"valkey.SetString failed : {oops.ToString ()}");
		}
		sb.AppendLine ("valkey get 'janos' : ");
		try {
			var getvalkey = await valkey.GetString ("janos");
			sb.AppendLine ($"valkey.GetString = {getvalkey}");
		} catch (Exception oops) {
			sb.AppendLine ($"valkey.GetString failed : {oops.ToString ()}");
		}
		sb.AppendLine ();


		sb.AppendLine ("template cache pool : ");
		var templateCacheItems = Utils.GetTemplateCache ();

		if (templateCacheItems == null) {
			sb.AppendLine ("templateCache is null");
		} else if (templateCacheItems.Count == 0) {
			sb.AppendLine ("templateCache has zero items");
		} else {
			foreach (var templateCache in templateCacheItems) {
				sb.AppendLine ($"    {templateCache.Key} expires {templateCache.Value.CacheTill} content length : {(templateCache.Value.CacheContent == null ? "null content" : templateCache.Value.CacheContent.Length)} etag : {templateCache.Value.ETag}");
			}
		}
		sb.AppendLine ();

		sb.AppendLine ("translation cache pool : ");
		var translationCacheItems = TranslationManager.GetTemplateCache ();

		if (translationCacheItems == null) {
			sb.AppendLine ("translationCache is null");
		} else if (translationCacheItems.Count == 0) {
			sb.AppendLine ("translationCache has zero items");
		} else {
			foreach (var translationCacheItem in translationCacheItems) {
				sb.AppendLine ($"    {translationCacheItem.Key}");
			}
		}
		sb.AppendLine ();


		// try {
		// 	var conf = new DynamoDBOperationConfig () {
		// 		OverrideTableName = "we-marketing-automation-form-injection-api-form-dvm"
		// 	};

		// 	Models.Form? form = await dynamoContext.LoadAsync<Models.Form> ("marketingcloudformonly", "en-US", conf);

		// 	sb.AppendLine ("DynamoDb context is functioning.");
		// 	sb.AppendLine ($"Cd/Locale : {form.Cd}/{form.Locale} , Name : {form.Name}, Script template : {form.FormTemplatePath}");

		// 	Console.WriteLine ();
		// } catch (Exception oops) {
		// 	sb.AppendLine ("error testing out dynamoDb context");
		// 	sb.AppendLine (oops.ToString ());
		// }
		// sb.AppendLine ();

		// string? scriptContents = Utils.GetTemplateContents (
		// 	"s3://us-east-1--api-ma-platform-services-dvm/form-injection/forms/standard-lead-form",
		// 	false,
		// 	amazonS3
		// );
		// sb.AppendLine ("GetTemplateContents : ");
		// sb.AppendLine (scriptContents);
		// sb.AppendLine ();

		// dvm
		(string formcd, string formlocale) testform = ("bimmocontact", "fr-FR");

		if (env.IsTest ()) {
			testform = ("loopnetspanishtest", "es-ES");
		}
		if (env.IsProduction ()) {
			testform = ("lnukawu", "en-GB");
		}

		try {
			var form = await dynamoClient.GetForm (testform.formcd, testform.formlocale);

			if (form != null) {
				sb.AppendLine ("DynamoDb client is functioning.");
				sb.AppendLine ($"Cd/Locale : {form.Cd}/{form.Locale} , Name : {form.Name}, Script template : {form.FormTemplatePath}");
			} else {
				sb.AppendLine ("form not found in DynamoDb");
			}

			Console.WriteLine ();
		} catch (Exception oops) {
			sb.AppendLine ("error testing out dynamoDb client");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();

		try {
			var char3s = new string[] { "USA", "CAN", "GBR", "ESP", "DEU", "FRA" };
			foreach (var char3 in char3s) {
				sb.AppendLine ($"{char3} = {dynamoClient.GetCountry3to2 (char3).Result?.Two}");
			}

		} catch (Exception oops) {
			sb.AppendLine ("error getting two-character country code out dynamoDb client");
			sb.AppendLine (oops.ToString ());
		}


		try {
			sb.AppendLine ("OpenSearch Client tests : ");
			var goodPostal = await openSearchClient.IsRealPostalCode ("USA", "23114");
			var badPostal = await openSearchClient.IsRealPostalCode ("USA", "23100");

			sb.AppendLine ($"USA, 23114 is a real postal code ? {goodPostal} (should be true)");
			sb.AppendLine ($"USA, 23100 is a real postal code ? {badPostal} (should be false)");

			Console.WriteLine ();
		} catch (Exception oops) {
			sb.AppendLine ("error testing out OpenSearch client");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();


		// some networking info
		try {
			sb.AppendLine ("Live reading of current network interface DNS servers : ");
			NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces ();
			foreach (NetworkInterface adapter in adapters) {

				IPInterfaceProperties adapterProperties = adapter.GetIPProperties ();
				IPAddressCollection dnsServers = adapterProperties.DnsAddresses;
				if (dnsServers.Count > 0) {
					sb.AppendLine (adapter.Description);
					foreach (IPAddress dns in dnsServers) {
						sb.AppendLine ($"  DNS Servers ............................. : {dns}");
					}
				}
			}
		} catch (Exception oops) {
			sb.AppendLine ("Error getting network interfaces : ");
			sb.AppendLine (oops.ToString ());
		}
		sb.AppendLine ();

		sb.AppendLine ("Startup cached reading of DNS servers");
		if (Program.DnsServers.Count == 0) {
			sb.AppendLine ("Error! none found!");
		} else {
			foreach (var dns in Program.DnsServers) {
				sb.AppendLine (dns);
			}
		}
		sb.AppendLine ();

		sb.AppendLine ("Allowed IP's to hit protected endpoints (A records derived from CORS list)");
		if (Program.AllowedIps == null || Program.AllowedIps.Count == 0) {
			sb.AppendLine ("PROBLEM! no ip addresses found");
		} else {
			foreach (var ip in Program.AllowedIps.Keys) {
				sb.AppendLine (ip.ToString ());
			}
		}
		sb.AppendLine ();

		try {
			sb.AppendLine ("All good domains in the last month");
			var bpdomains = await dynamoClient.GetAllGoodDomainsSince (DateTimeOffset.Now.AddMonths (-1));
			foreach (var bpdomain in bpdomains) {
				sb.AppendLine (bpdomain.Domain.PadRight (60, '.') + bpdomain.Timestamp);
			}
			sb.AppendLine ();
		} catch (Exception oops) {
			sb.AppendLine ($"error getting good domains : {oops.ToString ()}");
		}
		sb.AppendLine ();

		try {
			sb.AppendLine ("All bad domains in the last month");
			var bpdomains = await dynamoClient.GetAllBadDomainsSince (DateTimeOffset.Now.AddMonths (-1));
			foreach (var bpdomain in bpdomains) {
				sb.AppendLine (bpdomain.Domain.PadRight (60, '.') + bpdomain.Timestamp);
			}
			sb.AppendLine ();
		} catch (Exception oops) {
			sb.AppendLine ($"error getting bad domains : {oops.ToString ()}");
		}
		sb.AppendLine ();

		try {
			if (env.IsLocal ()) {
				sb.AppendLine ("i18n directories and files : ");
				enumerateDirectory (Path.Combine (env.WebRootPath, "i18n"), sb);
			} else {
				sb.AppendLine ("i18n directories and files in /tmp");
				enumerateDirectory ("/tmp/i18n", sb);
			}
		} catch (Exception oops) {
			sb.AppendLine ("error enumerating i18n files : ");
			sb.AppendLine (oops.ToString ());
		}

		sb.AppendLine ();

		await ctx.Response.WriteAsync (sb.ToString ());
	}

	private static void enumerateDirectory (
		string dirRoot,
		StringBuilder sb
	) {

		// Get information about the source directory
		var dir = new DirectoryInfo (dirRoot);

		// Check if the source directory exists
		if (!dir.Exists) {
			throw new DirectoryNotFoundException ($"Source directory not found: {dir.FullName}");
		}

		// Cache directories before we start copying
		DirectoryInfo[] dirs = dir.GetDirectories ();

		// Get the files in the source directory and copy to the destination directory
		foreach (FileInfo file in dir.GetFiles ()) {
			sb.AppendLine (Path.Combine (dirRoot, file.Name));
		}

		foreach (DirectoryInfo subDir in dirs) {
			string newDestinationDir = Path.Combine (dirRoot, subDir.Name);
			enumerateDirectory (subDir.FullName, sb);
		}

	}
}
