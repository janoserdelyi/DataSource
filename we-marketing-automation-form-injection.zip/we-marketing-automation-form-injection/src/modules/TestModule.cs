using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using MailVerifier;
using Newtonsoft.Json;
using WeMarketingAutomationFormInjection.Filters;
using Amazon.IdentityManagement.Model.Internal.MarshallTransformations;
using WeMarketingAutomationFormInjection.Models;

namespace WeMarketingAutomationFormInjection;

public class TestModule : CarterModule
{
	private readonly string templateDir;
	private readonly IWebHostEnvironment env;
	private readonly IConfiguration config;
	public required string EnvironmentName;
	private readonly IAmazonS3 s3client;
	private readonly IDynamoClient dynamoClient;

	public TestModule (
		IWebHostEnvironment env,
		IConfiguration config,
		IAmazonS3 s3client,
		IDynamoClient dynamocClient
	) : base () {

		templateDir = Path.Combine (env.WebRootPath, "templates");
		this.config = config;
		EnvironmentName = env.SanitizedEnvironment ();
		this.env = env;
		this.s3client = s3client;
		this.dynamoClient = dynamocClient;
	}

	public override void AddRoutes (
		IEndpointRouteBuilder app
	) {

		var testgroup = app.MapGroup ("/test").AddEndpointFilter<PublicProductionFilter> ();
		var tempgroup = app.MapGroup ("/temp").AddEndpointFilter<PublicProductionFilter> ();
		var managegroup = app.MapGroup ("/manage").AddEndpointFilter<PublicProductionFilter> ();

		// a test page to inject into
		testgroup.MapGet ("/{pageidentifier}", getTestPage);

		testgroup.MapGet ("/createmarketinglead", getTestCreateMarketingLead)
			.ExcludeFromDescription ();
		testgroup.MapGet ("/changesegmentpreference/{brand}/{segmentid:int}/{opt:bool}", getTestSetSegmentOpt);
		testgroup.MapGet ("/checkpostal/{countrycode}/{postalcode}", getTestPostalCode);
		testgroup.MapGet ("/country/threetotwo/{countrycode}", getTestCountryCodeThreeToTwo);

		tempgroup.MapGet ("/mxcheck/{domain}", getMxCheck);
		// //.WithName ("MX check a domain")
		// .WithTags ("diagnostics")
		// .WithSummary ("DNS MX check a domain")
		// .WithDescription ("Ensure that a mailer domain actually has MX records")
		// .WithOpenApi (operation => new OpenApiOperation (operation) {
		// 	Parameters = new List<OpenApiParameter> {
		// 		new OpenApiParameter {
		// 			Name = "domain",
		// 			In = ParameterLocation.Path,
		// 			Required = true,
		// 			Schema = new OpenApiSchema { Type = "string" },
		// 			Description = "domain to check"
		// 		}
		// 	}
		// });
		tempgroup.MapGet ("/emailcheck/{address}", getFullEmailCheck);
		tempgroup.MapGet ("/emaildomains/bad/add/{domain}", getAddDomainToBadList);
		tempgroup.MapGet ("/emaildomains/bad/remove/{domain}", getRemoveDomainFromBadList);
		tempgroup.MapGet ("/emaildomains/bad/testall", getRetestAllBadDomains);
		tempgroup.MapGet ("/emaildomains/bad/retest/{domain}", getRetestBadDomain);

		// i want to pound a bunch of emails through the validation system to load up dynamo so that i can test its pagination. local only
		tempgroup.MapGet ("/emailtest/load", getLoadEmailTest).ExcludeFromDescription ();
		// do the same for the DVM dynamo request log
		// tempgroup.MapGet ("/dynamodb/requestlog/load", getLoadRequestLog).ExcludeFromDescription ();

		tempgroup.MapGet ("/translations/regenerate", getRegenerateAllTranslations);
		tempgroup.MapGet ("/translations/regenerate/{locale}", getRegenerateTranslation);
		tempgroup.MapGet ("/translations/get/{locale}", getMachineLocale);
		tempgroup.MapGet ("/fake", () => "There's no place like 127.0.0.1").RequireAuthorization ("is_admin");

		// temp. only because i don't have rights in those envs as my own user
		// i want to push the standard-lead-form.js file into s3 in tsm
		// these are no longer needed since i have management endpoints
		//tempgroup.MapGet ("/s3push", (Delegate)getS3Push);
		tempgroup.MapGet ("/countries/load", getLoadCountries).ExcludeFromDescription ();
		tempgroup.MapGet ("/postalcodes/load", getLoadPostalCodes).ExcludeFromDescription ();

		// test the RDS postgresql database. mssql in the dmz too while i'm at it
		tempgroup.MapGet ("/database/postgresql", getPostgresqlTest);
		tempgroup.MapGet ("/database/mssql", getMssqlTest);

		managegroup.MapGet ("/api/v{version:int}/dynamodb/{tablename}", getDynamoTableContents);
		managegroup.MapPost ("/api/v{version:int}/dynamodb/form", submitDynamoForm);
		managegroup.MapDelete ("/api/v{version:int}/dynamodb/form", deleteDynamoForm);

		// managegroup.MapGet ("/api/v{version:int}/dynamodb/requestlog/{formcd}/{locale}/{sincedt:datetime}", getRequestLogsSince); // note i could have used getDynamoTableContents, but i didn't want to play a bunch of detection games on which aparams were being passed in
		managegroup.MapGet ("/api/v{version:int}/opensearch/requestlog/{formcd}/{locale}/{sincedt:datetime}", getLogFormRequestsSince);

		managegroup.MapDelete ("/api/v{version:int}/dynamodb/{domain}/{statuscd}", deleteDynamoDomain);

		managegroup.MapGet ("/api/v{version:int}/s3/{category}/{key}", getS3);
		managegroup.MapPost ("/api/v{version:int}/s3", submitS3);
		managegroup.MapDelete ("/api/v{version:int}/s3/{project}/{keypath}/{keyname}", deleteS3);

		managegroup.MapGet ("/api/v{version:int}/templateCache/flush", getTemplateCacheFlush);

		// just a test for something like an Article 14 page
		app.MapGet ("/article14", getArticle14)
			//.WithName ("article14")
			.RequireRateLimiting (Program.RATE_LIMIT_POLICY_NAME);

		// TODO : internal-only facing kill switch to stop submission requests for demo (and likely one for regular forms)
		// store a value in valkey and watch for it
		// take a time in minutes to block. 0 minutes = clear the value

		// directly get form script template contents
		tempgroup.MapGet ("/form/{formcd}", getFormTemplateContents);
	}

	private async Task getFormTemplateContents (
		HttpContext ctx,
		string formcd
	) {

		string envAcronym = getEnvironmentShortWord (EnvironmentName);

		string pathTemplate = $"s3://us-east-1--api-ma-platform-services-{envAcronym}/form-injection/forms/{formcd}";

		string? scriptContents = Utils.GetTemplateContents (
			pathTemplate,
			false,
			s3client
		);

		if (scriptContents == null) {
			await ctx.Response.WriteAsync ("contents not found");
			return;
		}

		ctx.Response.StatusCode = 200;
		ctx.Response.ContentType = "text/javascript";
		await ctx.Response.WriteAsync (scriptContents);
	}


	private async Task getArticle14 (
		HttpContext ctx,
		LinkGenerator linkgen
	) {
		var sb = new StringBuilder ();

		sb.AppendLine ($"PathBase : {ctx.Request.PathBase}, Path : {ctx.Request.Path}");
		sb.AppendLine ($"Link : {linkgen.GetPathByName (ctx, "article14", values: null)}");

		await ctx.Response.WriteAsync (sb.ToString ());
	}

	private async Task getTemplateCacheFlush (
		HttpContext ctx,
		int version
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		Utils.FlushTemplateCache ();

		await ctx.Response.WriteAsync ("FlushTemplateCache called");
	}

	private async Task deleteS3 (
		IAmazonS3 s3client,
		HttpContext ctx,
		int version,
		string project,
		string keypath,
		string keyname
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string key = $"{project}/{keypath}/{keyname}";

		string envAcronym = getEnvironmentShortWord (EnvironmentName);

		string bucketName = $"us-east-1--api-ma-platform-services-{envAcronym}";

		try {
			var deleteobject = await s3client.DeleteObjectAsync (new Amazon.S3.Model.DeleteObjectRequest () {
				BucketName = bucketName,
				Key = key
			});
		} catch (Exception oops) {
			await ctx.Response.AsJson (new { Success = false, Message = $"Error uploading file : {oops.Message}" });
			return;
		}

		await ctx.Response.AsJson (new { Success = true, Message = "Success" });
	}

	private async Task getS3 (
		IAmazonS3 s3client,
		HttpContext ctx,
		int version,
		string category,
		string key
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string filepath = $"s3://{config.GetSection ("AwsS3Bucket").Get<string> ()}/form-injection/{category}/{key}";

		string? fileContents = null;

		try {
			fileContents = Utils.GetTemplateContentsFromS3 (s3client, filepath, reduceContent: false);
		} catch (ArgumentOutOfRangeException) {
			fileContents = null;
		}

		if (fileContents == null) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string contentType = "text/plain";

		switch (category) {
			case "js":
			case "forms":
				contentType = "text/javascript";
				break;
			case "css":
				contentType = "text/css";
				break;
		}

		ctx.Response.StatusCode = 200;
		ctx.Response.ContentType = contentType;
		await ctx.Response.WriteAsync (fileContents);
	}

	private async Task submitS3 (
		IAmazonS3 s3client,
		HttpContext ctx,
		int version
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		var file = await ctx.Request.BindFile ();

		if (file == null) {
			await ctx.Response.AsJson (new { Success = false, Message = $"no file submitted" });
			return;
		}

		if (file.Length == 0) {
			await ctx.Response.AsJson (new { Success = false, Message = $"empty file submitted" });
			return;
		}

		var form = ctx.Request.Form;

		if (form == null || form.Count == 0) {
			await ctx.Response.AsJson (new { Success = false, Message = $"the form collection is empty. expected : 'key=s3KeyValue'" });
			return;
		}

		if (form.ContainsKey ("key") == false) {
			await ctx.Response.AsJson (new { Success = false, Message = $"the form collection is missing the key 'key'. expected : 'key=s3KeyValue'" });
			return;
		}

		if (string.IsNullOrEmpty (form["key"])) {
			await ctx.Response.AsJson (new { Success = false, Message = $"the form collection's 'key' is missing a value. expected : 'key=s3KeyValue'" });
			return;
		}

		string fileKey = form["key"]!;

		string envAcronym = getEnvironmentShortWord (EnvironmentName);

		string bucketName = $"us-east-1--api-ma-platform-services-{envAcronym}";

		var memstream = new MemoryStream ();

		try {
			await file.CopyToAsync (memstream);

			var putobject = await s3client.PutObjectAsync (new Amazon.S3.Model.PutObjectRequest () {
				BucketName = bucketName,
				InputStream = memstream,
				Key = fileKey,
				ContentType = file.ContentType
			});
		} catch (Exception oops) {
			await ctx.Response.AsJson (new { Success = false, Message = $"Error uploading file : {oops.Message}" });
			return;
		} finally {
			memstream.Close ();
		}

		await ctx.Response.AsJson (new { Success = true, Message = "Success" });
	}

	private async Task deleteDynamoDomain (
		IDynamoClient dynamoClient,
		HttpContext ctx,
		int version,
		string domain,
		string statuscd
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		try {
			await dynamoClient.DeleteDomain (domain, statuscd);
			await ctx.Response.AsJson (new { Success = true, Message = $"domain '{domain}' '{statuscd}' deleted" });
			return;
		} catch (Exception oops) {
			await ctx.Response.AsJson (new { Success = false, Message = $"Error deleting domain data : {oops.Message}" });
			return;
		}
	}

	private async Task deleteDynamoForm (
		IDynamoClient dynamoClient,
		HttpContext ctx,
		int version
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string? formcd = ctx.Request.Query.As<string> ("cd");
		string? locale = ctx.Request.Query.As<string> ("locale");

		if (string.IsNullOrEmpty (formcd) || string.IsNullOrEmpty (locale)) {
			await ctx.Response.AsJson (new { Success = false, Message = $"'cd' and 'locale' values are required in the querystring" });
			return;
		}

		try {
			await dynamoClient.DeleteForm (formcd, locale);
			await ctx.Response.AsJson (new { Success = true, Message = $"form '{formcd}' '{locale}' deleted" });
			return;
		} catch (Exception oops) {
			await ctx.Response.AsJson (new { Success = false, Message = $"Error deleting form data : {oops.Message}" });
			return;
		}
	}

	private async Task submitDynamoForm (
		IDynamoClient dynamoClient,
		HttpContext ctx,
		int version,
		Models.Form form
	) {
		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		try {
			await dynamoClient.UpsertForm (form);
			await ctx.Response.AsJson (new { Success = true, Message = $"form '{form.Cd}' '{form.Locale}' added/updated" });
			return;
		} catch (Exception oops) {
			await ctx.Response.AsJson (new { Success = false, Message = $"Error updating form data : {oops.Message}" });
			return;
		}
	}

	private async Task getDynamoTableContents (
		IDynamoClient dynamoClient,
		HttpContext ctx,
		int version,
		string tablename
	) {

		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		// query string info will be specific to the table to narrow the query
		switch (tablename) {
			case "form":
				string? formcd = ctx.Request.Query.As<string> ("cd");
				string? locale = ctx.Request.Query.As<string> ("locale");

				if (string.IsNullOrEmpty (formcd) || string.IsNullOrEmpty (locale)) {
					await ctx.Response.AsJson (new { Success = false, Message = $"'cd' and 'locale' values are required in the querystring" });
					return;
				}

				var form = await dynamoClient.GetForm (formcd, locale);

				if (form == null) {
					await ctx.Response.AsJson (new { Success = false, Message = $"no form found for {formcd} {locale}" });
					return;
				}

				await ctx.Response.AsJson (new { Success = true, Message = "Success", Form = form });
				return;
			case "requestlog":

				break;
		}

		await ctx.Response.AsJson (new { Success = false, Message = $"unknown dynamodb table {tablename}" });
	}

	// private async Task getRequestLogsSince (
	// 	IDynamoClient dynamoClient,
	// 	HttpContext ctx,
	// 	int version,
	// 	string formcd,
	// 	string locale,
	// 	DateTime sincedt
	// ) {

	// 	if (version != 1) {
	// 		ctx.Response.StatusCode = 404;
	// 		return;
	// 	}

	// 	string? method = ctx.Request.Query.As<string> ("method");

	// 	List<Models.DynamoDb.FormRequestLog>? logs = null;

	// 	if (string.IsNullOrEmpty (method)) {
	// 		logs = await dynamoClient.GetAllFormRequestLogSince (formcd, locale, sincedt);
	// 	} else {
	// 		logs = await dynamoClient.GetAllFormRequestLogSince (formcd, locale, sincedt, method);
	// 	}

	// 	await ctx.Response.AsJson (new { Success = true, Message = "Success", Logs = logs });
	// }

	private async Task getLogFormRequestsSince (
		IOpenSearchClient opensearchClient,
		HttpContext ctx,
		int version,
		string formcd,
		string locale,
		DateTime sincedt
	) {

		if (version != 1) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string? method = ctx.Request.Query.As<string> ("method");

		List<Models.FormLogRecord>? logs = null;

		if (string.IsNullOrEmpty (method)) {
			logs = await opensearchClient.GetAllFormRequestLogSince (formcd, locale, sincedt);
		} else {
			logs = await opensearchClient.GetAllFormRequestLogSince (formcd, locale, sincedt, method);
		}

		await ctx.Response.AsJson (new { Success = true, Message = "Success", Logs = logs });
	}

	private async Task getTestPostalCode (
		IOpenSearchClient openSearchClient,
		HttpContext ctx,
		string countryCode,
		string postalCode
	) {
		bool checkIt = await openSearchClient.IsRealPostalCode (countryCode, postalCode);

		if (checkIt) {
			await ctx.Response.WriteAsync ($"{countryCode} {postalCode} exists!");
			return;
		}

		await ctx.Response.WriteAsync ($"{countryCode} {postalCode} does not exist");
	}

	private async Task getTestCountryCodeThreeToTwo (
		IDynamoClient dynamoClient,
		HttpContext ctx,
		string countryCode
	) {
		var char2 = await dynamoClient.GetCountry3to2 (countryCode.ToUpper ());

		if (char2 == null) {
			await ctx.Response.WriteAsync ($"No two-letter country code found for {countryCode}");
			return;
		}

		await ctx.Response.WriteAsync ($"{countryCode} = {char2.Two}");
	}

	private async Task getTestSetSegmentOpt (
		IHttpClientFactory httpClientFactory,
		HttpContext ctx,
		string brand,
		int segmentid,
		bool opt
	) {

		var emailpref = new Models.EmailPreference () {
			EmailAddress = "jerdelyi@costar.com",
			CountryCode = "USA",
			Brand = [brand],
			OptIntoSegments = new List<Models.MarketingBrandSegmentPreference> {
				{new Models.MarketingBrandSegmentPreference(){
					MarketingBrandSegmentId = segmentid,
					OptIn = opt
				}}
			}
		};

		var httpClient = httpClientFactory.CreateClient ();

		var endpoint = config.GetSection ("EmailPreferenceEndpoint").Get<string> ()!;

		var securityKey = "2dfa028d8478164fd111897044b728fbe2f4a914";

		try {

			// just expanded here for debugging purposes
			var serializedBody = JsonConvert.SerializeObject (emailpref, NewtonsoftCustomResponseNegotiator.Serializer);

			var requestMessage = new HttpRequestMessage {
				Method = HttpMethod.Post,
				RequestUri = new Uri (endpoint),
				Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
			};

			var token = Utils.CreateRsaJwt (
				securityKey,
				DateTime.UtcNow.AddMinutes (5)
			);

			requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("Bearer", token);

			var response = await httpClient.SendAsync (requestMessage);

			if (response.IsSuccessStatusCode == false) {
				//logger.Error (new Exception ($"{response.StatusCode}, {response.ReasonPhrase}"), "Error submitting to create-lead endpoint");
				await ctx.Response.AsJson (new { Success = false, Message = $"Error, {response.ReasonPhrase}", StatusCode = response.StatusCode, Errors = new List<string> (), ResponseHeaders = response.Headers, RequestHeaders = requestMessage.Headers, RequestBody = emailpref });
				return;
			}
		} catch (Exception oops) {
			//logger.Error (oops, "Error submitting to create-lead endpoint");
			await ctx.Response.AsJson (new { Success = false, Message = oops.Message, FullMessage = oops.ToString (), Errors = new List<string> () });
			return;
		}

		await ctx.Response.AsJson (new { Success = true, Message = "Thank you" });
	}

	private async Task getTestCreateMarketingLead (
		IHttpClientFactory httpClientFactory,
		//ILogger logger,
		HttpContext ctx
	) {
		var httpClient = httpClientFactory.CreateClient ();

		var lead = new Models.Lead () {
			FirstName = "janos",
			LastName = "erdelyi",
			EmailAddress = "jerdelyi@costar.com",
			PostalCode = "23114",
			CompanyName = "CoStar Group",
			PhoneNumber = "804 304 5488",
			FormType = "Marketing",
			LeadSource = "STR",
			SourceType = "Web",
			Brand = "STR",
			CountryCode = "USA"
		};

		var endpoint = $"https://marketing-automation-api-{getEnvironmentShortWord (EnvironmentName)}.costar.com/create-lead";
		if (env.IsProduction ()) {
			endpoint = "https://ma-api-gateway.prd.dataservices.aws.dshrp.com/v1/create-lead";
		}

		var securityKey = "2dfa028d8478164fd111897044b728fbe2f4a914";

		try {

			// just expanded here for debugging purposes
			var serializedBody = JsonConvert.SerializeObject (lead, NewtonsoftCustomResponseNegotiator.Serializer);

			var requestMessage = new HttpRequestMessage {
				Method = HttpMethod.Post,
				RequestUri = new Uri (endpoint),
				Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
			};

			var token = Utils.CreateRsaJwt (
				securityKey,
				DateTime.UtcNow.AddMinutes (5)
			);

			requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("Bearer", token);

			var response = await httpClient.SendAsync (requestMessage);

			if (response.IsSuccessStatusCode == false) {
				//logger.Error (new Exception ($"{response.StatusCode}, {response.ReasonPhrase}"), "Error submitting to create-lead endpoint");
				await ctx.Response.AsJson (new { Success = false, Message = $"Error, {response.ReasonPhrase}", StatusCode = response.StatusCode, Errors = new List<string> (), ResponseHeaders = response.Headers, RequestHeaders = requestMessage.Headers, RequestBody = lead });
				return;
			}
		} catch (Exception oops) {
			//logger.Error (oops, "Error submitting to create-lead endpoint");
			await ctx.Response.AsJson (new { Success = false, Message = oops.Message, FullMessage = oops.ToString (), Errors = new List<string> () });
			return;
		}

		await ctx.Response.AsJson (new { Success = true, Message = "Thank you" });
	}

	private async Task getRegenerateAllTranslations (
		HttpContext ctx,
		ITranslationClient translationClient
	) {
		TranslationManager.RegenerateAllTranslations (env, translationClient);

		await ctx.Response.WriteAsync ("translations regenerated");
	}

	private async Task getRegenerateTranslation (
		HttpContext ctx,
		ITranslationClient translationClient,
		string locale
	) {
		var result = TranslationManager.RegenerateTranslation (env, translationClient, locale);

		await ctx.Response.WriteAsync ($"translation regenerated for {locale} : {result}");
	}

	private async Task getMachineLocale (
		HttpContext ctx,
		IWebHostEnvironment env,
		ITranslationClient translationClient,
		string locale
	) {
		var translationManager = new TranslationManager (env, translationClient);
		Models.CommonTranslationValues? translations = null;

		try {
			translations = await translationManager.Get (locale);
		} catch (Exception oops) {
			await ctx.Response.WriteAsync ($"error creating translations for {locale} : {oops.Message}");
			return;
		}

		if (translations == null) {
			await ctx.Response.WriteAsync ($"no translations returned for {locale}");
			return;
		}

		await ctx.Response.WriteAsJsonAsync (translations);
	}

	private async Task getMxCheck (
		HttpContext ctx,
		string domain
	) {
		ctx.Response.ContentType = "text/plain";

		try {
			if (Program.DnsServers.Count == 0) {
				// hard-coded. at the time of this writing (2024-10-07) this is the cluster DNS server
				Verify.AddDns ("172.20.0.10");
			} else {
				foreach (var dns in Program.DnsServers) {
					Verify.AddDns (dns);
				}
			}

			var results = Verify.GetMxDomains ("test@" + domain);

			var sb = new StringBuilder ();
			sb.AppendLine ("mx domains : ");

			foreach (var result in results) {
				sb.AppendLine (result);
			}

			await ctx.Response.WriteAsync (sb.ToString ());
		} catch (Exception oops) {
			await ctx.Response.WriteAsync (oops.Message);
		}

		return;
	}

	private async Task getFullEmailCheck (
		HttpContext ctx,
		IDynamoClient dynamoClient,
		string address
	) {
		// ctx.Response.ContentType = "text/plain";

		bool dofullValidation = env.IsLocal () == false;

		try {
			var result = Utils.ValidateEmailAddress (address, dofullValidation, dynamoClient);

			// if (Program.DnsServers.Count == 0) {
			// 	// hard-coded. at the time of this writing (2024-10-07) this is the cluster DNS server
			// 	Verify.AddDns ("172.20.0.10");
			// } else {
			// 	foreach (var dns in Program.DnsServers) {
			// 		Verify.AddDns (dns);
			// 	}
			// }

			// // a test
			// //var bypassDomains = await dynamoClient.GetAllGoodDomainsSince (DateTimeOffset.Now.AddMonths (-1));

			// var result = await Verify.Check (address);

			// var sb = new StringBuilder ();
			// sb.AppendLine ("results : ");
			// sb.AppendLine ($"success? : {result.IsSuccess}");
			// sb.AppendLine ("message : " + result.ErrorMessage);

			// // await dynamoClient.AddDomain (result.Domain, statusCd: (result.Success ? "ok" : "bad"));

			// await ctx.Response.WriteAsync (sb.ToString ());

			await ctx.Response.WriteAsJsonAsync (new { Success = result.IsSuccess, Message = result.ErrorMessage, Result = result });
		} catch (Exception oops) {
			await ctx.Response.WriteAsJsonAsync (new { Success = false, Message = oops.Message });
		}

		return;
	}

	private async Task getAddDomainToBadList (
		HttpContext ctx,
		IDynamoClient dynamoClient,
		string domain
	) {
		var response = Utils.AddDisallowedDomain (domain, dynamoClient);

		await ctx.Response.WriteAsJsonAsync (new { Success = true, Message = (response ? $"{domain} added to bad list" : $"{domain} not added to bad list. was likely already on it") });
	}

	private async Task getRemoveDomainFromBadList (
		HttpContext ctx,
		IDynamoClient dynamoClient,
		string domain
	) {
		var response = Utils.RemoveDisallowedDomain (domain, dynamoClient);

		await ctx.Response.WriteAsJsonAsync (new { Success = true, Message = (response ? $"{domain} removed from bad list" : $"{domain} not removed from bad list. was likely not on it") });
	}

	private async Task getRetestBadDomain (
		HttpContext ctx,
		IDynamoClient dynamoClient,
		string domain
	) {
		var response = Utils.RetestBadDomain (domain, dynamoClient);

		await ctx.Response.WriteAsJsonAsync (new { Success = true, Message = response });
	}

	private async Task getRetestAllBadDomains (
		HttpContext ctx,
		IDynamoClient dynamoClient
	) {
		Utils.RetestAllBadDomains (dynamoClient);

		await ctx.Response.WriteAsJsonAsync (new { Success = true, Message = "running" });
	}

	private async Task getLoadEmailTest (
		HttpContext ctx,
		IWebHostEnvironment env,
		IDynamoClient dynamoClient,
		IHttpClientFactory httpClientFactory
	) {
		if (env.IsLocal () == false) {
			await ctx.Response.WriteAsync ("this is only allowed in local environment");
			return;
		}

		var httpClient = httpClientFactory.CreateClient ();
		httpClient.DefaultRequestHeaders.Add ("User-Agent", "TestModule");

		var endpoint = $"https://ma-platform-services-use1.dvm.enterprise.aws.dshrp.com/we-marketing-automation-form-injection/temp/emailcheck/";

		// get 1000? email addresses and test them
		// just going to make an array/list here since it's ridiculous to add SQL infrastructure to this project just for this

		var emailaddresses = new List<string> { "felicia_braxton@yahoo.com", "ferditraub@web.de", "fdedomenici2010@kellogg.northwestern.edu", "fcheng@crownww.com", "feliciabrinson@optonline.net", "fernanda@bonillare.vom", "fdelcpa@msn.com", "fchlmrs@verizon.net", "feliciaspivey7373@yahoo.com", "fernny6@yahoo.com", "fdidier@nhood.com", "fclausier@vauban-es.com", "felicitybloom@yahoo.com", "floraikone@yahoo.com", "fedaykin66@yahoo.com", "fcreek@msn.com", "felix.bengner@mauritzhof.de", "floreedabear@aol.com", "fedeeternita@aol.com", "fcrwb1@aol.com", "felix.jonas@me.com", "florence.mebrouk@pimcopre.com", "fedenas@yahoo.com", "fd@isphere.net", "felixelsalvadorrr@yahoo.com", "flores.melissa72682@yahoo.com", "fedorable1@yahoo.com", "fdavemorrison@yahoo.com", "felixgpollo@yahoo.com", "floresguadalupe808@yahoo.com", "fedorovmichele@yahoo.com", "fervi_7@hotmail.com", "felixjuls03@yahoo.com", "florida_betty@yahoo.com", "feeds4@mac.com", "fessler921@comcast.net", "femmlc9mel@yahoo.com", "floridarebel2525@yahoo.com", "feistysquidchick@aol.com", "fetherheth@yahoo.com", "fengjie_jiang@hotmail.com", "floridatah@yahoo.com", "feldridge555@yahoo.com", "fewebber@yahoo.com", "finchertx@yahoo.com", "floridawaters@aol.com", "felecia.sharps@hilton.com", "ffamularo2011@kellogg.northwestern.edu", "findmyhappyplac3@yahoo.com", "florinda_giron@yahoo.com", "felesh7@aol.com", "ffbrummett@hotmail.com", "fink8562@hotmail.com", "franca.schaefer@hotelairinberlin.de", "felice@goldengatecompanies.com", "ffdaughters@yahoo.com", "finkm23@yahoo.com", "francelinaconde@yahoo.com", "felicia.fuller@hilton.com", "ffiles@yahoo.com", "finnc8@yahoo.com", "frances.sperry@comcast.net", "firststudent101@yahoo.com", "ffleur01@aol.com", "fiona.taylor@tbo.com", "francesca.barba@villaserbelloni.com", "firstvp3553@aol.com", "ffmed1532@yahoo.com", "fionajuliana@yahoo.com", "francesca.garmon@concordhotels.com", "fishingkitty@comcast.net", "ffolu@yahoo.com", "fir.sumac2314@eagereverest.com", "francesca.labon@outlook.com", "fishwruss@yahoo.com", "ffreespiritalways@yahoo.com", "fire_to_touch@hotmail.com", "francesco.pantalone@shangri-la.com", "fislam_bd@yahoo.com", "fgh@ferran.es", "fireflowerfly@yahoo.com", "francescogalletti@hotmail.com", "fit59clag@yahoo.com", "fghamm@hotmail.com", "firefrith@hotmail.com", "franchesternance@yahoo.com", "fitri.rahmawati@primahotelindonesia.com", "fhesq@hotmail.com", "firehose1709@yahoo.com", "francie.whaley@shawinc.com", "fitzu2at@yahoo.com", "fhhdfhhd@yahoo.com", "firingpoint@yahoo.com", "francie0626@yahoo.com", "fivejacobis@yahoo.com", "fholton@hotmail.com", "fourinbigfork@yahoo.com", "francine3412@yahoo.com", "fivelouies@me.com", "fi2001@email.msn.com", "fournierjay@msn.com", "fred@plotsky.net", "fiveoclocksmwr@aol.com", "fibibinini@yahoo.com", "fourpaws04@yahoo.com", "fred_kris2000@yahoo.com", "fivepenniesbombshell@yahoo.com", "fieldjo@aol.com", "foutse@uindy.edu", "fredadiver@msn.com", "fiveuponedown@aol.com", "fields.carol@att.net", "fowler_porshia@yahoo.com", "freddiea86@yahoo.com", "fizia2000@yahoo.com", "fierro520@aol.com", "foxair9@yahoo.com", "freddiecox92@yahoo.com", "fjfritsch@yahoo.com", "fiesty61@yahoo.com", "foxhall90@aol.com", "freddy@nunezgroupchicago.com", "fjtk6rhcyg@privaterelay.appleid.com", "figit10@yahoo.com", "foxmary84@yahoo.com", "frederic.auguste@cbre.fr", "fkenpos2@yahoo.com", "fiiosin24@yahoo.com", "fpoapril@aol.com", "frederico.guerra@selina.pt", "fnandrad@usc.edu", "filiolaluarasi@yahoo.com", "fqkqg2bxb9@privaterelay.appleid.com", "fredesrod@yahoo.com", "fnflying@yahoo.com", "filip@filipvarga.com", "frafeu0704@skola.goteborg.se", "gaines_nancy_02@yahoo.com", "fo.fayrouz@jazhotels.com", "filster04@yahoo.com", "framos506@hotmail.com", "gajohn54@yahoo.com", "fo.sihurghada@swissinn.net", "finance@capellahotelgroup.com", "frank@wiseler.com", "galeblader@outlook.com", "fo@hotelonce.com", "fl.bodine123@yahoo.com", "frankancheta@yahoo.com", "galicia_tony@yahoo.com", "focus1998@yahoo.com", "fl51smith69@outlook.com", "frankb@fireandpumpservice.com", "galina.kolpatcheva@mydwellworks.com", "foghorn8241@outlook.com", "flameandcoyote@yahoo.com", "frankgn23@yahoo.com", "gallenstein@yahoo.com", "folden03@yahoo.com", "flamingosrock13@yahoo.com", "frankharbusch@hotmail.de", "galley-quit-scouts@duck.com", "folse_matthew@yahoo.com", "flavioberny@verizonn.net", "frankieflatch@hotmail.com", "gallowaybridgette@yahoo.com", "fom@gphkissimmee.com", "flaviofujimori@msn.com", "frankiepr0099@yahoo.com", "gallowayrandy@hotmail.com", "fon5ecas@hotmail.com", "flemflam35952@aol.com", "frankjohnpalmeri@hotmail.com", "galwayres@thedean.ie", "fontay@bellsouth.net", "fleshel@ymail.com", "franklin.clawson@zionsbank.com", "gambler@alaska.net", "fontysranch13@hotmail.com", "flexxed2003@yahoo.com", "franklin.delarosa@sohoworks.com", "gameedawyy48@yahoo.com", "fonzie.phan@yahoo.com", "fli15@johnshopkins.edu", "frijasr1@outlook.com", "gamgipson@yahoo.com", "foodmandan@yahoo.com", "flintstone59@yahoo.com", "frisco.nicole@yahoo.com", "garylmorey@hotmail.com", "footballfan_2003@yahoo.com", "flipbierkamp@yahoo.com", "frisonlasha@yahoo.com", "garymc@gamerealty.com", "forebay201354@yahoo.com", "flmidwestgirl@aol.com", "fritz@langgang.com", "garypedigo@rocketmail.com", "frank.barela23@yahoo.com", "floater33@comcast.net", "fritz_the_cat4731hm@yahoo.com", "garyrtools@yahoo.com", "frank.dececco@sageveterinary.com", "flowema1@bellsouth.net", "frobles@leitermanagement.com", "garywayne26@hotmail.com", "frank.gayeski@comcast.net", "floydandopeth@yahoo.com", "frog4ever@yahoo.com", "garyyoder@sbcglobal.net", "frank.maglio@yahoo.com", "floydsplace@aol.com", "frosty1sarah2weasel3@yahoo.com", "garza_mariah@yahoo.com", "frank@buchanan4.com", "flu122@yahoo.com", "fruc31@yahoo.com", "garzamari_69@yahoo.com", "frank@capitaldf.com", "flutterby71@yahoo.com", "fruitychick2000@yahoo.com", "gas222@lehigh.edu", "frank@franciscovich.com", "flyersrule41099@hotmail.com", "fsasso2011@kellogg.northwestern.edu", "gaston.wijs@progmatic.nl", "funmi@adelproperties.com", "flygirlaa@mac.com", "gabe_toth@hotmail.com", "gat82358@yahoo.com", "funmilola7@yahoo.com", "flyinpete@yahoo.com", "gabear536@yahoo.com", "gat837@aol.com", "furlongmic58@yahoo.com", "flyme0096@yahoo.com", "gabe-duarte@outlook.com", "gatesgirlgg@yahoo.com", "furlough1@msn.com", "flyn.dawson@zionsbank.com", "gabemcdougall@yahoo.com", "gatesnat@pdx.edu", "fursho@aol.com", "flyrodtraveler@yahoo.com", "gabouelfetouh@aldaudevelopment.com", "gatewoodm@live.com", "furrypurries2@aol.com", "fmk_enterprises@yahoo.com", "gabriel.foguel@fitchratings.com", "gatorbaitnsharkz13@duck.com", "fus3in702@aol.com", "foreverpresent@comcast.net", "gabriel.melodeassisreis@exprealty.com", "gatorgrl2284@yahoo.com", "fv1115@yahoo.com", "foreverprivateone@proton.me", "gabriel.modarelli@accor.com", "gatorp003@aol.com", "fwa7@yahoo.com", "foreversearchin2@yahoo.com", "gabriel@trustgemini.com", "gatrmartin@live.com", "fwestpoint@outlook.com", "forgetmenot4925@yahoo.com", "gabriel@unimostudios.com", "gaurav_chd37@yahoo.com", "fworgull@yahoo.com", "fornarischeri@yahoo.com", "gabriel_linn@outlook.com", "gaurdian191@yahoo.com", "fwunder2000@aol.com", "forourdreamz@yahoo.com", "gabriela@cremmgmt.com", "gautam_kumar_das@yahoo.com", "fwy88@hotmail.com", "forrest_webster@hotmail.com", "gabriela@hiverealestateca.com", "gene_lutz@outlook.com", "fyrecraker@hotmail.com", "fortheboysmi@yahoo.com", "gary@beswickrealty.com", "gene_s72401@yahoo.com", "fzambrano2012@kellogg.northwestern.edu", "forthoodian@yahoo.com", "gary@bridgecorerealty.com", "gene12081978@netscape.net", "gaffgirl13@yahoo.com", "fortneybrad@yahoo.com", "gary@carlyle-usa.com", "gene4ut@hotmail.com", "gaffneylindsey1@yahoo.com", "fortolive@yahoo.com", "gary@flannelly.com", "gene8888@att.net", "gagirl-n-nc@hotmail.com", "fortyrods@outlook.com", "gary@islandindoor.com", "genellm@rocketmail.com", "gail.crespy@mac.com", "foryours29@yahoo.com", "garyboucher68@yahoo.com", "genemr@yahoo.com", "gailbw2001@hotmail.com", "fosterd202@hotmail.com", "garygraefe@comcast.net", "generalmanager@laluciasands.com", "gailfares55@yahoo.com", "fotoclyde@yahoo.com", "garyjfrank@sbcglobal.net", "generalseti@yahoo.com", "gailmc31@yahoo.com", "foubisterc@bellsouth.net", "gbubbles74@yahoo.com", "genevievecohen@q-factory-amsterdam.nl", "garhardtimes65@yahoo.com", "francisco_espinoza78@yahoo.com", "gburklow@yahoo.com", "genice5867@yahoo.com", "garland.daniel@hotmail.com", "francisjannell1991@att.net", "gbwisconsin42000@yahoo.com", "genmarrero@protonmail.com", "garlic-undone-lisp@duck.com", "franco@southcoastventure.com", "gcag589@aol.com", "gennadysilenko@hotmail.com", "garnau@ppbi.com", "franco1977@verizon.net", "gcalder@bellsouth.net", "gennelle.daniels@yahoo.com", "garrett.bindel@ttu.edu", "francois.chauvey@realestate.bnpparibas", "gcano08@yahoo.com", "gennesistellez@yahoo.com", "garrett.moeller@expcommercial.com", "francois.demaret@clubmed.com", "gcapote@fordham.edu", "getquackin@duck.com", "garrett@naisawyer.com", "francorona@ymail.com", "gcarlton015@yahoo.com", "gettig@usc.edu", "garrett@prendiville.com.au", "frankn14@verizon.net", "gchase@snet.net", "getur@geturhotels.com", "garrett@unitedcarports.com", "frankwinger@hotmail.com", "gclark18@bethelu.edu", "gfahlsing@hotmail.com", "garretthadley@me.com", "fratoste@yahoo.com", "gclucas@aol.com", "gfdaenzer@yahoo.com", "garrettnelson@wellhouserealestate.com", "fraziermeaghan@yahoo.com", "gcollie@me.com", "gflattery@me.com", "garrison.eaker@ttu.edu", "frbreal@yahoo.com", "gcondon2003@yahoo.com", "gfmeister@comcast.net", "gcowen@roosevelt.edu", "frbryant@comcast.net", "george_jimenezg@att.net", "gfrancisco@aman.com", "gcs@everestkc.net", "freak4pj@yahoo.com", "george_matti@ymail.com", "gfsielski@yahoo.com", "gcs426@yahoo.com", "freakbyn8ure@outlook.com", "georgeann.hoover@azmoves.com", "gfytk8b9kw@privaterelay.appleid.com", "gcsbasket23@yahoo.com", "freck0127@yahoo.com", "georgefroland@outlook.com", "gg3admin@bellsouth.net", "gdclark42@hotmail.com", "fred.botwinik@elliman.com", "georgeglackin@aol.com", "gg91968@yahoo.com", "gdella123@aol.com", "fred.lehouillier@yahoo.com", "georgepaige31@yahoo.com", "ggallicho@sbcglobal.net", "gdenning@crmco.com", "fredhuggins@outlook.com", "georgerontiris@yahoo.com", "ggamazed@yahoo.com", "gdillon52@aol.com", "fredlakeclark@yandex.com", "georgesroad@aol.com", "ggamero2011@kellogg.northwestern.edu", "gdinger49@sbcglobal.net", "frednalice2@yahoo.com", "georgettekenney@yahoo.com", "ggarcia103@comcast.net", "gdluther@hotmail.com", "freedom4600@outlook.com", "ghejna@umich.edu", "ggarsons@verizon.net", "gdquast@gdqpc.com", "freedomlawn@frontier.com", "ghentze2010@kellogg.northwestern.edu", "gingercrousseau@yahoo.com", "gds029@yahoo.com", "freeflyin180@yahoo.com", "ghhowland@msn.com", "gingermaitai@yahoo.com", "ge1014orgea@hotmail.com", "freelu7925@yahoo.com", "ghinds@laalliance.org", "gingersnapp2@yahoo.com", "geabird@hotmail.com", "freeman1212@live.com", "ghiotti@dauchez.fr", "ginnya4000@yahoo.com", "george.harris@cbrealty.com", "freemanj_813@yahoo.com", "ghollis@shammasgroup.com", "ginnyoga@duck.com", "george@buildrightllc.com", "freeseinvestments@comcast.net", "ghpolishuk@hotmail.com", "ginnyroseroy@yahoo.com", "george@twinpeaks.net", "freeskithetrees@yahoo.com", "ghurtadohernandez@yahoo.com", "ginnysmith0001@yahoo.com", "ggiordano1@me.com", "freewax@aol.com", "gianluca.dragonetti@radissoncollection.com", "gino62@fone.net", "gglawrenceville@bellsouth.net", "frefer87@hotmail.com", "gip2005@msn.com", "gio@cozo.co", "ggpowerspac@yahoo.com", "frehkat77@yahoo.com", "girl47jam@yahoo.com", "giorgio.delgrosso@ozk.com", "ggraves@clemson.edu", "frenchcreekheaven@sbcglobal.net", "girlemt2013@yahoo.com", "giovanna.kennedy@gokennedyrealtor.com", "ggreenberg@tishmanspeyer.com", "frenchfarm@verizon.net", "giselemc281@yahoo.com", "glynis.gibson@gibsoncommunications.com", "ggthelight3@yahoo.com", "frenchiebb4@yahoo.com", "giselledente@yahoo.com", "glynn0406@yahoo.com", "ggtomani@aol.com", "frese6@aol.com", "gisellesantiago121397@yahoo.com", "gm.atlaa@aurohotels.com", "gguthmiller@thegroutmedic.com", "frevent1@yahoo.com", "gisurology_4033@yahoo.com", "gm.atlgi@aurohotels.com", "ghamilton@factory-connection.com", "frickdbq@msn.com", "giu_alves07@yahoo.com", "gm.flldb@aurohotels.com", "ghanson@trelora.com", "friedgreentomatoes23@yahoo.com", "giuliodavid@dapuzzo.it", "gm.hb@rshotels.in", "gildat@me.com", "fsdzisa@optimum.net", "giulvem@ccf.org", "gm.krakow.south@campanile.com", "gileshold@yahoo.com", "fshymn@aol.com", "gj18zz@yahoo.com", "gm.lq6739@aurohotels.com", "gilliamsbride2@msn.com", "fstewart@whml.com", "gjawid@yahoo.com", "gm.rch@royalorchidhotels.com", "gillian520@live.com", "fstoughton@verizon.net", "gjclmt@yahoo.com", "gm@alofthoustondowntown.com", "gillies@insightlink.com", "fstutzman@thestutzmanranch.com", "gjconner@twc.com", "gm@coogeebayhotel.com.au", "gimeabrak2000@yahoo.com", "fsuali@yahoo.com", "gjdennis@bellsouth.net", "gm@expressdefuniak.com", "gina.sefton@compass.com", "fswett2010@kellogg.northwestern.edu", "gjdgrits32@aol.com", "gm@goldentulipdowntownabudhabi.com", "glenn.gioseffi@kidder.com", "ftakayla@yahoo.com", "gjessy@live.com", "gm@hiemarina.com", "glenna.trujillo@yahoo.com", "ftealbuck@aol.com", "gloria.beene@yahoo.com", "gm@kooindahwaters.com.au", "glennwilliams134@yahoo.com", "ftmerritt@hotmail.com", "gloria.salazar.morris@hotmail.com", "gm@palavraresort.com", "glfdad1@yahoo.com", "fuechee@aol.com", "gloria@exitotb.com", "gm@parkpremierhotels.com", "glh1217@aol.com", "fuentes.o@sbcglobal.net", "gloriacctm@hotmail.com", "gpf1099@yahoo.com", "glm13579@proton.me", "fujiistockstill@yahoo.com", "gloriafagg@yahoo.com", "gpfeife2@johnshopkins.edu", "global_yield@candeo-hotels.com", "fujikake@starpress.co.jp", "gloriagoodwin60@yahoo.com", "gphilmit@aol.com", "gmfanelli3908@yahoo.com", "fujimoto1@hotmail.com", "gloriamccarthy@sbcglobal.net", "gplyle@yahoo.com", "gmflora@msn.com", "full_of_sunshine@yahoo.com", "gloriasolis57@yahoo.com", "gr8rdayz@comcast.net", "gmhagen@yahoo.com", "fulldad77@hotmail.com", "gloverm@kidsheart.com", "grace.barker@thalhimer.com", "gmikelpetrie@me.com", "fulps1@comcast.net", "glyfrench@aol.com", "grace.ritsema@cushwake.com", "gmkalogeras@yahoo.com", "fulya.plas@qfb.com.qa", "gonzalo.cubillos@cbrealty.com", "grace.xu@myfw.com", "gmmyers@bellsouth.net", "fun.hope0492@fastmail.com", "gonzalo@soyturealtorpro.com", "grace@gracehotel.com.au", "gmoe44@yahoo.com", "funch024@umn.edu", "gonzalquint@yahoo.com", "grichting@therme51.ch", "gmom_52@yahoo.com", "g.jenean@yahoo.com", "goodjohnis@outlook.com", "griders3@hotmail.com", "gmonae11@hotmail.com", "g.porru@starhotels.it", "goodold41@hotmail.com", "grievous.gram@me.com", "gmp6259@yahoo.com", "g@twodumbdogs.com", "goodpaster5@yahoo.com", "griffey.chris@yahoo.com", "gmp630@msn.com", "g_klingemann@yahoo.com", "goody2party@yahoo.com", "griffin.obrien@svn.com", "gmr714@rcn.com", "g_orlando@yahoo.com", "goodzl@yahoo.com", "griffind@opinicusinc.com", "gmroot2003@yahoo.com", "g_tenoch1@yahoo.com", "goofstersmom@hotmail.com", "griffith_g@yahoo.com", "gmtruk1555@yahoo.com", "g29fr6k2dx@privaterelay.appleid.com", "gopalwife@yahoo.com", "grindels@outlook.com", "gmutair@uw.edu", "g4rym@hotmail.com", "gord.doiron@coastalinns.com", "grisette63@yahoo.com", "gmwilkie@att.net", "g8qtk9924y@privaterelay.appleid.com", "gordon.mike88@yahoo.com", "grisma@ctmt.com", "gncutime2022@outlook.com", "ga_cavaliere1@msn.com", "gordon@gordonpolk.com", "grits5351@comcast.net", "graftedn@yahoo.com", "ga5675@yahoo.com", "grant@grantsorber.us", "grjelly05@yahoo.com", "gragsonm@hotmail.com", "gaa718@att.net", "grant@grantwarrenwilson.com", "grkfab@yahoo.com", "graham@highmonthome.com", "gab_gonzalez1012@yahoo.com", "grant@killianphd.com", "grmabear@yahoo.com", "graham@parkercoboston.com", "gabbriella47t@duck.com", "grant@rusticcapital.com", "grogers1130@yahoo.com", "grahamcrakr_01@yahoo.com", "gabby.reynolds66@aol.com", "granttemple@rocketmail.com", "grolean@hotmail.com", "graig3326@yahoo.com", "gabby@celermtg.com", "grateful2one@yahoo.com", "groovylife2000@yahoo.com", "grama.georgia@yahoo.com", "gabby@newagehtx.com", "gratefulgrandma3@outlook.com", "guthkim@yahoo.com", "grammiein2003@yahoo.com", "gabby_masia@hotmail.com", "gray.huang@marcopolohotels.com", "guth55@hotmail.com", "grammy.nelson@me.com", "gabbygabster09@yahoo.com", "gray_s3@yahoo.com", "guthriejrs@aol.com", "grammyb508@rocketmail.com", "gabbyoyadomari@comcast.net", "grayabby09@yahoo.com", "gutierrezjanelle@yahoo.com", "grandf@aol.com", "gabrielasanchez1977@yahoo.com", "grayem@alumni.vcu.edu", "gutierrezsilvia12@yahoo.com", "grandkids0956@att.net", "gabriele@masili.eu", "grayhme@yahoo.com", "guy.thompson@the-ascott.com", "grandmamaryof7@yahoo.com", "gabriellam28@aol.com", "graystheway@yahoo.com", "guy294j@yahoo.com", "grandmax6@bellsouth.net", "gabrielle@crimsonrealtytx.com", "greg@mghotelgroup.com.au", "gvandermersch@nhood.com", "grandmomma2013@twc.com", "gabrielle@kpr.net", "greg@muirheadtrucking.com", "gvandina@aol.com", "grannyshands@yahoo.com", "gabrielleharrison@ymail.com", "greg@netroworx.com", "gvc@capcoreadvisors.com", "greggwollard@msn.com", "gabrielovachon@yahoo.com", "greg@oakandsageok.com", "harvestprofessionalservices@yahoo.com", "gregh@gshindustries.com", "gabrielr0924@yahoo.com", "greg_lash@yahoo.com", "harvey.revana@yahoo.com", "gregmay@reagan.com", "gaby@abodestf.com", "greg617@yahoo.com", "hasananees@capitalspine.net", "gregmillhorn@me.com", "gaby_contreras5@yahoo.com", "gregamyjo8@aol.com", "hassanali8202797@yahoo.com", "gregnmar@msn.com", "gaby_roes@hotmail.com", "gregandmary@sbcglobal.net", "hasumi@nihonhotel.com", "gregoiref@ymail.com", "gabyhimes@yahoo.com", "gregarthur@hotmail.com", "hataylo1969@yahoo.com", "gregory.moore@zionsbancorp.com", "gammymay@live.com", "gregauhawaii@yahoo.com", "hathcockjc@rss.k12.nc.us", "gregory.w.graf@outlook.com", "ganbaru_11@yahoo.com", "gregausman@windermere.com", "hatj@flussollc.com", "gregory_powers_su@yahoo.com", "gandegghut@aol.com", "greg-bk@hotmail.com", "hattiealbertson@yahoo.com", "gregory0903@yahoo.com", "gander922@yahoo.com", "gregepstein7@me.com", "hattiehale@yahoo.com", "gregoryetter@comcast.net", "gands@ameritech.net", "gsieb@swbell.net", "haubnerdawn48@yahoo.com", "gtmuldoon@yahoo.com", "ganesha1070@yahoo.com", "gsimran@umich.edu", "havacupcoffeeser@aol.com", "gtqbw77ntr@privaterelay.appleid.com", "gannette54@yahoo.com", "gsiunely2@yahoo.com", "have2swtangels@yahoo.com", "gtrombino@aol.com", "gantes@usc.edu", "gsm@microtelweyburn.com", "heatherallen2017@yahoo.com", "guamarito@hotmail.com", "gaohv@bc.edu", "gsmith@lsh.co.uk", "heatherdcampbell@yahoo.com", "guela5@yahoo.com", "gapblanca@yahoo.com", "g-snyder123@comcast.net", "heatherdelvecchio@outlook.com", "guestservice@concordehotelnewyork.com", "garbismikaelian@yahoo.com", "gspringrose@kbra.com", "heatherdow01@yahoo.com", "guestservices@bluemonthotel.com", "garcher73@hotmail.com", "gsproper2008@yahoo.com", "heatherfeather1969@yahoo.com", "guestservices@legacysandiego.com", "garcia_leslie74@yahoo.com", "gsr13a@acu.edu", "heatherhatesppl0630@yahoo.com", "gufmaster@yahoo.com", "garciabrian@att.net", "gsrob2024@proton.me", "heatherjia@hotmail.com", "guiding@jessicabugbee.org", "garciacassandra247@yahoo.com", "gsterritt2011@kellogg.northwestern.edu", "heatherkarpa@yahoo.com", "guilencita@hotmail.com", "garciafambam7@outlook.com", "gsutch@duck.com", "hello@liveupstairs.com", "guilinf@aol.com", "garcia-rosa@hotmail.com", "gswann83@yahoo.com", "hello@thespaceconnect.com", "guillaume.cariou@telamon-groupe.com", "garda19@protonmail.com", "gtaylor0406@yahoo.com", "hello@wimberleyinn.com", "guillermo.sepulveda@ymail.com", "garden1968wmc@yahoo.com", "gthekey@yahoo.com", "hello+rls@ermolay.com", "h_jacki@yahoo.com", "gardenoflocs@yahoo.com", "gwmel@srt.com", "hellodanw@hotmail.com", "h2investor@aim.com", "gardner8910@yahoo.com", "gwpbadfad76@outlook.com", "hillary.justice@cbrealty.com", "h5p6fsyffm@privaterelay.appleid.com", "gardnerlo@yahoo.com", "gwynnero@swbell.net", "hillblaine@aol.com", "h6469-gl@accor.com", "gardning4god@proton.me", "gy6xw5tpxx@privaterelay.appleid.com", "hilles@pdx.edu", "h7v2b2txs2@privaterelay.appleid.com", "garryfeary@otto.ie", "gymjunky50@aol.com", "hillhockey@hotmail.com", "h8wm2vv2rc@privaterelay.appleid.com", "garvilla2018@yahoo.com", "gypsyvera@aol.com", "hilll6@mail.uc.edu", "ha.huyenlinh@the-ascott.com", "gary.gasper@digis.net", "gyvette17@yahoo.com", "hillstefan@yahoo.com", "haasnatalie@yahoo.com", "gary.guldin@yahoo.com", "gzrcjsjd@hworld.com", "hilma.hindriyani@thetribrata.com", "hannah.f.mcconnell@protonmail.com", "gary.loke@panpacific.com", "h.ashi@shadenhospitality.sa", "hilo_mama@yahoo.com", "hannah.i.cavazos@ttu.edu", "gary.panzer@verizon.net", "h.avard@mgs-developpement.eu", "hilumberton@sree.com", "hannah.kerkaert@aol.com", "gary.sapp@huntcompanies.com", "h.dellmann@novum-hospitality.com", "himsingh_nusl@yahoo.com", "hannah.parker@amegybank.com", "gavinemenaker@att.net", "h.hatam@aol.com", "hinatea.cristol@temoana.pf", "hannah.pohler@amegybank.com", "gavingreen73@yahoo.com", "h.heidemann@12-18.com", "hines1979@yahoo.com", "hannah.robbins@temple.edu", "gavinjlucas@proton.me", "h.mcginnis@hotmail.com", "hines77@yahoo.com", "hannah.thompson97@yahoo.com", "gavin-sarowa@hotmail.com", "h.najjar@baglionihotels.com", "hintha@sbcglobal.net", "hannah@buddyshenricoseptic.com", "gaycinque@yahoo.com", "h.oita@tokyuhotels.co.jp", "hiromaru@uw.edu", "hannah@eastmanmanagement.com", "gayel.clayton@yahoo.com", "h.reliford@yoorealtygroup.com", "hollywoodbob@live.com", "hannah@foxallen.com", "gaylamcgreger@rocketmail.com", "h.sandoval.c@hotmail.com", "hollywooddaniel@me.com", "hannah@thelenderagent.com", "gaylynnemelton@yahoo.com", "h.timbes@hotmail.com", "holmes.ash1013@yahoo.com", "hannah_nicole1996@yahoo.com", "gazelle03253@yahoo.com", "halfaharkey@yahoo.com", "holmessh@bc.edu", "hannahgrace2415@yahoo.com", "gbart91@live.com", "halima.moses@ipaper.com", "holmgreen1@yahoo.com", "hannahgrimes0313@yahoo.com", "gbauto1@yahoo.com", "halit@hdcarpentrycorp.com", "holwegerdc@sigecom.net", "hannahiahb@outlook.com", "gben1333@yahoo.com", "hall2647@yahoo.com", "homaira.hilburn@yahoo.com", "hannahkampenga@yahoo.com", "gbezner@ttu.edu", "halmansouri60@gmail.com?", "home@lunaberry.net", "harry.hodgkinson@eddisons.com", "gbgcabinets@tds.net", "halmccauley@yahoo.com", "homer@giz.mozmail.com", "harry@washlb.com", "gbotello@cesarstacos2go.com", "halocraft@aol.com", "homersimpson2nd@hotmail.com", "harrycii2004@yahoo.com", "gbrisneida@yahoo.com", "halperts@bc.edu", "homes.2r4eh@8shield.net", "harryo20032000@yahoo.com", "geenacasey@ymail.com", "halpoll1@aol.com", "homes.4vbld@passmail.net", "hart@stellarj.com", "geetanjali.ningappa@analog.com", "halspach@me.com", "homes.bankroll143@passmail.net", "hart4u@cinci.rr.com", "gehle@laharpe.us", "halterson@washingtonprop.net", "homes.coat990@passmail.net", "hartpr@yahoo.com", "gemas@realtyincome.com", "hamamatsuchou@kuretake-inn.com", "homes.com.only752@passmail.net", "harvard@nashrealestate.com", "gemma@hotelwestport.ie", "hamann_330i@yahoo.com", "homes.com.voqlv@passmail.com", "hdnhdb@yahoo.com", "gemorlan@tutanota.com", "hamcat1163@ung.edu", "homes.com.constrain921@passmail.net", "hdpink62@yahoo.com", "gemsplace61@yahoo.com", "hamel.kathy@yahoo.com", "homes.com@surplusholdingsllc.com", "hdrider1352@yahoo.com", "gen3pro@outlook.com", "hammedbalogun36@yahoo.com", "homes.luxurious285@passinbox.com", "hdtommyg@yahoo.com", "genadaignault@yahoo.com", "harbaughjerrica@yahoo.com", "homes.pu7g2@8shield.net", "healingharper@aol.com", "genasill@yahoo.com", "hardwicke@verizon.net", "howie.vradenburgh@yahoo.com", "healingheart2010@att.net", "genavi11512@yahoo.com", "harj8477@yahoo.ca", "howlingdogs2@yahoo.com", "healingstone@yahoo.com", "genduran@yahoo.com", "harlan.parker@aol.com", "howlinghikers@yahoo.com", "healthyhealing77@yahoo.com", "gene.anderson@fremontbank.com", "harleycity@hotmail.com", "hparrish6@liberty.edu", "hearinsue@yahoo.com", "gene.hauck@evrealestate.com", "harleydude1992@yahoo.com", "hplcy@msn.com", "heart_talk143@yahoo.com", "gene.rindels@outlook.com", "harleyleewells@yahoo.com", "hqvo15@yahoo.com", "heart2heart55@yahoo.com", "gensealc@verizon.net", "harleyrider54@comcast.net", "hr.berlin@arcotel.com", "heartgod@aol.com", "gentleman6238@yahoo.com", "harmad41@yahoo.com", "hr@globeorigin.com", "hearthomes@aol.com", "gentlemanmark@protonmail.com", "harmanmw@live.com", "hramirez@grandpointbank.com", "heather.dees@hotmail.com", "geoff@kbagroup.com", "harmoncedric@ymail.com", "hrcleme@yahoo.com", "heather.hargett@yahoo.com", "geoffrey.dodd@capitalone.com", "harmony72653@yahoo.com", "hreinauer@walkerdunlop.com", "heersema@usc.edu", "geogheja@bc.edu", "harnaldo@pm.me", "hrenfro1@mac.com", "hefferlump007@yahoo.com", "geojoy80538@yahoo.com", "hayward.76@hotmail.com", "hrfb@me.com", "hegel62@yahoo.com", "geonbell@aol.com", "haywoodjoshua59@yahoo.com", "hyaudas@yahoo.com", "heidbrink81@live.com", "georgina.leme@transwestern.com", "hb1r9-na@accor.com", "hydepark@hpgmanagement.com", "heideh@duck.com", "georgina.spence@att.net", "hb4u6-mk@accor.com", "hymanbr@outlook.com", "heidfaer@comcast.net", "georginabasta@hotmail.com", "hbadillo@aman.com", "hymansro@bc.edu", "heidi.haugenwomack@outlook.com", "georginalanning@tds.net", "hbeisen@comcast.net", "hymantanner@yahoo.com", "heidi.kamei@exprealty.com", "georkhalaf@yahoo.com", "hbenterprise2000@yahoo.com", "hyperpam62@yahoo.com", "heidi.kiss@engelvoelkers.com", "geostone1@pm.me", "hberkec@yahoo.com", "hzaph@fastmail.com", "heidi.oblander@sbcglobal.net", "geostone1@proton.me", "hbmxhhnvvq@privaterelay.appleid.com", "i.garcia1995@yahoo.com", "heidi.stead@yahoo.com", "gerabarraza@yahoo.com", "hboswald@yahoo.com", "i.muraglia@unahotels.it", "heidi@arthurberry.com", "gerald148@aol.com", "hbradman@mac.com", "i.schlanstedt@lind-hotel.de", "heidicharlery@hotmail.com", "geraldinep05@yahoo.com", "hbrill1@johnshopkins.edu", "i.straver@goldengreenhotels.nl", "heidiconnor1005@yahoo.com", "geraldwilliam222000@yahoo.com" };

		foreach (var emailaddress in emailaddresses) {

			var requestMessage = new HttpRequestMessage {
				Method = HttpMethod.Get,
				RequestUri = new Uri (endpoint + emailaddress)
			};

			// i don't really care about the response
			var response = await httpClient.SendAsync (requestMessage);
		}

		await ctx.Response.WriteAsync ("done");
	}

	// private async Task getLoadRequestLog (
	// 	HttpContext ctx,
	// 	IDynamoClient dynamoClient
	// ) {
	// 	if (env.IsLocal () == false) {
	// 		await ctx.Response.WriteAsync ("this is only allowed in local environment");
	// 		return;
	// 	}

	// 	var locale = "en-US";
	// 	var formcd = "costardemo";
	// 	var headerstring = string.Empty;
	// 	foreach (var key in ctx.Request.Headers.Keys) {
	// 		headerstring += $"{key}={ctx.Request.Headers[key]}, ";
	// 	}
	// 	var body = "testbody";

	// 	for (var i = 0; i < 1000; i++) {
	// 		var now = DateTimeOffset.Now;

	// 		await dynamoClient.InsertLog (new Models.DynamoDb.FormRequestLog () {
	// 			RequestDt = now.ToUnixTimeMilliseconds (),
	// 			Timestamp = now.ToString ("yyyy-MM-dd HH:mm:ss:fff zzz"),
	// 			FormCd = formcd,
	// 			SourceIp = ctx.SessionStorage ().SourceIp!.ToString (),
	// 			UserAgent = ctx.SessionStorage ().UserAgent!,
	// 			Method = "POST", //ctx.Request.Method,
	// 			Protocol = ctx.Request.Protocol,
	// 			Host = ctx.Request.Host.Value,
	// 			Path = ctx.Request.Path.Value ?? "",
	// 			Querystring = ctx.Request.QueryString.HasValue ? ctx.Request.QueryString.Value : "",
	// 			Headers = headerstring,
	// 			Body = body,
	// 			Locale = locale,
	// 			TtlMeasure = now.ToUnixTimeSeconds ()
	// 		});
	// 	}

	// 	await ctx.Response.WriteAsync ("done");
	// }

	private async Task getTestPage (
		HttpContext ctx,
		string pageidentifier
	) {
		string? templatePath = null;

		switch (pageidentifier.ToLower ()) {
			case "clean":
				templatePath = "clean.html";
				break;
			case "cleanmarketinglead":
				templatePath = "cleanmarketinglead.html";
				break;
			case "cleangoback":
				templatePath = "cleangoback.html";
				break;
			case "cleaninjection":
				templatePath = "clean-injection.html";
				break;
			case "script-test":
				templatePath = "scripttest.html";
				break;
			case "loopnet":
				templatePath = "loopnet.html";
				break;
			case "loopnetspanish":
				templatePath = "loopnet-spanish.html";
				break;
			case "loopnet-with-form":
				templatePath = "loopnet-with-form.html";
				break;
			case "homes-with-mc-form":
				templatePath = "marketingcloudpage.html";
				break;
			case "marketingcloud-form-only":
				templatePath = "marketingcloud-form-only.html";
				break;
			case "str":
				templatePath = "str.html";
				break;
			case "mailto":
				templatePath = "mailto.html";
				break;
			case "pardot":
				templatePath = "pardot.html";
				break;
			case "homes":
				templatePath = "homes.html";
				break;
			case "homesdemo":
				templatePath = "homesdemo.html";
				break;
			case "costar":
				templatePath = "costar.html";
				break;
			case "tenx":
				templatePath = "tenx-inject-whole-form.html";
				break;
			case "privacy":
				templatePath = "privacy.html";
				break;
			case "apartments-grow":
				templatePath = "apartments-grow.html";
				break;
		}

		if (templatePath == null) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string fullpath = Path.Combine (templateDir, templatePath);

		if (File.Exists (fullpath) == false) {
			ctx.Response.StatusCode = 404;
			return;
		}

		string contents = File.ReadAllText (fullpath);

		contents = contents.Replace ("{{rooturl}}", Program.RootUrl);

		ctx.Response.ContentType = "text/html";
		await ctx.Response.WriteAsync (contents);
	}

	// same for the css
	// private async Task getS3Push (
	// 	HttpContext ctx
	// ) {
	// 	var files = new List<(string localpath, string remotekey)> () {
	// 		(Path.Combine (env.WebRootPath, "templates/forms/standard-lead-form.js"), "form-injection/forms/standard-lead-form"),
	// 		(Path.Combine (env.WebRootPath, "templates/css/structural-validation.css"), "form-injection/css/structural-validation"),
	// 		(Path.Combine (env.WebRootPath, "templates/forms/pardot-lead-form.js"), "form-injection/forms/pardot-lead-form"),
	// 	};

	// 	string envAcronym = getEnvironmentShortWord (EnvironmentName);

	// 	string bucketName = $"us-east-1--api-ma-platform-services-{envAcronym}";

	// 	foreach (var file in files) {
	// 		try {
	// 			pushFileToS3 (s3client, file.localpath, bucketName, file.remotekey);
	// 		} catch (Exception oops) {
	// 			await ctx.Response.WriteAsync ($"us-east-1--api-ma-platform-services-{envAcronym}\n\n" + oops.ToString ());
	// 			ctx.Response.StatusCode = (int)HttpStatusCode.OK;
	// 			return;
	// 		}
	// 	}

	// 	ctx.Response.StatusCode = (int)HttpStatusCode.OK;
	// 	return;
	// }

	private async Task getLoadCountries (
		HttpContext ctx
	) {
		var staticpath = Path.Combine (env.WebRootPath, "staticfiles");
		var datapath = Path.Combine (staticpath, "allcountries.json");

		List<CountryDefinition>? countries = JsonConvert.DeserializeObject<List<CountryDefinition>> (File.ReadAllText (datapath));

		if (countries != null && countries.Count > 0) {
			foreach (var country in countries) {
				await dynamoClient.InsertCountry3to2 (new Models.Country3to2 () {
					Three = country.Alpha3,
					Two = country.Alpha2,
					Name = country.Name
				});
				await dynamoClient.InsertCountry2to3 (new Models.Country2to3 () {
					Three = country.Alpha3,
					Two = country.Alpha2,
					Name = country.Name
				});
			}
		}
	}

	// rough duplication of https://tfs.prd.costargroup.com/CoStarCollection/CoStar%20One/_git/we-marketing-automation-jobs?path=%2Fsrc%2FJobs%2FPlatform%2FZipCodeSyncJob.cs&_a=contents&version=GBmain
	// this is really just to get the data into TSR
	// this is NOT going to be pretty
	private async Task getLoadPostalCodes (
		HttpContext ctx,
		IOpenSearchClient openSearchClient,
		IAmazonS3 s3client
	) {

		string envAcronym = getEnvironmentShortWord (EnvironmentName);

		string s3BucketName = $"us-east-1--api-ma-platform-services-{envAcronym}";

		var chunkSize = 10000;
		var specialCountries = new List<string> () {
			"CA",
			"GB",
			"NL"
		};
		// used as a cache for the map of iso2 to iso3 country codes
		var countryMap = new Dictionary<string, string> () {
			{"AW", "ABW"},
			{"AF", "AFG"},
			{"AO", "AGO"},
			{"AI", "AIA"},
			{"AL", "ALB"},
			{"AD", "AND"},
			{"AE", "ARE"},
			{"AR", "ARG"},
			{"AM", "ARM"},
			{"AS", "ASM"},
			{"TF", "ATF"},
			{"AG", "ATG"},
			{"AU", "AUS"},
			{"AT", "AUT"},
			{"AZ", "AZE"},
			{"BI", "BDI"},
			{"BE", "BEL"},
			{"BJ", "BEN"},
			{"BQ", "BES"},
			{"BF", "BFA"},
			{"BD", "BGD"},
			{"BG", "BGR"},
			{"BH", "BHR"},
			{"BS", "BHS"},
			{"BA", "BIH"},
			{"BL", "BLM"},
			{"BY", "BLR"},
			{"BZ", "BLZ"},
			{"BM", "BMU"},
			{"BO", "BOL"},
			{"BR", "BRA"},
			{"BB", "BRB"},
			{"BN", "BRN"},
			{"BT", "BTN"},
			{"BW", "BWA"},
			{"CF", "CAF"},
			{"CA", "CAN"},
			{"CC", "CCK"},
			{"CH", "CHE"},
			{"CL", "CHL"},
			{"CN", "CHN"},
			{"CI", "CIV"},
			{"CM", "CMR"},
			{"CD", "COD"},
			{"CG", "COG"},
			{"CK", "COK"},
			{"CO", "COL"},
			{"KM", "COM"},
			{"CV", "CPV"},
			{"CR", "CRI"},
			{"CU", "CUB"},
			{"CW", "CUW"},
			{"CX", "CXR"},
			{"KY", "CYM"},
			{"CY", "CYP"},
			{"CZ", "CZE"},
			{"DE", "DEU"},
			{"DJ", "DJI"},
			{"DM", "DMA"},
			{"DK", "DNK"},
			{"DO", "DOM"},
			{"DZ", "DZA"},
			{"EC", "ECU"},
			{"EG", "EGY"},
			{"ER", "ERI"},
			{"ES", "ESP"},
			{"EE", "EST"},
			{"ET", "ETH"},
			{"FI", "FIN"},
			{"FJ", "FJI"},
			{"FK", "FLK"},
			{"FR", "FRA"},
			{"FO", "FRO"},
			{"FM", "FSM"},
			{"GA", "GAB"},
			{"GB", "GBR"},
			{"GE", "GEO"},
			{"GH", "GHA"},
			{"GI", "GIB"},
			{"GN", "GIN"},
			{"GP", "GLP"},
			{"GM", "GMB"},
			{"GW", "GNB"},
			{"GQ", "GNQ"},
			{"GR", "GRC"},
			{"GD", "GRD"},
			{"GL", "GRL"},
			{"GT", "GTM"},
			{"GF", "GUF"},
			{"GU", "GUM"},
			{"GY", "GUY"},
			{"HK", "HKG"},
			{"HN", "HND"},
			{"HR", "HRV"},
			{"HT", "HTI"},
			{"HU", "HUN"},
			{"ID", "IDN"},
			{"IN", "IND"},
			{"IO", "IOT"},
			{"IE", "IRL"},
			{"IR", "IRN"},
			{"IQ", "IRQ"},
			{"IS", "ISL"},
			{"IL", "ISR"},
			{"IT", "ITA"},
			{"JM", "JAM"},
			{"JO", "JOR"},
			{"JP", "JPN"},
			{"KZ", "KAZ"},
			{"KE", "KEN"},
			{"KG", "KGZ"},
			{"KH", "KHM"},
			{"KI", "KIR"},
			{"KN", "KNA"},
			{"KR", "KOR"},
			{"KW", "KWT"},
			{"LA", "LAO"},
			{"LB", "LBN"},
			{"LR", "LBR"},
			{"LY", "LBY"},
			{"LC", "LCA"},
			{"LI", "LIE"},
			{"LK", "LKA"},
			{"LS", "LSO"},
			{"LT", "LTU"},
			{"LU", "LUX"},
			{"LV", "LVA"},
			{"MO", "MAC"},
			{"MF", "MAF"},
			{"MA", "MAR"},
			{"MC", "MCO"},
			{"MD", "MDA"},
			{"MG", "MDG"},
			{"MV", "MDV"},
			{"MX", "MEX"},
			{"MH", "MHL"},
			{"MK", "MKD"},
			{"ML", "MLI"},
			{"MT", "MLT"},
			{"MM", "MMR"},
			{"ME", "MNE"},
			{"MN", "MNG"},
			{"MP", "MNP"},
			{"MZ", "MOZ"},
			{"MR", "MRT"},
			{"MS", "MSR"},
			{"MQ", "MTQ"},
			{"MU", "MUS"},
			{"MW", "MWI"},
			{"MY", "MYS"},
			{"YT", "MYT"},
			{"NA", "NAM"},
			{"NC", "NCL"},
			{"NE", "NER"},
			// {"NE", "NES"},
			{"NG", "NGA"},
			{"NI", "NIC"},
			{"NU", "NIU"},
			{"NL", "NLD"},
			{"NO", "NOR"},
			{"NP", "NPL"},
			{"NR", "NRU"},
			{"NZ", "NZL"},
			{"OM", "OMN"},
			{"PK", "PAK"},
			{"PA", "PAN"},
			{"PN", "PCN"},
			{"PE", "PER"},
			{"PH", "PHL"},
			{"PW", "PLW"},
			{"PG", "PNG"},
			{"PL", "POL"},
			{"PR", "PRI"},
			{"KP", "PRK"},
			{"PT", "PRT"},
			{"PY", "PRY"},
			{"PS", "PSE"},
			{"PF", "PYF"},
			{"QA", "QAT"},
			{"RE", "REU"},
			{"RO", "ROU"},
			{"RU", "RUS"},
			{"RW", "RWA"},
			{"SA", "SAU"},
			{"SD", "SDN"},
			{"SN", "SEN"},
			{"SG", "SGP"},
			{"GS", "SGS"},
			{"SH", "SHN"},
			{"SB", "SLB"},
			{"SL", "SLE"},
			{"SV", "SLV"},
			{"SM", "SMR"},
			{"SO", "SOM"},
			{"PM", "SPM"},
			{"RS", "SRB"},
			{"SS", "SSD"},
			{"ST", "STP"},
			{"SR", "SUR"},
			{"SK", "SVK"},
			{"SI", "SVN"},
			{"SE", "SWE"},
			{"SZ", "SWZ"},
			{"SX", "SXM"},
			{"SC", "SYC"},
			{"SY", "SYR"},
			{"TC", "TCA"},
			{"TD", "TCD"},
			{"TG", "TGO"},
			{"TH", "THA"},
			{"TJ", "TJK"},
			{"TK", "TKL"},
			{"TM", "TKM"},
			{"TL", "TLS"},
			{"TO", "TON"},
			// {"SH", "TRS"},
			{"TT", "TTO"},
			{"TN", "TUN"},
			{"TR", "TUR"},
			{"TV", "TUV"},
			{"TA", "TWN"},
			{"TZ", "TZA"},
			{"UG", "UGA"},
			{"UA", "UKR"},
			{"UM", "UMI"},
			{"UN", "UNK"},
			{"UY", "URY"},
			{"US", "USA"},
			{"UZ", "UZB"},
			{"VA", "VAT"},
			{"VC", "VCT"},
			{"VE", "VEN"},
			{"VG", "VGB"},
			{"VI", "VIR"},
			{"VN", "VNM"},
			{"VU", "VUT"},
			{"WF", "WLF"},
			{"WS", "WSM"},
			{"YE", "YEM"},
			{"ZA", "ZAF"},
			{"ZM", "ZMB"},
			{"ZW", "ZWE"}
		};

		List<GeoNameApiS3> zipCountryUrls = new List<GeoNameApiS3> () {
			new GeoNameApiS3()
			{
				Url = "https://download.geonames.org/export/zip/allCountries.zip",
				S3Path = "postalcodes/all/",
				fileInitials = Enum.GetName(typeof(FileInitials), FileInitials.allCountries) ?? string.Empty,
			},
			new GeoNameApiS3() {
				Url = "https://download.geonames.org/export/zip/CA_full.csv.zip",
				S3Path = "postalcodes/ca/",
				fileInitials = Enum.GetName(typeof(FileInitials), FileInitials.ca_full) ?? string.Empty,
			},
			new GeoNameApiS3() {
				Url = "https://download.geonames.org/export/zip/GB_full.csv.zip",
				S3Path = "postalcodes/gb/",
				fileInitials =Enum.GetName(typeof(FileInitials), FileInitials.gb_full) ?? string.Empty,
			},
			new GeoNameApiS3() {
				Url = "https://download.geonames.org/export/zip/NL_full.csv.zip",
				S3Path = "postalcodes/nl/",
				fileInitials = Enum.GetName(typeof(FileInitials), FileInitials.nl_full) ?? string.Empty,
			}
		};

		// Step 1: Download the zip file
		foreach (var geoName in zipCountryUrls) {
			var isAllCountries = geoName.fileInitials == Enum.GetName (typeof (FileInitials), FileInitials.allCountries);
			string? fileName = null;
			using (var zipStream = await downloadZipAsync (geoName.Url)) {
				// Step 2: Unzip and upload each file directly to S3
				fileName = await unzipToS3Async (s3client, zipStream, s3BucketName, geoName);
			}

			if (string.IsNullOrEmpty (fileName) == false) {
				// Step 3: Read the text file from S3
				// Step 4: Parse the text file and convert to GeoLocationNames and save it to Elastic
				await readFileFromS3AndSaveElasticAsync (openSearchClient, s3client, s3BucketName, fileName, isAllCountries, specialCountries, countryMap, chunkSize).ConfigureAwait (false);
			}
		}

		await ctx.Response.WriteAsync ("postal codes loaded");
	}

	private static async Task<MemoryStream> downloadZipAsync (
		string url
	) {
		try {
			using (HttpClient client = new HttpClient ()) {
				var response = await client.GetAsync (url);
				response.EnsureSuccessStatusCode ();
				var zipStream = new MemoryStream ();
				await response.Content.CopyToAsync (zipStream);
				zipStream.Seek (0, SeekOrigin.Begin);  // Reset stream position for reading
				return zipStream;
			}
		} catch (Exception oops) {
			Console.WriteLine ($"failed downloadZipAsyn for url: {url} {oops.Message}");
			throw;
		}
	}
	// Unzip the file in memory and upload each entry directly to S3
	private static async Task<string> unzipToS3Async (
		IAmazonS3 s3client,
		MemoryStream zipStream,
		string bucketName,
		GeoNameApiS3 geoNames
	) {
		try {
			var fileNames = new List<string> ();
			using (var archive = new ZipArchive (zipStream, ZipArchiveMode.Read)) {
				foreach (var entry in archive.Entries) {
					if (entry.Name.EndsWith (".txt") && entry.Name.Contains (".") && entry.Name.Split ('.')[0].ToLower () == geoNames.fileInitials.ToLower ()) {
						// Upload the txt file to S3
						using (var entryStream = entry.Open ())
						using (var memoryStream = new MemoryStream ()) {
							// Memory Stream is created so that S3 knows what data size is being sent
							await entryStream.CopyToAsync (memoryStream);
							// Reset the position of the memory stream to the beginning
							memoryStream.Seek (0, SeekOrigin.Begin);

							var fileName = geoNames.S3Path + entry.Name;
							var putRequest = new PutObjectRequest {
								BucketName = bucketName,
								Key = fileName,
								InputStream = memoryStream,
								ContentType = "text/plain",
							};
							await s3client.PutObjectAsync (putRequest);
							fileNames.Add (fileName);
							Console.WriteLine ($"Uploaded {entry.Name} to S3 as {fileName}");
						}
					}
				}
			}
			return fileNames?.FirstOrDefault () ?? string.Empty;
		} catch (Exception oops) {
			Console.WriteLine ($"Failed UnzipToS3Async for Geography: {JsonConvert.SerializeObject (geoNames)}. {oops.Message}");
			throw;
		}
	}

	private static async Task readFileFromS3AndSaveElasticAsync (
		IOpenSearchClient openSearchClient,
		IAmazonS3 s3client,
		string bucketName,
		string fileName,
		bool isAllCountries,
		List<string> specialCountries,
		Dictionary<string, string> countryMap,
		int chunkSize
	) {
		try {
			var getRequest = new GetObjectRequest {
				BucketName = bucketName,
				Key = fileName
			};
			using (var response = await s3client.GetObjectAsync (getRequest))
			using (var reader = new StreamReader (response.ResponseStream)) {
				var chunk = new List<Models.OpenSearch.PostalCountry> ();
				string? line;
				int lineCount = 0;
				int chunkCount = 0;

				// Read the file line by line
				while ((line = await reader.ReadLineAsync ()) != null) {
					// Split the line into fields
					var parts = line.Split ('\t');
					if (parts.Length >= 3) {
						if (isAllCountries && specialCountries.Contains (parts[0].Trim ())) {
							continue;
						}

						// ISO2 country code in lowercase
						string iso2Code = parts[0].Trim ().ToLower ();

						// Check if the dictionary contains the key
						if (countryMap.TryGetValue (iso2Code.ToUpper (), out string? iso3Code) == false) {
							// Console.WriteLine ($"The ISO3 code for '{iso2Code}' was not found.");
							// iso3Code = parts[0].Trim ().ToUpper ();
							// countryMap.Add (iso2Code, iso3Code);
							Console.WriteLine ($"The ISO3 code for '{iso2Code}' was not found, skipping");
							continue;
						}

						// permutations to see if i can match what's in opensearch already
						var alllower = generateId ($"{parts[0].ToLower ().Trim ()} {parts[1].ToLower ().Trim ()}", string.Empty);
						var allupper = generateId ($"{parts[0].ToUpper ().Trim ()} {parts[1].ToUpper ().Trim ()}", string.Empty);
						var lowerupper = generateId ($"{parts[0].ToLower ().Trim ()} {parts[1].ToUpper ().Trim ()}", string.Empty);
						var upperlower = generateId ($"{parts[0].ToUpper ().Trim ()} {parts[1].ToLower ().Trim ()}", string.Empty);

						var location = new Models.OpenSearch.PostalCountry {
							PostalCountryCd = generateId ($"{parts[0].Trim ()} {parts[1].Trim ()}", string.Empty),
							CountryCd = iso3Code,
							PostalCd = parts[1].Trim (),
							Name = parts[2].Trim ()
						};
						chunk.Add (location);
						lineCount++;
					}

					// Process the chunk when it reaches 10,000 lines
					if (lineCount >= chunkSize) {
						chunkCount++;
						// Step 4: Save the 10k Zip Codes to Elasticsearch, process chunk
						// await indexToElasticsearchAsync (openSearchClient, chunk, fileName).ConfigureAwait (false);
						await openSearchClient.WritePostalCodes (chunk);
						Console.WriteLine ($"Processed Chunk Count: {chunkCount}");
						// Process and send to Elasticsearch or convert to JSON
						chunk.Clear ();
						// Clear the chunk for the next batch
						lineCount = 0;
						// Reset line count
					}
				}

				// Process any remaining lines that didn't complete a full chunk
				if (chunk.Count > 0) {
					chunkCount++;
					// await indexToElasticsearchAsync (openSearchClient, chunk, fileName).ConfigureAwait (false);
					await openSearchClient.WritePostalCodes (chunk);
					Console.WriteLine ($"Processed Chunk Count: {chunkCount}");
				}
			}
		} catch (Exception oops) {
			Console.WriteLine ($"Failed readFileFromS3AndSaveElasticAsync for bucket: {bucketName} and file name: {fileName}. {oops.Message}");
			throw;
		}
	}
	// private static async Task indexToElasticsearchAsync (
	// 	OpenSearchClient openSearchClient,
	// 	List<Models.OpenSearch.PostalCountry> locations,
	// 	string fileName
	// ) {
	// 	// Index each location into Elasticsearch
	// 	var indexResponse = await _elasticClient.BulkAsync (b => b.Index ("ma-zipcodes.writer")
	// 		.UpdateMany (locations,
	// 		(descriptor, doc) => descriptor.Id (doc.Id).Doc (doc).DocAsUpsert (true))
	// 	);
	// 	if (!indexResponse.IsValid) {
	// 		Console.WriteLine ($"Failed to Update Elastic Between {locations.FirstOrDefault ()} and {locations.LastOrDefault ()}");
	// 		Console.WriteLine ($"Failed to Bulk Upsert for Location: {fileName} and info: {indexResponse.DebugInformation}");
	// 		foreach (var itemWithError in indexResponse.ItemsWithErrors) {
	// 			Console.WriteLine ($"DocumentId: {itemWithError.Id} failed: {itemWithError.Error.Reason}");
	// 		}
	// 		throw new InvalidOperationException ($"Failed to index zip for locations: {indexResponse.OriginalException.Message}");
	// 	}
	// }
	// Generate a consistent ID based on input string and salt
	private static string generateId (
		string input,
		string salt
	) {
		try {
			// Concatenate input string with salt
			var saltedInput = input + salt;
			// Id size
			var length = 8;
			// Convert the concatenated string to bytes
			using (SHA256 sha256Hash = SHA256.Create ()) {
				// Compute the hash
				byte[] bytes = sha256Hash.ComputeHash (Encoding.UTF8.GetBytes (saltedInput));
				// Convert byte array to a hexadecimal string
				StringBuilder builder = new StringBuilder ();
				for (int i = 0; i < length; i++) {
					builder.Append (bytes[i].ToString ("x2"));
				}
				// Return the hexadecimal string
				return builder.ToString ();
			}

		} catch (Exception oops) {
			Console.WriteLine ($"Failed to generateId for input: {input}. {oops.Message}");
			throw;
		}
	}

	private async Task getPostgresqlTest (
		HttpContext ctx
	) {
		// realllly rough pg test
		var connectionStrings = config.GetSection ("ConnectionStrings").Get<Models.ConnectionStrings> ();

		if (connectionStrings == null) {
			await ctx.Response.WriteAsync ("no connection strings found in appsettings");
			return;
		}

		if (string.IsNullOrEmpty (connectionStrings.PgMktSupport)) {
			await ctx.Response.WriteAsync ("no connection string found for postgresql mksupport");
			return;
		}

		if (env.IsDevelopment ()) {
			try {
				var dvm = ConnectionPropertyBag.Parse (connectionStrings.PgMktSupport, DatabaseType.Postgresql);
				dvm.Name = "dvm";

				ConnectionManager.Instance.AddConnection (dvm);

				var serverTime = new Connect (dvm.Name).Query ("select now() as now;").Go<DateTimeOffset?> ((cmd) => {
					using (var dr = cmd.ExecuteReader ()) {
						ArgumentNullException.ThrowIfNull (cmd.DRH);
						if (dr.Read ()) {
							return cmd.DRH.GetDateTimeOffset ("now");
						}

						return null;
					}
				});

				if (serverTime != null) {
					await ctx.Response.WriteAsync ($"server time : {serverTime}");
				}
				await ctx.Response.WriteAsync ($"server time : nothing returned");
				return;
			} catch (Exception oops) {
				await ctx.Response.WriteAsync ($"error testing postgresql : {oops.ToString ()}");
				return;
			}
		}

		await ctx.Response.WriteAsync ("nothing to see here");
	}

	private async Task getMssqlTest (
		HttpContext ctx
	) {
		// realllly rough test for the 631 server
		var connectionStrings = config.GetSection ("ConnectionStrings").Get<Models.ConnectionStrings> ();

		if (connectionStrings == null) {
			await ctx.Response.WriteAsync ("no connection strings found in appsettings");
			return;
		}

		if (string.IsNullOrEmpty (connectionStrings.MsMarketingSupport)) {
			await ctx.Response.WriteAsync ("no connection string found for Sql Server Marketingsupport");
			return;
		}

		await ctx.Response.WriteAsync ("nothing to see here");
	}


	private static string getEnvironmentShortWord (
		string environmentName
	) {
		if (environmentName == "local" || environmentName.StartsWith ("d")) {
			environmentName = "dvm";
		} else if (environmentName.StartsWith ("t")) { // tst.main vs tst.rele
			if (environmentName.Contains ("main")) {
				environmentName = "tsm";
			} else if (environmentName.Contains ("rele")) {
				environmentName = "tsr";
			} else {
				environmentName = "tsm";
			}
		}

		return environmentName;
	}

	private static void pushFileToS3 (
		IAmazonS3 s3client,
		string localpath,
		string bucketName,
		string key
	) {
		if (!File.Exists (localpath)) {
			throw new FileNotFoundException ($"file does not exist - exiting upload.\n{localpath}");
		}

		try {
			var putobject = s3client.PutObjectAsync (new Amazon.S3.Model.PutObjectRequest () {
				BucketName = bucketName,
				ContentBody = File.ReadAllText (localpath),
				Key = key
			}).Result;
		} catch (Exception) {
			throw;
		}
	}
}

public class CountryDefinition
{
	[Newtonsoft.Json.JsonProperty ("name")]
	public required string Name { get; set; }

	[Newtonsoft.Json.JsonProperty ("alpha-3")]
	public required string Alpha3 { get; set; }

	[Newtonsoft.Json.JsonProperty ("alpha-2")]
	public required string Alpha2 { get; set; }
}

public class GeoNameApiS3
{
	public required string Url { get; set; }
	public required string S3Path { get; set; }
	public required string fileInitials { get; set; }
}

public enum FileInitials
{
	allCountries,
	ca_full,
	gb_full,
	nl_full
}
