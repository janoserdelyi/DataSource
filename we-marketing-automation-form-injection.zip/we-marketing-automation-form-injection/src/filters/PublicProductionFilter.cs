using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Net;

namespace WeMarketingAutomationFormInjection.Filters;

public class PublicProductionFilter : IEndpointFilter
{

	private readonly IWebHostEnvironment env;
	//private readonly static string publicProductionHostname = "ma-platform-services.costar.com";

	public PublicProductionFilter (
		IWebHostEnvironment env
	) {
		this.env = env;
	}

	public async ValueTask<object?> InvokeAsync (
		EndpointFilterInvocationContext context,
		EndpointFilterDelegate next
	) {
		var ctx = context.HttpContext;

		// turns out the way requests are routed through Akamai, the host header is changed to the internal dns name, so this check doesn't work
		// if (env.IsProduction () && ctx.Request.Host.Host.ToLower () == publicProductionHostname) {
		// 	ctx.Response.StatusCode = (int)HttpStatusCode.NotFound;
		// 	return Results.NotFound ();
		// }

		// but Jesse is awesome and added this for me so that i can distinguish internal from external production calls. thanks, Jesse!
		// akamaiheader: true (it's returning true,true for some reason)
		// also adding a way for us to see it if we need it
		if (env.IsProduction () && ctx.Request.Headers.ContainsKey ("akamaiheader")) {

			if (ctx.Request.Headers.ContainsKey ("x-allow-devops") == false) {
				ctx.Response.StatusCode = (int)HttpStatusCode.NotFound;
				return Results.NotFound ();
			}

		}

		return await next (context);
	}
}