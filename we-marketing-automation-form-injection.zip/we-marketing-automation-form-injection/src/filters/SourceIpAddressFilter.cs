using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

namespace WeMarketingAutomationFormInjection.Filters;

public class SourceIpAddressFilter : IEndpointFilter
{
	private readonly IWebHostEnvironment env;

	public SourceIpAddressFilter (
		IWebHostEnvironment env
	) {
		this.env = env;
	}

	public async ValueTask<object?> InvokeAsync (
		EndpointFilterInvocationContext context,
		EndpointFilterDelegate next
	) {
		// i really only need to protect production
		if (env.IsProduction () == false) {
			return await next (context);
		}

		var ctx = context.HttpContext;

		// and really, just publicly-accessible production
		if (ctx.Request.Headers.ContainsKey ("akamaiheader") == false) {
			return await next (context);
		}

		if (ctx.SessionStorage ().SourceIp == null || Program.AllowedIps!.ContainsKey (ctx.SessionStorage ().SourceIp!) == false) {
			ctx.Response.StatusCode = 403;
			await ctx.Response.AsJson (new { Success = false, Message = $"Invalid request source ({ctx.SessionStorage ().SourceIp})" });
			return Results.Forbid ();
		}

		return await next (context);
	}
}