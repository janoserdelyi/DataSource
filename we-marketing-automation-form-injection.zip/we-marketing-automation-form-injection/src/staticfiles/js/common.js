
// for importing you may wish to do something like :
// import * as Common from '/templates/test/js/common.js';
// and use like :
// Common.binder.bind();

export let binder = function () {

	let transforms;

	return {
		addTransform: function (
			name, // name of the function
			func // function call itself. it takes one param - the value
		) {
			if (!transforms) {
				transforms = {};
			}

			transforms[name] = func;
		},
		bind: function (
			targets, // html nodes to operate on
			bindingObject // the javascript object containing the properties and values we want
		) {

			// this should be passed in
			//let targets = document.getElementsByClassName("databound");
			//console.log(targets);

			for (const target of targets) {
				// we need to know what we're operating on. (and that it even exists)
				let prop = target.dataset["bind"];

				if (!prop) {
					continue;
				}

				let val = undefined;

				if (prop.indexOf('.') > -1) {
					val = prop.split('.').reduce((acc, part) => acc && acc[part], bindingObject);
				} else {
					val = bindingObject[prop];
				}

				// going to move this below the transforms so that they can deal with the undefined
				//if (val === undefined) {
				//	continue;
				//}

				// transform the data if there are directives to do so
				let transprop = target.dataset["transforms"];

				if (transprop) {
					// the can be comma-separated
					let ts = transprop.split(',');

					for (const transform of ts) {
						val = transforms[transform](val);
					}
				}

				if (val === undefined) {
					continue;
				}

				switch (target.tagName.toLowerCase()) {
					case "input" :
						switch (target.type) {
							case "text" :
							case "hidden" :
							case "tel" :
							case "number" :
							case "email" :
							case "url" :
							case "date" :
								target.value = val;
								break;
							case "radio" :
								if (Array.isArray(val)) {
									// i'd like to use Array.includes() but it's a strict compare
									target.checked = (val.find(el => el.toString() === target.value.toString())) !== undefined;
								} else {
									if (val === null) {
										val = "";
									}
									target.checked = (target.value.toString() === val.toString());
								}
								break;
							case "checkbox" :
								if (Array.isArray(val)) {
									// i'd like to use Array.includes() but it's a strict compare
									target.checked = (val.find(el => el.toString() === target.value.toString())) !== undefined;
								} else {
									if (val === null) {
										val = "";
									}
									target.checked = (target.value.toString() === val.toString());
								}
								break;
						}
						break;
					case "textarea" :
						target.value = val;
						break;
					case "select" :
						target.value = val;
						break;
					case "img" :
						target.src = val || "";
						break;
					case "a" :
						// a hack, but handy. the value can be comma separated. [0] = anchor, [1] = link visual value
						// otherwise it's the anchor
						let vals = val.split(',');
						target.href = vals[0];
						if (vals.length > 1) {
							// the value could have commas.. so join in back together, minus the first element
							target.textContent = vals.slice(1).join(',');
						}
						break;
					default :
						// i just handled how the binding works based on tag, but added attributes could be used to define too
						// for example :
						// target.setAttribute(target.dataset["bindattr"], val);
						// or
						// target[target.dataset["bindattr"]] = val;
						// checking that bindattr exists first of course
						target.innerHTML = val;
						break;
				}
			}

		}
	}
}();

// assuming an import like :
// import * as Common from '/templates/test/js/common.js';
// use :
// Common.formObj.load(document.getElementById("some-container-id"));
// for individual elements, if you what the resultant js object to have different property names than the form element names, use data-bindingname="the-name-you-want"
// you can also inform the datatype with data-strict-type="int" for example

export let formObj = function () {
	"use strict";

	function formToArray (
		form,
		includeUncheckedRadioCheckbox = false
	) {
		return inputsToArray(form.querySelectorAll("input, textarea, select, [contenteditable=true]"), includeUncheckedRadioCheckbox);
	}

	function collectionToArray (
		collection,
		includeUncheckedRadioCheckbox = false
	) {
		return inputsToArray(collection, includeUncheckedRadioCheckbox);
	}

	function inputsToArray (
		inputs,
		includeUncheckedRadioCheckbox = false
	) {
		let arr = [];

		for (let i=0; i<inputs.length; i++) {
			let input = inputs[i];
			let name = input.dataset["bindingname"] || input.name || input.dataset["name"];
			let val = input.dataset["bindingvalue"] || input.value;

			if (!name || ((input.type === 'checkbox' || input.type === 'radio') && !input.checked && !includeUncheckedRadioCheckbox)) {
				continue;
			}

			if (input.getAttribute('contenteditable') === 'true') {
				val = input.innerHTML;
			}

			let dataType = input.dataset["strictType"];

			if (dataType !== undefined) {
				val = coerceType(dataType, val);
			}

			arr.push({
				name: name,
				bindingname: input.dataset["bindingname"],
				value: val
			});
		}

		return arr;
	}

	function coerceType (
		dataType,
		val
	) {
		switch (dataType.toLowerCase()) {
			case "string" :
				return val.toString();
			case "nullstring" : // if a string is empty, return null basically
				if (val == "") {
					return null;
				}
				if (val.toString().trim() == "") {

				}
				return val.toString();
			case "int" :
			case "integer" :
			case "number" :
				// i may regex this to remove non-digits first because parseInt acts funny imo
				if (val != null && val.length > 0) {
					val = val.replace(/[^\d\.\-]+/g, "");
				}
				val = parseInt(val, 10); // i'm going to go ahead and assume a base10 radix. this could be another data attribute too
				if (isNaN(val)) {
					val = null;
				}
				return val;
			case "decimal" :
			case "float" :
				if (val === "") {
					return null;
				}
				val = parseFloat(val);
				if (isNaN(val)) {
					val = null;
				}
				return val;
			case "bool" :
			case "boolean" :
				switch (val.toString().toLowerCase()) {
					case "true" :
					case "on" :
					case "1" :
						return true;
					case "false" :
					case "off" :
					case "0" :
						return false;
					default :
						return val;
				}
			case "date" :
				let d = new Date(val);
				if (d instanceof Date && !isNaN(d.valueOf())) {
					return val;
				}
				return null;
			// TODO: add timestamp
			default:
				return val;
		}
	}

	function isPrimitive (test) {
		return test !== Object(test);
	}

	function addProp (
		o,
		prop,
		val
	) {
		let props = prop.split('.');
		let lastProp = props.length - 1;

		//console.log("addProp - o, prop, val : "); console.log(o); console.log(prop); console.log(val);

		//props.reduce(function (obj, prop, i) { // console.log("set prop obj and props : "); console.log(obj); console.log(props);
		//	return setProp(obj, prop, i === lastProp ? val : {});
		//}, o);

		props.reduce(function (obj, prop, i) {
			return setProp(obj, prop, i === lastProp ? val : {}, i === lastProp);
		}, o);
	}

	function setProp (
		obj,
		name,
		val,
		lastProp
	) {
		// short-cutting some things. this works well for flat and nested regular properties
		// it is screwing over checkboxes though
		//if (obj[name] !== undefined) {
		//	console.log(name  + " is array? " + Array.isArray(obj[name]));
		//	return obj[name];
		//}

		if (obj[name] !== undefined && lastProp !== true) {
			return obj[name];
		}

		if (name.slice(-2) === "[]") {
			makeArray(obj, name).push(val);
		} else if (obj[name] !== undefined) {

			//console.log("val : " + val  + " isPrimitive? " + isPrimitive(val));
			// this was just :
			// return obj[name];

			// but i think if the object key already exists, the value should be converted to an array and new values pushed in

			if (Array.isArray(obj[name])) {
				obj[name].push(val);
			} else {
				let arr = [];
				arr.push(obj[name]);
				arr.push(val);
				obj[name] = arr;
			}

			return val;
		} else if (name[name.length - 1] === "]") {
			let arr = makeArray(obj, name);

			if (arr.prevName === name) {
				return arr[arr.length - 1];
			}

			arr.push(val);
			arr.prevName = name;
		} else {
			obj[name] = val;
		}

		return val;
	}

	function makeArray (
		obj,
		name
	) {
		let arrName = name.replace(/\[\d*\]/, '');
		return (obj[arrName] || (obj[arrName] = []));
	}

	function getObjectValue (
		obj
	) {

		if (obj instanceof Node) {
			let o = null;

			// unchecked checkboxes and radios should not return a value
			if ((obj.type == "checkbox" || obj.type == "radio") && obj.checked == false) {
				return "";
			}

			if (obj.tagName == "SELECT") {
				o = obj;
			}

			// this does not work properly for selects. the length is the number of options
			if (o == null && obj.length === undefined) {
				o = obj;
			}

			if (o == null) {
				o = obj[0];
			}

			let dataType = o.dataset["strictType"];

			if (dataType) {
				return coerceType(dataType, o.value);
			}

			return o.value;
		}

		return null;
	}

	return {
		load: function (
			form, // expecting a form object, not an id. well really any object. just needs to contain form elements
			includeUncheckedRadioCheckbox = false // careful. you almost never want this to be true. true is really just for gathering all form elements in the form into this object. the values become suspect
		) {
			let fields = formToArray(form, includeUncheckedRadioCheckbox);

			fields.sort(function (a, b) {
				return a.name.localeCompare(b.name);
			});

			return fields.reduce(function (obj, field) {
				addProp(obj, (field.bindingname || field.name), field.value);
				return obj;
			}, {});
		},
		loadObjectCollection: function (
			collection,
			includeUncheckedRadioCheckbox = false // careful. you almost never want this to be true. true is really just for gathering all form elements in the form into this object. the values become suspect
		) {
			let fields = collectionToArray(collection, includeUncheckedRadioCheckbox);

			fields.sort(function (a, b) {
				return a.name.localeCompare(b.name);
			});

			return fields.reduce(function (obj, field) {
				addProp(obj, (field.bindingname || field.name), field.value);
				return obj;
			}, {});
		},
		val: function (identifierOrObj) {
			//console.log("identifierOrObj : ");
			//console.log(identifierOrObj);

			if (typeof(identifierOrObj) != "string") {
				if (identifierOrObj instanceof Node) {
					return getObjectValue(identifierOrObj);
				}
				if (identifierOrObj instanceof NodeList) {
					console.log("UNHANDLED CONDITION : formObj.val() does not accept NodeLists at this time");
					return null;
				}
			}

			let field = document.getElementById(identifierOrObj);

			// single item (ie: not radio or checkbox group)
			if (field && field instanceof Node) {
				return getObjectValue(field);
			}

			if (!field) {
				field = document.getElementsByName(identifierOrObj);
			}

			if (field && field instanceof NodeList) {

				let arr = Array.from(field).map(function(x){
					return getObjectValue(x);
				}).filter(function(x){
					if (x) {
						return x;
					}
				});

				return arr;
			}

			return null;
		}
	};
}();

/*

with a table id of "FooTable"
Common.tableSort.addTable(document.getElementById("FooTable"));

decorate table header cells with the sorter you wish to sort by
4 are included : case-insensitive text (default), case-sensitive text, integer, float
<th data-sort="integer">cool numbers</th>

decorate body cells with data to use if it's different from the display value. example might be
some formatted currency or some contorted date format
<td data-sortdata="12345">$12,345</td>

example adding a really rough date sorter
Common.tableSort.addSorter("date", function(a, b, asc) {
	let dirmod = asc ? 1 : -1;
	return Date.parse(a) > Date.parse(b) ? (1 * dirmod) : (-1 * dirmod);
});

2021-08-23 with the advent of display:contents; some display:grid; table implementations
have gotten far more sane

now accepting this structure :

<div id="TestTableGrid" class="table">
	<div class="trow header">
		<div>id</div>
		<div>name</div>
		<div>date</div>
		<div data-sort="float">foo</div>
		<div>bar</div>
	</div>

	<div class="tbody">
		<div class="trow">
			<div class="numeral">1</div>
			<div>Fred Jones</div>
			<div>2021-08-03</div>
			<div class="numeral" data-sortdata="1000000">1,000,000</div>
			<div>glarble</div>
		</div>

		<div class="trow">...
		<div class="trow">...
		<div class="trow">...
	</div>
</div>

2023-07-12 added configOptions. i wanted to be able to extend this
initially for a pre-sort event - the config.preSortEvent(tableObject) signature takes the top-level table object
*/
export let tableSort = function () {
	let initialized = false;
	let sorts = {};
	let tables = [];

	function getTextData (el) {
		if (el.dataset["sortdata"]) {
			return el.dataset["sortdata"].trim();
		}
		return el.textContent.trim();
	}

	function sorterbase (sortFunc, tableIndex, columnIndex, asc = true) {
		let dirmod = asc ? 1 : -1;

		let sorted = [];

		if (tables[tableIndex].isTable) {
			sorted = tables[tableIndex].rows.sort(function(a, b) {
				let atext = getTextData(a.querySelector(`td:nth-child(${(columnIndex + 1)})`)); //`
				let btext = getTextData(b.querySelector(`td:nth-child(${(columnIndex + 1)})`)); //`

				return sortFunc(atext, btext, asc);
			});
		} else {
			sorted = tables[tableIndex].rows.sort(function(a, b) {
				let atext = getTextData(a.querySelector(`:scope > *:nth-child(${(columnIndex + 1)})`)); //`
				let btext = getTextData(b.querySelector(`:scope > *:nth-child(${(columnIndex + 1)})`)); //`

				return sortFunc(atext, btext, asc);
			});
		}

		while (tables[tableIndex].tbody.firstChild) {
			tables[tableIndex].tbody.removeChild(tables[tableIndex].tbody.firstChild);
		}

		tables[tableIndex].tbody.append(...sorted);
	}

	function sortAlphaCaseInsensitive (a, b, asc) {
		let dirmod = asc ? 1 : -1;
		return a.toLowerCase() > b.toLowerCase() ? (1 * dirmod) : (-1 * dirmod);
	}

	function sortAlphaCaseSensitive (a, b, asc) {
		let dirmod = asc ? 1 : -1;
		return a > b ? (1 * dirmod) : (-1 * dirmod);
	}

	function sortInteger (a, b, asc) {
		let dirmod = asc ? 1 : -1;
		return parseInt(a) > parseInt(b) ? (1 * dirmod) : (-1 * dirmod);
	}

	function sortFloat (a, b, asc) {
		let dirmod = asc ? 1 : -1;
		return parseFloat(a) > parseFloat(b) ? (1 * dirmod) : (-1 * dirmod);
	}

	function sortDate (a, b, asc) {
		let dirmod = asc ? 1 : -1;
		return Date.parse(a) > Date.parse(b) ? (1 * dirmod) : (-1 * dirmod);
	};

	return {
		addTable: function (
			tableElement,
			addSumFooter,
			configOptions
		) {

			if (addSumFooter === undefined) {
				addSumFooter = false;
			}

			configOptions = configOptions || {};

			let isTable = false;

			if (initialized !== true) {
				tableSort.addSorter("alphaany", sortAlphaCaseInsensitive);
				tableSort.addSorter("alphacase", sortAlphaCaseSensitive);
				tableSort.addSorter("integer", sortInteger);
				tableSort.addSorter("float", sortFloat);
				tableSort.addSorter("currency", sortFloat);
				tableSort.addSorter("date", sortDate);

				initialized = true;
			}

			if (!tableElement || !tableElement instanceof Node) {
				console.log("wrong type of object for table sort");
				console.log(tableElement);
				return;
			}

			isTable = tableElement.tagName.toLowerCase() === "table";

			if (!isTable && !tableElement.classList.contains("table")) {
				console.log("expecting a table or a table grid for table sort");
				console.log(tableElement);
				return;
			}

			let idx = tables.length;

			tables[idx] = {
				isTable : isTable,
				t: tableElement,
				config: configOptions
			};

			if (isTable) {
				tables[idx].tbody = tableElement.querySelector("tbody");
				tables[idx].rows = Array.from(tables[idx].tbody.querySelectorAll("tr"));

				tables[idx].t.querySelectorAll("thead tr th").forEach(function(o){
					o.addEventListener("click", tableSort.sort);
					if (!o.dataset["sortdir"]) {
						o.dataset["sortdir"] = "asc";
					}
					o.dataset["tableidx"] = idx;
				});
			} else {
				tables[idx].tbody = tableElement.querySelector(".tbody");
				tables[idx].rows = Array.from(tables[idx].t.querySelectorAll(":scope > .tbody > .trow:not(.header)"));

				tables[idx].t.querySelectorAll(".trow.header > *").forEach(function(o){
					o.addEventListener("click", tableSort.sort);
					if (!o.dataset["sortdir"]) {
						o.dataset["sortdir"] = "asc";
					}
					o.dataset["tableidx"] = idx;
				});

				if (addSumFooter === true) {

					// get the first row
					let firstrow = tables[idx].rows[0];

					if (!(firstrow === undefined || firstrow === null) && firstrow.children !== undefined) {
						let f = `<div class="tfooter">${([...firstrow.children].map(function(el, ix){

							let sorttype = el.dataset["sort"];

							if (sorttype !== undefined && (sorttype === "integer" || sorttype === "float" || sorttype === "currency")) {

								// this feels heavy, but let's do it
								// run through the rows, summing the row sortdata for the row index in question

								let sum = tables[idx].rows.reduce(function(acc, arr){
									let cell = arr.children[ix];
									let sortdata = cell.dataset["sortdata"];
									if (sortdata === undefined) {
										console.log("data-sortdata is required for the sum column");
										return acc;
									}
									// it can be the text "null" sometimes. yeah let's not
									if (sortdata === "null") {
										return acc;
									}
									if (sorttype === "integer") {
										return acc + parseInt(sortdata);
									}
									if (sorttype === "float" || sorttype === "currency") {
										return acc + parseFloat(sortdata);
									}
									return acc;
								}, 0);

								if (sorttype === "currency") {
									return `<div class="numeral">${sum.toUSD(2)}</div>`;
								}
								return `<div class="numeral">${sum}</div>`;
							}
							return '<div></div>';
						}).join(''))}</div>`;

						let temp = document.createElement('template');
						temp.innerHTML = f;

						tables[idx].t.appendChild(temp.content);
					}
				}
			}

			tables[idx].t.classList.add("tablesort");
		},
		sort : function (e) {
			let ct = e.currentTarget;
			let idx = ct.dataset["tableidx"];

			if (!idx) {
				return;
			}

			idx = parseInt(idx);

			if (!tables[idx]) {
				return;
			}

			if (tables[idx].config.preSortEvent !== undefined && typeof(tables[idx].config.preSortEvent) === "function") {
				tables[idx].config.preSortEvent(tables[idx].t);
			}

			let sorter = null;

			sorter = ct.dataset["sort"] || "alphaany";

			if (sorts[sorter]) {
				let columnIndex = tables[idx].isTable ? ct.cellIndex : Array.prototype.indexOf.call(ct.parentNode.children, ct);

				sorterbase(sorts[sorter], idx, columnIndex, (ct.dataset["sortdir"] === "asc"));

				if (ct.dataset["sortdir"] === "asc") {
					ct.dataset["sortdir"] = "desc"
				} else {
					ct.dataset["sortdir"] = "asc"
				}
			}

		},
		addSorter: function (sortName, sortFunc) {
			if (typeof(sortFunc) !== "function") {
				return;
			}
			sorts[sortName] = sortFunc;
		}
	}
}();

// 'f' is the number of decimal points you want. defaults to zero
// String.prototype.toUSD = function (f) {
// 	let s = this;

// 	if (s === undefined || s === null || s === "") {
// 		return "";
// 	}
// 	f = f || 0;

// 	s = parseFloat(s);

// 	return s.toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits:f, maximumFractionDigits: f})
// };
// Number.prototype.toUSD = function (f) {
// 	let n = this;

// 	f = f || 0;

// 	return n.toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits:f, maximumFractionDigits: f})
// };
// Number.prototype.toPercent = function (f) {
// 	let n = this;

// 	f = f || 0;

// 	return n.toLocaleString("en-US", {style: "percent", minimumFractionDigits:f, maximumFractionDigits: f})
// };

Number.prototype.toFriendlyFileSize = function (f) {
	let size = this;

	f = f || 0;

	let sizes = [ "B", "KiB", "MiB", "GiB", "TiB" ];
	let order = 0;
	while (size >= 1024 && order < sizes.length - 1) {
		order++;
		size = size / 1024;
	}

	return size.toFixed(f) + sizes[order];
};

// String.prototype.toInt = function (radix) {

// 	if (radix === undefined) {
// 		radix = 10;
// 	}

// 	let val = this.toString();

// 	let res = parseInt(val, radix);

// 	if (isNaN(res)) {
// 		return val;
// 	}

// 	return res;
// };

// // this is simply to avoid errors, though i could use it to squash decimals to integers
// Number.prototype.toInt = function (radix) {
// 	return this;
// };