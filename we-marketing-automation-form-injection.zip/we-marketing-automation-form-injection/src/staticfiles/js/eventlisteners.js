// credit to https://github.com/colxi/getEventListeners/blob/master/src/getEventListeners.js with some alterations and additions
(function() {
	'use strict';

	console.log("eventlisteners.js loaded");


	// save the original methods before overwriting them
	Element.prototype._addEventListener = Element.prototype.addEventListener;
	Element.prototype._removeEventListener = Element.prototype.removeEventListener;

	Element.prototype.addEventListener = function (type, listener, useCapture=false ) {

		// declare listener
		this._addEventListener (type, listener, useCapture);

		if (!this.eventListenerList) {
			this.eventListenerList = {/*test*/};
		}
		if (!this.eventListenerList[type]) {
			this.eventListenerList[type] = [];
		}

		// if (type == "input" && this.nodeName == "FORM") {
		// 	console.log("adding input event to nodeName : " + this.nodeName);
		// }

		// add listener to event tracking list
		this.eventListenerList[type].push( {type, listener, useCapture} );

		let addEventEvent = new CustomEvent("eventAdded", {
			detail: { element: this, eventType: type, eventListener: listener },
			bubbles: false,
			cancelable: false
		});

		// console.log(`dispatching event 'eventAdded' ${type} on a ${this.nodeName}`);
		window.dispatchEvent(addEventEvent);
	};

	Element.prototype.removeEventListener = function (type, listener, useCapture=false) {
		// remove listener
		this._removeEventListener (type, listener, useCapture);

		if (!this.eventListenerList) {
			this.eventListenerList = {};
		}
		if (!this.eventListenerList[type]) {
			this.eventListenerList[type] = [];
		}

		// Find the event in the list, If a listener is registered twice, one
		// with capture and one without, remove each one separately. Removal of
		// a capturing listener does not affect a non-capturing version of the
		// same listener, and vice versa.
		for (let i = 0; i < this.eventListenerList[type].length; i++){
			if (
				this.eventListenerList[type][i].listener === listener &&
				this.eventListenerList[type][i].useCapture === useCapture
			) {
				this.eventListenerList[type].splice(i, 1);
				break;
			}
		}

		// if no more events of the removed event type are left, remove the group
		if (this.eventListenerList[type].length == 0) {
			delete this.eventListenerList[type];
		}

		// if jQuery is loaded, i want to remove those events also
		if (window.jQuery) {
			window.jQuery(this).off(type);
		}
	};

	// find all listeners by type and remove them
	Element.prototype.removeEventListenersByType = function (type) {

		if (!this.eventListenerList) {
			this.eventListenerList = {};
		}
		if (!this.eventListenerList[type]) {
			this.eventListenerList[type] = [];
		}

		// Find the event in the list, If a listener is registered twice, one
		// with capture and one without, remove each one separately. Removal of
		// a capturing listener does not affect a non-capturing version of the
		// same listener, and vice versa.
		for (let i = 0; i < this.eventListenerList[type].length; i++){

			// remove listener
			this._removeEventListener (
				type,
				this.eventListenerList[type][i].listener,
				this.eventListenerList[type][i].useCapture
			);
		}

		// remove the group of events of this type
		delete this.eventListenerList[type];

		// if jQuery is loaded, i want to remove those events also
		if (window.jQuery) {
			window.jQuery(this).off(type);
		}
	};


	Element.prototype.getEventListeners = function (type) {
		if(!this.eventListenerList) {
			this.eventListenerList = {};
		}

		// return requested listeners type or all them
		if (type === undefined) {
			return this.eventListenerList;
		}

		return this.eventListenerList[type];
	};


	/*
	Element.prototype.clearEventListeners = function(a){
		if(!this.eventListenerList)
			this.eventListenerList = {};
		if(a==undefined){
			for(var x in (this.getEventListeners())) this.clearEventListeners(x);
			return;
		}
		var el = this.getEventListeners(a);
		if(el==undefined)
			return;
		for(var i = el.length - 1; i >= 0; --i) {
			var ev = el[i];
			this.removeEventListener(a, ev.listener, ev.useCapture);
		}
	};
	*/

})();