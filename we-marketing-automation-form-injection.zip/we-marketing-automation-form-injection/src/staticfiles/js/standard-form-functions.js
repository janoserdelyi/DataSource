
export let standardFormUtils = function () {

	// see if there is a "fullName" property. if so, attempt to create a firstName and LastName (provided they don't exist)
	function splitFullName (payload) {

		if (payload.fullName === undefined) {
			return payload;
		}

		// if there are no spaces, set the first name
		let fullname = payload.fullName.trim();

		if (fullname === "") {
			return payload;
		}

		let parts = fullname.split(' ');

		if (parts.length < 2) {
			payload.firstName = parts[0];
			return payload;
		}

		// take the last element in the parts array, make that the last name and everything else is the first name
		payload.lastName = parts[parts.length-1];
		payload.firstName = parts.slice(0,parts.length-1).join(' ');

		return payload;
	}

	function addHiddenFieldIfNotExists (
		formElement,
		elementName,
		elementValue = ""
	) {
		if (!formElement) {
			return;
		}

		let localeInput = formElement.querySelector(`input[data-bindingname=${elementName}]`);

		if (!localeInput) {
			let d = document.createElement("input");
			d.setAttribute("type", "hidden");
			d.setAttribute("value", elementValue);
			d.dataset["bindingname"] = elementName;
			formElement.appendChild(d);
			console.log(`${elementName} '${elementValue}' added`);
		} else {
			localeInput.value = elementValue;
		}
	}

	return {
		test: function () {
			console.log("foo");
		},
		addStylesheet: function (rooturl) {
			document.head.insertAdjacentHTML('afterbegin', `<link type="text/css" rel="stylesheet" href="${rooturl}/api/v1/css/structural-validation.css"/>`);
		},
		addLocaleField: function (formElement, locale) {
			addHiddenFieldIfNotExists(formElement, "locale", locale);
		},
		addAdditionalValuesField: function (formElement) {
			addHiddenFieldIfNotExists(formElement, "additionalValues");
		},
		addClass: function (el, className) {
			if (!el.classList.contains(className)) {
				el.classList.add(className);
			}
		},
		createPayloadFormatted: function (
			payload
		) {
			// need to enumerate all the possible legit fields
			// the rest get pushed into "addtionalData"
			let realFields = new Array (
				"firstName",
				"lastName",
				"company",
				"zipCode",
				"phone",
				"emailAddress",
				"countryCode",
				"formType",
				"leadSource",
				"sourceType",
				"contactId",
				"brand",
				"city",
				"stateCode",
				"notes",
				"productLineCode",
				"productName",
				"campaignId",
				"language",
				"sourceUrl",
				"businessType",
				"businessSubType",
				"sfLeadOrContactId",
				"sfOutBoundCampaignId",
				"marketingOptIn",
				"optIntoSegments",
				"locale",
				"address", // possibly dangerous. this is for the privacy form and is not a lead field
				"relationship" // possibly dangerous. this is for the privacy form and is not a lead field. the danger is if it gets added and i expected to be added to additionalAdata instead
			);

			payload = splitFullName (payload);

			// load utm values onto the payload
			var utms = this.getUtms();

			Object.getOwnPropertyNames(utms).forEach(function(prop) {
				// skip if it's already on the payload
				if (payload[prop]) {
					return;
				}

				payload[prop] = utms[prop];
			});

			console.log("payload : ");
			console.log(payload);

			let payloadProps = Object.getOwnPropertyNames(payload);

			// add the additionalData property to the frm
			if (payload.additionalData === undefined) {
				payload.additionalData = {};
			}

			// add the user's timezone
			try {
				payload.additionalData.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
			} catch (err) {
				console.error(err);
			}
			payload.additionalData.timezoneOffset = new Date().getTimezoneOffset().toString();

			payloadProps.forEach(function (prop) {
				if (realFields.includes(prop) == false) {
					payload.additionalData[prop] = payload[prop];
					delete payload[prop];
					return;
				}
				// trim string values
				if (payload[prop] && typeof payload[prop] == "string") {
					payload[prop] = payload[prop].trim()
				}
			});

			// optIntoSegments needs a little extra massaging. it should come in as an array of numbers. if a value is there, it means it's true
			if (payload.optIntoSegments !== undefined) {
				// if it's not an array, make it an array. this can happen when a single checkbox is selected
				if (Array.isArray(payload.optIntoSegments) == false) {
					let segval = payload.optIntoSegments;
					payload.optIntoSegments = new Array();
					payload.optIntoSegments.push(segval);
				}

				payload.optIntoSegments = payload.optIntoSegments.map(function(el) {
					return {
						segment: el,
						optInPref: true
					};
				});
			}

			// ensure that sourceUrl is submitted.
			// check for a value, if a value was already added don't overwrite
			if (payload.sourceUrl === undefined || payload.sourceUrl === "" || payload.sourceUrl === null) {
				payload.sourceUrl = window.location.href;
			}

			return payload;
		},
		realignFieldConstraints: function (
			formElement
		) {
			// i recommend hiding the form by default. this will show it
			formElement.style.removeProperty("display");

			// i have encountered email address patterns which don't allow some legit RFC-allowed characters for the localpart
			// i'm already doing this check on the server side. just remove the pattern if it exists
			let emailInput = formElement.querySelector(`#${formElement.id} input[data-bindingname=emailAddress]`);
			if (emailInput) {
				if (emailInput.hasAttribute("pattern")) {
					emailInput.removeAttribute("pattern");
				}
				emailInput.setAttribute("minlength", "5");
				emailInput.setAttribute("maxlength", "100");
			}

			// it appears that phone also has overly-restrictive (US-based) pattern constriaints in some forms. remove
			let phoneInput = formElement.querySelector(`#${formElement.id} input[data-bindingname=phone]`);
			if (phoneInput) {
				if (phoneInput.hasAttribute("pattern")) {
					phoneInput.removeAttribute("pattern");
				}
				phoneInput.setAttribute("minlength", "4");
				phoneInput.setAttribute("maxlength", "20"); // this is the largest we accept in the contact table and marketinglead table
			}

			// seeing some insane max lengths which will never survive to the database
			let fnameInput = formElement.querySelector(`#${formElement.id} input[data-bindingname=firstName]`);
			if (fnameInput) {
				if (fnameInput.hasAttribute("pattern")) {
					fnameInput.removeAttribute("pattern");
				}
				fnameInput.setAttribute("minlength", "1");
				fnameInput.setAttribute("maxlength", "16"); // this is the largest we accept in the contact table and marketinglead table
			}
			let lnameInput = formElement.querySelector(`#${formElement.id} input[data-bindingname=lastName]`);
			if (lnameInput) {
				if (lnameInput.hasAttribute("pattern")) {
					lnameInput.removeAttribute("pattern");
				}
				lnameInput.setAttribute("minlength", "1");
				lnameInput.setAttribute("maxlength", "25"); // this is the largest we accept in the contact table and marketinglead table
			}

			// we'll deal with new conditions as they come
		},
		unEventChildrenRecurse: function (node) {
			let children = node.childNodes;

			if (!children || children.length == 0) {
				return;
			}

			children.forEach(function (child) {
				if (child.nodeType != 1) {
					return;
				}

				child.removeEventListenersByType("submit");
				child.removeEventListenersByType("click");
				child.removeEventListenersByType("keypress");
				child.removeEventListenersByType("mousedown");

				standardFormUtils.unEventChildrenRecurse (child);
			});
		},
		santizeSubmitButtons: function (
			formElement,
			disableButtons
		) {
			// find submits. buttons default to 'type="submit"' iirc, hence the last selector group
			let submits = document.querySelectorAll(`#${formElement.id} input[type=submit], #${formElement.id} button[type=submit], #${formElement.id} button:not([type])`);

			if (submits) {
				submits.forEach(function(el) {
					el.removeEventListenersByType("click");
					el.removeEventListenersByType("keypress");
					el.removeEventListenersByType("mousedown");
				});
			}

			if (disableButtons == false) {
				// there's no point in wiring up submission if this fails
				// also, let's disable the submits
				submits.forEach(function(el) {
					el.setAttribute("disabled", "disabled");
				});
				return;
			}
		},
		showMissingFormBanner: function (rooturl) {
			standardFormUtils.addStylesheet(rooturl);
			let d = document.createElement("div");
			d.id = "MissingFormBanner-{{scriptcd}}";
			standardFormUtils.addClass(d, "missing-form-banner");
			document.querySelector("body").prepend(d);
			let banner = document.querySelector(`.missing-form-banner`);
			banner.innerHTML = `<h3>Form not found</h3>`;
		},
		getUtms: function () {
			let url = new URL(window.location.href);
			let params = url.searchParams;

			return {
				campaignId : params.get("utm_campaign_id") ?? params.get("utm_campaignid"),
				campaign : params.get("utm_campaign"),
				medium : params.get("utm_medium"),
				source : params.get("utm_source"),
				content : params.get("utm_content")
			};
		},
	}
}();