using System.Linq;
using System.Text.RegularExpressions;

namespace WeMarketingAutomationFormInjection;

public class LetterDistribution
{
	public LetterDistribution (
		string input
	) {
		Input = input;

		if (string.IsNullOrEmpty (input)) {
			Total = 0;
			Distinct = 1;
			Ratio = 1;
			return;
		}

		Total = input.Length;
		Distinct = input.ToLowerInvariant ().Distinct ().Count ();
		Ratio = Math.Round ((decimal)Distinct / Total, 4);
	}

	public string Input { get; set; }
	public int Total { get; private set; } // total input character count
	public int Distinct { get; private set; } // lower invariant distinct values. not interested in upper vs lower differences
	public decimal Ratio { get; private set; }
}

// time to rework this closer to something i'd really use
public class InputQuality
{
	static InputQuality () {

	}

	public InputQuality (
		string _value,
		string locale = "en-US" // this may play more later. especially since certain character sequences in different languages are more or less common
	) {
		Value = _value;

		IsAllCaps = CalculateIsAllCaps (Value);

		var letterDistribution = new LetterDistribution (Value);
		LetterDistributionRatio = letterDistribution.Ratio;

		ShannonEntropy = CalculateShannonEntropy (Value);

		VowelProportion = CalculateVowelProportion (Value);

		MaxCharacterDistance = CalculateMaxAdjacency (Value);

		HasExcessiveCharacterRepeat = CalculateExcessiveCharacterRepeat (Value);

		AreValuesInSameRow = CalculateIsSameKeyboardRow (Value);

		NumberOfVerbotenCharacters = CalculateNumberOfVerbotenCharacters (Value);

		HasCommentSequences = CalculateCommentSequences (Value);

		UncommonRepeatCharacterCount = CalculateUncommonRepeatCharacters (Value);

		AreAllVowelsAtEndOfWord = CalculateAreAllVowelsAtEndOfWord (Value, locale);

		MaxCharacterFrequency = CalculateMaxCharacterFrequency (Value);

		RepeatedBigrams = CalculateRepeatedBigrams (Value);

		MaxConsecutiveVowels = CalculateMaxConsecutiveVowels (Value);

		MaxConsecutiveConsonants = CalculateMaxConsecutiveConsonants (Value);

		ConsonantVowelTransitionRatio = CalculateConsonantVowelTransitionRatio (Value);
	}

	public int CalculateScore () {
		int score = 0;

		if (IsAllCaps) {
			score += 5;
		}

		if (HasExcessiveCharacterRepeat) {
			score += 10;
		}

		if (AreValuesInSameRow) {
			score += 10;
		}

		if (Value.Length > 4) {
			// if (LetterDistributionRatio >= .9m) {
			// 	score += 5;
			// }
			if (LetterDistributionRatio < 0.35m || LetterDistributionRatio >= .95m) {
				score += 5;
			}

			// some more nuance. if it's a fairly long input and the letter distribution is bad, punish more
			if (Value.Length >= 8 && LetterDistributionRatio < .5m) {
				score += 10;
			}

			// it's unlikely/uncommon for long values that the letter distribution will be 1
			if (Value.Length >= 10 && LetterDistributionRatio == 1) {
				score += 10;
			}
		}

		if (VowelProportion < .25m || VowelProportion > .8m) {
			score += 10;
		}
		if (VowelProportion <= .15m) {
			score += 15;
		}
		if (Value.Length > 5 && (VowelProportion < .3m || VowelProportion > .7m)) {
			score += 10;
		}

		if (MaxCharacterDistance <= 4.0m) {
			score += 5;
		}
		if (MaxCharacterDistance <= 2.2m) {
			score += 10;
		}
		if (MaxCharacterDistance <= 1m) {
			score += 10;
		}

		if (ShannonEntropy < 2.8) {
			score += 5;
		}
		if (ShannonEntropy <= 1.7) {
			score += 5;
		}
		if (ShannonEntropy <= 1) {
			score += 10;
		}
		if (ShannonEntropy >= 3.2) {
			score += 5;
		}
		if (ShannonEntropy >= 3.4) {
			score += 5;
		}
		if (ShannonEntropy >= 3.6) {
			score += 5;
		}

		// each verboten character will add to the score
		score += NumberOfVerbotenCharacters * 5;

		// each uncommon repeat will add to the score
		score += UncommonRepeatCharacterCount * 5;

		if (HasCommentSequences) {
			score += 10; // i'm tempted to make this far more punishing, but we'll see
		}

		if (AreAllVowelsAtEndOfWord) {
			score += 15;
		}

		if (MaxCharacterFrequency > .5m) {
			score += 10;
		}
		if (MaxCharacterFrequency > .6m) {
			score += 5;
		}
		if (MaxCharacterFrequency > .7m) {
			score += 5;
		}
		if (MaxCharacterFrequency > .8m) {
			score += 5;
		}

		score += RepeatedBigrams * 5;

		if (MaxConsecutiveVowels >= 3) {
			score += 5;
		}
		if (MaxConsecutiveVowels >= 4) {
			score += 10;
		}

		if (MaxConsecutiveConsonants >= 5) {
			score += 10;
		}
		if (MaxConsecutiveConsonants >= 6) {
			score += 5;
		}
		if (MaxConsecutiveConsonants >= 7) {
			score += 10;
		}

		if (ConsonantVowelTransitionRatio < .4m) {
			score += 5;
		}
		if (ConsonantVowelTransitionRatio < .3m) {
			score += 5;
		}

		return score;
	}

	public static readonly string[] KEYBOARD = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]; // this is obviously very english-centric
	public static readonly Dictionary<char, (int x, int y)> KEYBOARD_COORDS = preCalcKeyboardCoordinates ();
	public static readonly string VERBOTEN_CHARACTERS = "\\@[]{}^%$()";
	public static readonly string[] COMMENT_SEQUENCES = ["--", "//"];
	public static readonly string UNCOMMON_REPEAT_CHARACTERS = "qzxwvgy"; // yes i realize this us very english-centric at the moment
	public static readonly string VOWELS = "aeiouy";
	public static readonly string CONSONANTS = "bcdfghjklmnpqrstvwxyz"; // yes i'm including 'y' in both vowels and consonants

	public string Value { get; private set; }

	public bool IsAllCaps { get; set; }
	public decimal LetterDistributionRatio { get; set; } = 1; // just setting to one, since the failure threshold will be lower and i'll default to erring on the side of success
	public double ShannonEntropy { get; set; }
	public decimal VowelProportion { get; set; } = 1;
	public decimal MaxCharacterDistance { get; set; } = 20;
	public bool HasExcessiveCharacterRepeat { get; set; } = false;
	public bool AreValuesInSameRow { get; set; } = false;
	public int NumberOfVerbotenCharacters { get; set; } = 0;
	public bool HasCommentSequences { get; set; } = false;
	public int UncommonRepeatCharacterCount { get; set; } = 0;
	public bool AreAllVowelsAtEndOfWord { get; set; } = false;
	public decimal MaxCharacterFrequency { get; set; } = 0;
	public int RepeatedBigrams { get; set; } = 0;
	public int MaxConsecutiveVowels { get; set; } = 0;
	public int MaxConsecutiveConsonants { get; set; } = 0;
	public decimal ConsonantVowelTransitionRatio { get; set; } = 1;

	private static Dictionary<char, (int x, int y)> preCalcKeyboardCoordinates () {
		var result = new Dictionary<char, (int x, int y)> ();

		for (var i = 0; i < KEYBOARD.Length; i++) {
			for (var j = 0; j < KEYBOARD[i].Length; j++) {
				result.Add (KEYBOARD[i][j], new (i, j));
			}
		}

		return result;
	}

	public static bool CalculateIsAllCaps (
		string input
	) {
		return input.ToUpperInvariant () == input;
	}

	public static decimal CalculateVowelProportion (
		string input
	) {
		var vowelCount = input.ToLowerInvariant ().Count (c => VOWELS.Contains (c));
		return input.Length > 0 ? Math.Round ((decimal)vowelCount / input.Length, 4) : 0;
	}

	public static decimal CalculateMaxAdjacency (
		string input
	) {
		input = input.ToLowerInvariant ();

		decimal max = 0m;

		// roll through each character position and calculate adjacency to the previous char (which is why i'm starting the iterator at 1 and not 0), keeping the largest value
		for (var i = 1; i < input.Length; i++) {
			var distance = getDistance (input[i - 1], input[i]);
			if (distance > max) {
				max = distance;
			}
		}

		return Math.Round (max, 2);
	}

	private static decimal getDistance (
		char a,
		char b
	) {
		KEYBOARD_COORDS.TryGetValue (a, out (int x, int y) pos1);
		KEYBOARD_COORDS.TryGetValue (b, out (int x, int y) pos2);

		return (decimal)Math.Sqrt (Math.Pow (pos2.x - pos1.x, 2) + Math.Pow (pos2.y - pos1.y, 2));
	}

	// this seems to punish short names
	public static double CalculateShannonEntropy (string input) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		// Count frequency of each character
		var frequencies = new Dictionary<char, int> ();
		foreach (var c in input) {
			if (frequencies.ContainsKey (c)) {
				frequencies[c]++;
			} else {
				frequencies[c] = 1;
			}
		}

		// Calculate entropy: H(X) = -Σ(p(x) * log2(p(x)))
		double entropy = 0;
		int length = input.Length;

		foreach (var freq in frequencies.Values) {
			double probability = (double)freq / length;
			entropy -= probability * Math.Log2 (probability);
		}

		return Math.Round (entropy, 4);
	}

	public static bool CalculateExcessiveCharacterRepeat (
		string input,
		int threshold = 3
	) {
		if (threshold < 2) {
			return false;
		}

		if (input.Length < threshold) {
			return false;
		}

		input = input.ToLowerInvariant ();

		for (var i = threshold - 1; i < input.Length; i++) {
			char target = input[i];
			bool hasRepeat = true;

			for (var j = 1; j < threshold; j++) {
				if (input[i - j] != target) {
					hasRepeat = false;
					break;
				}
			}

			if (hasRepeat) {
				return true;
			}

		}

		return false;
	}

	public static bool CalculateIsSameKeyboardRow (
		string input
	) {
		//ArgumentNullException.ThrowIfNullOrEmpty (input);
		if (string.IsNullOrEmpty (input)) {
			return false;
		}

		input = input.ToLowerInvariant ();

		if (KEYBOARD_COORDS.ContainsKey (input[0]) == false) {
			return false;
		}
		// the first character will establish the row
		var row = KEYBOARD_COORDS[input[0]].x;

		for (var i = 0; i < input.Length; i++) {
			if (KEYBOARD_COORDS.TryGetValue (input[i], out (int x, int y) coord)) {
				if (coord.x != row) {
					return false;
				}
			} else {
				return false;
			}
		}

		return true;
	}

	public static int CalculateNumberOfVerbotenCharacters (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		var violationCount = 0;

		foreach (var chr in input) {
			if (VERBOTEN_CHARACTERS.IndexOf (chr) > -1) {
				violationCount++;
			}
		}

		return violationCount;
	}

	public static bool CalculateCommentSequences (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return true;
		}

		foreach (var sequence in COMMENT_SEQUENCES) {
			if (input.IndexOf (sequence) > -1) {
				return true;
			}
		}

		return false;
	}

	public static int CalculateUncommonRepeatCharacters (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		input = input.ToLowerInvariant ();

		var count = 0;

		foreach (var chr in UNCOMMON_REPEAT_CHARACTERS) {
			var occurrences = input.Count (c => c == chr);
			if (occurrences > 1) {
				count++;
			}
		}

		return count;
	}

	public static bool CalculateAreAllVowelsAtEndOfWord (
		string input,
		string locale
	) {
		if (string.IsNullOrEmpty (input)) {
			return false;
		}

		input = input.ToLowerInvariant ();

		// Find the first vowel
		int firstVowelIndex = -1;
		for (int i = 0; i < input.Length; i++) {
			if (VOWELS.IndexOf (input[i]) > -1) {
				firstVowelIndex = i;
				break;
			}
		}

		// If no vowels found, return true. this is a punishment :)
		if (firstVowelIndex == -1) {
			return true;
		}

		// Check if all characters from first vowel to end are vowels
		for (int i = firstVowelIndex; i < input.Length; i++) {
			if (VOWELS.IndexOf (input[i]) == -1) {
				return false;
			}
		}

		return true;
	}

	public static decimal CalculateMaxCharacterFrequency (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		input = input.ToLowerInvariant ();
		var maxCount = input.GroupBy (c => c).Max (g => g.Count ());

		return Math.Round ((decimal)maxCount / input.Length, 4);
	}

	public static int CalculateRepeatedBigrams (
		string input
	) {
		if (input.Length < 2) {
			return 0;
		}

		input = input.ToLowerInvariant ();

		var bigrams = new Dictionary<string, int> ();

		for (int i = 0; i < input.Length - 1; i++) {
			var bigram = input.Substring (i, 2);

			if (bigrams.ContainsKey (bigram)) {
				bigrams[bigram]++;
			} else {
				bigrams[bigram] = 1;
			}

		}

		return bigrams.Count (b => b.Value > 1);
	}

	// i may need to re-eval this
	public static int CalculateMaxConsecutiveVowels (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		input = input.ToLowerInvariant ();
		int maxVowels = 0, currentVowels = 0;

		foreach (char c in input) {
			if (VOWELS.IndexOf (c) > -1) {
				currentVowels++;
				maxVowels = Math.Max (maxVowels, currentVowels);
			} else {
				currentVowels = 0;
			}
		}

		return maxVowels;
	}

	public static int CalculateMaxConsecutiveConsonants (
		string input
	) {
		if (string.IsNullOrEmpty (input)) {
			return 0;
		}

		input = input.ToLowerInvariant ();
		int maxConsonants = 0, currentConsonants = 0;

		foreach (char c in input) {
			if (CONSONANTS.IndexOf (c) > -1) {
				currentConsonants++;
				maxConsonants = Math.Max (maxConsonants, currentConsonants);
			} else {
				currentConsonants = 0;
			}
		}

		return maxConsonants;
	}

	// meh
	public static bool HasRepeatingPattern (
		string input
	) {
		if (input.Length < 4) {
			return false;
		}

		input = input.ToLowerInvariant ();

		// Check for patterns of length 2-4
		for (int patternLen = 2; patternLen <= Math.Min (4, input.Length / 2); patternLen++) {
			for (int i = 0; i <= input.Length - (patternLen * 2); i++) {
				string pattern = input.Substring (i, patternLen);
				string next = input.Substring (i + patternLen, Math.Min (patternLen, input.Length - i - patternLen));

				if (pattern == next) {
					return true;
				}
			}
		}

		return false;
	}

	// real names should have more vowel to consonant transitions
	public static decimal CalculateConsonantVowelTransitionRatio (
		string input
	) {
		if (input.Length < 2) {
			return 1;
		}

		input = input.ToLowerInvariant ();
		int transitions = 0;

		for (int i = 1; i < input.Length; i++) {
			bool prevIsVowel = VOWELS.IndexOf (input[i - 1]) > -1;
			bool currIsVowel = VOWELS.IndexOf (input[i]) > -1;

			if (prevIsVowel != currIsVowel) transitions++;
		}

		return Math.Round (transitions / (decimal)(input.Length - 1), 4); // it's length -1 because it's out of all possible transitions, not out of all characters. "ab" has only one possible transition. "abc" has two, etc
	}
}