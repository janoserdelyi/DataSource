using Newtonsoft.Json;
using WeMarketingAutomationFormInjection.Models;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System.Net;

namespace WeMarketingAutomationFormInjection;

// TODO: now with the advent of sending to Case Creation in some situations, this really should be named an orchestrator and restructured
public interface ILeadSubmissionService
{
	Task<ApiResponse<CreateLeadResponse>> SubmitLeadAsync (Lead lead, Form form);
	Task<ApiResponse<CreateLeadResponse>> SubmitCaseAsync (Case caseModel, Lead lead, Form form);
}

public class LeadSubmissionService : ILeadSubmissionService
{
	private readonly HttpClient httpClient;
	private readonly ILogger<HomeModule> logger;
	private readonly IConfiguration config;
	private readonly IDynamoClient dynamoClient;
	private readonly IStringLocalizer stringLocalizer;
	private readonly string EnvironmentName;

	public LeadSubmissionService (
		HttpClient httpClient,
		ILogger<HomeModule> logger,
		IConfiguration config,
		IDynamoClient dynamoClient,
		IStringLocalizer stringLocalizer,
		string EnvironmentName
	) {
		this.httpClient = httpClient;
		this.logger = logger;
		this.config = config;
		this.dynamoClient = dynamoClient;
		this.stringLocalizer = stringLocalizer;
		this.EnvironmentName = EnvironmentName;
	}

	public async Task<ApiResponse<CreateLeadResponse>> SubmitCaseAsync (
		Case caseModel,
		Lead lead,
		Form form
	) {
		try {
			Console.WriteLine ("re-route to case management");
			try {
				return await SubmitCase (caseModel, lead, form);
			} catch (Exception oops) {
				logger.LogError (oops, $"Error submitting to case create endpoint: {oops.Message} from {Environment.MachineName}");
				return ApiResponse<CreateLeadResponse>.IsFailure (oops.Message, fullMessage: oops.ToString ());
			}

		} catch (Exception oops) {
			logger.LogError (oops, $"Error submitting to case create endpoint: {oops.Message} from {Environment.MachineName}");
			return ApiResponse<CreateLeadResponse>.IsFailure (oops.Message, fullMessage: oops.ToString ());
		}
	}

	public async Task<ApiResponse<CreateLeadResponse>> SubmitLeadAsync (
		Lead lead,
		Form form
	) {
		try {
			var serializedBody = JsonConvert.SerializeObject (lead, NewtonsoftCustomResponseNegotiator.Serializer);
			var requestMessage = CreateHttpRequest (serializedBody, form);

			var response = await SendWithRetryAsync (requestMessage, form.SecurityKey);

			if (!response.IsSuccessStatusCode) {
				logger.LogError (
					"Error submitting to create-lead endpoint: {StatusCode}, {ReasonPhrase} from {MachineName}",
					response.StatusCode, response.ReasonPhrase, Environment.MachineName
				);

				return ApiResponse<CreateLeadResponse>.IsFailure ($"Error, {response.ReasonPhrase}", (int)response.StatusCode);
			}

			var responseString = await response.Content.ReadAsStringAsync ();
			var responseObject = JsonConvert.DeserializeObject<CreateLeadResponse> (responseString);

			if (responseObject == null) {
				return ApiResponse<CreateLeadResponse>.IsFailure ("Unknown error, malformed response message from server");
			}

			if (!responseObject.Success) {
				return ApiResponse<CreateLeadResponse>.IsFailure ("Error submitting request");
			}

			return ApiResponse<CreateLeadResponse>.IsSuccess (responseObject);
		} catch (Exception oops) {
			logger.LogError (oops, $"Error submitting to case create endpoint: {oops.Message} from {Environment.MachineName}");
			return ApiResponse<CreateLeadResponse>.IsFailure (oops.Message, fullMessage: oops.ToString ());
		}
	}

	private async Task<HttpResponseMessage> SendWithRetryAsync (
		HttpRequestMessage requestMessage,
		string securityKey
	) {
		const int MAX_RETRIES = 3;
		var retryCount = 0;

		while (true) {
			var token = Utils.CreateRsaJwt (securityKey, DateTime.UtcNow.AddMinutes (5));
			requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("bearer", token);

			var response = await httpClient.SendAsync (requestMessage);

			if (response.StatusCode != HttpStatusCode.Forbidden || retryCount >= MAX_RETRIES) {
				return response;
			}

			retryCount++;

			logger.LogWarning (
				"Forbidden error submitting to create-lead endpoint. retry #{RetryCount} from {MachineName}",
				retryCount,
				Environment.MachineName
			);
		}
	}

	private static HttpRequestMessage CreateHttpRequest (string serializedBody, Form form) {
		return new HttpRequestMessage {
			Method = HttpMethod.Post,
			RequestUri = new Uri (form.SubmissionEndpoint),
			Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
		};
	}

	private async Task<ApiResponse<CreateLeadResponse>> SubmitCase (
		Case caseModel,
		Lead lead,
		Form form
	) {
		var settings = new JsonSerializerSettings {
			ContractResolver = NewtonsoftCustomResponseNegotiator.Serializer.ContractResolver,
			NullValueHandling = NewtonsoftCustomResponseNegotiator.Serializer.NullValueHandling,
			Converters = { new NameValueCollectionKeyValueConverter () }
		};

		var serializedBody = JsonConvert.SerializeObject (caseModel, settings);

		var requestMessage = new HttpRequestMessage {
			Method = HttpMethod.Post,
			RequestUri = new Uri (config.GetSection ("CreateCaseEndpoint").Get<string> ()!),
			Content = new StringContent (serializedBody, Encoding.UTF8, "application/json")
		};

		var token = Utils.CreateRsaJwt (form.SecurityKey, DateTime.UtcNow.AddMinutes (5)); // for now seeing if that security key works
		requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue ("bearer", token);

		var response = await httpClient.SendAsync (requestMessage);

		if (!response.IsSuccessStatusCode) {
			logger.LogError (
				"Error submitting to create-case endpoint: {StatusCode}, {ReasonPhrase} from {MachineName}",
				response.StatusCode, response.ReasonPhrase, Environment.MachineName
			);

			return ApiResponse<CreateLeadResponse>.IsFailure ($"Error, {response.ReasonPhrase}", (int)response.StatusCode);
		}

		var responseString = await response.Content.ReadAsStringAsync ();
		var responseObject = JsonConvert.DeserializeObject<CreateLeadResponse> (responseString);

		if (responseObject == null) {
			return ApiResponse<CreateLeadResponse>.IsFailure ("Unknown error, malformed response message from server");
		}

		if (!responseObject.Success) {
			return ApiResponse<CreateLeadResponse>.IsFailure ("Error submitting request");
		}

		// we still need to handle opts if they exist
		if (lead.OptIntoSegments != null && lead.OptIntoSegments.Count > 0) {
			try {
				var prefResponse = await EmailPreferenceModule.submitEmailPreferenceInnards (
					config,
					new Models.EmailPreference () {
						EmailAddress = lead.EmailAddress,
						Brand = new List<string> { lead.Brand! },
						CountryCode = lead.CountryCode,
						OptIntoSegments = lead.OptIntoSegments
					},
					httpClient,
					dynamoClient,
					stringLocalizer!,
					EnvironmentName
				);

				if (prefResponse.Success == false) {
					Console.WriteLine ($"Error setting preference for : {lead.EmailAddress} segments : {JsonConvert.SerializeObject (lead.OptIntoSegments)} response : {JsonConvert.SerializeObject (prefResponse)}");
				}
			} catch (Exception oops) {
				Console.WriteLine ($"Error setting preference for : {lead.EmailAddress} segments : {JsonConvert.SerializeObject (lead.OptIntoSegments)} response : {oops.Message}");
			}
		}

		return ApiResponse<CreateLeadResponse>.IsSuccess (responseObject);
	}
}


