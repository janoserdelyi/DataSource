using System.Linq;
using System.Net;
using Amazon.DynamoDBv2.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace WeMarketingAutomationFormInjection;

public class Jwt
{
	private readonly RequestDelegate _next;

	public Jwt (
		RequestDelegate next
	) {
		_next = next;
	}

	public async Task InvokeAsync (
		HttpContext ctx,
		IConfiguration config
	// IUserService userService
	) {

		var endpoint = ctx.GetEndpoint ();

		// i only want this to work for endpoints which require authorization. otherwise bypass
		if (endpoint == null || endpoint.Metadata == null) {
			goto gtfo;
		}

		var hasAuthorizeAttribute = endpoint.Metadata.Any (m => m is Microsoft.AspNetCore.Authorization.AuthorizeAttribute);

		// this endpoint does not require authorization. pass through
		if (hasAuthorizeAttribute == false) {
			goto gtfo;
		}

		if (ctx.Request.Headers.ContainsKey ("Authorization") == false) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		var tokenString = ctx.Request.Headers["Authorization"].FirstOrDefault ()?.Split (" ").Last ();

		if (string.IsNullOrEmpty (tokenString)) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		var securityKey = config.GetSection ("EmailPreferenceSecurityKey").Get<string> ()!;

		var decryptedToken = Utils.ValidateRsaToken (tokenString, securityKey);

		if (decryptedToken == null) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		// var nameClaim = ((System.IdentityModel.Tokens.Jwt.JwtSecurityToken)decryptedToken).Claims.FirstOrDefault (c => c.Type == "unique_name");

		// if (nameClaim != null) {
		// 	Console.WriteLine ($"Specific Claim Value: {nameClaim.Value}");
		// }

		var roleClaim = ((System.IdentityModel.Tokens.Jwt.JwtSecurityToken)decryptedToken).Claims.FirstOrDefault (c => c.Type == "role");

		if (roleClaim == null) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		// if there are no policies on the authorization, good to go
		var authMetadata = endpoint.Metadata.GetMetadata<Microsoft.AspNetCore.Authorization.AuthorizeAttribute> ();

		if (string.IsNullOrEmpty (authMetadata!.Policy)) {
			goto gtfo;
		}

		// if it's not a real policy we've created, fail
		if (Program.Roles.ContainsKey (authMetadata!.Policy) == false) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		// now see if the policy role and the roleClaim match
		if (Program.Roles[authMetadata!.Policy].Contains (roleClaim.Value) == false) {
			ctx.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
			return;
		}

		// if using [Authorize] attributes (or the RequireAuthorization() route extension method - which adds a [Authorize] atttribute), an exception will be thrown that Authorization middleware was not detected
		// this will bypass that
		// ctx.Items[EndpointMiddleware.AuthorizationMiddlewareInvokedKey] = true;
		// the is not accessible. its raw value though is "__AuthorizationMiddlewareWithEndpointInvoked". https://github.com/dotnet/aspnetcore/blob/18e00de95dde3e9123eff926d682a9ee78c84212/src/Http/Routing/src/EndpointMiddleware.cs#L15
		// this is pretty dumb
		ctx.Items["__AuthorizationMiddlewareWithEndpointInvoked"] = true;

	gtfo:

		await _next (ctx);
	}

}

public static class JwtExtensions
{
	public static IApplicationBuilder UseJwt (
		this IApplicationBuilder builder
	) {
		return builder.UseMiddleware<Jwt> ();
	}
}