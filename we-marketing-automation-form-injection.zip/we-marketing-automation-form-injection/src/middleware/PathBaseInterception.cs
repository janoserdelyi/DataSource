
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace WeMarketingAutomationFormInjection;

public class PathBaseInterception
{
	private readonly RequestDelegate _next;

	public PathBaseInterception (
		RequestDelegate next
	) {
		_next = next;
	}

	public async Task InvokeAsync (
		HttpContext ctx,
		LinkGenerator linkgen
	) {

		// this whole middleware is a test. it's not necessary unless i'm looking to grab different base paths, like article 14

		// use named routes
		// var targetPath = linkgen.GetPathByName (ctx, "article14", values: null);

		// if (targetPath != null) {

		// }

		// ... or just inspect the path
		if (ctx.Request.Path.ToString ().ToLower () == "/article14") {
			ctx.Request.PathBase = "/gdpr";
		}

		await _next (ctx);
	}
}

public static class PathBaseInterceptionExtensions
{
	public static IApplicationBuilder UsePathBaseInterception (
		this IApplicationBuilder builder
	) {
		return builder.UseMiddleware<PathBaseInterception> ();
	}
}