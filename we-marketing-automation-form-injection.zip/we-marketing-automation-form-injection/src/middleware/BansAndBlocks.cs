
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace WeMarketingAutomationFormInjection;

public class BansAndBlocks
{
	private readonly RequestDelegate _next;

	public BansAndBlocks (
		RequestDelegate next
	) {
		_next = next;
	}

	public async Task InvokeAsync (
		HttpContext ctx
	) {
		IPAddress? sourceip;
		try {
			sourceip = Utils.GetSourceIp (ctx.Request);
		} catch (Exception oops) {
			// log
			Console.WriteLine ($"Error getting request IP Address : {oops.Message}");
			ctx.Response.StatusCode = 403;
			return;
		}

		string? ua = null;
		try {
			ua = ctx.Request.Headers["User-Agent"];
		} catch {
			// not going to do anything. if you're null after this step you're not going anywhere
		}

		string requestPath = ctx.Request.Path;

		// only bots and inadequate scripts have no user-agent string
		if (string.IsNullOrEmpty (ua)) {

			if (requestPath.EndsWith ("/ping") || requestPath.EndsWith ("/health-check")) {

			}

			Console.WriteLine ($"Empty user-agent string for ip address {sourceip}");
			ctx.Response.StatusCode = 403;
			return;
		}

		// i could break out the session stuff to a separate middleware but that's overkill for what's going on here at the moment
		// clear previous session
		ctx.SessionStorage ().Clear ();

		// set the current session's ip address
		ctx.SessionStorage ().SourceIp = sourceip;
		ctx.SessionStorage ().UserAgent = ua;

		// any other security checks we'd want to do - do that here
		// for example if in general we don't like getting probed
		if (ctx.Request.Method == "HEAD") {
			ctx.Response.StatusCode = 403;
			return;
		}

		if (ctx.Request.Path == null || ctx.Request.Path.Value == null) {
			goto passesThrough;
		}

		string request = ctx.Request.Path.Value.ToLower ();

		if (request == "/favicon.ico") {
			goto passesThrough;
		}

	// this is where i would really start banning/terminating requests which are abusive

	passesThrough:
		await _next (ctx);
	}
}

public static class BansAndBlocksExtensions
{
	public static IApplicationBuilder UseBansAndBlocks (
		this IApplicationBuilder builder
	) {
		return builder.UseMiddleware<BansAndBlocks> ();
	}
}