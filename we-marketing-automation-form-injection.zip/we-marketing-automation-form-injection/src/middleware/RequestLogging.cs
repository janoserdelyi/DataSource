
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace WeMarketingAutomationFormInjection;

public class RequestLogging
{
	private readonly RequestDelegate _next;

	public RequestLogging (
		RequestDelegate next
	) {
		_next = next;
	}

	public async Task InvokeAsync (
		HttpContext ctx
	) {
		// really i could just do ctx.Request.EnableBuffering(); in this middleware and then do logging in specific controllers

		// an example just logging POSTs
		//string method = ctx.Request.Method.ToLower ();

		//if (method == "post") {
		// string? body = null;
		ctx.Request.EnableBuffering ();
		// using (var reader = new StreamReader(ctx.Request.Body, encoding: System.Text.Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true)) {
		// 	body = reader.ReadToEndAsync().Result;
		// }
		// ctx.Request.Body.Position = 0;
		// // log to database here

		// Console.WriteLine(ctx.SessionStorage().SourceIp);
		// Console.WriteLine(ctx.SessionStorage().UserAgent);
		// Console.WriteLine(body);
		//}

		await _next (ctx);
	}
}

public static class RequestLoggingExtensions
{
	public static IApplicationBuilder UseRequestLogging (
		this IApplicationBuilder builder
	) {
		return builder.UseMiddleware<RequestLogging> ();
	}
}