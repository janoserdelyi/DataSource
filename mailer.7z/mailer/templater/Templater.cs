using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace templatetests;

public class Templater
{

	public string Process (
		string jsonData,
		string template,
		Dictionary<string, Func<object, object>>? functions = null
	) {
		var obj = JsonConvert.DeserializeObject (jsonData);

		if (obj == null) {
			return template;
		}

		// Replace function tokens like {{funcName(arg)}}
		if (functions != null) {
			template = Regex.Replace (template, @"\{\{(\w+)\(([^\)]+)\)\}\}", match => {

				var funcName = match.Groups[1].Value;

				var argPath = match.Groups[2].Value.Trim ();

				if (!functions.TryGetValue (funcName, out var func)) {
					return match.Value;
				}

				// Support only o.XXX.YYY as arg
				object? current = obj;
				foreach (var part in argPath.Split ('.')) {
					if (current == null) {
						break;
					}
					if (part == "o") {
						continue;
					}

					if (current is Newtonsoft.Json.Linq.JObject jObj && jObj.ContainsKey (part)) {
						current = jObj[part];
					} else if (current is Newtonsoft.Json.Linq.JToken jToken) {
						current = jToken[part];
					} else {
						var propInfo = current.GetType ().GetProperty (part);
						if (propInfo == null) {
							current = null;
							break;
						}
						current = propInfo.GetValue (current);
					}
				}
				return func (current ?? new object ())?.ToString () ?? string.Empty;
			});
		}

		// Replace object tokens, including nested (e.g., {{o.Property}}, {{o.List.Count}})
		template = Regex.Replace (template, @"\{\{o\.([\w\.]+)\}\}", match => {
			string path = match.Groups[1].Value;
			object? current = obj;
			foreach (var part in path.Split ('.')) {
				if (current == null) {
					break;
				}

				if (part == "Count" && current is Newtonsoft.Json.Linq.JArray jArray) {
					current = jArray.Count;
				} else if (current is Newtonsoft.Json.Linq.JObject jObj && jObj.ContainsKey (part)) {
					current = jObj[part];
				} else if (current is Newtonsoft.Json.Linq.JToken jToken) {
					current = jToken[part];
				} else {
					var propInfo = current.GetType ().GetProperty (part);
					if (propInfo == null) {
						current = null;
						break;
					}
					current = propInfo.GetValue (current);
				}
			}
			return current?.ToString () ?? string.Empty;
		});

		// Find all loop tokens like [[foreach ... in o.X.Y.Z]]
		var loopRegex = new Regex (@"\[\[foreach [^\s]+ in (?<listtoken>o(?:\.[\w]+)+)\]\]", RegexOptions.Singleline);
		var matches = loopRegex.Matches (template);
		foreach (Match m in matches) {
			var listToken = m.Groups["listtoken"].Value;

			// Traverse the object graph for deep property access
			object? current = obj;
			foreach (var part in listToken.Split ('.')) {
				if (current == null) {
					break;
				}
				if (part == "o") {
					continue;
				}

				if (current is Newtonsoft.Json.Linq.JObject jObj && jObj.ContainsKey (part)) {
					current = jObj[part];
				} else if (current is Newtonsoft.Json.Linq.JToken jToken) {
					current = jToken[part];
				} else {
					var propInfo = current.GetType ().GetProperty (part);
					if (propInfo == null) {
						current = null;
						break;
					}
					current = propInfo.GetValue (current);
				}
			}
			if (current is Newtonsoft.Json.Linq.JArray jArray) {
				template = parseLoopFromJson (template, listToken, jArray);
			} else if (current is System.Collections.IEnumerable list && !(current is string)) {
				template = parseLoop (template, listToken, list);
			}
		}

		return template;
	}

	private static string parseLoopFromJson (
		string template,
		string listToken,
		Newtonsoft.Json.Linq.JArray items
	) {
		// Find the loop block
		string pattern = @$"\[\[foreach (?<objectname>[^\s]+) in\s*{Regex.Escape (listToken)}\s*\]\](?<loopcontent>.*?)\[\[endeach\]\]";
		var regex = new Regex (pattern, RegexOptions.Singleline);
		var match = regex.Match (template);

		if (!match.Success) {
			return template;
		}

		string loopContent = match.Groups["loopcontent"].Value;
		string objectname = match.Groups["objectname"].Value;

		var sb = new System.Text.StringBuilder ();

		foreach (var item in items) {
			if (item == null) {
				continue;
			}

			string itemStr = loopContent;
			if (item is Newtonsoft.Json.Linq.JObject jObj) {
				foreach (var prop in jObj.Properties ()) {
					string token = @$"{{{{{objectname}.{prop.Name}}}}}";
					var value = prop.Value?.ToString () ?? string.Empty;
					itemStr = itemStr.Replace (token, value);
				}
			}

			sb.Append (itemStr);
		}

		// Replace the whole loop block with the expanded content
		return template.Replace (match.Value, sb.ToString ());
	}

	private static string parseLoop (
		string template,
		string listToken,
		System.Collections.IEnumerable items
	) {
		// Find the loop block
		string pattern = @$"\[\[foreach (?<objectname>[^\s]+) in\s*{Regex.Escape (listToken)}\s*\]\](?<loopcontent>.*?)\[\[endeach\]\]";
		//
		var regex = new Regex (pattern, RegexOptions.Singleline);
		var match = regex.Match (template);

		if (!match.Success) {
			return template;
		}

		string loopContent = match.Groups["loopcontent"].Value;
		string objectname = match.Groups["objectname"].Value;

		var sb = new System.Text.StringBuilder ();

		foreach (var itemObj in items) {
			if (itemObj == null) {
				continue;
			}

			string itemStr = loopContent;
			var props = itemObj.GetType ().GetProperties ();

			foreach (var prop in props) {
				string token = @$"{{{{{objectname}.{prop.Name}}}}}";
				var value = prop.GetValue (itemObj)?.ToString () ?? string.Empty;
				itemStr = itemStr.Replace (token, value);
			}

			sb.Append (itemStr);
		}

		// Replace the whole loop block with the expanded content
		return template.Replace (match.Value, sb.ToString ());
	}
}