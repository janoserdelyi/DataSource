﻿
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace templatetests;

public class Program
{
	public static void Main (
		string[] args
	) {

		var templater = new Templater ();

		var exampleObject = new ExampleObject () {
			FirstName = "janos",
			GoodListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" }
			},
			BadListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" },
				new Listing() { Id = 897, FullAddress = "503 S River Pl, City, AL 15432" }
			}
		};

		// var template = "<h1>{{o.FirstName}}</h1>\n<h2>Good Listings</h2>\n<ul>\n[[foreach listing in o.GoodListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>\n<h2>Bad Listings</h2>\n<ul>\n[[foreach listing in o.BadListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>";

		var template = @"
<h1>{{ToUpper(o.FirstName)}}</h1>

<h2>Good Listings ({{GetCount(o.GoodListings)}})</h2>
<ul>
[[foreach thing in o.GoodListings]]
	<li id=""{{thing.Id}}"">{{thing.FullAddress}}</li>
[[endeach]]
</ul>

<h2>Bad Listings ({{o.BadListings.Count}})</h2>
<ul>
[[foreach listing in o.BadListings]]
	<li id=""{{listing.Id}}"">{{listing.FullAddress}}</li>
[[endeach]]
</ul>";

		var result = processTemplate<ExampleObject> (
			exampleObject,
			template,
			new Dictionary<string, Func<object, object>>{
				{ "getCount", x => BuiltIns.GetCount(x as System.Collections.IEnumerable) },
				{ "toUpper", x => BuiltIns.ToUpper(x.ToString()) }
			}
		);

		Console.WriteLine (result);

		Console.WriteLine ("=".PadRight (80, '='));


		var clusteredObject = new ExampleClusteredObject () {
			ObjectOne = exampleObject,
			Person = new Person () {
				FirstName = "janos",
				LastName = "erdelyi",
				EmailAddress = "jerdelyi@costar.com"
			}
		};

		var clusteredTemplate = @"
<h1>{{ToUpper(o.Person.FirstName)}}</h1>

<h2>Good Listings ({{GetCount(o.ObjectOne.GoodListings)}})</h2>
<ul>
[[foreach thing in o.ObjectOne.GoodListings]]
	<li id=""{{thing.Id}}"">{{thing.FullAddress}}</li>
[[endeach]]
</ul>

<h2>Bad Listings ({{o.ObjectOne.BadListings.Count}})</h2>
<ul>
[[foreach listing in o.ObjectOne.BadListings]]
	<li id=""{{listing.Id}}"">{{listing.FullAddress}}</li>
[[endeach]]
</ul>";

		var result2 = processTemplate<ExampleClusteredObject> (
			clusteredObject,
			clusteredTemplate,
			new Dictionary<string, Func<object, object>> {
				{ "GetCount", x => BuiltIns.GetCount(x as System.Collections.IEnumerable) },
				{ "ToUpper", x => BuiltIns.ToUpper(x.ToString()) }
			}
		);

		Console.WriteLine (result2);
		Console.WriteLine ("=".PadRight (80, '='));

		var serializedExample = JsonConvert.SerializeObject (clusteredObject);

		var result3 = templater.Process (
			serializedExample,
			clusteredTemplate,
			new Dictionary<string, Func<object, object>> {
				{ "GetCount", x => BuiltIns.GetCount(x as System.Collections.IEnumerable) },
				{ "ToUpper", x => BuiltIns.ToUpper(x.ToString()) }
			}
		);

		Console.WriteLine (result3);

		Console.WriteLine ("done");
	}

	internal static string processTemplate<T> (
		T obj,
		string template,
		Dictionary<string, Func<object, object>>? functions = null
	) {
		// Replace function tokens like {{funcName(arg)}}
		if (functions != null) {
			template = Regex.Replace (template, @"\{\{(\w+)\(([^\)]+)\)\}\}", match => {
				var funcName = match.Groups[1].Value;
				var argPath = match.Groups[2].Value.Trim ();
				if (!functions.TryGetValue (funcName, out var func)) {
					return match.Value;
				}
				// Support only o.XXX.YYY as arg
				object? current = obj;
				foreach (var part in argPath.Split ('.')) {
					if (current == null) {
						break;
					}
					if (part == "o") {
						continue;
					}

					var propInfo = current.GetType ().GetProperty (part);

					if (propInfo == null) {
						current = null;
						break;
					}

					current = propInfo.GetValue (current);
				}
				return func (current ?? new object ())?.ToString () ?? string.Empty;
			});
		}

		// Replace object tokens, including nested (e.g., {{o.Property}}, {{o.List.Count}})
		template = Regex.Replace (template, @"\{\{o\.([\w\.]+)\}\}", match => {
			string path = match.Groups[1].Value;
			object? current = obj;
			var type = typeof (T);
			foreach (var part in path.Split ('.')) {
				if (current == null) {
					break;
				}

				if (part == "Count" && current is System.Collections.ICollection coll) {
					current = coll.Count;
				} else {
					var propInfo = current.GetType ().GetProperty (part);

					if (propInfo == null) {
						current = null;
						break;
					}

					current = propInfo.GetValue (current);
				}
			}
			return current?.ToString () ?? string.Empty;
		});
		var props = typeof (T).GetProperties ();

		// Find all loop tokens like [[foreach ... in o.X.Y.Z]]
		var loopRegex = new Regex (@"\[\[foreach [^\s]+ in (?<listtoken>o(?:\.[\w]+)+)\]\]", RegexOptions.Singleline);
		var matches = loopRegex.Matches (template);
		foreach (Match m in matches) {
			var listToken = m.Groups["listtoken"].Value;

			// Traverse the object graph for deep property access
			object? current = obj;
			foreach (var part in listToken.Split ('.')) {
				if (current == null) {
					break;
				}
				if (part == "o") {
					continue;
				}

				var propInfo = current.GetType ().GetProperty (part);

				if (propInfo == null) {
					current = null;
					break;
				}

				current = propInfo.GetValue (current);
			}
			if (current is System.Collections.IEnumerable list && !(current is string)) {
				template = parseLoop (template, listToken, list);
			}
		}

		return template;
	}

	private static string parseLoop (
		string template,
		string listToken,
		System.Collections.IEnumerable items
	) {
		// Find the loop block
		string pattern = @$"\[\[foreach (?<objectname>[^\s]+) in\s*{Regex.Escape (listToken)}\s*\]\](?<loopcontent>.*?)\[\[endeach\]\]";
		//
		var regex = new Regex (pattern, RegexOptions.Singleline);
		var match = regex.Match (template);

		if (!match.Success) {
			return template;
		}

		string loopContent = match.Groups["loopcontent"].Value;
		string objectname = match.Groups["objectname"].Value;

		var sb = new System.Text.StringBuilder ();

		foreach (var itemObj in items) {
			if (itemObj == null) {
				continue;
			}

			string itemStr = loopContent;
			var props = itemObj.GetType ().GetProperties ();

			foreach (var prop in props) {
				string token = @$"{{{{{objectname}.{prop.Name}}}}}";
				var value = prop.GetValue (itemObj)?.ToString () ?? string.Empty;
				itemStr = itemStr.Replace (token, value);
			}

			sb.Append (itemStr);
		}

		// Replace the whole loop block with the expanded content
		return template.Replace (match.Value, sb.ToString ());
	}
}

public class Listing
{
	public required int Id { get; set; }
	public required string FullAddress { get; set; }
}

public class ExampleObject
{
	public string? FirstName { get; set; }
	public List<Listing> GoodListings { get; set; } = new List<Listing> ();
	public List<Listing> BadListings { get; set; } = new List<Listing> ();
}
public class Person
{
	public required string FirstName { get; set; }
	public required string LastName { get; set; }
	public required string EmailAddress { get; set; }
}

// just testing when lumping multiple objects together in order to pass multiple things into the templater
public class ExampleClusteredObject
{
	public required ExampleObject ObjectOne { get; set; }
	public required Person Person { get; set; }
}