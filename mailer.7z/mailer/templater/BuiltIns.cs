namespace templatetests;

public static class BuiltIns
{
	internal static int GetCount (
		System.Collections.IEnumerable? collection
	) {
		if (collection == null) {
			return 0;
		}

		// Check if it's a collection with a Count property first
		if (collection is System.Collections.ICollection genericCollection) {
			return genericCollection.Count;
		}

		// Check for generic ICollection<T>
		if (collection is System.Collections.Generic.ICollection<object> typedCollection) {
			return typedCollection.Count;
		}

		// Use LINQ Count() as fallback - more efficient than manual enumeration
		return System.Linq.Enumerable.Count (collection.Cast<object> ());
	}

	internal static string ToUpper (
		string? input
	) {
		if (string.IsNullOrEmpty (input)) {
			return string.Empty;
		}

		return input.ToUpper ();
	}
}