namespace scaffold;

public interface ILinkConverter
{
	string GetLink (string input);
}