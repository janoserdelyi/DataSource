
using Microsoft.AspNetCore.Http;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System;
using Carter.Request;

namespace scaffold;

public partial class EmailModule : ICarterModule
{
	private static readonly byte[] trackingGif = [0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00, 0x01, 0x00, 0x81, 0x00, 0x00, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21, 0xff, 0x0b, 0x4e, 0x45, 0x54, 0x53, 0x43, 0x41, 0x50, 0x45, 0x32, 0x2e, 0x30, 0x03, 0x01, 0x01, 0x00, 0x00, 0x21, 0xf9, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x2c, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x08, 0x04, 0x00, 0x01, 0x04, 0x04, 0x00, 0x3b];

	public void AddRoutes (IEndpointRouteBuilder app) {

		app.MapGet ("/m/img/{messageid}/transparentpixel.gif", getTrackingImage);
		// app.MapGet("/m/img/{messageid}/{imageid}", getImage);
		// app.MapGet("/m/url/{messageid}/{urlid}", goToUrl);

		// Send email endpoint
		app.MapPost ("/email/send", submitSendEmail);

		// SNS notification endpoint (for send and bounce)
		app.MapPost ("/email/sns", async (HttpContext ctx) => {
			// Parse SNS notification
			using var reader = new StreamReader (ctx.Request.Body);
			var body = await reader.ReadToEndAsync ();
			if (string.IsNullOrWhiteSpace (body)) {
				ctx.Response.StatusCode = 400;
				await ctx.Response.WriteAsync ("Empty SNS message");
				return;
			}
			try {
				var snsEnvelope = JsonConvert.DeserializeObject<SnsEnvelope> (body);
				if (snsEnvelope == null || string.IsNullOrEmpty (snsEnvelope.Type)) {
					ctx.Response.StatusCode = 400;
					await ctx.Response.WriteAsync ("Invalid SNS envelope");
					return;
				}
				// Handle subscription confirmation
				if (snsEnvelope.Type == "SubscriptionConfirmation" && !string.IsNullOrEmpty (snsEnvelope.SubscribeURL)) {
					// Optionally: fetch the SubscribeURL to confirm subscription
					ctx.Response.StatusCode = 200;
					await ctx.Response.WriteAsync ("Subscription confirmation received");
					return;
				}
				if (snsEnvelope.Type == "Notification" && !string.IsNullOrEmpty (snsEnvelope.Message)) {
					var notification = JsonConvert.DeserializeObject<SesNotification> (snsEnvelope.Message);
					if (notification?.NotificationType == "Bounce") {
						// Handle bounce
						// TODO: Log or process bounce info
						await ctx.Response.WriteAsync ($"Bounce for: {string.Join (",", notification.Bounce?.BouncedRecipients?.Select (r => r.EmailAddress))}");
						return;
					}
					if (notification?.NotificationType == "Send") {
						// Handle send
						// TODO: Log or process send info
						await ctx.Response.WriteAsync ($"Send for: {notification.Mail?.Destination?.FirstOrDefault ()}");
						return;
					}
				}
				ctx.Response.StatusCode = 200;
				await ctx.Response.WriteAsync ("SNS message received");
			} catch (Exception ex) {
				ctx.Response.StatusCode = 500;
				await ctx.Response.WriteAsync ($"SNS processing error: {ex.Message}");
			}
		});


		// Email open tracking (resource request)
		// app.MapGet ("/email/open/{id}", async (string id, HttpContext ctx) => {
		// 	// TODO: Track open event for id
		// 	// Return a 1x1 transparent pixel
		// 	ctx.Response.ContentType = "image/gif";
		// 	await ctx.Response.Body.WriteAsync (new byte[] { 71, 73, 70, 56, 57, 97, 1, 0, 1, 0, 128, 0, 0, 0, 0, 0, 255, 255, 255, 33, 249, 4, 1, 0, 0, 1, 0, 44, 0, 0, 0, 0, 1, 0, 1, 0, 0, 2, 2, 68, 1, 0, 59 });
		// });

		// Link click tracking
		app.MapGet ("/email/click/{id}", async (string id, HttpContext ctx) => {
			// TODO: Track click event for id, redirect to actual URL
			ctx.Response.Redirect ("https://ma.costar.com");
			await Task.CompletedTask;
		});
	}

	private async Task getTrackingImage (
		HttpContext ctx,
		string messageid
	) {

		// TODO log the message was opened

		ctx.Response.ContentType = "image/gif";
		await ctx.Response.Body.WriteAsync (trackingGif);
	}

	private async Task submitSendEmail (
		HttpContext ctx
	) {
		var requestBody = await ctx.Request.Body.AsStringAsync ();
		var request = JsonConvert.DeserializeObject<SendEmailRequestDto> (requestBody);
		if (request == null || string.IsNullOrEmpty (request.To) || string.IsNullOrEmpty (request.Subject) || string.IsNullOrEmpty (request.HtmlBody)) {
			ctx.Response.StatusCode = 400;
			await ctx.Response.WriteAsync ("Invalid request");
			return;
		}
		var result = await SendEmailAsync (request);
		if (result)
			await ctx.Response.WriteAsync ("Email sent");
		else {
			ctx.Response.StatusCode = 500;
			await ctx.Response.WriteAsync ("Failed to send email");
		}
	}

	private static async Task<bool> SendEmailAsync (SendEmailRequestDto req) {
		try {
			using var client = new AmazonSimpleEmailServiceClient ();
			var sendRequest = new SendEmailRequest {
				Source = "noreply@ma.costar.com",
				Destination = new Destination { ToAddresses = new List<string> { req.To } },
				Message = new Message {
					Subject = new Content (req.Subject),
					Body = new Body {
						Html = new Content (req.HtmlBody),
						Text = !string.IsNullOrEmpty (req.TextBody) ? new Content (req.TextBody) : null
					}
				}
			};
			var response = await client.SendEmailAsync (sendRequest);
			return response.HttpStatusCode == System.Net.HttpStatusCode.OK;
		} catch {
			return false;
		}
	}

	private class SendEmailRequestDto
	{
		public string To { get; set; }
		public string Subject { get; set; }
		public string HtmlBody { get; set; }
		public string TextBody { get; set; }
	}
}
