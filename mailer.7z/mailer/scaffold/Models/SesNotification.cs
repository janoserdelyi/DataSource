namespace scaffold.models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SesNotification
{
	public string NotificationType { get; set; }
	public SesMail Mail { get; set; }
	public SesBounce Bounce { get; set; }
}
