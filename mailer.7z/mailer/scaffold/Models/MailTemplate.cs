using System.Collections.Generic;

namespace scaffold.models;

public class MailTemplate
{
	public required string Subject { get; set; }
	public string? Text { get; set; }
	public string? Html { get; set; }
	public IDictionary<string, string>? Tokens { get; set; }
	public required string ProtocolAndDomain { get; set; }
	public string? TrackingPixelUrl { get; set; }
	public string? UnsubscribeUrl { get; set; }
	public ILinkConverter? LinkConverter { get; set; }

	public required string Sender { get; set; }
	public required string SenderName { get; set; }
	public required string Recipient { get; set; }
	public string? Replyto { get; set; }

	public IDictionary<string, string>? AdditionalTags { get; set; }

	public required string Surrogate { get; set; }

	public IList<string>? Cc { get; set; }
	public IList<string>? Bcc { get; set; }
}
