using System.Collections.Generic;

namespace scaffold.models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SesBounce
{
	public required List<SesBouncedRecipient> BouncedRecipients { get; set; }
}
