namespace scaffold.models;

// SNS envelope and SES notification models
[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SnsEnvelope
{
	public required string Type { get; set; }
	public required string MessageId { get; set; }
	public required string TopicArn { get; set; }
	public required string Subject { get; set; }
	public required string Message { get; set; }
	public required string SubscribeURL { get; set; }
}

