using System.Collections.Generic;

namespace scaffold.models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SesMail
{
	public string MessageId { get; set; }
	public List<string> Destination { get; set; }
}
