namespace scaffold.models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SesBouncedRecipient
{
	public required string EmailAddress { get; set; }
}
