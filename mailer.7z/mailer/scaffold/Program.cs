using Microsoft.Extensions.DependencyInjection;

namespace scaffold;

public class Program
{
	public static void Main (
		string[] args
	) {
		var builder = WebApplication.CreateBuilder (args);

		builder.Services.AddCarter ();


		// Register EmailModule
		// builder.Services.AddSingleton<ICarterModule, EmailModule> ();

		var app = builder.Build ();

		app.MapCarter ();

		app.Run ();
	}
}
