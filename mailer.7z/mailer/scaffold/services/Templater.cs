using System.Text.RegularExpressions;

namespace scaffold;

public class Templater
{

	public static MailTemplate Process (
		MailTemplate template
	) {

		template.Subject = TokenReplacement (template.Subject, template.Tokens);

		template.Text ??= "";
		template.Html ??= "";

		string textResult = Templater.TokenReplacement (template.Text, template.Tokens);
		string htmlResult = Templater.TokenReplacement (template.Html, template.Tokens);

		if (template.LinkConverter != null) {
			HashSet<string> textLinks = getTextLinks (textResult);
			HashSet<string> htmlLinks = getHtmlLinks (htmlResult);

			textLinks.UnionWith (htmlLinks);

			var linkConversions = new Dictionary<string, string?> ();

			foreach (string s in textLinks) {
				if (string.IsNullOrEmpty (s)) {
					continue;
				}
				if (!linkConversions.ContainsKey (s)) {
					linkConversions.Add (s, null);
				}
			}

			var needsLink = new HashSet<string> ();

			foreach (KeyValuePair<string, string?> kvp in linkConversions) {
				if (string.IsNullOrEmpty (kvp.Value)) {
					// i don't recall what is going on here. all values will be null
					//Console.WriteLine(kvp.Key + " needs a value");
					needsLink.Add (kvp.Key);
				}
			}

			foreach (string s in needsLink) {
				linkConversions[s] = template.LinkConverter.GetLink (s);
			}

			/*	i just ran into a logic problem!
				if i just loop these links, making replacements, i start doing double replacements if any of the links are "https://www.homes.com" for example
				ie:
					i replace https://www.homes.com with https://www.homes.com/m/example/1
					then i replace https://www.homes.com/some/real/deep/link with https://www.homes.com/m/example/2
					then the https://www.homes.com replacement can happen later again and i end up with https://www.homes.com/m/example/3/m/example/1

				so i need to drop in tokens then sweep back again
			*/

			// this feels so stupid. i need to revisit
			if (!string.IsNullOrEmpty (textResult)) {
				IDictionary<string, string> swap = new Dictionary<string, string> ();
				int iter = 0;

				foreach (KeyValuePair<string, string?> kvp in linkConversions) {
					// changing to a regex replace. it needs to ignore anything prefixed with "magic-"
					//textResult = textResult.Replace (kvp.Key, "[[" + iter.ToString () + "]]");
					textResult = Regex.Replace (textResult, "^(?!magic-)" + kvp.Key, $"[[{iter}]]");
					swap.Add ($"[[{iter}]]", (kvp.Value == null ? "" : kvp.Value));
					textResult = textResult.Replace (kvp.Key, $"[[{iter}]]");
					iter++;
				}

				foreach (KeyValuePair<string, string> kvp in swap) {
					textResult = textResult.Replace (kvp.Key, kvp.Value);
				}
			}

			if (!string.IsNullOrEmpty (htmlResult)) {
				IDictionary<string, string> swap = new Dictionary<string, string> ();
				int iter = 0;

				// wrapping in href="[[foo]]" to avoid swapping out links that are text for display
				// example: <a href="https://foo.bar">i look like a link but i'm just text for display https://foo.bar</a>
				foreach (KeyValuePair<string, string?> kvp in linkConversions) {
					//htmlResult = htmlResult.Replace ("href=\"" + kvp.Key + "\"", "href=\"[[" + iter.ToString () + "]]\"");
					htmlResult = Regex.Replace (htmlResult, $"href=\"^(?!magic-){kvp.Key}\"", $"href=\"[[{iter}]]\"");
					swap.Add ("[[" + iter + "]]", (kvp.Value == null ? "" : kvp.Value));
					htmlResult = Regex.Replace (htmlResult, $"href=\"{kvp.Key}\"", $"href=\"[[{iter}]]\"");
					iter++;
				}

				foreach (KeyValuePair<string, string> kvp in swap) {
					htmlResult = htmlResult.Replace (kvp.Key, kvp.Value);
				}
			}
		}

		// inject a tracking pixel into the html template
		if (!string.IsNullOrEmpty (template.TrackingPixelUrl) && !string.IsNullOrEmpty (htmlResult)) {
			htmlResult = htmlResult.Replace ("</body>", "<img src=\"" + template.TrackingPixelUrl + "\"/ height=\"1\" width=\"1\"></body>");
		}

		template.Text = textResult;
		template.Html = htmlResult;

		return template;
	}


	public static string TokenReplacement (
		string content,
		IDictionary<string, string>? tokens
	) {

		if (string.IsNullOrEmpty (content)) {
			return content;
		}

		// tokens may have anywhere from 1 to 3 curly-braces around them
		// some platforms do diff things with varying numbers of braces. 3 braces in sparkpost (i think?) makes sure the link it's re-encoded. this should not impact us for this usage
		// just in case i end up wanting to handle them differently, i will replace the 3 brace situation separately first then handle the 1,2 braces

		if (tokens == null || tokens.Count == 0) {
			return content;
		}

		foreach (KeyValuePair<string, string> kvp in tokens) {
			//MatchCollection matches = Regex.Matches(content, "(?<token>{{{" + kvp.Key + "}}})");
			Regex reg3 = new Regex ("(\\{{3}" + kvp.Key + "\\}{3})");
			content = reg3.Replace (content, kvp.Value); // so if i were to handle triple braces differently, this is where i would do it

			Regex reg12 = new Regex ("(\\{{1,2}" + kvp.Key + "\\}{1,2})");
			content = reg12.Replace (content, kvp.Value);
		}

		return content;
	}

	public static string GetLinkSurrogate (
		string endpoint
	) {
		// 1. select surrogate from the link table based on the endpoint value. return surrogate

		// 2. if no existing value, generate a link id keylength 8, case sensitive

		// 3. add this surrogate and endpoint to database.

		// 4. return the surrogate

		return "foo";
	}

	internal static HashSet<string> getTextLinks (
		string textContent
	) {
		HashSet<string> links = new HashSet<string> ();

		if (string.IsNullOrEmpty (textContent)) {
			return links;
		}

		//const string textLinkPattern = "\\s+^(?!magic-)(?<link>http(s){0,1}://[^\\s!]+)";
		const string textLinkPattern = "\\s+(magic-){0}(?<link>http(s){0,1}://[^\\s!]+)";

		MatchCollection matches = Regex.Matches (textContent, textLinkPattern, RegexOptions.IgnoreCase);

		if (matches == null || matches.Count == 0) {
			return links;
		}

		Console.ForegroundColor = ConsoleColor.DarkGray;
		foreach (Match match in matches) {
			string linkurl = match.Groups["link"].Value;
			Console.WriteLine ("text link match found : " + linkurl);
			links.Add (linkurl);
		}
		Console.ResetColor ();

		return links;
	}

	internal static HashSet<string> getHtmlLinks (
		string htmlContent
	) {
		HashSet<string> links = new HashSet<string> ();

		if (string.IsNullOrEmpty (htmlContent)) {
			return links;
		}

		const string htmlLinkPattern = "href=\"(?<link>http(s){0,1}://[^\"\\s!]+)\"{1}";

		// i don't want to evalulate anything above the <body>
		if (htmlContent.IndexOf ("<body") > -1) {
			htmlContent = htmlContent.Substring (htmlContent.IndexOf ("<body"));
		}

		MatchCollection matches = Regex.Matches (htmlContent, htmlLinkPattern, RegexOptions.IgnoreCase);

		if (matches == null || matches.Count == 0) {
			return links;
		}

		Console.ForegroundColor = ConsoleColor.DarkGray;
		foreach (Match match in matches) {
			string linkurl = match.Groups["link"].Value;
			Console.WriteLine ("html link match found : " + linkurl);
			links.Add (linkurl);
		}
		Console.ResetColor ();

		return links;
	}

	internal static string processLoops () {
		var exampleObject = new ExampleObject () {
			FirstName = "janos",
			GoodListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" }
			},
			BadListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" },
				new Listing() { Id = 897, FullAddress = "503 S River Pl, City, AL 15432" }
			}
		};

		var template = "<h1>{{o.FirstName}}</h1>\n<h2>Good Listings</h2>\n<ul>\n[[foreach listing in o.GoodListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>\n<h2>Bad Listings</h2>\n<ul>\n[[foreach listing in o.BadListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>";

		// Replace object tokens (e.g., {{o.FirstName}})
		template = template.Replace ("{{o.FirstName}}", exampleObject.FirstName ?? "");

		// Handle GoodListings loop
		template = parseLoop (template, "o.GoodListings", exampleObject.GoodListings);
		// Handle BadListings loop
		template = parseLoop (template, "o.BadListings", exampleObject.BadListings);

		return template;
	}

	private static string parseLoop<T> (string template, string listToken, List<T> items) {
		// Find the loop block
		string pattern = @$"\[\[foreach listing in {Regex.Escape (listToken)}\]\](.*?)\[\[endeach\]\]";
		var regex = new Regex (pattern, RegexOptions.Singleline);
		var match = regex.Match (template);

		if (!match.Success) {
			return template;
		}

		string loopContent = match.Groups[1].Value;

		var result = new System.Text.StringBuilder ();

		foreach (var itemObj in items) {
			string itemStr = loopContent;
			var props = typeof (T).GetProperties ();
			foreach (var prop in props) {
				string token = $"{{{{listing.{prop.Name}}}}}";
				var value = prop.GetValue (itemObj)?.ToString () ?? string.Empty;
				itemStr = itemStr.Replace (token, value);
			}
			result.Append (itemStr);
		}
		// Replace the whole loop block with the expanded content
		return template.Replace (match.Value, result.ToString ());
	}
}

/*
public static string processLoops () {
		var exampleObject = new ExampleObject () {
			FirstName = "janos",
			GoodListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" }
			},
			BadListings = {
				new Listing() { Id = 123, FullAddress = "213 Street Place, Townville, CO 23987" },
				new Listing() { Id = 456, FullAddress = "18 N Johnson Rd, Place, IL 45678" },
				new Listing() { Id = 897, FullAddress = "503 S River Pl, City, AL 15432" }
			}
		};
		var template = "<h1>{{o.FirstName}}</h1>\n<h2>Good Listings</h2>\n<ul>\n[[foreach listing in o.GoodListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>\n<h2>Bad Listings</h2>\n<ul>\n[[foreach listing in o.BadListings]]\n    <li id=\\\"{{listing.Id}}\\\">{{listing.FullAddress}}</li>\n[[endeach]]\n</ul>";
		template = template.Replace ("{{o.FirstName}}", exampleObject.FirstName ?? "");
		template = Templater.ParseLoop (template, "o.GoodListings", exampleObject.GoodListings);
		template = Templater.ParseLoop (template, "o.BadListings", exampleObject.BadListings);
		return template;
	}

	private static string ParseLoop (string template, string listToken, List<Listing> listings) {
		string pattern = @$"\[\[foreach listing in {Regex.Escape (listToken)}\]\](.*?)\[\[endeach\]\]";
		var regex = new Regex (pattern, RegexOptions.Singleline);
		var match = regex.Match (template);
		if (!match.Success)
			return template;
		string loopContent = match.Groups[1].Value;
		var result = new System.Text.StringBuilder ();
		foreach (var listing in listings) {
			string item = loopContent
				.Replace ("{{listing.Id}}", listing.Id.ToString ())
				.Replace ("{{listing.FullAddress}}", listing.FullAddress);
			result.Append (item);
		}
		return template.Replace (match.Value, result.ToString ());
	}
*/

public class Listing
{
	public required int Id { get; set; }
	public required string FullAddress { get; set; }
}

public class ExampleObject
{
	public string? FirstName { get; set; }
	public List<Listing> GoodListings { get; set; } = new List<Listing> ();
	public List<Listing> BadListings { get; set; } = new List<Listing> ();
}