using System.Threading.Tasks;
using Amazon;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;

namespace scaffold;

public class SesConfig
{
	public required string Accesskey { get; set; }
	public required string Secret { get; set; }
	public required string RegionName { get; set; } = "us-east-1";
	public string? ConfigsetName { get; set; } = null;
}

public class Mailer
{
	public static async Task<SendRawEmailResponse?> SendEmail (
		MailTemplate template,
		SesConfig config,
		string[]? attachmentPaths = null
	) {
		using (var sesClient = new AmazonSimpleEmailServiceClient (config.Accesskey, config.Secret, RegionEndpoint.GetBySystemName (config.RegionName))) {

			var body = new BodyBuilder () {
				HtmlBody = string.IsNullOrEmpty (template.Html) ? null : template.Html,
				TextBody = string.IsNullOrEmpty (template.Text) ? null : template.Text,
			};

			if (attachmentPaths != null && attachmentPaths.Length > 0) {
				foreach (string attachmentPath in attachmentPaths) {
					try {
						body.Attachments.Add (attachmentPath);
					} catch (Exception oops) {
						Console.WriteLine ("error with attachment : " + oops.Message);
					}
				}
			}

			var message = new MimeMessage ();
			message.From.Add (new MailboxAddress (template.SenderName, template.Sender));
			message.To.Add (new MailboxAddress (string.Empty, template.Recipient));

			if (template.Cc != null && template.Cc.Count > 0) {
				foreach (string cc in template.Cc) {
					message.Cc.Add (new MailboxAddress (string.Empty, cc));
				}
			}

			if (template.Bcc != null && template.Bcc.Count > 0) {
				foreach (string bcc in template.Bcc) {
					message.Bcc.Add (new MailboxAddress (string.Empty, bcc));
				}
			}

			message.Subject = template.Subject;
			message.Body = body.ToMessageBody ();

			if (!string.IsNullOrEmpty (template.UnsubscribeUrl)) {
				message.Headers.Add ("List-Unsubscribe", template.UnsubscribeUrl);
			}

			SendRawEmailRequest? sendRequest = null;

			using (var memstr = new System.IO.MemoryStream ()) {
				message.WriteTo (memstr);
				sendRequest = new SendRawEmailRequest { RawMessage = new RawMessage (memstr) };
			}

			try {
				Console.WriteLine ("Sending email using AWS SES...");
				return await sesClient.SendRawEmailAsync (sendRequest);
			} catch (Exception e) {
				Console.WriteLine ("The email was not sent.");
				Console.WriteLine ("Error message: " + e.Message);
				await Task.CompletedTask;
				return null;
			}
		}

	}
}