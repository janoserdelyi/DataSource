﻿using EnrollmentPipeline.Models;
using Microsoft.Extensions.Logging;
using OpenSearch.Client;

namespace EnrollmentPipeline.Repositories;

public interface IContactRepository
{
    /// <summary>
    /// Checks if a contact exists by its ID.
    /// </summary>
    /// <param name="id">Contact ID</param>
    /// <returns>True if contact exists.</returns>
    Task<bool> ContactExistsAsync(int id);
    /// <summary>
    /// Checks if multiple contacts exist by their IDs.
    /// </summary>
    /// <param name="ids">Array of Contact IDs</param>
    /// <returns>Dictionary mapping each ID to whether it exists.</returns>
    Task<Dictionary<int, bool>> ContactExistsAsync(int[] ids);
    /// <summary>
    /// Retrieves a contact by its ID.
    /// </summary>
    /// <param name="id">Contact ID</param>
    /// <returns></returns>
    Task<Contact?> GetContactByIdAsync(int id);
    /// <summary>
    /// Retrieves multiple contacts by their IDs.
    /// </summary>
    /// <param name="ids">Array of Contact IDs</param>
    /// <returns></returns>
    Task<IEnumerable<Contact>> GetContactsByIdsAsync(int[] ids);
    /// <summary>
    /// Retrieves all contacts with pagination.
    /// </summary>
    /// <param name="limit">Maximum number of contacts to retrieve.</param>
    /// <param name="offset">Number of contacts to skip.</param>
    /// <returns></returns>
	Task<IEnumerable<Contact>> GetAllContacts(int limit, int offset = 0);
}

public class ContactRepository(IOpenSearchClient client, ILogger<ContactRepository> logger) : IContactRepository
{
    private static readonly string CONTACT_INDEX = "marketing-contact-data-lake.reader";

    public async Task<bool> ContactExistsAsync(int id)
    {
        try
        {
            logger.LogDebug("Checking if contact exists with ID {ContactId}", id);

            var query = new SearchDescriptor<Contact>()
                .Index(CONTACT_INDEX)
                .Query(q => q
                    .Ids(i => i
                        .Values([ id.ToString() ])
                    )
                )
                .Source(false); // We only need IDs, not the full documents

            var response = await client.SearchAsync<Contact>(query);

            if (!response.IsValid)
            {
                logger.LogError("OpenSearch error checking contact existence {ContactId}: {Error}",
                    id, response.ServerError?.Error?.Reason ?? "Unknown error");
                throw new InvalidOperationException($"Failed to check contact existence {id}: {response.ServerError?.Error?.Reason ?? "Unknown error"}");
            }

            logger.LogDebug("Contact {ContactId} exists: {Exists}", id, response.Hits.Any());
            return response.Hits.Any();
        }
        catch (Exception ex) when (ex is not InvalidOperationException)
        {
            logger.LogError(ex, "Unexpected error checking contact existence {ContactId}", id);
            throw new InvalidOperationException($"Failed to check contact existence {id}", ex);
        }
    }

    public async Task<Dictionary<int, bool>> ContactExistsAsync(int[] ids)
    {
        var uniqueIds = ids.Distinct().ToArray();

        if (uniqueIds.Length == 0)
        {
            return [];
        }

        var tasks = uniqueIds
            .Chunk(10_000) // Process in chunks of 10,000 to avoid too large queries
            .Select(async chunk =>
            {
                logger.LogDebug("Checking existence for contact ID chunk: [{Ids}]", string.Join(", ", chunk));
                try
                {
                    var query = new SearchDescriptor<Contact>()
                        .Index(CONTACT_INDEX)
                        .Query(q => q
                            .Ids(i => i
                                .Values(chunk.Select(id => id.ToString()))
                            )
                        )
                        .Size(chunk.Length)
                        .Source(false); // We only need IDs, not the full documents

                    var response = await client.SearchAsync<Contact>(query);

                    if (!response.IsValid)
                    {
                        throw new InvalidOperationException($"Failed to check contact existence: {response.ServerError?.Error?.Reason ?? "Unknown error"}");
                    }

                    // Retrieves the IDs that were found
                    return response.Hits.Select(hit => int.Parse(hit.Id)).ToHashSet();
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "OpenSearch error checking contact existence for IDs: [{Ids}]: {Error}",
                        string.Join(", ", chunk), ex.Message);

                    return [];
                }
            });

        var foundIds = (await Task.WhenAll(tasks))
            .SelectMany(ids => ids)
            .ToHashSet();

        // Build result dictionary with all requested IDs
        var result = uniqueIds.ToDictionary(id => id, foundIds.Contains);

        var foundCount = result.Count(kvp => kvp.Value);
        logger.LogDebug("Found {FoundCount} out of {RequestedCount} contacts exist", foundCount, uniqueIds.Length);

        return result;
    }

    public async Task<IEnumerable<Contact>> GetAllContacts(int limit, int offset = 0)
    {
        logger.LogDebug("Starting scroll query for {Limit} contacts with offset {Offset}", limit, offset);

        // Return empty list if limit is 0 (Elasticsearch doesn't support size=0 in scroll context)
        if (limit <= 0)
        {
            logger.LogDebug("Limit is 0 or negative, returning empty list");
            return Enumerable.Empty<Contact>();
        }

        var allContacts = new List<Contact>();
        var scrollTime = "1m"; // Keep scroll context alive for 1 minute
        var scrollSize = Math.Min(10000, limit); // Max 10000 per scroll batch

        // Initial search request with scroll
        var initialQuery = new SearchDescriptor<Contact>()
            .Index(CONTACT_INDEX)
            .Size(scrollSize)
            .Scroll(scrollTime)
            .Sort(s => s.Ascending(c => c.Id)); // Consistent ordering for pagination

        var initialResponse = await client.SearchAsync<Contact>(initialQuery);

        if (!initialResponse.IsValid)
        {
            logger.LogError("OpenSearch error starting scroll: {Error}",
                initialResponse.ServerError?.Error?.Reason ?? "Unknown error");
            throw new InvalidOperationException($"Failed to start scroll: {initialResponse.ServerError?.Error?.Reason ?? "Unknown error"}");
        }

        var scrollId = initialResponse.ScrollId;
        var scrolledContacts = initialResponse.Documents.ToList();

        logger.LogDebug("Initial scroll returned {Count} contacts, scrollId={ScrollId}", scrolledContacts.Count, scrollId);

        // Skip contacts until we reach the desired offset
        var currentPosition = 0;

        try
        {
            while (!string.IsNullOrEmpty(scrollId))
            {
                // Process current batch
                foreach (var contact in scrolledContacts)
                {
                    if (currentPosition >= offset && allContacts.Count < limit)
                    {
                        allContacts.Add(contact);
                    }
                    currentPosition++;

                    // Stop if we've collected enough contacts
                    if (allContacts.Count >= limit)
                    {
                        break;
                    }
                }

                // Stop if we've collected enough contacts or no more documents
                if (allContacts.Count >= limit || scrolledContacts.Count == 0)
                {
                    break;
                }

                // Continue scrolling
                var scrollResponse = await client.ScrollAsync<Contact>(scrollTime, scrollId);

                if (!scrollResponse.IsValid)
                {
                    logger.LogError("OpenSearch error during scroll: {Error}",
                        scrollResponse.ServerError?.Error?.Reason ?? "Unknown error");
                    throw new InvalidOperationException($"Failed during scroll: {scrollResponse.ServerError?.Error?.Reason ?? "Unknown error"}");
                }

                scrollId = scrollResponse.ScrollId;
                scrolledContacts = scrollResponse.Documents.ToList();

                logger.LogDebug("Scroll returned {Count} contacts, total collected={TotalCount}",
                    scrolledContacts.Count, allContacts.Count);
            }
        }
        finally
        {
            // Always clear the scroll context when done
            if (!string.IsNullOrEmpty(scrollId))
            {
                logger.LogDebug("Clearing scroll context: {ScrollId}", scrollId);
                try
                {
                    await client.ClearScrollAsync(c => c.ScrollId(scrollId));
                }
                catch (Exception ex)
                {
                    logger.LogWarning(ex, "Failed to clear scroll context: {ScrollId}", scrollId);
                }
            }
        }

        logger.LogDebug("Scroll query complete, retrieved {TotalCount} contacts", allContacts.Count);
        return allContacts;
    }

    public async Task<Contact?> GetContactByIdAsync(int id)
    {
        try
        {
            logger.LogDebug("Searching for contact with ID {ContactId}", id);

            var response = await client.GetAsync<Contact>(id, idx => idx.Index(CONTACT_INDEX));

            if (response.IsValid && response.Found)
            {
                logger.LogDebug("Found contact with ID {ContactId}", id);
                return response.Source;
            }

            logger.LogDebug("Contact with ID {ContactId} not found", id);
            return null;
        }
        catch (Exception ex) when (ex is not InvalidOperationException)
        {
            logger.LogError(ex, "Unexpected error searching for contact {ContactId}", id);
            throw new InvalidOperationException($"Failed to search for contact {id}", ex);
        }
    }

    public async Task<IEnumerable<Contact>> GetContactsByIdsAsync(int[] ids)
    {
        if (ids.Length == 0)
        {
            return [];
        }

        try
        {
            logger.LogDebug("Searching for {Count} contacts with IDs: [{Ids}]", ids.Length, string.Join(", ", ids));

            var query = new SearchDescriptor<Contact>()
                .Index(CONTACT_INDEX)
                .Query(q => q
                    .Ids(i => i
                        .Values(ids.Select(id => id.ToString()))
                    )
                )
                .Size(ids.Length);

            var response = await client.SearchAsync<Contact>(query);

            if (!response.IsValid)
            {
                logger.LogError("OpenSearch error searching for contacts with IDs [{Ids}]: {Error}",
                    string.Join(", ", ids), response.ServerError?.Error?.Reason ?? "Unknown error");
                throw new InvalidOperationException($"Failed to search for contacts: {response.ServerError?.Error?.Reason ?? "Unknown error"}");
            }

            var contacts = response.Documents.ToList();

            logger.LogDebug("Found {FoundCount} out of {RequestedCount} contacts", contacts.Count, ids.Length);
            return contacts;
        }
        catch (Exception ex) when (ex is not InvalidOperationException)
        {
            logger.LogError(ex, "Unexpected error searching for contacts with IDs: [{Ids}]", string.Join(", ", ids));
            throw new InvalidOperationException($"Failed to search for contacts", ex);
        }
    }
}
