﻿using EnrollmentPipeline.Models;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Logging;
using OpenSearch.Client;

namespace EnrollmentPipeline.Repositories;

public interface ICampaignRepository
{
	/// <summary>
	/// Checks if a marketing campaign exists by its ID.
	/// </summary>
	/// <param name="id">Marketing Campaign ID</param>
	/// <returns>True if campaign exists.</returns>
	Task<bool> CampaignExistsAsync(int id);
	/// <summary>
	/// Retrieves a marketing campaign by its ID.
	/// </summary>
	/// <param name="id">Marketing Campaign ID</param>
	/// <returns>The marketing campaign if found; otherwise, null.</returns>
	Task<MarketingCampaign?> GetCampaignByIdAsync(int id);
    /// <summary>
    /// Retrieves a marketing campaign by its ID, utilizing caching.
    /// </summary>
	/// <returns>The marketing campaign if found; otherwise, null.</returns>
	Task<MarketingCampaign?> GetCachedCampaignByIdAsync(int id);
	/// <summary>
	/// Retrieves multiple marketing campaigns by their IDs.
	/// </summary>
	/// <param name="ids">Array of Marketing Campaign IDs</param>
    /// <param name="useCache">Whether to use cached results</param>
	/// <returns>An array of marketing campaigns.</returns>
	Task<IEnumerable<MarketingCampaign>> GetCampaignsByIdAsync(int[] ids, bool useCache = false);
}

public class CampaignRepository(
    HybridCache hybridCache,
    IOpenSearchClient client, 
    ILogger<CampaignRepository> logger
) : ICampaignRepository
{
	private static readonly string CAMPAIGN_INDEX = "ma-campaigns.reader";
    /// <summary>
    /// In-memory cache duration for marketing campaigns.
    /// </summary>
    private static readonly TimeSpan LocalCacheDuration = TimeSpan.FromSeconds(30);
    /// <summary>
    /// Distributed cache (Redis) duration for marketing campaigns.
    /// </summary>
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(2);
    /// <summary>
    /// Generates the cache key for a marketing campaign.
    /// </summary>
    private string GetCampaignCacheKey(int marketingCampaignId) => $"MarketingCampaign:{marketingCampaignId}";

	public async Task<bool> CampaignExistsAsync(int id)
    {
        try
        {
            logger.LogDebug("Checking if campaign exists with ID {CampaignId}", id);

            var response = await client.DocumentExistsAsync<MarketingCampaign>(id, idx => idx.Index(CAMPAIGN_INDEX));

            if (!response.IsValid)
            {
                logger.LogError("OpenSearch error checking campaign existence {CampaignId}: {Error}",
                    id, response.ServerError?.Error?.Reason ?? "Unknown error");
                throw new InvalidOperationException($"Failed to check campaign existence {id}: {response.ServerError?.Error?.Reason ?? "Unknown error"}");
            }

            logger.LogDebug("Campaign {CampaignId} exists: {Exists}", id, response.Exists);
            return response.Exists;
        }
        catch (Exception ex) when (ex is not InvalidOperationException)
        {
            logger.LogError(ex, "Unexpected error checking campaign existence {CampaignId}", id);
            throw new InvalidOperationException($"Failed to check campaign existence {id}", ex);
        }
    }

    public async Task<MarketingCampaign?> GetCampaignByIdAsync(int id)
    {
        try
        {
            logger.LogDebug("Searching for campaign with ID {CampaignId}", id);

            var response = await client.GetAsync<MarketingCampaign>(id, idx => idx.Index(CAMPAIGN_INDEX));

            if (response.IsValid && response.Found)
            {
                logger.LogDebug("Found campaign with ID {CampaignId}", id);
                return response.Source;
            }

            logger.LogDebug("Campaign with ID {CampaignId} not found", id);
            return null;
        }
        catch (Exception ex) when (ex is not InvalidOperationException)
        {
            logger.LogError(ex, "Unexpected error searching for campaign {CampaignId}", id);
            throw new InvalidOperationException($"Failed to search for campaign {id}", ex);
        }
    }

    public async Task<MarketingCampaign?> GetCachedCampaignByIdAsync(int id)
    {
        return await hybridCache.GetOrCreateAsync(
            GetCampaignCacheKey(id),
            async (cancellationToken) =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                return await GetCampaignByIdAsync(id);
            },
            options: new HybridCacheEntryOptions
            {
                LocalCacheExpiration = LocalCacheDuration,
                Expiration = CacheDuration
            });
    }

    public async Task<IEnumerable<MarketingCampaign>> GetCampaignsByIdAsync(int[] ids, bool useCache = false)
    {
        if (ids.Length == 0)
        {
            return [];
        }

        try
        {
            logger.LogDebug("Searching for {Count} campaigns with IDs: [{Ids}]", ids.Length, string.Join(", ", ids));

            var tasks = ids.Select(id => useCache ? GetCachedCampaignByIdAsync(id) : GetCampaignByIdAsync(id)).ToArray();
            var results = await Task.WhenAll(tasks);

            var campaigns = results.Where(c => c != null).Cast<MarketingCampaign>().ToList();

            logger.LogDebug("Found {FoundCount} out of {RequestedCount} campaigns", campaigns.Count, ids.Length);
            return campaigns;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error searching for campaigns with IDs: [{Ids}]", string.Join(", ", ids));
            throw new InvalidOperationException($"Failed to search for campaigns", ex);
        }
    }
}
