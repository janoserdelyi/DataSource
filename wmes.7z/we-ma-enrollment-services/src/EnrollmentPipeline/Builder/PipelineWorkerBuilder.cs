using EnrollmentPipeline.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EnrollmentPipeline.Builder;

public static class PipelineWorkerBuilder
{
	/// <summary>
	/// Creates a WebApplication object with Enrollment Pipeline worker configurations.
	/// </summary>
	/// <typeparam name="TWorker">Worker type</typeparam>
	/// <param name="args">Application arguments</param>
	/// <param name="configureBuilder">Function to configure the WebApplicationBuilder</param>
	/// <returns></returns>
	public static WebApplication Create<TWorker>(
		string[] args,
		Action<WebApplicationBuilder>? configureBuilder = null
	) where TWorker : StreamPipelineWorker
	{
		var app = Create(
			args,
			builder =>
			{
				// Add the worker as a hosted service
				builder.Services.AddHostedService<TWorker>();

				// Invoke additional configuration provided by the caller
				configureBuilder?.Invoke(builder);
			}
		);

		return app;
	}

	/// <summary>
	/// Creates a WebApplication object with Enrollment Pipeline worker configurations.
	/// </summary>
	/// <param name="args">Application arguments</param>
	/// <param name="configureBuilder">Function to configure the WebApplicationBuilder</param>
	/// <returns></returns>
	public static WebApplication Create(
		string[] args,
		Action<WebApplicationBuilder>? configureBuilder = null
	)
	{
		var builder = WebApplication.CreateBuilder(args);

		// Configure logging
		builder.Logging.AddDataDogJsonConsole();
		// Configure OpenTelemetry
		builder.AddOpenTelemetry();
		// Configure Redis connection with telemetry
		builder.AddRedis();
		// Add Postgres database
		builder.AddPostgresDatabase();

		// Invoke additional configuration provided by the caller
		configureBuilder?.Invoke(builder);

		// Add pipeline health checks
		builder.AddPipelineHealthChecks();

		var app = builder.Build();

		app.UseHttpsRedirection();
		// Add health check endpoints
		app.UseHealthCheckEndpoints();

		var basePath = app.Configuration.GetValue<string> ("BasePath");

		// Add base path when present
		if (!string.IsNullOrEmpty(basePath))
		{
			app.UsePathBase(basePath);
		}

		return app;
	}
}