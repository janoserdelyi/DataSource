﻿using Microsoft.Extensions.DependencyInjection;

namespace EnrollmentPipeline.DataAccess.Queries;

public interface IQueryDispatcher
{
	/// <summary>
	/// Dispatches a query and retrieves a query result
	/// </summary>
	/// <typeparam name="TQuery">Request to execute type</typeparam>
	/// <typeparam name="TResult">Request Result to get back type</typeparam>
	/// <param name="query">Request to execute</param>
	/// <param name="cancellationToken">Cancellation token</param>
	/// <returns>Request Result to get back</returns>
	Task<TResult> Dispatch<TQuery, TResult>(TQuery query, CancellationToken cancellationToken = new CancellationToken());
}

public class QueryDispatcher(IServiceProvider provider) : IQueryDispatcher
{
	public async Task<TResult> Dispatch<TQuery, TResult>(TQuery query, CancellationToken cancellationToken = new CancellationToken())
	{
		var handler = provider.GetRequiredService<IQueryHandler<TQuery, TResult>>();
		return await handler.GetAsync(query, cancellationToken);
	}
}
