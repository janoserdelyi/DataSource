using Microsoft.Extensions.DependencyInjection;

namespace EnrollmentPipeline.DataAccess.Commands;

public interface ICommandDispatcher
{
	Task Dispatch<TCommand>(TCommand command);
}

public class CommandDispatcher(IServiceProvider provider) : ICommandDispatcher
{
	public async Task Dispatch<TCommand>(TCommand command)
	{
		var handler = provider.GetRequiredService<ICommandHandler<TCommand>>();
		await handler.ExecuteAsync(command);
	}
}
