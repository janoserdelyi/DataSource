﻿using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.DataAccess.Queries;

public interface IQueryHandler<TQuery, TResult>
{
	Task<TResult> GetAsync(TQuery query, CancellationToken cancellationToken = new CancellationToken());
}

/// <summary>
/// A base to the MarketingQuery that can hopefully be re-used. Defaults to using Dapper to return the Response based on the provided Request
/// </summary>
/// <typeparam name="TQuery"></typeparam>
/// <typeparam name="TResult"></typeparam>
public abstract class QueryHandler<TQuery, TResult>(
	ILogger<QueryHandler<TQuery, TResult>> logger) : IQueryHandler<TQuery, TResult>
{

	/// <summary>
	/// Runs the <paramref name="query"/>.
	/// </summary>
	/// <param name="query">The Query to handle</param>
	/// <param name="cancellationToken"></param>
	/// <returns></returns>
	public async Task<TResult> GetAsync(TQuery query, CancellationToken cancellationToken = new CancellationToken())
	{
		try
		{
			// TODO: Add a retry mechanism
			return await Handle(query);
		}
		catch (Exception ex)
		{
			logger.LogError(ex, $"Exception Executing Query: {typeof(TQuery).Name}");
			throw;
		}
	}

	protected abstract Task<TResult> Handle(TQuery query);
}
