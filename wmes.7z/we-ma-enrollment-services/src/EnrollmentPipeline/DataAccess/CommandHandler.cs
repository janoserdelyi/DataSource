using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.DataAccess.Commands;

public interface ICommandHandler<TCommand>
{
	Task ExecuteAsync(TCommand command, CancellationToken cancellationToken = new CancellationToken());
}

public abstract class CommandHandler<TCommand>(
	ILogger<CommandHandler<TCommand>> logger
) : ICommandHandler<TCommand>
{	public async Task ExecuteAsync(TCommand command, CancellationToken cancellationToken = new CancellationToken())
	{
		try
		{
			// TODO: Add a retry mechanism
			await Handle(command);
		}
		catch (Exception ex)
		{
			logger.LogError(ex, $"Exception Executing Query: {typeof(TCommand).Name}");
			throw;
		}
	}

	protected abstract Task Handle(TCommand command);
}
