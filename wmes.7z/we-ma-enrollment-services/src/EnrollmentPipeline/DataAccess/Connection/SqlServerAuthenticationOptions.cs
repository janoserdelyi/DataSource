using Microsoft.Extensions.Options;

namespace EnrollmentPipeline.DataAccess.Connection
{
	/// <summary>
	/// Options for connecting to SQL Server using SQL Server Authentication.
	/// To be used with <see cref="IOptionsMonitor{SqlServerAuthenticationOptions}" />
	/// </summary>
	public class SqlServerAuthenticationOptions
	{
		/// <summary>
		/// Gets or sets the user name to use to connect to SQL Server.
		/// </summary>
		public required string Username { get; set; }

		/// <summary>
		/// Gets or sets the password for the <see cref="Username"/> account.
		/// </summary>
		public required string Password { get; set; }
	}
}
