using OpenSearch.Client;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace EnrollmentPipeline.HealthChecks;

public class OpenSearchHealthCheck(IOpenSearchClient client) : IHealthCheck
{

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            // First check basic connectivity
            var pingResponse = await client.PingAsync(ct: cancellationToken);

            if (!pingResponse.IsValid)
            {
                var exception = pingResponse.OriginalException;

                if (exception != null)
                {
                    if (exception is OperationCanceledException canceledException)
                    {
                        return HealthCheckResult.Degraded($"OpenSearch health check cancelled.", canceledException);
                    }

                    return HealthCheckResult.Unhealthy($"OpenSearch cluster not accessible: {exception.Message}", exception);
                }

                var errorMessage = pingResponse.ServerError?.Error?.Reason ?? "Unknown connectivity error";
                return HealthCheckResult.Unhealthy($"OpenSearch cluster not accessible: {errorMessage}");
            }

            // Get cluster health for detailed status
            var healthResponse = await client.Cluster.HealthAsync(ct: cancellationToken);

            if (!healthResponse.IsValid)
            {
                var errorMessage = healthResponse.ServerError?.Error?.Reason ?? "Unable to retrieve cluster health";
                return HealthCheckResult.Degraded($"Cluster accessible but health check failed: {errorMessage}");
            }

            var clusterHealth = healthResponse;
            stopwatch.Stop();

            var healthData = new Dictionary<string, object>
            {
                ["cluster_name"] = clusterHealth.ClusterName,
                ["status"] = clusterHealth.Status.ToString().ToLowerInvariant(),
                ["response_time_ms"] = stopwatch.ElapsedMilliseconds,
                ["nodes"] = new
                {
                    total = clusterHealth.NumberOfNodes,
                    data = clusterHealth.NumberOfDataNodes
                },
                ["indices"] = new
                {
                    active_primary_shards = clusterHealth.ActivePrimaryShards,
                    active_shards = clusterHealth.ActiveShards,
                    relocating_shards = clusterHealth.RelocatingShards,
                    initializing_shards = clusterHealth.InitializingShards,
                    unassigned_shards = clusterHealth.UnassignedShards
                }
            };

            // Determine health status based on cluster status
            var healthStatus = HealthStatus.Healthy;
            var statusString = clusterHealth.Status.ToString().ToLowerInvariant();
            var message = $"Cluster '{clusterHealth.ClusterName}' is {statusString} ({stopwatch.ElapsedMilliseconds}ms)";

            switch (statusString)
            {
                case "green":
                    healthStatus = HealthStatus.Healthy;
                    break;

                case "yellow":
                    healthStatus = HealthStatus.Degraded;
                    message += $" - {clusterHealth.UnassignedShards} unassigned shards";
                    break;

                case "red":
                    healthStatus = HealthStatus.Unhealthy;
                    message += $" - {clusterHealth.UnassignedShards} unassigned shards";
                    break;

                default:
                    healthStatus = HealthStatus.Unhealthy;
                    message = $"Cluster '{clusterHealth.ClusterName}' has unknown status: {statusString}";
                    break;
            }

            return new HealthCheckResult(healthStatus, message, data: healthData);
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy($"OpenSearch health check failed: {ex.Message}", ex);
        }
    }
}