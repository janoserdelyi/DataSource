using System.Data;
using System.Diagnostics;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
using Dapper;
using Microsoft.Extensions.DependencyInjection;
using EnrollmentPipeline.Extensions;

namespace EnrollmentPipeline.HealthChecks;

/// <summary>
/// Health check for SQL Server database connectivity and performance
/// </summary>
public class SqlServerHealthCheck : IHealthCheck
{
	private readonly IDbConnection _connection;
	private readonly ILogger<SqlServerHealthCheck> _logger;

	public SqlServerHealthCheck([FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
		ILogger<SqlServerHealthCheck> logger)
	{
		_connection = connection;
		_logger = logger;
	}

	public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context,
		CancellationToken cancellationToken = default)
	{
		var stopwatch = Stopwatch.StartNew();

		try
		{
			// Test basic connectivity
			if (_connection.State != ConnectionState.Open)
			{
				_connection.Open();
			}

			// Get database version and basic info
			var versionInfo = await _connection.QueryFirstOrDefaultAsync<DatabaseInfo>(
				@"SELECT 
                    @@VERSION as version,
                    DB_NAME() as databaseName,
                    SYSTEM_USER as currentUser,
                    @@SERVERNAME as serverName",
				commandTimeout: 30) ?? new DatabaseInfo();

			// Test query performance with a simple operation
			var performanceTestStart = Stopwatch.StartNew();
			_ = await _connection.QueryFirstOrDefaultAsync<int>(
				"SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process = 1",
				commandTimeout: 30);
			performanceTestStart.Stop();

			// Get server role and edition info
			ServerInfo serverInfo;
			try
			{
				serverInfo = await _connection.QueryFirstOrDefaultAsync<ServerInfo>(
					@"SELECT 
                        CASE 
                            WHEN SERVERPROPERTY('IsHadrEnabled') = 1 THEN 'AlwaysOn'
                            WHEN @@VERSION LIKE '%Azure%' THEN 'Azure SQL'
                            ELSE 'Standalone'
                        END as role,
                        CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128)) as serverVersion,
                        CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128)) as edition,
                        CAST(SERVERPROPERTY('EngineEdition') AS INT) as engineEdition",
					commandTimeout: 30) ?? new ServerInfo();
			}
			catch (Exception ex)
			{
				_logger.LogWarning("Unable to retrieve server info, using defaults: {Error}", ex.Message);
				serverInfo = new ServerInfo
				{
					Role = "unknown",
					ServerVersion = "unknown",
					Edition = "unknown",
					EngineEdition = 0
				};
			}

			// Get database state
			var databaseState = "ONLINE";
			try
			{
				databaseState = await _connection.QueryFirstOrDefaultAsync<string>(
					"SELECT state_desc FROM sys.databases WHERE name = DB_NAME()",
					commandTimeout: 15) ?? "UNKNOWN";
			}
			catch (Exception ex)
			{
				_logger.LogWarning("Unable to retrieve database state: {Error}", ex.Message);
			}

			stopwatch.Stop();

			var healthData = new Dictionary<string, object>
			{
				["database_name"] = versionInfo.DatabaseName ?? "unknown",
				["server_name"] = versionInfo.ServerName ?? "unknown",
				["current_user"] = versionInfo.CurrentUser ?? "unknown",
				["version"] = ExtractSqlServerVersion(versionInfo.Version),
				["database_state"] = databaseState,
				["response_time_ms"] = stopwatch.ElapsedMilliseconds,
				["query_performance_ms"] = performanceTestStart.ElapsedMilliseconds,
				["server"] = new
				{
					role = serverInfo.Role ?? "unknown",
					server_version = serverInfo.ServerVersion ?? "unknown",
					edition = serverInfo.Edition ?? "unknown",
					engine_edition = GetEngineEditionName(serverInfo.EngineEdition)
				}
			};

			// Determine health status based on various metrics
			var healthStatus = HealthStatus.Healthy;
			var issues = new List<string>();

			// Check database state
			if (databaseState != "ONLINE")
			{
				healthStatus = HealthStatus.Unhealthy;
				issues.Add($"database not online (state: {databaseState})");
			}

			// Check response time
			if (stopwatch.ElapsedMilliseconds > 5000) // 5 seconds
			{
				healthStatus = HealthStatus.Unhealthy;
				issues.Add($"slow response ({stopwatch.ElapsedMilliseconds}ms)");
			}
			else if (stopwatch.ElapsedMilliseconds > 1000) // 1 second
			{
				if (healthStatus == HealthStatus.Healthy)
				{
					healthStatus = HealthStatus.Degraded;
				}

				issues.Add($"elevated response time ({stopwatch.ElapsedMilliseconds}ms)");
			}

			var message = issues.Any()
				? $"SQL Server database accessible with issues: {string.Join(", ", issues)} ({stopwatch.ElapsedMilliseconds}ms)"
				: "SQL Server database healthy";

			return new HealthCheckResult(healthStatus, message, data: healthData);
		}
		catch (Exception ex)
		{
			stopwatch.Stop();
			_logger.LogError(ex, "SQL Server health check failed after {ElapsedMs}ms: {Error}",
				stopwatch.ElapsedMilliseconds, ex.Message);

			var errorData = new Dictionary<string, object>
			{
				["response_time_ms"] = stopwatch.ElapsedMilliseconds,
				["error_type"] = ex.GetType().Name,
				["error_message"] = ex.Message
			};

			return HealthCheckResult.Unhealthy($"SQL Server database health check failed: {ex.Message}", ex, errorData);
		}
	}

	private static string ExtractSqlServerVersion(string? fullVersion)
	{
		if (string.IsNullOrEmpty(fullVersion))
		{
			return "unknown";
		}

		// Extract version number from full version string
		// e.g., "Microsoft SQL Server 2019 (RTM) - 15.0.2000.5..." -> "15.0.2000.5"
		try
		{
			var parts = fullVersion.Split(['-', ' '], StringSplitOptions.RemoveEmptyEntries);
			foreach (var part in parts)
			{
				if (part.Contains('.') && char.IsDigit(part[0]))
				{
					return part.Trim();
				}
			}
		}
		catch
		{
			// Fall through to return truncated version
		}

		return fullVersion.Length > 50 ? fullVersion[..50] + "..." : fullVersion;
	}

	private static string GetEngineEditionName(int engineEdition)
	{
		return engineEdition switch
		{
			1 => "Personal",
			2 => "Standard",
			3 => "Enterprise",
			4 => "Express",
			5 => "Azure SQL Database",
			6 => "Azure Synapse Analytics",
			8 => "Azure SQL Managed Instance",
			9 => "Azure SQL Edge",
			11 => "Azure Synapse serverless SQL pool",
			_ => $"Unknown ({engineEdition})"
		};
	}

	private class DatabaseInfo
	{
		public string? Version { get; init; }
		public string? DatabaseName { get; init; }
		public string? CurrentUser { get; init; }
		public string? ServerName { get; init; }
	}

	private class ServerInfo
	{
		public string? Role { get; init; }
		public string? ServerVersion { get; init; }
		public string? Edition { get; init; }
		public int EngineEdition { get; init; }
	}
}
