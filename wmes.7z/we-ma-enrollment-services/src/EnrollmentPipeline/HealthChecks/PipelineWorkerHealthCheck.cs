using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;

namespace EnrollmentPipeline.HealthChecks;

/// <summary>
/// Health check for monitoring pipeline worker status
/// </summary>
public class PipelineWorkerHealthCheck : IHealthCheck
{
    private readonly IEnumerable<IHostedService> _hostedServices;

    public PipelineWorkerHealthCheck(IEnumerable<IHostedService> hostedServices)
    {
        _hostedServices = hostedServices ?? throw new ArgumentNullException(nameof(hostedServices));
    }

    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var streamPipelineWorkers = _hostedServices
                .OfType<StreamPipelineWorker>()
                .ToList();

            if (!streamPipelineWorkers.Any())
            {
                return Task.FromResult(HealthCheckResult.Degraded(
                    "No pipeline workers found",
                    data: new Dictionary<string, object>
                    {
                        ["worker_count"] = 0,
                        ["total_hosted_services"] = _hostedServices.Count()
                    }));
            }

            var workerStatus = new List<object>();
            var healthyWorkers = 0;

            foreach (var worker in streamPipelineWorkers)
            {
                var workerType = worker.GetType();
                var isHealthy = worker != null;

                if (isHealthy)
                {
                    healthyWorkers++;
                }

                workerStatus.Add(new
                {
                    name = worker?.WorkerName,
                    status = isHealthy ? "running" : "stopped",
                    assembly = workerType.Assembly.GetName().Name,
                    worker_id = worker?.WorkerId.ToString() ?? "not-configured"
                });
            }

            var totalWorkers = streamPipelineWorkers.Count;
            var healthPercentage = (double)healthyWorkers / totalWorkers * 100;

            if (healthyWorkers == totalWorkers)
            {
                return Task.FromResult(HealthCheckResult.Healthy(
                    $"All {totalWorkers} pipeline workers are running",
                    data: new Dictionary<string, object>
                    {
                        ["worker_count"] = totalWorkers,
                        ["healthy_workers"] = healthyWorkers,
                        ["health_percentage"] = healthPercentage,
                        ["workers"] = workerStatus
                    }));
            }

            if (healthyWorkers > 0)
            {
                return Task.FromResult(HealthCheckResult.Degraded(
                    $"{healthyWorkers}/{totalWorkers} pipeline workers are running",
                    data: new Dictionary<string, object>
                    {
                        ["worker_count"] = totalWorkers,
                        ["healthy_workers"] = healthyWorkers,
                        ["health_percentage"] = healthPercentage,
                        ["workers"] = workerStatus
                    }));
            }

            return Task.FromResult(HealthCheckResult.Unhealthy(
                "No pipeline workers are running",
                data: new Dictionary<string, object>
                {
                    ["worker_count"] = totalWorkers,
                    ["healthy_workers"] = healthyWorkers,
                    ["health_percentage"] = 0,
                    ["workers"] = workerStatus
                }));
        }
        catch (Exception ex)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy(
                "Pipeline worker health check failed",
                ex,
                data: new Dictionary<string, object>
                {
                    ["error"] = ex.Message
                }));
        }
    }
}
