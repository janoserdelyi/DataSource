using System.Data;
using System.Diagnostics;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
using Dapper;
using Microsoft.Extensions.DependencyInjection;
using EnrollmentPipeline.Extensions;

namespace EnrollmentPipeline.HealthChecks;

/// <summary>
/// Health check for PostgreSQL database connectivity and performance
/// </summary>
public class PostgresHealthCheck : IHealthCheck
{
	private readonly IDbConnection _connection;
	private readonly ILogger<PostgresHealthCheck> _logger;

	public PostgresHealthCheck([FromKeyedServices(DbConnectionType.Postgres)] IDbConnection connection,
		ILogger<PostgresHealthCheck> logger)
	{
		_connection = connection;
		_logger = logger;
	}

	public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context,
		CancellationToken cancellationToken = default)
	{
		var stopwatch = Stopwatch.StartNew();

		try
		{
			// Test basic connectivity
			if (_connection.State != ConnectionState.Open)
			{
				_connection.Open();
			}

			// Get database version and basic info
			var versionInfo = await _connection.QueryFirstOrDefaultAsync<DatabaseInfo>(
				"SELECT version() as version, current_database() as databaseName, current_user as currentUser",
				commandTimeout: 30) ?? new DatabaseInfo();

			// Test query performance with a simple operation
			var performanceTestStart = Stopwatch.StartNew();
			_ = await _connection.QueryFirstOrDefaultAsync<int>(
				"SELECT count(*) FROM pg_stat_activity WHERE state = 'active'",
				commandTimeout: 30);
			performanceTestStart.Stop();

			// Get database size information (with Aurora compatibility)
			DatabaseStats databaseStats;
			try
			{
				databaseStats = await _connection.QueryFirstOrDefaultAsync<DatabaseStats>(
					@"SELECT 
                        COALESCE(pg_database_size(current_database()), 0) as sizeBytes,
                        (SELECT count(*) FROM pg_stat_activity) as totalConnections,
                        (SELECT count(*) FROM pg_stat_activity WHERE state = 'active') as activeConnections,
                        (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') as maxConnections",
					commandTimeout: 30) ?? new DatabaseStats();
			}
			catch (Exception ex)
			{
				_logger.LogWarning("Unable to retrieve database stats, using connection info only: {Error}",
					ex.Message);
				// Fallback to basic connection count only
				var basicStats = await _connection.QueryFirstOrDefaultAsync<dynamic>(
					"SELECT count(*) as active_connections FROM pg_stat_activity WHERE state = 'active'",
					commandTimeout: 15);
				databaseStats = new DatabaseStats
				{
					ActiveConnections = basicStats?.active_connections ?? 0,
					TotalConnections = basicStats?.active_connections ?? 0,
					MaxConnections = 100, // Default fallback
					SizeBytes = 0
				};
			}

			// Get basic server info (Aurora-compatible)
			ServerInfo serverInfo;
			try
			{
				serverInfo = await _connection.QueryFirstOrDefaultAsync<ServerInfo>(
					@"SELECT 
                        CASE WHEN pg_is_in_recovery() THEN 'replica' ELSE 'primary' END as role,
                        current_setting('server_version') as serverVersion",
					commandTimeout: 30) ?? new ServerInfo();
			}
			catch (Exception ex)
			{
				_logger.LogWarning("Unable to retrieve server info, using defaults: {Error}", ex.Message);
				serverInfo = new ServerInfo { Role = "unknown", ServerVersion = "unknown" };
			}

			stopwatch.Stop();

			// Calculate connection utilization percentage
			var connectionUtilization = databaseStats.MaxConnections > 0
				? Math.Min(100.0, (double)databaseStats.TotalConnections / databaseStats.MaxConnections * 100)
				: 0.0;

			var healthData = new Dictionary<string, object>
			{
				["database_name"] = versionInfo.DatabaseName ?? "unknown",
				["current_user"] = versionInfo.CurrentUser ?? "unknown",
				["version"] = versionInfo.Version ?? "unknown",
				["response_time_ms"] = stopwatch.ElapsedMilliseconds,
				["query_performance_ms"] = performanceTestStart.ElapsedMilliseconds,
				["connections"] =
					new
					{
						active = databaseStats.ActiveConnections,
						total = databaseStats.TotalConnections,
						max = databaseStats.MaxConnections,
						utilization_percent =
							double.IsFinite(connectionUtilization) ? Math.Round(connectionUtilization, 1) : 0.0
					},
				["database_size"] = new
				{
					bytes = databaseStats.SizeBytes,
					mb =
						databaseStats.SizeBytes > 0
							? Math.Round(databaseStats.SizeBytes / (1024.0 * 1024.0), 1)
							: 0.0,
					gb = databaseStats.SizeBytes > 0
						? Math.Round(databaseStats.SizeBytes / (1024.0 * 1024.0 * 1024.0), 2)
						: 0.0
				},
				["server"] = new
				{
					role = serverInfo.Role ?? "unknown",
					server_version = serverInfo.ServerVersion ?? "unknown"
				}
			};

			// Determine health status based on various metrics
			var healthStatus = HealthStatus.Healthy;
			var issues = new List<string>();

			// Check response time
			if (stopwatch.ElapsedMilliseconds > 5000) // 5 seconds
			{
				healthStatus = HealthStatus.Unhealthy;
				issues.Add($"slow response ({stopwatch.ElapsedMilliseconds}ms)");
			}
			else if (stopwatch.ElapsedMilliseconds > 1000) // 1 second
			{
				healthStatus = HealthStatus.Degraded;
				issues.Add($"elevated response time ({stopwatch.ElapsedMilliseconds}ms)");
			}

			// Check connection utilization
			if (connectionUtilization > 90)
			{
				healthStatus = HealthStatus.Unhealthy;
				issues.Add($"high connection utilization ({connectionUtilization:F1}%)");
			}
			else if (connectionUtilization > 75)
			{
				if (healthStatus == HealthStatus.Healthy)
				{
					healthStatus = HealthStatus.Degraded;
				}
				issues.Add($"elevated connection utilization ({connectionUtilization:F1}%)");
			}

			var message = issues.Any()
				? $"Postgres database accessible with issues: {string.Join(", ", issues)}"
				: $"Postgres database healthy";

			_logger.Log(
				healthStatus == HealthStatus.Healthy ? LogLevel.Debug :
				healthStatus == HealthStatus.Degraded ? LogLevel.Information : LogLevel.Warning,
				"Postgres health check completed: Status={Status}, ResponseTime={ResponseTime}ms, Connections={ActiveConnections}/{MaxConnections}, Database={DatabaseName}, Role={Role}, Issues={Issues}",
				healthStatus, stopwatch.ElapsedMilliseconds, databaseStats.ActiveConnections,
				databaseStats.MaxConnections,
				versionInfo.DatabaseName, serverInfo.Role, string.Join(", ", issues));

			return new HealthCheckResult(healthStatus, message, data: healthData);
		}
		catch (Exception ex)
		{
			stopwatch.Stop();
			_logger.LogError(ex, "Postgres health check failed after {ElapsedMs}ms: {Error}",
				stopwatch.ElapsedMilliseconds, ex.Message);

			var errorData = new Dictionary<string, object>
			{
				["response_time_ms"] = stopwatch.ElapsedMilliseconds,
				["error_type"] = ex.GetType().Name,
				["error_message"] = ex.Message
			};

			return HealthCheckResult.Unhealthy($"Postgres database health check failed: {ex.Message}", ex, errorData);
		}
	}

	private class DatabaseInfo
	{
		public string? Version { get; init; }
		public string? DatabaseName { get; init; }
		public string? CurrentUser { get; init; }
	}

	private class DatabaseStats
	{
		public long SizeBytes { get; init; }
		public int TotalConnections { get; init; }
		public int ActiveConnections { get; init; }
		public int MaxConnections { get; init; }
	}

	private class ServerInfo
	{
		public string? Role { get; init; }
		public string? ServerVersion { get; init; }
	}
}