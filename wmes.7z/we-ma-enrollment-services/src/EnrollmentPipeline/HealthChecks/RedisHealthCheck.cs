using Microsoft.Extensions.Diagnostics.HealthChecks;
using StackExchange.Redis;

namespace EnrollmentPipeline.HealthChecks;

/// <summary>
/// Health check for Redis connectivity and basic operations
/// </summary>
public class RedisHealthCheck : IHealthCheck
{
	private readonly IConnectionMultiplexer _redis;

	public RedisHealthCheck(IConnectionMultiplexer redis)
	{
		_redis = redis ?? throw new ArgumentNullException(nameof(redis));
	}

	public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
	{
		try
		{
			var database = _redis.GetDatabase();

			// Test basic connectivity with a ping
			var pingTime = await database.PingAsync();

			// Test basic read/write operations
			var guid = Guid.NewGuid();
			var testKey = $"healthcheck:test:{guid}";
			var testValue = $"test-{DateTime.UtcNow:yyyyMMdd-HHmmss-fff}";

			await database.StringSetAsync(testKey, testValue, TimeSpan.FromSeconds(10));
			var retrievedValue = await database.StringGetAsync(testKey);

			if (!string.Equals(retrievedValue, testValue))
			{
				return HealthCheckResult.Unhealthy(
					"Redis read/write test failed",
					data: new Dictionary<string, object>
					{
						["ping_time_ms"] = pingTime.TotalMilliseconds,
						["test_failed"] = true
					});
			}

			// Clean up test key
			await database.KeyDeleteAsync(testKey);

			var streamName = $"{testKey}:stream";
			var consumerGroupName = $"{streamName}-group";
			var instanceName = $"{testKey}-{Environment.MachineName}";
			var messageKey = "test-key";

			// Create test stream
			await database.StreamCreateConsumerGroupAsync(
				streamName,
				consumerGroupName,
				StreamPosition.Beginning,
				createStream: true);

			// Add message
			await database.StreamAddAsync(streamName, messageKey, testValue);

			// Read messages
			var messagesInStream = await database.StreamReadGroupAsync(
				streamName,
				consumerGroupName,
				instanceName,
				">" // Read only new messages not delivered to any consumer
			);

			if (messagesInStream.Length == 0)
			{
				return HealthCheckResult.Unhealthy(
					"Redis stream read/write test failed",
					data: new Dictionary<string, object>
					{
						["ping_time_ms"] = pingTime.TotalMilliseconds,
						["stream_test_failed"] = true
					});
			}

			// Verify test value is in stream message
			var matchingMessage = messagesInStream.First(m => m.Values.FirstOrDefault(v => v.Name == messageKey).Value == testValue);

			if (matchingMessage.IsNull)
			{
				return HealthCheckResult.Unhealthy(
					"Redis stream read/write test failed - message not found",
					data: new Dictionary<string, object>
					{
						["ping_time_ms"] = pingTime.TotalMilliseconds,
						["stream_test_failed"] = true,
						["messages_in_stream"] = messagesInStream.Length
					});
			}

			try
			{
				var messageIds = messagesInStream.Select(m => m.Id).ToArray();
				// Ack message from stream
				await database.StreamAcknowledgeAsync(streamName, consumerGroupName, messageIds);
				// Remove message from stream
				await database.StreamDeleteAsync(streamName, messageIds);
				// Delete test stream
				await database.KeyDeleteAsync(streamName);
			}
			catch (Exception ex)
			{
				return HealthCheckResult.Unhealthy(
					"Redis stream cleanup failed",
					ex,
					data: new Dictionary<string, object>
					{
						["ping_time_ms"] = pingTime.TotalMilliseconds,
						["stream_cleanup_failed"] = true
					});
			}

			// Check connection status
			var endpoints = _redis.GetEndPoints();
			var serverInfo = new List<object>();

			foreach (var endpoint in endpoints)
			{
				var server = _redis.GetServer(endpoint);
				serverInfo.Add(new
				{
					endpoint = endpoint.ToString(),
					is_connected = server.IsConnected,
					is_replica = server.IsReplica,
					database_count = server.DatabaseCount
				});
			}

			return HealthCheckResult.Healthy(
				"Redis is healthy",
				data: new Dictionary<string, object>
				{
					["ping_time_ms"] = pingTime.TotalMilliseconds,
					["connection_count"] = _redis.GetCounters().TotalOutstanding,
					["servers"] = serverInfo
				});
		}
		catch (Exception ex)
		{
			return HealthCheckResult.Unhealthy(
				"Redis health check failed",
				ex,
				data: new Dictionary<string, object>
				{
					["error"] = ex.Message,
					["connection_status"] = _redis.IsConnected ? "connected" : "disconnected"
				});
		}
	}
}
