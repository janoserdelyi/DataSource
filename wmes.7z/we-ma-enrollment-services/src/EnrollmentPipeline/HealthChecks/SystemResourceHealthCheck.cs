using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Diagnostics;

namespace EnrollmentPipeline.HealthChecks;

/// <summary>
/// Health check for system resources and metrics
/// </summary>
public class SystemResourceHealthCheck : IHealthCheck
{
    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var process = Process.GetCurrentProcess();

            // Get memory usage
            var workingSetMB = Math.Round((double)process.WorkingSet64 / 1024 / 1024, 2);
            var privateMemoryMB = Math.Round((double)process.PrivateMemorySize64 / 1024 / 1024, 2);
            var availableMemoryMB = Math.Round((double)GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1024 / 1024, 2);
            var memoryUsagePercent = Math.Round((privateMemoryMB / availableMemoryMB) * 100, 2);

            // Get CPU time
            var totalProcessorTime = process.TotalProcessorTime;
            var userProcessorTime = process.UserProcessorTime;

            // Get thread count
            var threadCount = process.Threads.Count;

            // Get uptime
            var uptime = DateTime.UtcNow - process.StartTime.ToUniversalTime();
            var uptimeMinutes = Math.Round(uptime.TotalMinutes, 2);

            var data = new Dictionary<string, object>
            {
                ["working_set_mb"] = workingSetMB,
                ["private_memory_mb"] = privateMemoryMB,
                ["available_memory_mb"] = availableMemoryMB,
                ["memory_usage_percent"] = memoryUsagePercent,
                ["thread_count"] = threadCount,
                ["uptime_minutes"] = uptimeMinutes,
                ["total_processor_time_ms"] = totalProcessorTime.TotalMilliseconds,
                ["user_processor_time_ms"] = userProcessorTime.TotalMilliseconds,
                ["process_id"] = process.Id,
                ["process_name"] = process.ProcessName,
                ["machine_name"] = Environment.MachineName,
                ["processor_count"] = Environment.ProcessorCount
            };

            // Check for concerning resource usage
            if (memoryUsagePercent > 95)
            {
                return Task.FromResult(HealthCheckResult.Degraded(
                    $"High memory usage detected: {privateMemoryMB}MB ({memoryUsagePercent:F2}%)",
                    data: data));
            }

            return Task.FromResult(HealthCheckResult.Healthy(
                "System resources are within normal ranges",
                data: data));
        }
        catch (Exception ex)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy(
                "System resource health check failed",
                ex,
                data: new Dictionary<string, object>
                {
                    ["error"] = ex.Message
                }));
        }
    }
}
