using System.ComponentModel.DataAnnotations;
using Amazon;

namespace EnrollmentPipeline.Aws;

/// <summary>
/// Configuration for AWS RDS database connection with IAM authentication.
/// Contains all necessary parameters for connecting to the specific AWS RDS instance.
/// </summary>
public class AwsRdsConfiguration
{
    /// <summary>
    /// AWS profile name for credential authentication (optional - uses default credential chain if not specified)
    /// </summary>
    public string? ProfileName { get; set; }
    
    /// <summary>
    /// RDS cluster hostname
    /// </summary>
    [Required]
    public required string Hostname { get; set; }
    
    /// <summary>
    /// Database port (typically 5432 for PostgreSQL)
    /// </summary>
    [Required]
    [Range(1, 65535)]
    public required int Port { get; set; }
    
    /// <summary>
    /// Database name
    /// </summary>
    [Required]
    public required string DatabaseName { get; set; }
    
    /// <summary>
    /// Database username for IAM authentication
    /// </summary>
    [Required]
    public required string Username { get; set; }

    /// <summary>
    /// Database password for authentication (optional - used if not using IAM authentication)
    /// </summary>
    public string? Password { get; set; }
    
    /// <summary>
    /// AWS region system name (e.g., "us-east-1", "us-west-2")
    /// </summary>
    [Required]
    public required string RegionSystemName { get; set; }
    
    /// <summary>
    /// AWS region where the RDS instance is located
    /// </summary>
    public RegionEndpoint Region => RegionEndpoint.GetBySystemName(RegionSystemName);
    
    /// <summary>
    /// Connection timeout in seconds
    /// </summary>
    [Required]
    [Range(1, 3600)]
    public required int ConnectionTimeoutSeconds { get; set; }
    
    /// <summary>
    /// Command timeout in seconds
    /// </summary>
    [Required]
    [Range(1, 3600)]
    public required int CommandTimeoutSeconds { get; set; }
    
    /// <summary>
    /// Whether to enable SSL encryption
    /// </summary>
    [Required]
    public required bool EnableSsl { get; set; }
    
    /// <summary>
    /// Maximum retry attempts for connection failures
    /// </summary>
    [Required]
    [Range(0, 10)]
    public required int MaxRetryCount { get; set; }
    
    /// <summary>
    /// Maximum delay between retry attempts in seconds (used for JSON configuration)
    /// </summary>
    [Required]
    [Range(1, 300)]
    public required int MaxRetryDelaySeconds { get; set; }
    
    /// <summary>
    /// Maximum delay between retry attempts
    /// </summary>
    public TimeSpan MaxRetryDelay => TimeSpan.FromSeconds(MaxRetryDelaySeconds);
}
