using Amazon;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.RDS.Util;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Aws;

/// <summary>
/// AWS RDS authentication service that provides IAM database authentication tokens.
/// Uses AWS SDK default credential chain for authentication.
/// </summary>
public interface IAwsRdsAuthService
{
    /// <summary>
    /// Generates an RDS authentication token for database connection.
    /// Uses the configured AWS credentials and RDS settings.
    /// </summary>
    /// <returns>Authentication token for database connection</returns>
    Task<string> GenerateAuthTokenAsync();
}

/// <summary>
/// Modern AWS RDS authentication service using AWS SDK credential chain.
/// No external CLI dependencies required.
/// </summary>
public class AwsRdsAuthService : IAwsRdsAuthService
{
    private readonly ILogger<AwsRdsAuthService> _logger;
    private readonly AwsRdsConfiguration _config;
    private readonly AWSCredentials _credentials;

    public AwsRdsAuthService(
        ILogger<AwsRdsAuthService> logger,
        AwsRdsConfiguration config,
        AWSCredentials credentials)
    {
        _logger = logger;
        _config = config;
        _credentials = credentials;
    }

    public async Task<string> GenerateAuthTokenAsync()
    {
        try
        {
            _logger.LogDebug("Generating RDS auth token for {Username}@{Hostname}:{Port}",
                _config.Username, _config.Hostname, _config.Port);

            // Generate RDS auth token using AWS SDK
            var token = await Task.Run(() =>
                RDSAuthTokenGenerator.GenerateAuthToken(
                    _credentials,
                    _config.Region,
                    _config.Hostname,
                    _config.Port,
                    _config.Username));

            _logger.LogDebug("Successfully generated RDS auth token for {Username}@{Hostname}:{Port}",
                _config.Username, _config.Hostname, _config.Port);

            return token;
        }
        catch (AmazonServiceException ex)
        {
            _logger.LogError(ex, "AWS service error while generating RDS auth token: {ErrorCode} - {Message}",
                ex.ErrorCode, ex.Message);
            throw new UnauthorizedAccessException($"AWS service error: {ex.Message}", ex);
        }
        catch (AmazonClientException ex)
        {
            _logger.LogError(ex, "AWS client error while generating RDS auth token: {Message}", ex.Message);
            throw new InvalidOperationException($"AWS client error: {ex.Message}", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while generating RDS auth token for {Username}@{Hostname}:{Port}",
                _config.Username, _config.Hostname, _config.Port);
            throw new InvalidOperationException($"Failed to generate RDS auth token: {ex.Message}", ex);
        }
    }
}
