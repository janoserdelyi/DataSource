using System.Data;
using System.Text.Json;
using Dapper;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Services;

/// <summary>
/// Service interface for tracking enrollment processing in the database.
/// Provides methods for recording the start and completion of contact processing.
/// </summary>
public interface IEnrollmentService
{
    /// <summary>
    /// Gets staged enrollment with related entities loaded (status, pipeline version, workers)
    /// </summary>
    /// <param name="enrollmentId">The enrollment identifier</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>The staged enrollment with related data if found, null otherwise</returns>
    Task<StagedEnrollment?> GetEnrollmentAsync(Guid enrollmentId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the current processing status for a contact in a campaign.
    /// Useful for checking processing history or debugging pipeline issues.
    /// </summary>
    /// <param name="contactId">The contact identifier</param>
    /// <param name="campaignId">The campaign identifier</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>The staged enrollment record if found, null otherwise</returns>
    Task<StagedEnrollment?> GetEnrollmentByContactAndCampaignIdAsync(int contactId, int campaignId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Records the start of processing for an enrollment.
    /// Updates existing record if StagedEnrollment has a valid ID, otherwise inserts a new record.
    /// </summary>
    /// <param name="enrollment">The campaign enrollment being processed</param>
    /// <param name="workerId">ID of the worker starting the processing</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>Task representing the async operation</returns>
    Task RecordProcessingStartAsync(StagedEnrollment enrollment, Guid workerId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Records the start of processing for enrollments.
    /// Updates existing record if StagedEnrollment has a valid ID, otherwise inserts a new record for each enrollment.
    /// </summary>
    /// <param name="enrollments">The campaign enrollments being processed</param>
    /// <param name="workerId">ID of the worker starting the processing</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>Task representing the async operation</returns>
    Task RecordProcessingStartAsync(IReadOnlyCollection<StagedEnrollment> enrollments, Guid workerId, CancellationToken cancellationToken = default);
    /// <summary>
    /// Records enrollments that failed to process.
    /// </summary>
    /// <param name="enrollments"></param>
    /// <param name="workerId"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    Task RecordProcessingFailedAsync(IReadOnlyCollection<StagedEnrollment> enrollments, Guid workerId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Records the completion of processing for a contact in a campaign.
    /// Updates the existing record with the final status and completion timestamp.
    /// </summary>
    /// <param name="result">The processing result containing status and contact information</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>Task representing the async operation</returns>
    Task RecordWorkerResultAsync(WorkerResult result, CancellationToken cancellationToken = default);

    /// <summary>
    /// Bulk updates processing completion for multiple results.
    /// Optimized for high-throughput scenarios.
    /// </summary>
    /// <param name="results">The processing results to update</param>
    /// <param name="cancellationToken">Cancellation token for async operations</param>
    /// <returns>Task representing the async operation</returns>
    Task BulkRecordProcessingCompletedAsync(IEnumerable<WorkerResult> results, CancellationToken cancellationToken = default);
}

/// <summary>
/// Service implementation for tracking enrollment processing in PostgreSQL database.
/// </summary>
public class EnrollmentService(
        [FromKeyedServices(DbConnectionType.Postgres)] IDbConnection connection,
        ILogger<EnrollmentService> logger) : IEnrollmentService
{
    public async Task<StagedEnrollment?> GetEnrollmentAsync(Guid enrollmentId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT 
                se.id, 
                se.marketing_campaign_id as marketingCampaignId, 
                se.contact_id as contactId, 
                se.status_id as statusId, 
                se.status_reason_id as statusReasonId, 
                se.status_message as statusMessage, 
                se.data_fields as dataFields, 
                se.pipeline_version_id as pipelineVersionId, 
                se.created_date as createdDate, 
                se.updated_date as updatedDate, 
                se.updated_by_worker_id as updatedByWorkerId
            FROM enrollment.staged se
            WHERE se.id = @EnrollmentId";

        try
        {
            var result = await connection.QueryAsync<StagedEnrollment>(
                sql,
                new { EnrollmentId = enrollmentId });

            var enrollment = result.FirstOrDefault();
            logger.LogDebug("Retrieved enrollment {EnrollmentId} with related data: {Found}", enrollmentId, enrollment != null);
            return enrollment;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error retrieving enrollment {EnrollmentId} with related data", enrollmentId);

            return null;
        }
    }

    public async Task<StagedEnrollment?> GetEnrollmentByContactAndCampaignIdAsync(int contactId, int campaignId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT 
                id,
                marketing_campaign_id as marketingCampaignId,
                contact_id as contactId,
                status_id as statusId,
                status_reason_id as statusReasonId,
                data_fields as dataFields,
                status_message as statusMessage,
                pipeline_version_id as pipelineVersionId,
                created_date as createdDate,
                updated_date as updatedDate,
                updated_by_worker_id as updatedByWorkerId
            FROM enrollment.staged 
            WHERE contact_id = @ContactId 
            AND marketing_campaign_id = @CampaignId";

        try
        {
            var parameters = new
            {
                ContactId = contactId,
                CampaignId = campaignId
            };

            var result = await connection.QueryFirstOrDefaultAsync<StagedEnrollment>(sql, parameters);

            return result;
        }
        catch (Exception ex)
        {
            logger.LogError(ex,
                "Failed to get processing status for Contact {ContactId} in Campaign {CampaignId}",
                contactId, campaignId);

            return null;
        }
    }

    public async Task RecordProcessingStartAsync(StagedEnrollment enrollment, Guid workerId, CancellationToken cancellationToken = default)
    {
        var sql = @"
            INSERT INTO enrollment.staged (
                id,
                contact_id, 
                marketing_campaign_id, 
                status_id, 
                pipeline_version_id, 
                data_fields,
                created_date,
                updated_by_worker_id
            )
            VALUES (
                @Id,
                @ContactId, 
                @MarketingCampaignId, 
                @StatusId, 
                @PipelineVersionId, 
                @DataFields::jsonb,
                @CreatedDate,
                @WorkerId
            )
            ON CONFLICT (id) DO UPDATE SET
                status_id = EXCLUDED.status_id,
                updated_date = EXCLUDED.created_date,
                updated_by_worker_id = EXCLUDED.updated_by_worker_id,
                pipeline_version_id = EXCLUDED.pipeline_version_id,
                data_fields = EXCLUDED.data_fields";

        var parameters = new
        {
            Id = enrollment.Id,
            ContactId = enrollment.ContactId,
            MarketingCampaignId = enrollment.MarketingCampaignId,
            StatusId = (short)PipelineStatus.Processing,
            PipelineVersionId = enrollment.PipelineVersionId,
            DataFields = enrollment.DataFields?.ToString() ?? "{}",
            CreatedDate = DateTimeOffset.UtcNow,
            WorkerId = workerId
        };

        await connection.ExecuteAsync(sql, parameters);

        logger.LogDebug(
            "Inserted/Updated enrollment with ID {EnrollmentId} for Contact {ContactId} in Campaign {CampaignId}",
            enrollment.Id,
            enrollment.ContactId,
            enrollment.MarketingCampaignId
        );
    }

    public async Task RecordProcessingStartAsync(IReadOnlyCollection<StagedEnrollment> enrollments, Guid workerId, CancellationToken cancellationToken = default)
    {
        if (enrollments == null || enrollments.Count == 0)
        {
            logger.LogWarning("No enrollments provided to RecordProcessingStartAsync");
            return;
        }

        // Process each enrollment individually to ensure IDs are updated
        foreach (var enrollment in enrollments)
        {
            await RecordProcessingStartAsync(enrollment, workerId, cancellationToken);
        }

        logger.LogDebug(
            "Recorded processing start for {Count} enrollments with Worker {WorkerId}",
            enrollments.Count,
            workerId
        );
    }

    public async Task RecordWorkerResultAsync(WorkerResult result, CancellationToken cancellationToken = default)
    {
        var sql = @"
            INSERT INTO enrollment.staged (
                id,
                contact_id, 
                marketing_campaign_id, 
                status_id, 
                status_reason_id,
                status_message,
                pipeline_version_id, 
                data_fields,
                created_date,
                updated_by_worker_id
            )
            VALUES (
                @Id,
                @ContactId, 
                @MarketingCampaignId, 
                @StatusId, 
                @StatusReasonId,
                @StatusMessage,
                @PipelineVersionId, 
                @DataFields::jsonb,
                @CreatedDate,
                @WorkerId
            )
            ON CONFLICT (id) DO UPDATE SET
                status_id = EXCLUDED.status_id,
                status_reason_id = EXCLUDED.status_reason_id,
                status_message = EXCLUDED.status_message,
                updated_date = EXCLUDED.created_date,
                updated_by_worker_id = EXCLUDED.updated_by_worker_id,
                pipeline_version_id = EXCLUDED.pipeline_version_id,
                data_fields = EXCLUDED.data_fields";

        var parameters = new
        {
            Id = result.Enrollment.Id,
            ContactId = result.Enrollment.ContactId,
            MarketingCampaignId = result.Enrollment.MarketingCampaignId,
            StatusId = (short)result.Status,
            StatusReasonId = (short?)result.StatusReason,
            StatusMessage = result.Message,
            PipelineVersionId = result.Enrollment.PipelineVersionId,
            DataFields = result.Enrollment.DataFields?.ToString() ?? "{}",
            CreatedDate = DateTimeOffset.UtcNow,
            WorkerId = result.WorkerId,
        };

        // Execute the insert or update
        await connection.ExecuteAsync(sql, parameters);

        logger.LogDebug(
            "Recorded worker result for Contact {ContactId} in Campaign {CampaignId} with Status {Status} (ID: {EnrollmentId})",
            result.Enrollment.ContactId, result.Enrollment.MarketingCampaignId, result.Status, result.Enrollment.Id);
    }

    public async Task BulkRecordProcessingCompletedAsync(IEnumerable<WorkerResult> results, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            UPDATE enrollment.staged 
            SET 
                updated_by_worker_id = @WorkerId,
                status_id = @StatusId,
                status_reason_id = @StatusReasonId,
                status_message = @StatusMessage,
                updated_date = @UpdatedDate
            WHERE id = @Id";

        try
        {
            var parameters = results.Select(result => new
            {
                Id = result.Enrollment.Id,
                WorkerId = result.WorkerId,
                StatusId = (short)result.Status,
                StatusReasonId = (short?)result.StatusReason,
                StatusMessage = result.Message,
                UpdatedDate = DateTimeOffset.UtcNow,
            });

            var rowsAffected = await connection.ExecuteAsync(sql, parameters);

            logger.LogDebug(
                "Bulk updated {RowsAffected} enrollment completions",
                rowsAffected);
        }
        catch (Exception ex)
        {
            logger.LogError(ex,
                "Failed to bulk record processing completions for {Count} results",
                results.Count());

            // Fall back to individual processing
            foreach (var result in results)
            {
                await RecordWorkerResultAsync(result, cancellationToken);
            }
        }
    }

    public async Task RecordProcessingFailedAsync(IReadOnlyCollection<StagedEnrollment> enrollments, Guid workerId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
                INSERT INTO enrollment.failed (
                    id,
                    marketing_campaign_id, 
                    contact_id, 
                    json_message,
                    status_id, 
                    status_reason_id, 
                    status_message,
                    pipeline_version_id, 
                    created_date
                )
                VALUES (
                    @Id,
                    @MarketingCampaignId, 
                    @ContactId, 
                    @JsonMessage::jsonb,
                    @StatusId, 
                    @StatusReasonId, 
                    @StatusMessage,
                    @PipelineVersionId, 
                    @CreatedDate
                )
                ON CONFLICT (id) DO UPDATE SET
                    marketing_campaign_id = EXCLUDED.marketing_campaign_id,
                    contact_id = EXCLUDED.contact_id,
                    json_message = EXCLUDED.json_message,
                    status_id = EXCLUDED.status_id,
                    status_reason_id = EXCLUDED.status_reason_id,
                    status_message = EXCLUDED.status_message,
                    pipeline_version_id = EXCLUDED.pipeline_version_id,
                    updated_date = EXCLUDED.created_date";

        var parameters = enrollments.Select(enrollment => new
        {
            Id = enrollment.Id,
            MarketingCampaignId = enrollment.MarketingCampaignId,
            ContactId = enrollment.ContactId,
            JsonMessage = JsonSerializer.Serialize(enrollment),
            StatusId = (short)enrollment.StatusId,
            StatusReasonId = (short?)enrollment.StatusReasonId,
            StatusMessage = enrollment.StatusMessage,
            PipelineVersionId = enrollment.PipelineVersionId,
            CreatedDate = DateTimeOffset.UtcNow,
            WorkerId = workerId,
        });

        var rowsAffected = await connection.ExecuteAsync(sql, parameters);

        logger.LogDebug(
            "Bulk updated {RowsAffected} enrollment completions",
            rowsAffected);
    }
}
