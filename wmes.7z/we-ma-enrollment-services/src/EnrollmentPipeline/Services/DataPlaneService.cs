using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using EnrollmentPipeline.Models.CostarSync;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Services;

/// <summary>
/// Data Plane client
/// </summary>
public interface IDataPlaneService
{
    /// <summary>
    /// Sends a GET request to the specified URL and returns the deserialized response.
    /// </summary>
    /// <typeparam name="T">Type to deserialize the response into.</typeparam>
    /// <param name="url">CoStar Sync API endpoint URL.</param>
    /// <returns></returns>
    public Task<T?> GetAsync<T>(string url);
    /// <summary>
    /// Get ContactSummary for a given list of contact IDs
    /// </summary>
    /// <param name="contactIds">Contact ID</param>
    /// <param name="batchType">Batch Request Type. Used to determine the route to call.</param>
    /// <returns></returns>
    public Task<IEnumerable<T>> GetBatchSyncModelAll<T>(IEnumerable<string> contactIds, BatchType batchType);
}

public class DataPlaneService(
    HttpClient client, ILogger<IDataPlaneService> logger) : IDataPlaneService
{
    public async Task<T?> GetAsync<T>(string url)
    {
        var response = await client.GetAsync(url);
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Request failed with the status code {response.StatusCode}");
        }

        var responseBody = await response.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<T>(responseBody);
    }

    public async Task<IEnumerable<T>> GetBatchSyncModelAll<T>(IEnumerable<string> ids, BatchType batchType)
    {
        const int batchSize = 500;

        var tasks = ids
            .Chunk(batchSize)
            .Select(batch => Task.Run(async () =>
            {
                try
                {
                    return await ProcessBatchAsync<T>(batch, batchType);
                }
                catch(Exception ex)
                {
                    logger.LogError(ex, "Error processing batch in DataPlaneService");
                    return [];
                }
            }));

        var results = await Task.WhenAll(tasks);

        return results
            .SelectMany(r => r)
            .ToList();
    }

    #region Helper Methods

    private async Task<IEnumerable<T>> ProcessBatchAsync<T>(IEnumerable<string> batch, BatchType batchType)
    {
        var jsonPayload = CreateBatchContactPayload(batch, batchType);
        var httpContent = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
        var response = await client.PostAsync("/batch", httpContent);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Request failed with the status code {response.StatusCode}");
        }

        var responseBody = await response.Content.ReadAsStringAsync();
        var responseObject = JsonObject.Parse(responseBody);
        var responses = responseObject?["responses"]?.AsObject();

        if (responses == null)
        {
            throw new InvalidDataException("DataPlane response object is null");
        }

        var resDetails = new List<T>();

        foreach (var property in responses)
        {
            var responsesContent = property.Value?["response_content"];

            if (responsesContent != null)
            {
                var detail = responsesContent.Deserialize<T>();
                if (detail != null)
                {
                    resDetails.Add(detail);
                }
            }
        }
        return resDetails;
    }

    private static string CreateBatchContactPayload(IEnumerable<string> contactIds, BatchType batchType)
    {
        var requestModel = new ContactRequestModel
        {
            Requests = contactIds.Select(id => new ContactRequest
            {
                Url = GetRouteByBatchType(batchType, id)
            })
        };
        return JsonSerializer.Serialize(requestModel);
    }

    private static string GetRouteByBatchType(BatchType batchType, string id)
    {

        return batchType switch
        {
            BatchType.Contact => $"/contact/ro/contact/{id}",
            BatchType.SalesTerritorySummaryKeysByContactID => $"/salesterritory/ro/salesterritorysummary-by-assignedcontact-id/{id}",
            BatchType.SalesTerritorySummary => $"/salesterritory/ro/salesterritorysummary/{id}",
            BatchType.LocationProfile => $"/location/ro/locationprofile/{id}",
            BatchType.MarketingLead => $"/marketing/ro/marketinglead/{id}",
            _ => "",
        };
    }

    #endregion
}