using System.Data;
using Dapper;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using Marketing.Enums;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Services;

/// <summary>
/// Service for managing pipeline entities using Dapper.
/// Handles PipelineWorker, PipelineVersion, PipelineStatus, and related operations.
/// </summary>
public interface IPipelineService
{
    /// <summary>
    /// Retrieves a pipeline worker by id.
    /// </summary>
    Task<PipelineWorker?> GetWorkerByIdAsync(Guid workerId, CancellationToken cancellationToken = default);
    /// <summary>
    /// Retrieves a pipeline version by id.
    /// </summary>
    Task<PipelineVersion?> GetVersionByIdAsync(short versionId, CancellationToken cancellationToken = default);
    /// <summary>
    /// Retrieves the latest pipeline version.
    /// </summary>
    /// <param name="brandId">The ID of the brand to retrieve the latest version for.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <throws cref="ArgumentNullException">Thrown when no pipeline versions are configured.</throws>
    Task<PipelineVersion> GetLatestVersionAsync(MarketingBrands brandId, CancellationToken cancellationToken = default);
    /// <summary>
    /// Retrieves all pipeline versions.
    /// </summary>
    Task<IEnumerable<PipelineVersion>> GetAllVersionsAsync(CancellationToken cancellationToken = default);
    /// <summary>
    /// Retrieves all workers for a specific pipeline version.
    /// </summary>
    Task<IEnumerable<PipelineVersionWorker>> GetVersionWorkersAsync(short versionId, CancellationToken cancellationToken = default);
}

/// <inheritdoc />
public class PipelineService(
    [FromKeyedServices(DbConnectionType.Postgres)] IDbConnection connection,
    ILogger<PipelineService> logger,
    HybridCache hybridCache
) : IPipelineService
{

    #region Pipeline Worker Operations

    public async Task<PipelineWorker?> GetWorkerByIdAsync(Guid workerId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT 
                id, 
                name, 
                description, 
                created_date as createdDate, 
                created_by as createdBy, 
                updated_date as updatedDate, 
                updated_by as updatedBy
            FROM enrollment.pipeline_worker 
            WHERE id = @WorkerId";

        try
        {
            var result = await connection.QueryFirstOrDefaultAsync<PipelineWorker>(sql, new { WorkerId = workerId });
            logger.LogDebug("Retrieved pipeline worker {WorkerId}: {Found}", workerId, result != null);
            return result;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error retrieving pipeline worker {WorkerId}", workerId);
            throw;
        }
    }

    #endregion

    #region Pipeline Version Operations

    public async Task<PipelineVersion?> GetVersionByIdAsync(short versionId, CancellationToken cancellationToken = default)
    {
        var allVersions = await GetAllVersionsAsync(cancellationToken);

        return allVersions.FirstOrDefault(v => v.Id == versionId);
    }

    public async Task<PipelineVersion> GetLatestVersionAsync(MarketingBrands brandId, CancellationToken cancellationToken = default)
    {
        var allVersions = await GetAllVersionsAsync(cancellationToken);

        // Filters out inactive versions and orders by ID descending
        // so that the latest active version is first
        var activeVersions = allVersions
            .Where(v => v.Active)
            .OrderByDescending(v => v.Id)
            .ToList();

        if (activeVersions.Count == 0)
        {
            throw new ArgumentNullException("No pipeline versions are configured.");
        }

        var brandSpecificVersions = activeVersions
            .Where(v => v.BrandId == brandId);

        // Return the latest brand-specific version if available
        if (brandSpecificVersions.Any())
        {
            return brandSpecificVersions
                .First();
        }

        // Otherwise, return the latest global version
        return activeVersions
            .First();
    }

    public async Task<IEnumerable<PipelineVersion>> GetAllVersionsAsync(CancellationToken cancellationToken = default)
    {
        var cacheKey = $"pipeline_version:all";

        var cachedVersions = await hybridCache.GetOrCreateAsync(cacheKey, async (cancellationToken) =>
            {
                return await GetAllPipelineVersionsAsync(cancellationToken);
            }, options: new HybridCacheEntryOptions
            {
                LocalCacheExpiration = TimeSpan.FromMinutes(15),
                Expiration = TimeSpan.FromHours(1)
            }, cancellationToken: cancellationToken);

        return cachedVersions;
    }

    public async Task<IEnumerable<PipelineVersionWorker>> GetVersionWorkersAsync(short versionId, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"pipeline_version:{versionId}:workers";

        var cachedWorkers = await hybridCache.GetOrCreateAsync(cacheKey, async (cancellationToken) =>
            {
                return await GetPipelineVersionWorkersAsync(versionId, cancellationToken);
            }, options: new HybridCacheEntryOptions
            {
                LocalCacheExpiration = TimeSpan.FromMinutes(15),
                Expiration = TimeSpan.FromHours(1)
            }, cancellationToken: cancellationToken);

        return cachedWorkers;
    }

    #endregion

    private async Task<IEnumerable<PipelineVersion>> GetAllPipelineVersionsAsync(CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT 
                pv.id, 
                pv.brand_id brandId, 
                pv.active, 
                pv.error_handler_worker_id errorHandlerWorkerId, 
                pv.created_date createdDate, 
                pv.created_by createdBy
            FROM enrollment.pipeline_version pv
            ORDER BY pv.id DESC";

        try
        {
            var versionDictionary = new Dictionary<short, PipelineVersion>();

            var result = await connection.QueryAsync<PipelineVersion>(
                sql
            );

            foreach (var version in result)
            {
                // Retrieve workers for each version
                version.Workers = (await GetPipelineVersionWorkersAsync(version.Id, cancellationToken)).ToList();
            }

            logger.LogDebug("Retrieved {Count} pipeline versions with workers", result.Count());

            return result;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error retrieving all pipeline versions with workers");
            throw;
        }
    }

    private async Task<IEnumerable<PipelineVersionWorker>> GetPipelineVersionWorkersAsync(short versionId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT
                pvw.worker_order,
                pw.id,
                pw.name,
                pw.description,
                pw.created_date createdDate,
                pw.created_by createdBy,
                pw.updated_date updatedDate,
                pw.updated_by updatedBy
            FROM enrollment.pipeline_version_worker pvw
            JOIN enrollment.pipeline_worker pw ON pvw.worker_id = pw.id
            WHERE pvw.version_id = @VersionId
            ORDER BY pvw.worker_order";

        try
        {
            var results = await connection.QueryAsync<int, PipelineWorker, PipelineVersionWorker>(
                sql,
                (workerOrder, worker) =>  new PipelineVersionWorker
                {
                    WorkerOrder = workerOrder,
                    Worker = worker
                },
                new { VersionId = versionId },
                splitOn: "id");

            logger.LogDebug("Retrieved {Count} workers for pipeline version {VersionId}", results.Count(), versionId);
            return results;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error retrieving workers for pipeline version {VersionId}", versionId);
            throw;
        }
    }
}
