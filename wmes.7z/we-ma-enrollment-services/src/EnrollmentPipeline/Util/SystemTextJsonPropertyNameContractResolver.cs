using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace EnrollmentPipeline.Util;

/// <summary>
/// Custom contract resolver that respects System.Text.Json JsonPropertyName attributes
/// </summary>
public class SystemTextJsonPropertyNameContractResolver : DefaultContractResolver
{
    protected override JsonProperty CreateProperty(System.Reflection.MemberInfo member, MemberSerialization memberSerialization)
    {
        var property = base.CreateProperty(member, memberSerialization);

        // Check for System.Text.Json.Serialization.JsonPropertyNameAttribute
        var jsonPropertyNameAttr = member.GetCustomAttributes(typeof(System.Text.Json.Serialization.JsonPropertyNameAttribute), false)
            .FirstOrDefault() as System.Text.Json.Serialization.JsonPropertyNameAttribute;

        if (jsonPropertyNameAttr != null)
        {
            property.PropertyName = jsonPropertyNameAttr.Name;
        }

        return property;
    }
}