using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;
using EnrollmentPipeline.Services;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.DependencyInjection;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;

namespace EnrollmentPipeline;

/// <summary>
/// Scalable Pipeline Worker using Redis Streams for automatic load balancing and guaranteed delivery.
/// Optimized for horizontal scaling with consumer groups and built-in auto-scaling capabilities.
/// Includes database tracking for campaign enrollment processing lifecycle.
/// </summary>
[DebuggerDisplay("{WorkerName} ({WorkerId})")]
public abstract class StreamPipelineWorker : BackgroundService
{
	private readonly IConnectionMultiplexer _redis;
	private readonly IStreamMessagePublisher _publisher;
	private readonly ILogger<StreamPipelineWorker> _logger;
	private readonly IServiceScopeFactory _scopeFactory;
	private readonly HybridCache _hybridCache;
	private PipelineWorker _worker;

	protected IEnrollmentService? EnrollmentService;
	protected IPipelineService? PipelineService;

	protected StreamPipelineWorker(
		IConnectionMultiplexer redis,
		IStreamMessagePublisher publisher,
		ILogger<StreamPipelineWorker> logger,
		IServiceScopeFactory scopeFactory,
		IConfiguration configuration,
		HybridCache hybridCache
	)
	{
		_redis = redis;
		_publisher = publisher;
		_logger = logger;
		_scopeFactory = scopeFactory;
		_hybridCache = hybridCache;

		var workerId = configuration.GetValue("PipelineWorker:Id", Guid.Empty);

		if (workerId == Guid.Empty)
		{
			throw new InvalidOperationException("PipelineWorker:Id is not configured.");
		}

		// Initializes the pipeline worker object with just the ID (this gets verified later in RunAsync)
		_worker = new PipelineWorker { Id = workerId };
	}


	#region OpenTelemetry Metrics
	private static readonly ActivitySource ActivitySource = new("EnrollmentPipeline.StreamPipelineWorker");
	private static readonly Meter Meter = new("EnrollmentPipeline.StreamPipelineWorker");

	// Core Metrics
	private static readonly Counter<long> MessagesProcessedCounter = Meter.CreateCounter<long>(
		"pipeline_stream_messages_processed_total");

	private static readonly Counter<long> MessagesFailedCounter = Meter.CreateCounter<long>(
		"pipeline_stream_messages_failed_total");

	private static readonly Histogram<double> MessageProcessingDuration = Meter.CreateHistogram<double>(
		"pipeline_stream_message_duration_seconds");

	private static readonly Histogram<double> BatchProcessingDuration = Meter.CreateHistogram<double>(
		"pipeline_stream_batch_duration_seconds");

	// Scaling Metrics
	private static readonly Gauge<long> StreamLengthGauge = Meter.CreateGauge<long>(
		"pipeline_stream_length");

	private static readonly Gauge<long> PendingMessagesGauge = Meter.CreateGauge<long>(
		"pipeline_stream_pending_messages");

	private static readonly Counter<long> ConsumerLagCounter = Meter.CreateCounter<long>(
		"pipeline_stream_consumer_lag_total");

	private static readonly Gauge<int> ActiveWorkersGauge = Meter.CreateGauge<int>(
		"pipeline_active_workers");

	// Backlog Processing Metrics
	private static readonly Counter<long> BacklogMessagesProcessedCounter = Meter.CreateCounter<long>(
		"pipeline_backlog_messages_processed_total");

	private static readonly Counter<long> PendingMessagesClaimedCounter = Meter.CreateCounter<long>(
		"pipeline_pending_messages_claimed_total");

	private static readonly Gauge<long> BacklogSizeGauge = Meter.CreateGauge<long>(
		"pipeline_backlog_size");

	// High-Priority Stream Metrics
	private static readonly Counter<long> HighPriorityMessagesProcessedCounter = Meter.CreateCounter<long>(
		"pipeline_high_priority_messages_processed_total");

	private static readonly Gauge<long> HighPriorityQueueLengthGauge = Meter.CreateGauge<long>(
		"pipeline_high_priority_queue_length");

	private static readonly Histogram<double> HighPriorityWaitTimeHistogram = Meter.CreateHistogram<double>(
		"pipeline_high_priority_wait_time_seconds");

	#endregion

	/// <summary>
	/// The worker ID for this worker, loaded from configuration at startup
	/// </summary>
	public Guid WorkerId => _worker.Id;
	/// <summary>
	/// The name of the worker, used for logging and metrics.
	/// </summary>
	public abstract string WorkerName { get; }
	/// <summary>
	/// The instance name for this worker, combining worker ID and machine name
	/// </summary>
	public string InstanceName => $"{WorkerId:N}-{Environment.MachineName}";
	private volatile bool _isLeader = false;

	#region Redis Configuration
	public string DefaultStreamName => _worker.DefaultStreamName;
	public string HighPriorityStreamName => _worker.HighPriorityStreamName;
	public string DefaultConsumerGroupName => $"{DefaultStreamName}-group";
	public string HighPriorityConsumerGroupName => $"{HighPriorityStreamName}-group";
	#endregion

	#region Worker Configuration

	/// <summary>
	/// The maximum number of retries for an enrollment.
	/// </summary>
	protected virtual int MaxRetries => 3;
	// Configuration Properties
	/// <summary>
	/// The maximum number of messages to process in a single batch.
	/// </summary>
	protected abstract int MaxBatchSize { get; }
	/// <summary>
	/// The duration of time to wait before reading messages from the stream. So that workers are not
	/// constantly polling the queue for records.
	/// </summary>
	protected abstract TimeSpan ReadDelay { get; }
	/// <summary>
	/// The maximum duration to wait for a message to be processed. After this duration, the message will be
	/// considered failed or "pending". Meaning, it will be picked up by another worker.
	/// </summary>
	protected abstract TimeSpan ProcessingTimeout { get; }
	#endregion

	#region Scaling Configuration

	/// <summary>
	/// The maximum number of workers that can be spawned for processing.
	/// </summary>
	protected virtual int MaxNumberOfWorkers => 20;
	/// <summary>
	/// The duration to wait before retrying a failed batch.
	/// </summary>
	protected virtual TimeSpan RetryDelay => TimeSpan.FromSeconds(5);
	/// <summary>
	/// The interval at which metrics are reported.
	/// </summary>
	protected virtual TimeSpan MetricsReportInterval => TimeSpan.FromSeconds(30);
	/// <summary>
	/// The threshold for scaling up the number of workers.
	/// </summary>
	protected virtual long ScaleUpThreshold => MaxBatchSize * 5; // Scale up if stream has 5x batch size
	/// <summary>
	/// The threshold for scaling down the number of workers.
	/// </summary>
	protected virtual long ScaleDownThreshold => MaxBatchSize / 2; // Scale down if stream has less than half batch size

	#endregion

	protected override Task ExecuteAsync(CancellationToken stoppingToken) => RunAsync(stoppingToken);

	/// <summary>
	/// Runs the worker processing loop until cancellation is requested.
	/// </summary>
	/// <param name="stoppingToken"></param>
	/// <returns></returns>
	public async Task RunAsync(CancellationToken stoppingToken)
	{
		using var mainActivity = ActivitySource.StartActivity("stream-worker-execution");
		mainActivity?.SetTag("worker.id", WorkerId);
		mainActivity?.SetTag("worker.name", WorkerName);
		mainActivity?.SetTag("instance.name", InstanceName);
		mainActivity?.SetTag("stream.default.name", DefaultStreamName);
		mainActivity?.SetTag("stream.high-priority.name", HighPriorityStreamName);
		mainActivity?.SetTag("consumer.default.group", DefaultConsumerGroupName);
		mainActivity?.SetTag("consumer.high-priority.group", HighPriorityConsumerGroupName);

		// Initiate the worker's logging scope
		using (_logger.BeginScope(
			new Dictionary<string, object>
			{
				{"WorkerId", WorkerId},
				{"WorkerName", WorkerName},
				{"InstanceName", InstanceName},
			}
		))
		{
			_logger.LogInformation("[{WorkerName}] Starting worker...", WorkerName);

			var database = _redis.GetDatabase();

			// Initialize consumer group and stream
			await InitializeStreams(database);

			// Start metrics reporting background task
			_ = Task.Run(() => ReportMetricsLoop(database, stoppingToken), stoppingToken);
			// Start leader election and scaling monitoring
			_ = Task.Run(() => LeaderElectionLoop(database, stoppingToken), stoppingToken);

			using var scope = _scopeFactory.CreateScope();

			// Creates scoped services
			EnrollmentService = scope.ServiceProvider.GetRequiredService<IEnrollmentService>();
			PipelineService = scope.ServiceProvider.GetRequiredService<IPipelineService>();

			// Validate that the Worker ID exists in the database
			var workerMetadata = await PipelineService.GetWorkerByIdAsync(WorkerId, stoppingToken);

			if (workerMetadata == null)
			{
				_logger.LogError("[{WorkerName}] Worker ID {WorkerId} not found in database. Ensure the metadata exists in the `enrollment.pipeline_worker` table.",
					WorkerName, WorkerId);

				if (_worker == null || _worker.Id == Guid.Empty)
				{
					_logger.LogError("[{WorkerName}] Worker metadata is not initialized properly. Worker ID must be set. Shutting down...", WorkerName);
					return;
				}
			}
			else
			{
				// Saves the updated metadata
				_worker = workerMetadata;
			}

			// Main processing loop
			while (!stoppingToken.IsCancellationRequested)
			{
				try
				{
					await ProcessStreamMessages(database, stoppingToken);
				}
				catch (OperationCanceledException)
				{
					_logger.LogDebug("[{WorkerName}] Cancellation requested, shutting down worker...", WorkerName);
					break;
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, "[{WorkerName}] Error in main processing loop for worker {WorkerId}", WorkerName, WorkerId);
					await Task.Delay(RetryDelay, stoppingToken);
				}
			}

			_logger.LogInformation("[{WorkerName}] Pipeline worker {WorkerId} shutting down", WorkerName, WorkerId);
		}
	}

	/// <summary>
	/// Processes a batch of staged enrollments asynchronously.
	/// </summary>
	/// <param name="enrollments">The collection of staged enrollments to process. Should be no larger than <see cref="MaxBatchSize"/>.</param>
	/// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
	/// <returns>An asynchronous stream of WorkerResult objects representing the processing results.</returns>
	public abstract IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken);

	/// <summary>
	/// Initializes the Redis/Valkey stream infrastructure, including creating the stream and consumer groups.
	/// Creates both normal and high-priority stream consumer groups.
	/// </summary>
	public async Task InitializeStreams(IDatabase database)
	{
		// Initialize normal stream consumer group
		await CreateRedisConsumerGroup(database, DefaultStreamName, DefaultConsumerGroupName);

		// Initialize high-priority stream consumer group
		await CreateRedisConsumerGroup(database, HighPriorityStreamName, HighPriorityConsumerGroupName);
	}

	public async Task ProcessStreamMessages(IDatabase database, CancellationToken cancellationToken)
	{
		using var batchActivity = ActivitySource.StartActivity("stream-batch-processing");
		batchActivity?.SetTag("worker.id", WorkerId);

		var batchStartTime = Stopwatch.GetTimestamp();

		try
		{
			// Prioritized message retrieval strategy:
			// 1st Priority: High-priority messages (ABSOLUTE PRIORITY)
			// 2nd Priority: Pending messages from failed consumers
			// 3rd Priority: Unacknowledged backlog messages
			// 4th Priority: New messages
			var (messages, isHighPriority) = await GetMessagesWithPriority(database, cancellationToken);

			if (messages.Length == 0)
			{
				await Task.Delay(ReadDelay, cancellationToken);
				return;
			}

			batchActivity?.SetTag("batch.size", messages.Length);
			batchActivity?.SetTag("is_high_priority", isHighPriority);

			_logger.LogDebug("[{WorkerName}] Processing batch of {Count} messages from {Stream} stream",
				WorkerName, messages.Length, isHighPriority ? "high-priority" : "normal");

			var enrollments = await ParseStreamMessages(database, messages, isHighPriority, cancellationToken);

			if (enrollments.Count > 0)
			{
				var processed = new HashSet<StagedEnrollment>();

				try
				{
					var messageProcessingStart = Stopwatch.GetTimestamp();

					await foreach (var workerResult in ProcessBatch(enrollments, cancellationToken))
					{
						// Track processed enrollments to avoid double-processing in case of errors
						processed.Add(workerResult.Enrollment);

						MessagesProcessedCounter.Add(1, new KeyValuePair<string, object?>("worker.id", WorkerId));
						MessageProcessingDuration.Record(Stopwatch.GetElapsedTime(messageProcessingStart).TotalSeconds,
							new KeyValuePair<string, object?>("worker.id", WorkerId));

						await ProcessWorkerResult(workerResult, database, cancellationToken);
					}
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, "[{WorkerName}] Error processing enrollment batch, will retry failed messages", WorkerName);

					batchActivity?.SetTag("error", true);

					// Handle errored batch (make sure it doesn't reprocess successfully processed messages)
					var missedEnrollments = enrollments.Except(processed).ToList().AsReadOnly();

					MessagesFailedCounter.Add(missedEnrollments.Count, new KeyValuePair<string, object?>("worker.id", WorkerId));

					// Create WorkerResults for missed messages
					var tasks = missedEnrollments
						.Select(enrollment =>
							ProduceResult(enrollment, DateTimeOffset.UtcNow)
								.WithStatus(PipelineStatus.Retrying)
								.WithMessage("Re-queued after batch failure.")
						)
						.Select(result => 
                            // Re-queue the failed enrollment back to the stream for retry
                            ProcessWorkerResult(result, database, cancellationToken));

					// Awaits all tasks to finish
					await Task.WhenAll(tasks);
				}

				batchActivity?.SetTag("messages.processed", processed.Count);
			}

			var batchDuration = Stopwatch.GetElapsedTime(batchStartTime).TotalSeconds;
			BatchProcessingDuration.Record(batchDuration,
				new KeyValuePair<string, object?>("worker.id", WorkerId),
				new KeyValuePair<string, object?>("batch.size", enrollments.Count));

			batchActivity?.SetTag("duration.seconds", batchDuration);
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] Cancellation requested during batch processing, shutting down worker...", WorkerName);
			throw; // Re-throw to maintain cancellation semantics
		}
		catch (Exception ex)
		{
			_logger.LogError(ex, "[{WorkerName}] Error processing stream messages", WorkerName);
			batchActivity?.SetTag("error", true);
			throw;
		}
	}

	/// <summary>
	/// Creates a WorkerResult with the current worker's name and specified status.
	/// </summary>
	protected WorkerResult ProduceResult(StagedEnrollment enrollment, DateTimeOffset startedAt)
	{
		return new WorkerResult
		{
			WorkerId = WorkerId,
			Enrollment = enrollment,
			StartedAt = startedAt,
			EndedAt = DateTimeOffset.UtcNow
		};
	}

	private async Task<List<StagedEnrollment>> ParseStreamMessages(IDatabase database, StreamEntry[] messages, bool isHighPriority, CancellationToken cancellationToken)
	{
		var enrollments = new List<StagedEnrollment>();

		// Parse messages
		foreach (var message in messages)
		{
			cancellationToken.ThrowIfCancellationRequested();

			try
			{
				if (TryParseStreamMessage(message, out var enrollment) && enrollment != null)
				{
					enrollment.IsHighPriority = isHighPriority;
					enrollments.Add(enrollment);
				}
			}
			catch (Exception ex)
			{
				var streamName = isHighPriority ? HighPriorityStreamName : DefaultStreamName;
				var consumerGroup = isHighPriority ? HighPriorityConsumerGroupName : DefaultConsumerGroupName;

				// Acknowledge and delete invalid messages to prevent reprocessing and clean up malformed data
				await database.StreamAcknowledgeAsync(streamName, consumerGroup, message.Id);
				await database.StreamDeleteAsync(streamName, [message.Id]);

				_logger.LogError(ex, "[{WorkerName}] Failed to parse message {MessageId} from stream {Stream}", WorkerName, message.Id, streamName);

				// TODO: Maybe send the invalid messages to a dead-letter queue (error-processing-stream or new batch staging table)
			}
		}

		return enrollments;
	}

	private async Task ProcessWorkerResult(WorkerResult result, IDatabase database, CancellationToken cancellationToken)
	{
		try
		{
			// Acknowledge message from the stream (Enrollment object contains message ID and priority)
			await AcknowledgeStreamMessage(database, result.Enrollment);

			// Updates the enrollment status from the worker result
			result.Enrollment.StatusId = result.Status;
			result.Enrollment.StatusReasonId = result.StatusReason;
			result.Enrollment.StatusMessage = result.Message;
			result.Enrollment.UpdatedDate = DateTimeOffset.UtcNow;
			result.Enrollment.UpdatedByWorkerId = WorkerId;

			if (result.Status == PipelineStatus.Retrying)
			{
				// Attempts to retry the enrollment                
				if (await TryRetryEnrollmentAsync(result.Enrollment))
				{
					_logger.LogDebug("[{WorkerName}] Re-queued enrollment for contact {ContactId} from campaign {CampaignId} for retry",
						WorkerName, result.Enrollment.ContactId, result.Enrollment.MarketingCampaignId);
					return;
				}
				else
				{
					_logger.LogWarning("[{WorkerName}] Failed to retry enrollment for contact {ContactId} from campaign {CampaignId} - retry limit exceeded",
						WorkerName, result.Enrollment.ContactId, result.Enrollment.MarketingCampaignId);

					result.Status = PipelineStatus.Failed;
					result.StatusReason = PipelineStatusReason.ExceededNumberOfRetries;
					result.Message = "Retry limit exceeded.";
				}
			}

			if (result.Status == PipelineStatus.Completed)
			{
				_logger.LogDebug("[{WorkerName}] Enrollment for contact {ContactId} from campaign {CampaignId} completed processing",
					WorkerName, result.Enrollment.ContactId, result.Enrollment.MarketingCampaignId);

				return;
			}

			var nextWorker = await GetNextWorker(result.Enrollment);

			// If nextWorker is null, it's the end of the pipeline for the enrollment
			if (nextWorker == null)
			{
				if (result.Status == PipelineStatus.Success)
				{
					// We can then mark the enrollment as completed (this is used for status reporting)
					result.Enrollment.StatusId = PipelineStatus.Completed;
				}
			}
			else
			{
				cancellationToken.ThrowIfCancellationRequested();
				// Post enrollment to next worker's stream
				await _publisher.PublishEnrollmentAsync(nextWorker, result.Enrollment);
			}

			_logger.LogDebug("[{WorkerName}] Processed enrollment for contact {ContactId} from campaign {CampaignId} with status {Status}",
				WorkerName, result.Enrollment.ContactId, result.Enrollment.MarketingCampaignId, result.Status);
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] ProcessWorkerResult operation was cancelled", WorkerName);
			throw; // Re-throw to maintain cancellation semantics
		}
	}

	/// <summary>
	/// Attempts to retry the enrollment by re-publishing it to the current worker's stream.
	/// It increments the retry count and checks against the maximum retries.
	/// </summary>
	/// <returns>A boolean indicating whether the retry was successful (true) or if the retry limit was exceeded (false).</returns>
	private async Task<bool> TryRetryEnrollmentAsync(StagedEnrollment enrollment)
	{
		if (!enrollment.Retries.ContainsKey(WorkerId))
		{
			enrollment.Retries[WorkerId] = new RetryInfo { Count = 1 };
		}

		var retryInfo = enrollment.Retries[WorkerId];

		// Check if retry limit exceeded before incrementing
		if (retryInfo.Count > MaxRetries)
		{
			// Mark enrollment as failed due to retry limit exceeded
			enrollment.StatusId = PipelineStatus.Failed;
			enrollment.StatusReasonId = PipelineStatusReason.ExceededNumberOfRetries;
			enrollment.StatusMessage = "Retry limit exceeded";

			return false;
		}

		// Increment retry count
		retryInfo.Count++;

		// Save reason for retry if available (for debugging purposes)
		if (!string.IsNullOrEmpty(enrollment.StatusMessage))
		{
			enrollment.Retries[WorkerId].Reasons.Add(enrollment.StatusMessage);
		}

		ArgumentNullException.ThrowIfNull(enrollment.PipelineVersionId);

		// Retrieve pipeline version for this enrollment
		var pipelineVersion = await GetCachedPipelineVersionById((short) enrollment.PipelineVersionId);

		// If this worker is the error handler, re-publish to the first worker in the pipeline version (full re-queue)
		if (pipelineVersion != null && WorkerId == pipelineVersion.ErrorHandlerWorkerId)
		{
			_logger.LogInformation("[{WorkerName}] Retrying enrollment for contact {ContactId} from campaign {CampaignId}. Retry count: {RetryCount}",
				WorkerName, enrollment.ContactId, enrollment.MarketingCampaignId, enrollment.Retries[WorkerId].Count);

			// Re-publish enrollment to the first worker in the pipeline version
			var firstWorker = pipelineVersion.GetNextWorker();

			if (firstWorker != null)
			{
				await _publisher.PublishEnrollmentAsync(firstWorker, enrollment);
				return true;
			}
		}

		// Retry by re-publishing to the current worker's stream (retry queue)
		await _publisher.PublishEnrollmentAsync(_worker, enrollment);

		return true;
	}

	private async Task AcknowledgeStreamMessage(IDatabase database, StagedEnrollment enrollment)
	{
		// Acknowledge message from the correct stream (high-priority or normal)
		var streamName = enrollment.IsHighPriority ? HighPriorityStreamName : DefaultStreamName;
		var consumerGroup = enrollment.IsHighPriority ? HighPriorityConsumerGroupName : DefaultConsumerGroupName;

		if (enrollment.MessageId != null)
		{
			// Acknowledge and delete message only if all consumer groups have acknowledged it
			await database.StreamAcknowledgeAsync(streamName, consumerGroup, enrollment.MessageId.Value);
			await database.StreamDeleteAsync(streamName, [enrollment.MessageId.Value]);
		}
	}

	/// <summary>
	/// Implements prioritized message retrieval strategy:
	/// 1st Priority: High-priority messages from dedicated high-priority stream (ABSOLUTE PRIORITY)
	/// 2nd Priority: Steal timed-out work from other consumers (XAUTOCLAIM)
	/// 3rd Priority: Resume my own previously delivered-but-unacked work (XREADGROUP with "0")
	/// 4th Priority: New messages (XREADGROUP with ">")
	/// </summary>
	/// <returns>A tuple containing the messages and a flag indicating if they're from high-priority stream</returns>
	private async Task<(StreamEntry[] messages, bool isHighPriority)> GetMessagesWithPriority(IDatabase database, CancellationToken cancellationToken)
	{
		using var activity = ActivitySource.StartActivity("get-messages-with-priority");
		activity?.SetTag("worker.id", WorkerId);

		// Priority 1: Check for high-priority messages (ABSOLUTE PRIORITY)
		var highPriorityMessages = await TryReadHighPriorityMessages(database, cancellationToken);
		if (highPriorityMessages.Length > 0)
		{
			activity?.SetTag("message.source", "high-priority");
			activity?.SetTag("message.count", highPriorityMessages.Length);
			_logger.LogInformation("[{WorkerName}] Retrieved {Count} high-priority messages", WorkerName, highPriorityMessages.Length);

			return (highPriorityMessages, true);
		}

		// Priority 2: Check for pending messages from failed/slow consumers
		var pendingMessages = await TryClaimPendingMessages(database, cancellationToken);
		if (pendingMessages.Length > 0)
		{
			activity?.SetTag("message.source", "pending");
			activity?.SetTag("message.count", pendingMessages.Length);
			_logger.LogInformation("[{WorkerName}] Auto-claimed {Count} pending messages", WorkerName, pendingMessages.Length);

			// Record pending messages claimed metric
			PendingMessagesClaimedCounter.Add(pendingMessages.Length,
				new KeyValuePair<string, object?>("worker.id", WorkerId));

			return (pendingMessages, false);
		}

		// Priority 3: Check for unacknowledged (unfinished) backlog messages (catch-up)
		var backlogMessages = await TryReadBacklogMessages(database, cancellationToken);
		if (backlogMessages.Length > 0)
		{
			activity?.SetTag("message.source", "backlog");
			activity?.SetTag("message.count", backlogMessages.Length);
			_logger.LogInformation("[{WorkerName}] Retrieved {Count} backlog messages for catch-up processing", WorkerName, backlogMessages.Length);

			// Record backlog messages processed metric
			BacklogMessagesProcessedCounter.Add(backlogMessages.Length,
				new KeyValuePair<string, object?>("worker.id", WorkerId));

			return (backlogMessages, false);
		}

		// Priority 4: Read new messages
		var newMessages = await TryReadNewMessages(database, cancellationToken);
		if (newMessages.Length > 0)
		{
			activity?.SetTag("message.source", "new");
			activity?.SetTag("message.count", newMessages.Length);
			_logger.LogInformation("[{WorkerName}] Retrieved {Count} new messages", WorkerName, newMessages.Length);
		}
		else
		{
			activity?.SetTag("message.source", "none");
			activity?.SetTag("message.count", 0);
		}

		return (newMessages, false);
	}

	/// <summary>
	/// Attempts to claim pending messages that were delivered to other consumers but left unacked.
	/// In practice: steal timed-out work from other consumers.
	/// Uses XAUTOCLAIM and only takes entries that idle longer than ProcessingTimeout.
	/// </summary>
	private async Task<StreamEntry[]> TryClaimPendingMessages(IDatabase database, CancellationToken cancellationToken)
	{
		try
		{
			// Check for cancellation before making Redis calls
			cancellationToken.ThrowIfCancellationRequested();

			var pendingInfo = await database.StreamPendingAsync(DefaultStreamName, DefaultConsumerGroupName);
			if (pendingInfo.PendingMessageCount == 0)
			{
				return [];
			}

			// Check for cancellation before claiming
			cancellationToken.ThrowIfCancellationRequested();

			var idleTimeMs = (long)ProcessingTimeout.TotalMilliseconds;

			// XAUTOCLAIM automatically finds and claims messages older than min-idle-time
			var autoClaimResult = await database.StreamAutoClaimAsync(
				DefaultStreamName,
				DefaultConsumerGroupName,
				InstanceName,
				idleTimeMs,
				"0-0", // Start from beginning
                MaxBatchSize);

			return autoClaimResult.ClaimedEntries;
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] Claiming pending messages was cancelled", WorkerName);
			throw; // Re-throw cancellation exceptions
		}
		catch (Exception ex)
		{
			_logger.LogWarning(ex, "[{WorkerName}] Error auto-claiming pending messages", WorkerName);
			return [];
		}
	}

	/// <summary>
	/// Attempts to read this consumer's own pending (already-delivered-but-unacked) messages.
	/// In practice: resume my own previously delivered-but-unacked work.
	/// Uses XREADGROUP with "0" for consumer-local catch-up.
	/// </summary>
	private async Task<StreamEntry[]> TryReadBacklogMessages(IDatabase database, CancellationToken cancellationToken)
	{
		try
		{
			// Check for cancellation before making the Redis call
			cancellationToken.ThrowIfCancellationRequested();

			// Try to read messages that haven't been delivered to this specific consumer
			var backlogMessages = await database.StreamReadGroupAsync(
				DefaultStreamName,
				DefaultConsumerGroupName,
				InstanceName,
				"0", // Read from beginning of undelivered messages for this consumer
                MaxBatchSize);

			return backlogMessages;
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] Reading backlog messages was cancelled", WorkerName);
			throw; // Re-throw cancellation exceptions
		}
		catch (Exception ex)
		{
			_logger.LogWarning(ex, "[{WorkerName}] Error reading backlog messages", WorkerName);
			return [];
		}
	}

	/// <summary>
	/// Attempts to read new messages that haven't been delivered to any consumer in the group.
	/// </summary>
	private async Task<StreamEntry[]> TryReadNewMessages(IDatabase database, CancellationToken cancellationToken)
	{
		try
		{
			// Check for cancellation before making the Redis call
			cancellationToken.ThrowIfCancellationRequested();

			var newMessages = await database.StreamReadGroupAsync(
				DefaultStreamName,
				DefaultConsumerGroupName,
				InstanceName,
				">", // Read only new messages not delivered to any consumer
                MaxBatchSize);

			return newMessages;
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] Reading new messages was cancelled", WorkerName);
			throw; // Re-throw cancellation exceptions
		}
		catch (Exception ex)
		{
			_logger.LogWarning(ex, "[{WorkerName}] Error reading new messages", WorkerName);
			return Array.Empty<StreamEntry>();
		}
	}

	/// <summary>
	/// Attempts to read high-priority messages from the dedicated high-priority stream.
	/// These messages should be processed before backlog and new messages.
	/// </summary>
	private async Task<StreamEntry[]> TryReadHighPriorityMessages(IDatabase database, CancellationToken cancellationToken)
	{
		try
		{
			// Check for cancellation before making the Redis call
			cancellationToken.ThrowIfCancellationRequested();

			// First, try to claim pending high-priority messages
			var pendingInfo = await database.StreamPendingAsync(HighPriorityStreamName, HighPriorityConsumerGroupName);
			if (pendingInfo.PendingMessageCount > 0)
			{
				var idleTimeMs = (long)ProcessingTimeout.TotalMilliseconds;
				var autoClaimResult = await database.StreamAutoClaimAsync(
					HighPriorityStreamName,
					HighPriorityConsumerGroupName,
					InstanceName,
					idleTimeMs,
					"0-0",
					MaxBatchSize);

				if (autoClaimResult.ClaimedEntries.Length > 0)
				{
					HighPriorityMessagesProcessedCounter.Add(autoClaimResult.ClaimedEntries.Length,
						new KeyValuePair<string, object?>("worker.id", WorkerId));

					return autoClaimResult.ClaimedEntries;
				}
			}

			// Then try to read new high-priority messages
			var highPriorityMessages = await database.StreamReadGroupAsync(
				HighPriorityStreamName,
				HighPriorityConsumerGroupName,
				InstanceName,
				">", // Read only new messages not delivered to any consumer
                MaxBatchSize);

			if (highPriorityMessages.Length > 0)
			{
				HighPriorityMessagesProcessedCounter.Add(
					highPriorityMessages.Length,
					new KeyValuePair<string, object?>("worker.id", WorkerId)
				);

				// Calculate wait time for high-priority messages
				foreach (var message in highPriorityMessages)
				{
					var messageTimestamp = ExtractTimestampFromMessageId(message.Id);
					var waitTimeSeconds = (DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - messageTimestamp) / 1000.0;
					HighPriorityWaitTimeHistogram.Record(
						waitTimeSeconds,
						new KeyValuePair<string, object?>("worker.id", WorkerId)
					);
				}
			}

			return highPriorityMessages;
		}
		catch (OperationCanceledException)
		{
			_logger.LogDebug("[{WorkerName}] Reading high-priority messages was cancelled", WorkerName);
			throw; // Re-throw cancellation exceptions
		}
		catch (Exception ex)
		{
			_logger.LogWarning(ex, "[{WorkerName}] Error reading high-priority messages", WorkerName);
			return Array.Empty<StreamEntry>();
		}
	}

	private bool TryParseStreamMessage(StreamEntry message, out StagedEnrollment? enrollment)
	{
		enrollment = null;

		try
		{
			// Look for the enrollment data in the message fields
			var enrollmentData = message.Values.FirstOrDefault(v => v.Name == SharedConstants.StreamFieldKey);

			if (enrollmentData.Value.IsNull)
			{
				return false;
			}

			var jsonString = enrollmentData.Value.ToString();
			if (string.IsNullOrEmpty(jsonString))
			{
				return false;
			}

			enrollment = JsonSerializer.Deserialize<StagedEnrollment>(jsonString);
			if (enrollment != null)
			{
				// Set the MessageId for later acknowledgment purposes
				enrollment.MessageId = message.Id;
				return true;
			}
			return false;
		}
		catch (Exception ex)
		{
			_logger.LogWarning(ex, "[{WorkerName}] Failed to parse stream message {MessageId}", WorkerName, message.Id);
			return false;
		}
	}

	private async Task ReportMetricsLoop(IDatabase database, CancellationToken cancellationToken)
	{
		while (!cancellationToken.IsCancellationRequested)
		{
			try
			{
				cancellationToken.ThrowIfCancellationRequested();

				// Report normal stream metrics
				var streamInfo = await database.StreamInfoAsync(DefaultStreamName);
				StreamLengthGauge.Record(
					streamInfo.Length,
					new KeyValuePair<string, object?>("stream.name", DefaultStreamName)
				);

				// Report pending messages
				var pendingInfo = await database.StreamPendingAsync(DefaultStreamName, DefaultConsumerGroupName);
				PendingMessagesGauge.Record(
					pendingInfo.PendingMessageCount,
					new KeyValuePair<string, object?>("consumer.group", DefaultConsumerGroupName)
				);

				// Calculate and report backlog size (undelivered messages + pending messages)
				var groupInfos = await database.StreamGroupInfoAsync(DefaultStreamName);

				if (groupInfos.Length > 0)
				{
					// Estimate undelivered messages as difference between stream length and delivered messages
					// This is an approximation since Redis doesn't directly expose undelivered count
					var estimatedBacklogSize = streamInfo.Length; // Conservative estimate
					BacklogSizeGauge.Record(
						estimatedBacklogSize,
						new KeyValuePair<string, object?>("consumer.group", DefaultConsumerGroupName)
					);
				}

				// Report consumer lag
				if (pendingInfo.PendingMessageCount > 0 && !pendingInfo.LowestPendingMessageId.IsNull)
				{
					var lag = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() -
							 ExtractTimestampFromMessageId(pendingInfo.LowestPendingMessageId);

					ConsumerLagCounter.Add(Math.Max(0, lag),
						new KeyValuePair<string, object?>("consumer.group", DefaultConsumerGroupName)
					);
				}

				// Report high-priority stream metrics
				try
				{
					var highPriorityStreamInfo = await database.StreamInfoAsync(HighPriorityStreamName);
					HighPriorityQueueLengthGauge.Record(
						highPriorityStreamInfo.Length,
						new KeyValuePair<string, object?>("stream.name", HighPriorityStreamName)
					);

					var highPriorityPendingInfo = await database.StreamPendingAsync(HighPriorityStreamName, HighPriorityConsumerGroupName);
					PendingMessagesGauge.Record(
						highPriorityPendingInfo.PendingMessageCount,
						new KeyValuePair<string, object?>("consumer.group", HighPriorityConsumerGroupName)
					);
				}
				catch (RedisServerException ex) when (ex.Message.Contains("no such key"))
				{
					// High-priority stream doesn't exist yet, which is fine
					HighPriorityQueueLengthGauge.Record(
						0,
						new KeyValuePair<string, object?>("stream.name", HighPriorityStreamName)
					);
				}

				await Task.Delay(MetricsReportInterval, cancellationToken);
			}
			catch (OperationCanceledException)
			{
				_logger.LogDebug("[{WorkerName}] Metrics reporting was cancelled for worker {WorkerId}", WorkerName, WorkerId);
				throw; // Re-throw to exit the loop gracefully
			}
			catch (Exception ex)
			{
				_logger.LogWarning(ex, "[{WorkerName}] Error reporting metrics", WorkerName);
				try
				{
					await Task.Delay(MetricsReportInterval, cancellationToken);
				}
				catch (OperationCanceledException)
				{
					_logger.LogDebug("[{WorkerName}] Metrics reporting delay was cancelled for worker {WorkerId}", WorkerName, WorkerId);
					throw; // Exit on cancellation
				}
			}
		}
	}

	private async Task LeaderElectionLoop(IDatabase database, CancellationToken cancellationToken)
	{
		var leaderKey = $"leader:{DefaultConsumerGroupName}";
		var leaderLockDuration = TimeSpan.FromSeconds(60);

		while (!cancellationToken.IsCancellationRequested)
		{
			try
			{
				cancellationToken.ThrowIfCancellationRequested();

				// Try to acquire leadership
				var acquired = await database.LockTakeAsync(leaderKey, InstanceName, leaderLockDuration);

				if (acquired && !_isLeader)
				{
					_isLeader = true;
					_logger.LogDebug("[{WorkerName}] Worker {WorkerId} acquired leadership for consumer group {ConsumerGroup}",
						WorkerName, WorkerId, DefaultConsumerGroupName);

					// Start scaling monitoring
					_ = Task.Run(() => ScalingMonitorLoop(database, cancellationToken), cancellationToken);
				}
				else if (!acquired && _isLeader)
				{
					_isLeader = false;
					_logger.LogDebug("[{WorkerName}] Worker {WorkerId} lost leadership for consumer group {ConsumerGroup}",
						WorkerName, WorkerId, DefaultConsumerGroupName);
				}

				await Task.Delay(TimeSpan.FromSeconds(30), cancellationToken);
			}
			catch (OperationCanceledException)
			{
				_logger.LogDebug("[{WorkerName}] Leader election was cancelled for worker {WorkerId}", WorkerName, WorkerId);
				_isLeader = false; // Clean up leadership state
				throw; // Re-throw to exit the loop gracefully
			}
			catch (Exception ex)
			{
				_logger.LogWarning(ex, "[{WorkerName}] Error in leader election", WorkerName);
				_isLeader = false;
				try
				{
					await Task.Delay(TimeSpan.FromSeconds(30), cancellationToken);
				}
				catch (OperationCanceledException)
				{
					_logger.LogDebug("[{WorkerName}] Leader election delay was cancelled for worker {WorkerId}", WorkerName, WorkerId);
					throw; // Exit on cancellation
				}
			}
		}
	}

	private async Task ScalingMonitorLoop(IDatabase database, CancellationToken cancellationToken)
	{
		while (!cancellationToken.IsCancellationRequested && _isLeader)
		{
			try
			{
				cancellationToken.ThrowIfCancellationRequested();

				var streamInfo = await database.StreamInfoAsync(DefaultStreamName);
				var pendingInfo = await database.StreamPendingAsync(DefaultStreamName, DefaultConsumerGroupName);
				var totalLoad = streamInfo.Length + pendingInfo.PendingMessageCount;

				// Report scaling recommendation via metrics
				var recommendedWorkers = CalculateOptimalWorkerCount(totalLoad);
				ActiveWorkersGauge.Record(recommendedWorkers,
					new KeyValuePair<string, object?>("stream.name", DefaultStreamName),
					new KeyValuePair<string, object?>("recommendation", "optimal"));

				// Log scaling recommendations
				if (totalLoad > ScaleUpThreshold)
				{
					_logger.LogDebug("[{WorkerName}] Scaling recommendation: SCALE UP - Stream load: {Load}, Recommended workers: {Workers}",
						WorkerName, totalLoad, recommendedWorkers);
				}
				else if (totalLoad < ScaleDownThreshold)
				{
					_logger.LogDebug("[{WorkerName}] Scaling recommendation: SCALE DOWN - Stream load: {Load}, Recommended workers: {Workers}",
						WorkerName, totalLoad, recommendedWorkers);
				}

				await Task.Delay(TimeSpan.FromSeconds(60), cancellationToken);
			}
			catch (OperationCanceledException)
			{
				_logger.LogDebug("[{WorkerName}] Scaling monitoring was cancelled for worker {WorkerId}", WorkerName, WorkerId);
				throw; // Re-throw to exit the loop gracefully
			}
			catch (Exception ex)
			{
				_logger.LogWarning(ex, "[{WorkerName}] Error in scaling monitor", WorkerName);
				try
				{
					await Task.Delay(TimeSpan.FromSeconds(60), cancellationToken);
				}
				catch (OperationCanceledException)
				{
					_logger.LogDebug("[{WorkerName}] Scaling monitor delay was cancelled for worker {WorkerId}", WorkerName, WorkerId);
					throw; // Exit on cancellation
				}
			}
		}
	}

	private async Task CreateRedisConsumerGroup(IDatabase database, string streamName, string consumerGroupName)
	{
		// Initialize default stream consumer group
		try
		{
			await database.StreamCreateConsumerGroupAsync(
				streamName,
				consumerGroupName,
				StreamPosition.Beginning,
				createStream: true);

			_logger.LogDebug("[{WorkerName}] Created consumer group {ConsumerGroup} for stream {Stream}",
				WorkerName, consumerGroupName, streamName);
		}
		catch (RedisServerException ex)
		{
			if (ex.Message.Contains("BUSYGROUP"))
			{
				// Consumer group already exists, which is fine
				_logger.LogDebug("[{WorkerName}] Consumer group {ConsumerGroup} already exists for stream {Stream}",
					WorkerName, consumerGroupName, streamName);
			}
			else
			{
				_logger.LogError(ex, "[{WorkerName}] Error creating consumer group {ConsumerGroup} for stream {Stream}",
					WorkerName, consumerGroupName, streamName);
			}
		}
	}

	/// <summary>
	/// Calculates the optimal number of workers for the given stream load.
	/// Example: If the total load is 1000 and MaxBatchSize is 100, the recommended
	/// number of workers would be 10.
	/// </summary>
	/// <param name="totalLoad"></param>
	/// <returns></returns>
	private int CalculateOptimalWorkerCount(long totalLoad)
	{
		// Simple scaling algorithm: one worker per MaxBatchSize messages
		var baseWorkers = Math.Max(1, (int)Math.Ceiling((double)totalLoad / MaxBatchSize));

		// Add buffer for high load scenarios
		if (totalLoad > ScaleUpThreshold * 2)
		{
			baseWorkers = (int)(baseWorkers * 1.5);
		}

		return Math.Min(baseWorkers, MaxNumberOfWorkers);
	}

	private static long ExtractTimestampFromMessageId(RedisValue messageId)
	{
		try
		{
			var parts = messageId.ToString().Split('-');
			if (parts.Length >= 2 && long.TryParse(parts[0], out var timestamp))
			{
				return timestamp;
			}
		}
		catch
		{
			// Ignore parsing errors
		}

		return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
	}

	/// <summary>
	/// Gets the next worker ID in the pipeline after the current worker.
	/// Returns null if current worker is not found or is the last step.
	/// </summary>
	/// <returns>The next PipelineWorker or null if last step. If the status is an error state, returns the ErrorHandler worker.</returns>
	private async Task<PipelineWorker?> GetNextWorker(StagedEnrollment enrollment)
	{
		ArgumentNullException.ThrowIfNull(enrollment.PipelineVersionId);

		var pipelineVersion = await GetCachedPipelineVersionById((short) enrollment.PipelineVersionId);

		// Return the ErrorHandler's worker id if the current status is an error state
		if (enrollment.StatusId == PipelineStatus.Failed)
		{
			return pipelineVersion?.ErrorHandlerWorker;
		}

		// Check if the next worker exists in the ordered workers
		return pipelineVersion?.GetNextWorker(WorkerId);
	}

	/// <summary>
	/// Gets the cached PipelineVersion by ID using hybrid caching (in-memory + Redis distributed cache).
	/// This allows sharing cache between different worker instances.
	/// </summary>
	/// <param name="pipelineVersionId"></param>
	/// <returns></returns>
	private async Task<PipelineVersion?> GetCachedPipelineVersionById(short pipelineVersionId)
	{
		var cacheKey = $"pipeline_version:{pipelineVersionId}";

		// Try to get from hybrid cache (checks in-memory first, then Redis)
		var cachedVersion = await _hybridCache.GetOrCreateAsync(
			cacheKey,
			async (cancellationToken) =>
			{
				if (PipelineService == null)
				{
					return null;
				}

                // Fetch from database if not in cache
                var version = await PipelineService.GetVersionByIdAsync(pipelineVersionId, cancellationToken);

				_logger.LogDebug("[{WorkerName}] Loaded pipeline version {VersionId} from database for caching", WorkerName, pipelineVersionId);

				return version;
			},
			options: new HybridCacheEntryOptions
			{
                // Cache for 15 minutes in memory and 1 hour in Redis
                LocalCacheExpiration = TimeSpan.FromMinutes(15),
				Expiration = TimeSpan.FromHours(1)
			});

		return cachedVersion;
	}

	public override void Dispose()
	{
		ActivitySource.Dispose();
		Meter.Dispose();
		base.Dispose();
	}
}
