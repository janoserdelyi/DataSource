namespace EnrollmentPipeline.Models;

/// <summary>
/// Entity representing the junction table enrollment.pipeline_version_worker.
/// Links pipeline versions to their constituent workers with ordering information.
/// </summary>
public class PipelineVersionWorker
{
    public required PipelineWorker Worker { get; set; }
    public required int WorkerOrder { get; set; }
}
