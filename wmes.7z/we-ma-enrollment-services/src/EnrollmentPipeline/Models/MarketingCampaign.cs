using System.Collections.ObjectModel;
using System.Text.Json.Serialization;
using Marketing.Enums;

namespace EnrollmentPipeline.Models;

public class MarketingCampaign
{
    public int Id { get; set; }
    public int MarketingCampaignId { get; set; }
    public MarketingBrands MarketingBrandId { get; set; }
    public string BrandName { get; set; } = string.Empty;
    public string MarketingCampaignName { get; set; } = string.Empty;
    public bool CampaignStatus { get; set; }
    public DateTimeOffset CreatedDate { get; set; }
    public DateTimeOffset CampaignStartDate { get; set; }
    public DateTimeOffset CampaignEndDate { get; set; }
    public string? CampaignDescription { get; set; }
    public bool CampaignAllowUnenroll { get; set; }
    public bool IsCampaignPublished { get; set; }
    public List<EnrollmentMethod> EnrollmentMethods { get; set; } = new();
    public int TemplateCount { get; set; }
    public bool IsOperational { get; set; }
    public bool IsTransactional { get; set; }
    public string DeliveryType { get; set; } = string.Empty;
    public bool IsCampaignDeleted { get; set; }
    public bool IsCampaignActive { get; set; }
    public bool AssignSupportLeadWE { get; set; }
    public bool AssignSalesLeadWE { get; set; }
    public bool AssignMarketingLeadWE { get; set; }
    public int ChannelSourceId { get; set; }
    public string? SfCampaignId { get; set; }
    public string? ExternalCampaignId { get; set; }
    public int LeadBrandId { get; set; }
    public string LeadBrandName { get; set; } = string.Empty;
    public List<CallTrackingNumberInfo> Ctns { get; set; } = new();
    public List<CampaignDescription> Descriptions { get; set; } = new();
    public int BrandSegmentId { get; set; }
    public string BrandSegmentName { get; set; } = string.Empty;
    public int ParentBrandSegmentId { get; set; }
    public string ParentBrandSegmentName { get; set; } = string.Empty;
    public int? MarketingCloudAccountId { get; set; }
    public string? DataExtensionId { get; set; }
    public required IReadOnlyCollection<MarketingDataField> DataFields { 
        get; 
        set {
            field = value ?? [];

            var activeFields = new List<MarketingDataField>();
            var requiredFields = new List<MarketingDataField>();

            foreach (var dataField in field)
            {
                if (dataField.IsActiveForCampaign)
                {
                    activeFields.Add(dataField);
                    
                    if (dataField.IsRequiredForCampaign)
                    {
                        requiredFields.Add(dataField);
                    }
                }
            }

            RequiredDataFields = requiredFields.AsReadOnly();
            ActiveDataFields = activeFields.AsReadOnly();
        }
    }

    [JsonIgnore]
    public IReadOnlyCollection<MarketingDataField> RequiredDataFields
    {
        get; private set;
    } = [];

    [JsonIgnore]
    public IReadOnlyCollection<MarketingDataField> ActiveDataFields
    {
        get; private set;
    } = [];
}

public class CampaignDescription
{
    public string CultureCode { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}

public class CallTrackingNumberInfo
{
    public string CountryCode { get; set; } = string.Empty;
    public string CallTrackingNumber { get; set; } = string.Empty;
    public string DestinationName { get; set; } = string.Empty;
    public string DestinationPhoneNumber { get; set; } = string.Empty;
}

public class MarketingDataField
{
    public int MarketingDataFieldId { get; set; }
    public string FieldName { get; set; } = string.Empty;
    public string FieldType { get; set; } = string.Empty;
    public bool IsRequiredForCampaign { get; set; }
    public bool IsActiveForCampaign { get; set; }
}
