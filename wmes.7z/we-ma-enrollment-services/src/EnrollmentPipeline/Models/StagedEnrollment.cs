﻿using System.Diagnostics;
using System.IO.Pipelines;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using EnrollmentPipeline.Enums;
using Marketing.Enums;
using StackExchange.Redis;

namespace EnrollmentPipeline.Models;

/// <summary>
/// Represents a staged enrollment record in the pipeline.
/// </summary>
[DebuggerDisplay("Contact #{ContactId} - Campaign {MarketingCampaignId} ({BrandId})")]
public class StagedEnrollment
{
	/// <summary>
	/// This constructor is required for deserialization and <b>should not</b> be used directly.
	/// </summary>
	public StagedEnrollment()
	{
	}

	public StagedEnrollment(
		int contactId,
		JsonObject dataFields,
		MarketingCampaign campaign,
		PipelineVersion pipelineVersion
	) : this(contactId, dataFields, campaign.Id, campaign.MarketingBrandId, pipelineVersion.Id)
	{
		Campaign = campaign;
		PipelineVersion = pipelineVersion;
	}

	public StagedEnrollment(
		int contactId,
		JsonObject dataFields,
		int marketingCampaignId,
		MarketingBrands brandId,
		short pipelineVersionId
	)
	{
		ContactId = contactId;
		DataFields = dataFields;
		MarketingCampaignId = marketingCampaignId;
		BrandId = brandId;
		PipelineVersionId = pipelineVersionId;
	}

	public Guid Id { get; set; } = Guid.NewGuid();
	/// <summary>
	/// Batch identifier for grouping enrollments.
	/// </summary>
	public Guid? BatchId { get; set; }
	public int MarketingCampaignId { get; set; }
	public MarketingBrands BrandId { get; set; }
	public int ContactId { get; set; }
	public short? PipelineVersionId { get; set; }
	public JsonObject DataFields { get; set; } = [];
	/// <summary>
	/// Number of times this record has been retried. 
	/// Key is the WorkerId, Value is the retry information (count and reasons).
	/// </summary>
	public Dictionary<Guid, RetryInfo> Retries { get; set; } = [];
	/// <summary>
	/// Current status of the enrollment in the pipeline.
	/// </summary>
	public PipelineStatus StatusId { get; set; } = PipelineStatus.Created;
	/// <summary>
	/// Optional reason for the current status.
	/// </summary>
	public PipelineStatusReason? StatusReasonId { get; set; }
	/// <summary>
	/// Optional message providing additional context about the status.
	/// </summary>
	public string? StatusMessage { get; set; }
	/// <summary>
	/// Indicates if this message should use the high-priority streams.
	/// </summary>
	public bool IsHighPriority { get; set; }
	public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.UtcNow;
	public DateTimeOffset? UpdatedDate { get; set; } = null;
	public Guid? UpdatedByWorkerId { get; set; } = null;
	/// <summary>
	/// Redis Stream Message ID for acknowledgment purposes.
	/// This is not persisted to the database and is set when the message is read from the Redis stream.
	/// </summary>
	[JsonIgnore]
	public RedisValue? MessageId { get; set; }

	/// <summary>
	/// The pipeline version associated with this enrollment. This is not persisted to the database and is only used for the initial publishing logic.
	/// </summary>
	[JsonIgnore]
	public PipelineVersion? PipelineVersion
	{
		get;
		set
		{
			field = value;

			if (value != null)
			{
				PipelineVersionId = value.Id;
			}
		}
	}
	/// <summary>
	/// The metadata for the campaign associated with this enrollment. This is not persisted to the database and is only used for the initial publishing logic.
	/// </summary>
	[JsonIgnore]
	public MarketingCampaign? Campaign
	{
		get;
		set
		{
			field = value;

			if (value != null)
			{
				MarketingCampaignId = value.Id;
				BrandId = value.MarketingBrandId;
			}
		}
	}

	/// <summary>
	/// Extracts the email address from the DataFields JSON document.
	/// </summary>
	/// <returns></returns>
	public string? GetEmailAddress()
	{
		if (DataFields == null || DataFields.Count == 0)
		{
			return null;
		}

		if (DataFields.TryGetPropertyValue("EmailAddress", out var emailElement))
		{
			return emailElement?.GetValue<string>();
		}

		return null;
	}

	/// <summary>
	/// Extracts the Location ID from the DataFields JSON document.
	/// </summary>
	/// <returns></returns>
	public int? GetLocationId()
	{
		if (DataFields == null || DataFields.Count == 0)
		{
			return null;
		}

		if (DataFields.TryGetPropertyValue("LocationId", out var locationElement))
		{
			return locationElement?.GetValue<int>();
		}

		return null;
	}
}

public class RetryInfo
{
	public int Count { get; set; } = 0;
	/// <summary>
	/// Stores the reason for the retry which comes from <see cref="WorkerResult.Message"/>.
	/// For example:
	/// {
	///     "0": "Failed to check for required campaign fields.",
	///     "1": "Error validating required fields: Error message from exception."
	/// }
	/// </summary>
	public List<string> Reasons { get; set; } = [];
}