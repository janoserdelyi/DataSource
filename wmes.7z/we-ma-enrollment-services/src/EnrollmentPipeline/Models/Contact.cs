namespace EnrollmentPipeline.Models;

public record Contact(
    int Id,
    string CountryCode,
    string FirstName,
    string LastName,
    ContactLocation Location
);

public record ContactLocation(
    int Id,
    string Name
);