﻿using EnrollmentPipeline.Enums;

namespace EnrollmentPipeline.Models;

public class WorkerResult
{
    public required Guid WorkerId { get; init; }
    public required StagedEnrollment Enrollment { get; init; }
    public PipelineStatus Status { get; set; } = PipelineStatus.Processing;
    public PipelineStatusReason? StatusReason { get; set; }
    public string? Message { get; set; }
    public DateTimeOffset StartedAt { get; set; }
    public DateTimeOffset EndedAt { get; set; }
}