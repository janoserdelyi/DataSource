using System.Diagnostics;
using System.Text.Json.Serialization;

namespace EnrollmentPipeline.Models;

/// <summary>
/// Entity representing a pipeline worker in the enrollment.pipeline_worker table.
/// Represents individual processing components that can be arranged in pipeline versions.
/// </summary>
[DebuggerDisplay("{Name} - {Id}")]
public class PipelineWorker
{
	public required Guid Id { get; set; }

	public string? Name { get; set; }

	public string? Description { get; set; }

	public DateTimeOffset CreatedDate { get; set; }

	public int? CreatedBy { get; set; }

	public DateTimeOffset UpdatedDate { get; set; }

	public int? UpdatedBy { get; set; }

	/// <summary>
	/// Gets the Redis Stream name for this worker.
	/// </summary>
	[JsonIgnore]
	public string DefaultStreamName => $"{Id}:default";

	/// <summary>
	/// Gets the high-priority Redis Stream name for this worker.
	/// </summary>
	[JsonIgnore]
	public string HighPriorityStreamName => $"{Id}:high-priority";
}
