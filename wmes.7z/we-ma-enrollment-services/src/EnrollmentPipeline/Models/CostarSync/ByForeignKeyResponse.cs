namespace EnrollmentPipeline.Models.CostarSync;

public class ByForeignKeyResponse
{
    public string? Key { get; set; }
    public List<ModelKeys> ModelKeys { get; set; } = [];
}

public class ModelKeys
{
    public string? k { get; set; }
    public int v { get; set; }
}