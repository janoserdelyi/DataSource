using System.Runtime.Serialization;

namespace EnrollmentPipeline.Models.CostarSync;

public class ContactRequestModel
{
	[DataMember(Name = "requests")]
	public IEnumerable<ContactRequest> Requests { get; set; } = [];
}

public class ContactRequest
{
	[DataMember(Name = "url")]
	public required string Url { get; set; }
}
