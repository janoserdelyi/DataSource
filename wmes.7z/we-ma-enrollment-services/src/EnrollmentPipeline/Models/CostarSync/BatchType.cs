namespace EnrollmentPipeline.Models.CostarSync;

public enum BatchType
{
    Contact = 1,
    SalesTerritorySummaryKeysByContactID = 2,
    SalesTerritorySummary = 3,
    LocationProfile = 4,
    MarketingLead = 5,
    ContactAccount = 6,
}