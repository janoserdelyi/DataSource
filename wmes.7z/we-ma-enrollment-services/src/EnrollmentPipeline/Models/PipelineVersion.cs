using Marketing.Enums;

namespace EnrollmentPipeline.Models;

/// <summary>
/// Entity representing a pipeline version in the enrollment.pipeline_version table.
/// Represents a specific version/configuration of the processing pipeline.
/// </summary>
public class PipelineVersion
{
    public short Id { get; set; }

    public MarketingBrands? BrandId { get; set; }

    public bool Active { get; set; }

    public DateTimeOffset CreatedDate { get; set; }

    public int? CreatedBy { get; set; }

    public Guid? ErrorHandlerWorkerId { 
        get; 
        set
        {
            field = value;

            if (value != null)
            {
                ErrorHandlerWorker = new PipelineWorker
                {
                    Id = value.Value
                };
            }
        } 
    }

    /// <summary>
    /// The worker designated as the error handler for this pipeline version.
    /// </summary>
    public PipelineWorker? ErrorHandlerWorker { get; private set; }

    /// <summary>
    /// Collection of workers associated with this pipeline version.
    /// Represents the one-to-many relationship through the junction table.
    /// </summary>
    public ICollection<PipelineVersionWorker> Workers { 
        get; 
        set
        {
            field = value;
            // Builds ordered dictionary off of new value
            OrderedWorkers = value.ToDictionary(pvw => pvw.WorkerOrder, pvw => pvw.Worker);
            // TODO: Create a dictionary that maps current worker to the next worker in the pipeline to replace the call above and the GetNextWorker method.
        }
    } = [];

    /// <summary>
    /// Convenience property to get the workers in order for this pipeline version.
    /// Returns workers sorted by their WorkerOrder.
    /// </summary>
    public Dictionary<int, PipelineWorker> OrderedWorkers { get; private set; } = [];

    /// <summary>
    /// Gets the next worker's stream name in the pipeline based on the current worker's ID.
    /// </summary>
    /// <param name="currentWorkerId">(Optional) The ID of the current worker. If null or Guid.Empty or the error handler worker ID, the stream name for the first worker is returned.</param>
    /// <returns>Returns null if there is no next worker (end of pipeline). Otherwise, returns the stream name of the next worker.</returns>
    /// <exception cref="InvalidOperationException">Thrown when no workers are configured in the pipeline version.</exception>
    /// <exception cref="ArgumentException">Thrown when the current worker ID is not found in the pipeline version.</exception>
    public PipelineWorker? GetNextWorker(Guid? currentWorkerId = null)
    {
        if (OrderedWorkers.Count == 0)
        {
            throw new InvalidOperationException("No workers are configured in this pipeline version.");
        }

        if (currentWorkerId == null || currentWorkerId == Guid.Empty || currentWorkerId == ErrorHandlerWorkerId)
        {
            // If no current worker ID is provided, or if it's the error handler worker, return the first worker's stream name
            var firstWorkerKey = OrderedWorkers.Keys.Min();
            var firstWorker = OrderedWorkers[firstWorkerKey];

            return firstWorker;
        }

        foreach (var pair in OrderedWorkers)
        {
            if (pair.Value.Id == currentWorkerId)
            {
                var currentOrder = pair.Key;

                // Try finding the next worker in order by incrementing the order first
                if (OrderedWorkers.TryGetValue(currentOrder + 1, out var nextWorker))
                {
                    // Returns the next worker
                    return nextWorker;
                }

                // If not found by incrementing, then try finding the next workers
                var nextWorkers = OrderedWorkers.Keys.Where(k => k > currentOrder);
                if (!nextWorkers.Any())
                {
                    // Current worker is the last in the pipeline, therefore no next worker
                    return null;
                }

                // Gets the next larger key
                var nextWorkerKey = nextWorkers.Min();
                // Returns the next worker
                return OrderedWorkers[nextWorkerKey];
            }
        }

        // Current worker not found in this pipeline version
        throw new ArgumentException("Unable to determine the next worker's stream name: Current worker ID not found in this pipeline version.");
    }
}
