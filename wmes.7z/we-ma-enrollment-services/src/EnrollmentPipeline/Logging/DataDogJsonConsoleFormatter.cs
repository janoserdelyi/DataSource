using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Options;

namespace EnrollmentPipeline.Logging;

/// <summary>
/// Custom JSON console formatter that outputs logs in DataDog's expected format.
/// </summary>
public sealed class DataDogJsonConsoleFormatter : ConsoleFormatter
{
	public static new readonly string Name = "datadog-json";
	private readonly IDisposable? _optionsReloadToken;
	private DataDogJsonConsoleFormatterOptions _formatterOptions;

	public DataDogJsonConsoleFormatter(IOptionsMonitor<DataDogJsonConsoleFormatterOptions> options)
		: base(Name)
	{
		_formatterOptions = options.CurrentValue;
		_optionsReloadToken = options.OnChange(ReloadLoggerOptions);
	}

	private void ReloadLoggerOptions(DataDogJsonConsoleFormatterOptions options)
	{
		_formatterOptions = options;
	}

	public override void Write<TState>(
		in LogEntry<TState> logEntry,
		IExternalScopeProvider? scopeProvider,
		TextWriter textWriter)
	{
		var message = logEntry.Formatter(logEntry.State, logEntry.Exception);

		using var stream = new MemoryStream();
		using var writer = new Utf8JsonWriter(stream, new JsonWriterOptions { Indented = false });

		writer.WriteStartObject();

		// Timestamp - "ts"
		var timestamp = _formatterOptions.UseUtcTimestamp
			? DateTimeOffset.UtcNow
			: DateTimeOffset.Now;
		writer.WriteString("ts", timestamp.ToString(_formatterOptions.TimestampFormat));

		// Log Level - "level" (lowercase)
		writer.WriteString("level", GetLogLevelString(logEntry.LogLevel));

		// Message - "event"
		writer.WriteString("event", message);

		// Properties - "props" (state values excluding OriginalFormat)
		WriteProperties(writer, logEntry.State);

		// Category - "cat"
		writer.WriteString("cat", logEntry.Category);

		// Event ID - "eventId"
		if (logEntry.EventId.Id != 0)
		{
			writer.WriteNumber("eventId", logEntry.EventId.Id);
		}

		// Exception details if present
		if (logEntry.Exception != null)
		{
			WriteExceptionDetails(writer, logEntry.Exception);
		}

		// Scopes (if enabled and present)
		if (_formatterOptions.IncludeScopes && scopeProvider != null)
		{
			WriteScopes(writer, scopeProvider);
		}

		writer.WriteEndObject();
		writer.Flush();

		// Get the JSON string from the memory stream
		var jsonString = Encoding.UTF8.GetString(stream.ToArray());

		textWriter.WriteLine(jsonString);
	}

	private static string GetLogLevelString(LogLevel logLevel)
	{
		return logLevel switch
		{
			LogLevel.Trace => "trace",
			LogLevel.Debug => "debug",
			LogLevel.Information => "info",
			LogLevel.Warning => "warn",
			LogLevel.Error => "error",
			LogLevel.Critical => "critical",
			LogLevel.None => "none",
			_ => "unknown"
		};
	}

	private static string? GetOriginalFormat<TState>(TState state)
	{
		if (state is IReadOnlyCollection<KeyValuePair<string, object?>> stateProperties)
		{
			foreach (var kvp in stateProperties)
			{
				if (kvp.Key == "{OriginalFormat}")
				{
					return kvp.Value?.ToString();
				}
			}
		}

		return null;
	}

	private static void WriteExceptionDetails(Utf8JsonWriter writer, Exception exception)
	{
		writer.WriteStartObject("exception");

		writer.WriteString("type", exception.GetType().FullName);
		writer.WriteString("message", exception.Message);
		writer.WriteString("stackTrace", exception.StackTrace);
		writer.WriteString("dump", exception.ToString());

		writer.WriteEndObject();
	}

	private static void WriteProperties<TState>(Utf8JsonWriter writer, TState state)
	{
		if (state is not IReadOnlyCollection<KeyValuePair<string, object?>> stateProperties)
		{
			return;
		}

		writer.WriteStartObject("props");

		foreach (var kvp in stateProperties)
		{
			WritePropertyValue(writer, kvp.Key, kvp.Value);
		}

		writer.WriteEndObject();
	}

	private static void WritePropertyValue(Utf8JsonWriter writer, string key, object? value)
	{
		if (value == null)
		{
			writer.WriteNull(key);
			return;
		}

		switch (value)
		{
			case string s:
				writer.WriteString(key, s);
				break;
			case int i:
				writer.WriteNumber(key, i);
				break;
			case long l:
				writer.WriteNumber(key, l);
				break;
			case double d:
				writer.WriteNumber(key, d);
				break;
			case float f:
				writer.WriteNumber(key, f);
				break;
			case bool b:
				writer.WriteBoolean(key, b);
				break;
			case DateTime dt:
				writer.WriteString(key, dt.ToString("O"));
				break;
			case DateTimeOffset dto:
				writer.WriteString(key, dto.ToString("O"));
				break;
			default:
				writer.WriteString(key, value.ToString());
				break;
		}
	}

	private static void WriteScopes(Utf8JsonWriter writer, IExternalScopeProvider scopeProvider)
	{
		var scopes = new List<object?>();

		scopeProvider.ForEachScope((scope, state) =>
		{
			state.Add(scope);
		}, scopes);

		if (scopes.Count > 0)
		{
			writer.WriteStartArray("scopes");
			foreach (var scope in scopes)
			{
				if (scope is IEnumerable<KeyValuePair<string, object?>> scopeProperties)
				{
					writer.WriteStartObject();
					foreach (var kvp in scopeProperties)
					{
						WritePropertyValue(writer, kvp.Key, kvp.Value);
					}
					writer.WriteEndObject();
				}
				else
				{
					writer.WriteStringValue(scope?.ToString() ?? string.Empty);
				}
			}
			writer.WriteEndArray();
		}
	}

	public void Dispose()
	{
		_optionsReloadToken?.Dispose();
	}
}
