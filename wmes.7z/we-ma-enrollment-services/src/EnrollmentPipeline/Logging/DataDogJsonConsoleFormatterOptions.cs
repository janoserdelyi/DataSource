using Microsoft.Extensions.Logging.Console;

namespace EnrollmentPipeline.Logging;

/// <summary>
/// Options for the DataDog JSON console formatter.
/// </summary>
public class DataDogJsonConsoleFormatterOptions : ConsoleFormatterOptions
{
	public DataDogJsonConsoleFormatterOptions()
	{
		// Default to UTC timestamps with ISO 8601 format including offset
		UseUtcTimestamp = false; // Use local time to include timezone offset
		TimestampFormat = "yyyy-MM-ddTHH:mm:ss.fffffffzzz";
	}

	/// <summary>
	/// Gets or sets the format string for timestamps.
	/// Default: "yyyy-MM-ddTHH:mm:ss.fffffffzzz" (ISO 8601 with timezone offset)
	/// </summary>
	public new string TimestampFormat { get; set; }
}
