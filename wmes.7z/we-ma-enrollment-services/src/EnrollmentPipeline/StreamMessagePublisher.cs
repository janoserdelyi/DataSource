using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Enums;

namespace EnrollmentPipeline;

public interface IStreamMessagePublisher
{
	/// <summary>
	/// Publishes a single enrollment to a specific Redis Stream
	/// </summary>
	/// <param name="streamName">The Redis Stream name</param>
	/// <param name="enrollment">Enrollment to publish</param>
	/// <returns>The message ID assigned by Redis</returns>
	Task<RedisValue> PublishEnrollmentAsync(string streamName, StagedEnrollment enrollment);
	/// <summary>
	/// Publishes a single enrollment to a worker-specific Redis Stream
	/// </summary>
	/// <param name="worker">The worker (used to derive stream name)</param>
	/// <param name="enrollment">Enrollment to publish</param>
	/// <returns>The message ID assigned by Redis</returns>
	Task<RedisValue> PublishEnrollmentAsync(PipelineWorker worker, StagedEnrollment enrollment);
	/// <summary>
	/// Publishes a batch of enrollments to a specific Redis Stream
	/// </summary>
	/// <param name="streamName">The Redis Stream name</param>
	/// <param name="enrollments">Enrollments to publish</param>
	/// <returns>Dictionary of enrollments to their Redis message IDs</returns>
	Task<Dictionary<StagedEnrollment, RedisValue>> PublishEnrollmentBatchAsync(string streamName, IReadOnlyCollection<StagedEnrollment> enrollments);
	/// <summary>
	/// Publishes a batch of enrollments for a specific worker
	/// </summary>
	/// <param name="worker">The worker (used to derive stream name)</param>
	/// <param name="enrollments">Enrollments to publish</param>
	/// <returns>Dictionary of enrollments to their Redis message IDs</returns>
	Task<Dictionary<StagedEnrollment, RedisValue>> PublishEnrollmentBatchAsync(PipelineWorker worker, IReadOnlyCollection<StagedEnrollment> enrollments);
}

/// <summary>
/// Utility class for publishing messages to Redis Streams for pipeline processing
/// </summary>
public class StreamMessagePublisher(
	IConnectionMultiplexer redis,
	ILogger<StreamMessagePublisher> logger
) : IStreamMessagePublisher
{
	private static readonly ActivitySource ActivitySource = new("EnrollmentPipeline.StreamMessagePublisher");
	private static readonly Meter Meter = new("EnrollmentPipeline.StreamMessagePublisher");

	// Publishing Metrics
	private static readonly Counter<long> MessagesPublishedCounter = Meter.CreateCounter<long>(
		"pipeline_stream_messages_published_total",
		"Total number of messages published to streams");

	private static readonly Counter<long> PublishErrorsCounter = Meter.CreateCounter<long>(
		"pipeline_stream_publish_errors_total",
		"Total number of publishing errors");

	private static readonly Histogram<double> PublishDuration = Meter.CreateHistogram<double>(
		"pipeline_stream_publish_duration_seconds",
		"Duration of message publishing operations");

	public async Task<RedisValue> PublishEnrollmentAsync(PipelineWorker worker, StagedEnrollment enrollment)
	{
		var streamName = enrollment.IsHighPriority ? worker.HighPriorityStreamName : worker.DefaultStreamName;

		logger.LogDebug("Publishing enrollment ({ContactId}) for worker {WorkerName} to auto-derived stream {StreamName}",
			enrollment.ContactId, worker.Name, streamName);

		return await PublishEnrollmentAsync(streamName, enrollment);
	}

	public async Task<Dictionary<StagedEnrollment, RedisValue>> PublishEnrollmentBatchAsync(PipelineWorker worker, IReadOnlyCollection<StagedEnrollment> enrollments)
	{
		logger.LogDebug("Publishing {Count} enrollments for worker {WorkerName} to stream {StreamName}",
			enrollments.Count, worker.Name, worker.DefaultStreamName);
		// Batches are always published to the main stream, not the high-priority stream
		return await PublishEnrollmentBatchAsync(worker.DefaultStreamName, enrollments);
	}

	public async Task<RedisValue> PublishEnrollmentAsync(string streamName, StagedEnrollment enrollment)
	{
		var database = redis.GetDatabase();
		var publishStart = Stopwatch.GetTimestamp();

		using var activity = ActivitySource.StartActivity("stream-message-publish");
		activity?.SetTag("stream.name", streamName);
		activity?.SetTag("campaign.id", enrollment.MarketingCampaignId);

		if (enrollment.BatchId.HasValue)
		{
			activity?.SetTag("batch.id", enrollment.BatchId);
		}

		try
		{
			var json = JsonSerializer.Serialize(enrollment);

			var messageId = await database.StreamAddAsync(streamName, SharedConstants.StreamFieldKey, json);

			var publishDuration = Stopwatch.GetElapsedTime(publishStart).TotalSeconds;

			// Record metrics
			MessagesPublishedCounter.Add(1,
				new KeyValuePair<string, object?>("stream.name", streamName));

			PublishDuration.Record(publishDuration,
				new KeyValuePair<string, object?>("stream.name", streamName));

			logger.LogDebug("Published contact {ContactId} from campaign {CampaignId} to stream {Stream} with ID {MessageId} in {Duration:F3}s",
				enrollment.ContactId, enrollment.MarketingCampaignId, streamName, messageId, publishDuration);

			return messageId;
		}
		catch (Exception ex)
		{
			var publishDuration = Stopwatch.GetElapsedTime(publishStart).TotalSeconds;

			PublishErrorsCounter.Add(1,
				new KeyValuePair<string, object?>("stream.name", streamName));

			PublishDuration.Record(publishDuration,
				new KeyValuePair<string, object?>("stream.name", streamName),
				new KeyValuePair<string, object?>("error", true));

			logger.LogError(ex, "Failed to publish contact {ContactId} from campaign {CampaignId} to stream {Stream} after {Duration:F3}s",
				enrollment.ContactId, enrollment.MarketingCampaignId, streamName, publishDuration);

			activity?.SetTag("error", true);
			activity?.SetTag("error.message", ex.Message);
			throw;
		}
	}

	public async Task<Dictionary<StagedEnrollment, RedisValue>> PublishEnrollmentBatchAsync(string streamName, IReadOnlyCollection<StagedEnrollment> enrollments)
	{
		var results = new Dictionary<StagedEnrollment, RedisValue>();
		var batchStart = Stopwatch.GetTimestamp();

		using var activity = ActivitySource.StartActivity("stream-batch-publish");
		activity?.SetTag("stream.name", streamName);
		activity?.SetTag("batch.size", enrollments.Count);

		var failedCount = 0;

		foreach (var enrollment in enrollments)
		{
			try
			{
				var messageId = await PublishEnrollmentAsync(streamName, enrollment);
				results[enrollment] = messageId;
			}
			catch (Exception ex)
			{
				logger.LogError(ex, "Failed to publish enrollment to stream {Stream}.", streamName);
				// Sets the result for the failed enrollment to a null value
				results[enrollment] = RedisValue.Null;
				// Increment the count of failed enrollments
				failedCount++;
			}
		}

		var batchDuration = Stopwatch.GetElapsedTime(batchStart).TotalSeconds;

		logger.LogInformation("Published batch of {Count} enrollments to stream {Stream} in {Duration:F3}s",
			results.Count, streamName, batchDuration);

		activity?.SetTag("error", failedCount > 0);
		activity?.SetTag("duration.seconds", batchDuration);
		activity?.SetTag("messages.failed", failedCount);
		activity?.SetTag("messages.published", results.Count - failedCount);

		return results;
	}
}
