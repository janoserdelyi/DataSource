namespace EnrollmentPipeline.Enums;

/// <summary>
/// Represents the pipeline status of a campaign contact
/// </summary>
public enum PipelineStatusReason
{
	/// <summary>
	/// The enrollment has exceeded the maximum number of retries allowed.
	/// </summary>
	ExceededNumberOfRetries = 1,
	/// <summary>
	/// The contact in the enrollment is missing an email address.
	/// </summary>
	MissingEmailAddress = 2,
	/// <summary>
	/// The contact in the enrollment is missing required fields.
	/// </summary>
	MissingRequiredFields = 3,
	/// <summary>
	/// The email address in the enrollment is invalid.
	/// </summary>
	InvalidEmailAddress = 4,
	/// <summary>
	/// The data field lookup process failed to retrieve any data fields.
	/// </summary>
	DataFieldLookupFailed = 5,
	/// <summary>
	/// Email address in the enrollment has not been verified.
	/// </summary>
	MissingEmailValidation = 6,
	/// <summary>
	/// Failed to enroll due to contact has opted out.
	/// </summary>
	ContactOptedOut = 7,
	/// <summary>
	/// Failed to enroll due to contact has UK government email domain.
	/// </summary>
	UkGovernmentEmailDomain = 8,
	/// <summary>
	/// Failed to enroll due to missing campaign metadata.
	/// </summary>
	MissingCampaignMetadata = 9,
	/// <summary>
	/// Failed to publish enrollment to Marketing Cloud.
	/// </summary>
	MarketingCloudPublishFailed = 10,
	/// <summary>
	/// Invalid contact (contact not found in the initial lookup)
	/// </summary>
	InvalidContact = 11,
}
