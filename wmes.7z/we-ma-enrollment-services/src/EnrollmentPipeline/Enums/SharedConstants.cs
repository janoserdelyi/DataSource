namespace EnrollmentPipeline.Enums;

public static class SharedConstants
{
    public static readonly string StreamFieldKey = "enrollment";
}