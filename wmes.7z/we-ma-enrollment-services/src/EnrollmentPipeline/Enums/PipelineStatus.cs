namespace EnrollmentPipeline.Enums;

/// <summary>
/// Represents the pipeline status of a campaign contact
/// </summary>
public enum PipelineStatus
{
    /// <summary>
    /// Contact has been created and is awaiting processing
    /// </summary>
    Created = 1,

    /// <summary>
    /// Contact is being processed through the pipeline
    /// </summary>
    Processing = 2,
    
    /// <summary>
    /// Contact processing succeeded
    /// </summary>
    Success = 3,
    
    /// <summary>
    /// Contact processing failed with errors
    /// </summary>
    Failed = 4,
    
    /// <summary>
    /// Contact processing completed successfully
    /// </summary>
    Completed = 5,
    
    /// <summary>
    /// Contact processing is being retried after failure
    /// </summary>
    Retrying = 6
}
