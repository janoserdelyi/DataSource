using System.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using StackExchange.Redis;
using EnrollmentPipeline.HealthChecks;
using OpenSearch.Client;
using OpenSearch.Client.JsonNetSerializer;
using OpenSearch.Net;
using Microsoft.Data.SqlClient;
using EnrollmentPipeline.Services;
using EnrollmentPipeline.Aws;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Npgsql;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Options;
using EnrollmentPipeline.DataAccess.Connection;
using EnrollmentPipeline.Repositories;
using EnrollmentPipeline.Util;
using Amazon.Runtime.Credentials;
using EnrollmentPipeline.Logging;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.DataAccess.Commands;
using System.Text.Json;
using OpenTelemetry;

namespace EnrollmentPipeline.Extensions;

/// <summary>
/// For use with AddKeyedScoped and FromKeyed in DI to select the DB connections
/// </summary>
public enum DbConnectionType
{
	Postgres,
	SqlServer
}

public static class ServiceCollectionExtensions
{
	#region Secrets
	/// <summary>
	/// Adds multiple secret JSON files from the vault secrets directory to the configuration.
	/// </summary>
	/// <param name="builder">App builder instance</param>
	/// <param name="secretNames">
	/// Names of the secret files. For example, for /vault/secrets/my-secret, use "my-secret".
	/// </param>
	public static void AddVaultSecrets(this WebApplicationBuilder builder, params string[] secretNames)
	{
		foreach (var secretName in secretNames)
		{
			// Add vault secrets file
			builder.Configuration.AddJsonFile(
				$"/vault/secrets/{secretName}",
				optional: true, // (optional locally)
				reloadOnChange: true
			);
		}
	}
	#endregion

	#region Pipeline
	/// <summary>
	/// Configure Redis connection
	/// </summary>
	public static void AddRedis(this WebApplicationBuilder builder)
	{
		builder.Services.AddSingleton((Func<IServiceProvider, IConnectionMultiplexer>)(serviceProvider =>
		{
			var configuration = serviceProvider.GetRequiredService<IConfiguration>();

			// Priority: Environment variable -> Connection string -> Default localhost
			var connectionString = configuration.GetConnectionString("Redis");

			ArgumentNullException.ThrowIfNull(connectionString, "Redis connection string is not configured.");

			var config = ConfigurationOptions.Parse(connectionString);
			var isAws = connectionString.Contains("amazonaws.com");

			config.AbortOnConnectFail = false; // Allow retries
			config.ConnectTimeout = 10000; // 10 second timeout
			config.SyncTimeout = 10000; // 10 second sync timeout
			config.ConnectRetry = 5; // 5 retry attempts
			config.ReconnectRetryPolicy = new ExponentialRetry(1000); // Start with 1 second, exponential backoff
			config.KeepAlive = 30; // 30 second keep alive
			config.DefaultDatabase = 0;
			config.Ssl = isAws; // Only use SSL for AWS Redis/Valkey instances

			return ConnectionMultiplexer.Connect(config);
		}));

		builder.Services.AddSingleton<IStreamMessagePublisher, StreamMessagePublisher>();
	}

	/// <summary>
	/// Adds a StreamPipelineWorker as a hosted service, ensuring only one can be registered per project
	/// </summary>
	/// <typeparam name="TWorker">The StreamPipelineWorker implementation</typeparam>
	/// <param name="builder">The web application builder</param>
	/// <returns>The service collection for chaining</returns>
	public static void AddStreamPipelineWorker<TWorker>(this WebApplicationBuilder builder)
		where TWorker : StreamPipelineWorker
	{
		// Check if any StreamPipelineWorker is already registered
		var existingWorker = builder.Services.FirstOrDefault(s =>
			s.ServiceType == typeof(IHostedService) &&
			s.ImplementationType != null &&
			typeof(StreamPipelineWorker).IsAssignableFrom(s.ImplementationType));

		if (existingWorker != null)
		{
			throw new InvalidOperationException(
				$"A StreamPipelineWorker ({existingWorker.ImplementationType?.Name}) is already registered. " +
				"Only one StreamPipelineWorker per project is supported. " +
				$"Cannot register {typeof(TWorker).Name}.");
		}

		builder.Services.AddHostedService<TWorker>();
	}
	#endregion

	#region Data Sources
	/// <summary>
	/// Adds an OpenSearch client to the service collection
	/// </summary>
	/// <param name="builder">The web application builder</param>
	/// <returns>The service collection for chaining</returns>
	public static void AddOpenSearchClient(this WebApplicationBuilder builder)
	{
		builder.Services.AddSingleton<IOpenSearchClient>(_ =>
		{
			var connectionString = builder.Configuration.GetConnectionString("OpenSearch") ??
								   throw new Exception("OpenSearch connection string is not configured.");

			var pool = new SingleNodeConnectionPool(new Uri(connectionString));
			var settings = new ConnectionSettings(
				pool,
				sourceSerializer: (builtin, connectionSettings) => new JsonNetSerializer(
					builtin,
					connectionSettings,
					() => new JsonSerializerSettings
					{
						ContractResolver = new SystemTextJsonPropertyNameContractResolver(),
						NullValueHandling = NullValueHandling.Include,
						// DateTimeZoneHandling = DateTimeZoneHandling.Utc
					}
				)
			);

			return new OpenSearchClient(settings);
		});

		builder.Services.AddScoped<ICampaignRepository, CampaignRepository>();
		builder.Services.AddScoped<IContactRepository, ContactRepository>();
	}

	/// <summary>
	/// Adds a database connection factory for PostgreSQL database services with configuration from appsettings.json
	/// Expects a "Postgres" connection string (which takes priority) or an "AwsRds" section in the configuration
	/// </summary>
	/// <param name="builder">The web application builder</param>
	/// <returns>The service collection for method chaining</returns>
	public static void AddPostgresDatabase(this WebApplicationBuilder builder)
	{
		builder.AddVaultSecrets("rds");

		// Check for simple Postgres connection string first (takes priority over AWS RDS)
		var postgresConnectionString = builder.Configuration.GetConnectionString("Postgres");

		if (!string.IsNullOrEmpty(postgresConnectionString))
		{
			builder.Services.AddKeyedScoped<IDbConnection>(DbConnectionType.Postgres,
				(_, _) =>
				{
					var connectionBuilder = new NpgsqlConnectionStringBuilder(postgresConnectionString)
					{
						SslMode = SslMode.Prefer,
						CommandTimeout = 60,
						Timeout = 30,
						Pooling = true,
						MinPoolSize = 1,
						MaxPoolSize = 100,
						ConnectionIdleLifetime = 300,  // Close idle connections after 5 minutes
						ConnectionPruningInterval = 10  // Check for stale connections every 10 seconds
					};

					// Don't open here - let Dapper manage the connection lifecycle
					return new NpgsqlConnection(connectionBuilder.ToString());
				});
		}
		else
		{
			// Fall back to AWS RDS configuration
			var awsRdsConfig = builder.Configuration.GetSection("AwsRds").Get<AwsRdsConfiguration>();
			if (awsRdsConfig == null)
			{
				throw new InvalidOperationException(
					"Either a 'Postgres' connection string or 'AwsRds' configuration section must be provided in appsettings.json");
			}

			// Validate the configuration
			var validationContext = new ValidationContext(awsRdsConfig);
			var validationResults = new List<ValidationResult>();
			if (!Validator.TryValidateObject(awsRdsConfig, validationContext, validationResults, true))
			{
				var errors = string.Join(", ", validationResults.Select(vr => vr.ErrorMessage));
				throw new InvalidOperationException($"AwsRds configuration validation failed: {errors}");
			}

			// Register AWS RDS configuration
			builder.Services.AddSingleton(awsRdsConfig);

			// Register AWS credentials based on configuration
			builder.Services.AddSingleton<AWSCredentials>(provider =>
			{
				var config = provider.GetRequiredService<AwsRdsConfiguration>();
				var logger = provider.GetRequiredService<ILogger<AwsRdsConfiguration>>();

				// If profile name is specified, use it
				if (!string.IsNullOrEmpty(config.ProfileName))
				{
					logger.LogDebug("Using AWS profile: {ProfileName}", config.ProfileName);
					var chain = new CredentialProfileStoreChain();
					if (chain.TryGetAWSCredentials(config.ProfileName, out var profileCredentials))
					{
						return profileCredentials;
					}

					throw new InvalidOperationException($"AWS profile '{config.ProfileName}' not found");
				}

				// Otherwise, use default credential chain
				logger.LogDebug("Using AWS default credential chain");
				return DefaultAWSCredentialsIdentityResolver.GetCredentials();
			});

			// Register AWS RDS authentication service
			builder.Services.AddScoped<IAwsRdsAuthService, AwsRdsAuthService>();

			// Register AWS RDS database connection with IAM authentication or username/password
			builder.Services.AddKeyedScoped<IDbConnection>(DbConnectionType.Postgres, (serviceProvider, _) =>
			{
				var config = serviceProvider.GetRequiredService<AwsRdsConfiguration>();
				var logger = serviceProvider.GetRequiredService<ILogger<AwsRdsConfiguration>>();

				var connectionBuilder = new NpgsqlConnectionStringBuilder
				{
					Host = config.Hostname,
					Port = config.Port,
					Database = config.DatabaseName,
					Username = config.Username,
					SslMode = SslMode.Require,
					CommandTimeout = 60,
					Timeout = 30,
					IncludeErrorDetail = true,
					Pooling = true,
					MinPoolSize = 1,
					MaxPoolSize = 100,
					ConnectionIdleLifetime = 300,  // Close idle connections after 5 minutes
					ConnectionPruningInterval = 10  // Check for stale connections every 10 seconds
				};

				// Determine authentication method
				if (!string.IsNullOrEmpty(config.Password))
				{
					// Use username and password authentication
					logger.LogDebug("Connecting to RDS using username and password");
					connectionBuilder.Password = config.Password;
				}
				else
				{
					// Use IAM authentication with token generation
					logger.LogDebug("Connecting to RDS using IAM authentication");
					var authService = serviceProvider.GetRequiredService<IAwsRdsAuthService>();
					var accessToken = authService.GenerateAuthTokenAsync().GetAwaiter().GetResult();
					connectionBuilder.Password = accessToken;
				}

				return new NpgsqlConnection(connectionBuilder.ToString());
			});
		}

		// Get Redis connection string from appsettings.json configuration
		var redisConnectionString = builder.Configuration.GetConnectionString("Redis");

		if (!string.IsNullOrEmpty(redisConnectionString))
		{
			var isAws = redisConnectionString.Contains("amazonaws.com");

			// Register Redis as distributed cache for HybridCache
			builder.Services.AddStackExchangeRedisCache(options =>
			{
				options.InstanceName = "enrollment_pipeline_cache:";
				options.ConnectionMultiplexerFactory = async () =>
				{
					var configOptions = ConfigurationOptions.Parse(redisConnectionString);
					configOptions.AbortOnConnectFail = false;
					configOptions.ConnectTimeout = 10000;
					configOptions.SyncTimeout = 10000;
					configOptions.ConnectRetry = 5;
					configOptions.Ssl = isAws;

					return await ConnectionMultiplexer.ConnectAsync(configOptions);
				};
			});
		}

		builder.Services.AddHybridCache(options =>
		{
			options.DefaultEntryOptions = new HybridCacheEntryOptions
			{
				// Default local cache expiration
				LocalCacheExpiration = TimeSpan.FromMinutes(10),
				// Default distributed cache expiration
				Expiration = TimeSpan.FromHours(2)
			};
		});

		builder.Services.AddScoped<IEnrollmentService, EnrollmentService>();
		builder.Services.AddScoped<IPipelineService, PipelineService>();
	}

	public static void AddSqlServerDatabase(this WebApplicationBuilder builder)
	{
		builder.AddVaultSecrets("sql-server");

		builder.Services.Configure<SqlServerAuthenticationOptions>(
			builder.Configuration.GetSection("SqlServerAuthenticationOptions"));

		// Registers the SQL Server connection factory
		builder.Services.AddKeyedScoped<IDbConnection>(DbConnectionType.SqlServer, (serviceProvider, _) =>
		{
			var logger = serviceProvider.GetRequiredService<ILogger<IDbConnection>>();
			var optionsMonitor = serviceProvider.GetRequiredService<IOptionsMonitor<SqlServerAuthenticationOptions>>();
			var connectionStringBuilder =
				new SqlConnectionStringBuilder(builder.Configuration.GetConnectionString("MarketingSupport"))
				{
					Encrypt = true,
					TrustServerCertificate = true
				};

			var currentAuthValue = optionsMonitor.CurrentValue;

			if (string.IsNullOrEmpty(currentAuthValue.Username) && string.IsNullOrEmpty(currentAuthValue.Password))
			{
				logger.LogDebug("Connecting to SQL Server using Integrated Security");
				connectionStringBuilder.IntegratedSecurity = true;
			}
			else
			{
				logger.LogDebug("Connecting to SQL Server using username and password");
				connectionStringBuilder.UserID = currentAuthValue.Username;
				connectionStringBuilder.Password = currentAuthValue.Password;
				connectionStringBuilder.IntegratedSecurity = false;
			}

			return new SqlConnection(connectionStringBuilder.ToString());
		});
	}

	public static void AddDataPlaneService(this WebApplicationBuilder builder)
	{
		// Add HttpClient for DataPlaneService
		builder.Services.AddHttpClient<IDataPlaneService, DataPlaneService>(client =>
		{
			var dataPlaneUrl = builder.Configuration.GetValue<string>("Services:DataPlane");

			ArgumentNullException.ThrowIfNull(dataPlaneUrl, "Services:DataPlane is not configured.");

			client.BaseAddress = new Uri(dataPlaneUrl);
		});
	}
	#endregion

	#region Telemetry
	public static void AddOpenTelemetry(this WebApplicationBuilder builder)
	{
		const string serviceName = "enrollment-pipeline-worker";
		const string serviceVersion = "1.0.0"; // TODO: make this not hardcoded

		// Configure resource information
		var resourceBuilder = ResourceBuilder.CreateDefault()
			.AddService(serviceName, serviceVersion)
			.AddAttributes(
			[
				new KeyValuePair<string, object>("environment",
					builder.Environment.EnvironmentName),
				new KeyValuePair<string, object>("host.name",
					Environment.MachineName),
			]);

		// Configure tracing
		builder.Services.AddOpenTelemetry()
			.WithTracing(tracing =>
			{
				tracing
					.SetResourceBuilder(resourceBuilder)
					.AddSource("EnrollmentPipeline.PipelineWorker")
					.AddSource("EnrollmentPipeline.StreamPipelineWorker")
					// .AddHttpClientInstrumentation(options =>
					// {
					// 	options.FilterHttpRequestMessage = _ => true;
					// 	options.EnrichWithHttpRequestMessage = (activity, request) =>
					// 	{
					// 		activity.SetTag("http.request.method", request.Method.Method);
					// 	};
					// 	options.EnrichWithHttpResponseMessage = (activity, response) =>
					// 	{
					// 		activity.SetTag("http.response.status_code", (int)response.StatusCode);
					// 	};
					// })
					.AddRedisInstrumentation(options =>
					{
						options.SetVerboseDatabaseStatements = builder.Environment.IsLocal();
						options.EnrichActivityWithTimingEvents = true;
					});

				if (!builder.Environment.IsLocal())
				{
					tracing.AddOtlpExporter();
				}
			})
			.WithMetrics(metrics =>
			{
				metrics
					.SetResourceBuilder(resourceBuilder)
					// Support both pipeline worker types
					.AddMeter("EnrollmentPipeline.PipelineWorker")
					.AddMeter("EnrollmentPipeline.StreamPipelineWorker")
					// .AddHttpClientInstrumentation()
					.AddRuntimeInstrumentation()
					.AddProcessInstrumentation();

				if (!builder.Environment.IsLocal())
				{
					metrics.AddOtlpExporter();
				}
			});

		// Configure logging with OpenTelemetry
		builder.Logging.AddOpenTelemetry(logging =>
		{
			logging.SetResourceBuilder(resourceBuilder);
			logging.IncludeScopes = true;

			if (!builder.Environment.IsLocal())
			{
				logging.AddOtlpExporter();
			}
		});
	}

	/// <summary>
	/// Configure health checks for the enrollment pipeline
	/// </summary>
	public static void AddPipelineHealthChecks(this WebApplicationBuilder builder)
	{
		var healthChecksBuilder = builder.Services.AddHealthChecks();

		healthChecksBuilder
			.AddCheck<SystemResourceHealthCheck>(
				name: "system-resources",
				failureStatus: HealthStatus.Degraded,
				tags: ["system", "resources"]);


		// Check if there are any IHostedService of type StreamPipelineWorker
		if (builder.Services.Any(service => service.ServiceType == typeof(IHostedService)
											&& service.ImplementationType != null
											&& typeof(StreamPipelineWorker).IsAssignableFrom(
												service.ImplementationType)))
		{
			healthChecksBuilder
				.AddCheck<PipelineWorkerHealthCheck>(
					name: "pipeline-workers",
					failureStatus: HealthStatus.Degraded,
					tags: ["application", "workers"]);
		}

		// Check builder.Services to see if redis and opensearchclient have been added
		if (builder.Services.Any(service => service.ServiceType == typeof(IConnectionMultiplexer)))
		{
			healthChecksBuilder
				.AddCheck<RedisHealthCheck>(
					name: "redis",
					failureStatus: HealthStatus.Unhealthy,
					tags: ["infrastructure", "redis"]);
		}

		if (builder.Services.Any(service => service.ServiceType == typeof(IOpenSearchClient)))
		{
			healthChecksBuilder
				.AddCheck<OpenSearchHealthCheck>(
					name: "opensearch",
					failureStatus: HealthStatus.Degraded,
					tags: ["infrastructure", "opensearch"]);
		}

		var dbConnections = builder.Services
			.Where(service => service.ServiceType == typeof(IDbConnection) && service.IsKeyedService)
			.ToList();

		if (dbConnections.Any())
		{
			// Check if Postgres connection is registered
			if (dbConnections.Any(service => (DbConnectionType?)service.ServiceKey == DbConnectionType.Postgres))
			{
				healthChecksBuilder
					.AddCheck<PostgresHealthCheck>(
						name: "postgres",
						failureStatus: HealthStatus.Unhealthy,
						tags: ["infrastructure", "database", "postgres"]);
			}

			// Check if SQL Server connection is registered
			if (dbConnections.Any(service => (DbConnectionType?)service.ServiceKey == DbConnectionType.SqlServer))
			{
				healthChecksBuilder
					.AddCheck<SqlServerHealthCheck>(
						name: "sqlserver",
						failureStatus: HealthStatus.Unhealthy,
						tags: ["infrastructure", "database", "sqlserver"]);
			}
		}
	}

	/// <summary>
	/// Configure Prometheus metrics endpoint in the web application
	/// </summary>
	public static void UsePrometheusMetrics(this WebApplication app)
	{
		// Map the Prometheus metrics endpoint
		app.MapPrometheusScrapingEndpoint();
	}
	#endregion

	#region Miscellaneous
	/// <summary>
	/// Adds Query and Command Dispatcher services to the service collection
	/// </summary>
	/// <param name="builder"></param>
	public static void AddQueryAndCommandDispatcher(this WebApplicationBuilder builder)
	{
		var interfacesToConfigure = new[] { typeof(IQueryHandler<,>).Name, typeof(ICommandHandler<>).Name };

		var queriesAndCommands = AppDomain.CurrentDomain.GetAssemblies()
			.SelectMany(a => a.GetTypes())
			.Where(t => t
							.GetInterfaces()
							.Select(i => i.Name)
							.Intersect(interfacesToConfigure).Any()
						&& !t.IsAbstract
						&& !t.IsInterface
			)
			.ToList();

		foreach (var type in queriesAndCommands)
		{
			var typeInterface = type.GetInterfaces()
				.Where(i => !string.IsNullOrWhiteSpace(i.FullName))
				.OrderByDescending(i => i.Name)
				.FirstOrDefault();

			if (typeInterface != null)
			{
				builder.Services.AddScoped(typeInterface, type);
			}
		}

		builder.Services.AddScoped<IQueryDispatcher, QueryDispatcher>();
		builder.Services.AddScoped<ICommandDispatcher, CommandDispatcher>();
	}
	#endregion
}
