using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Models;

namespace EnrollmentPipeline.Extensions;

public static class WorkerResultExtensions
{
    /// <summary>
    /// Adds a status to the WorkerResult. Resets any existing status reason.
    /// </summary>
    public static WorkerResult WithStatus(this WorkerResult result, PipelineStatus status)
    {
        result.Status = status;
        // Reset status reason
        result.StatusReason = null;
        return result;
    }

    /// <summary>
    /// Adds a reason for the status in the WorkerResult. <strong>MUST</strong> be used <strong>AFTER</strong> setting a status. See <see cref="WithStatus"/>.
    /// </summary>
    public static WorkerResult WithReason(this WorkerResult result, PipelineStatusReason reason)
    {
		result.StatusReason = reason;
        return result;
    }

    /// <summary>
    /// Adds a status message to the WorkerResult.
    /// </summary>
    public static WorkerResult WithMessage(this WorkerResult result, string message)
    {
        result.Message = message;
        return result;
    }
}