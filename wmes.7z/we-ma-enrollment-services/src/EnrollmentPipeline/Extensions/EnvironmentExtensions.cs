using System.Diagnostics;
using Microsoft.Extensions.Hosting;

namespace EnrollmentPipeline.Extensions;

public static class EnvironmentExtensions
{
	public static bool IsLocal(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.IsEnvironment("local") ||
			Debugger.IsAttached;

	public static bool IsSandbox(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.IsEnvironment("sbx") ||
			Debugger.IsAttached;

	public static bool IsDvm(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.IsEnvironment("dev") ||
			hostingEnvironment.IsEnvironment("dvm") ||
			hostingEnvironment.IsEnvironment("dvr") ||
			Debugger.IsAttached;

	public static bool IsTsm(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.IsEnvironment("tst") ||
			hostingEnvironment.IsEnvironment("tsm") ||
			hostingEnvironment.IsEnvironment("tsr");

	public static bool IsPrd(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.IsEnvironment("prd");

	public static bool IsEnvironment(this IHostEnvironment hostingEnvironment, string environmentName)
		=> hostingEnvironment.SanitizedEnvironment() == environmentName ||
			hostingEnvironment.SanitizedEnvironment().StartsWith($"{environmentName}.");

	public static string SanitizedEnvironment(this IHostEnvironment hostingEnvironment)
		=> hostingEnvironment.EnvironmentName.ToLowerInvariant();
}
