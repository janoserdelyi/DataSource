using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace EnrollmentPipeline.Extensions;

public static class HealthCheckEndpointExtensions
{
    /// <summary>
    /// Maps health check endpoints with detailed responses for the enrollment pipeline
    /// </summary>
    public static WebApplication UseHealthCheckEndpoints(this WebApplication app)
    {
        // Basic health check endpoint
        app.MapHealthChecks("/health", new HealthCheckOptions
        {
            ResponseWriter = WriteHealthResponse
        });

        // Detailed health check endpoint - returns detailed information
        app.MapHealthChecks("/diag", new HealthCheckOptions
        {
            ResponseWriter = WriteDiagResponse
        });

        // Live endpoint - checks if application is alive
        app.MapHealthChecks("/ping", new HealthCheckOptions
        {
            Predicate = _ => false, // Only runs the default health check
        });

        return app;
    }

    private static async Task WriteHealthResponse(HttpContext context, HealthReport healthReport)
    {
        context.Response.ContentType = "application/json; charset=utf-8";

        var response = new
        {
            status = healthReport.Status.ToString(),
            timestamp = DateTime.UtcNow,
            duration = healthReport.TotalDuration,
            checks = healthReport.Entries.Select(entry => new
            {
                name = entry.Key,
                status = entry.Value.Status.ToString(),
                duration = entry.Value.Duration,
                description = entry.Value.Description
            })
        };

        var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals
        });

        await context.Response.WriteAsync(jsonResponse);
    }

    private static async Task WriteDiagResponse(HttpContext context, HealthReport healthReport)
    {
        context.Response.ContentType = "application/json; charset=utf-8";

        var response = new
        {
            status = healthReport.Status.ToString(),
            timestamp = DateTime.UtcNow,
            duration = healthReport.TotalDuration,
            environment = context.RequestServices.GetRequiredService<IHostEnvironment>().SanitizedEnvironment(),
            aspnetcore_environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"),
            processId = Environment.ProcessId,
            checks = healthReport.Entries.Select(entry => new
            {
                name = entry.Key,
                status = entry.Value.Status.ToString(),
                duration = entry.Value.Duration,
                description = entry.Value.Description,
                data = entry.Value.Data,
                exception = entry.Value.Exception?.Message,
                tags = entry.Value.Tags
            })
        };

        var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals
        });

        await context.Response.WriteAsync(jsonResponse);
    }
}
