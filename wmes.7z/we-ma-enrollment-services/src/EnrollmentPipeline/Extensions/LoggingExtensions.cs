using EnrollmentPipeline.Logging;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Extensions;

public static class LoggingExtensions
{
    /// <summary>
    /// Adds a custom DataDog JSON console formatter for proper log parsing.
    /// </summary>
    public static void AddDataDogJsonConsole(this ILoggingBuilder loggingBuilder)
    {
        loggingBuilder.AddConsoleFormatter<DataDogJsonConsoleFormatter, DataDogJsonConsoleFormatterOptions>(options =>
        {
            options.IncludeScopes = true;
            options.UseUtcTimestamp = false; // Include timezone offset
            options.TimestampFormat = "yyyy-MM-ddTHH:mm:ss.fffffffzzz";
        });

        // Add custom DataDog JSON console formatter for proper log parsing
        loggingBuilder.AddConsole(options =>
        {
            options.FormatterName = DataDogJsonConsoleFormatter.Name;
        });
    }
}