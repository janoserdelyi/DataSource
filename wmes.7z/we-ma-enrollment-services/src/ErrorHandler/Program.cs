using ErrorHandler;
using EnrollmentPipeline.Builder;

var app = PipelineWorkerBuilder.Create<Worker>(args);

// Run the application
await app.RunAsync();
