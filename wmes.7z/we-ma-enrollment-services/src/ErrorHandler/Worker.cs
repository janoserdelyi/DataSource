using EnrollmentPipeline;
using EnrollmentPipeline.Models;
using StackExchange.Redis;
using Microsoft.Extensions.Caching.Hybrid;
using System.Runtime.CompilerServices;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Enums;

namespace ErrorHandler;

public class Worker(
	IConnectionMultiplexer redis,
	IStreamMessagePublisher publisher,
	ILogger<Worker> logger,
	IServiceScopeFactory serviceScopeFactory,
	IConfiguration configuration,
	HybridCache hybridCache
) : StreamPipelineWorker(redis, publisher, logger, serviceScopeFactory, configuration, hybridCache)
{
	public override string WorkerName => "error-handler";
	protected override int MaxBatchSize => 5000;
	protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);

	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		var enrollmentsToLog = new List<StagedEnrollment>();
		var startTime = DateTimeOffset.UtcNow;

		foreach (var enrollment in enrollments)
		{
			WorkerResult? result = null;

			// Log the error for future database insertion
			logger.LogDebug("[{WorkerName}] Processing failed for enrollment - ContactId: {ContactId}, CampaignId: {CampaignId}, Reason: {Reason}",
				WorkerName, enrollment.ContactId, enrollment.MarketingCampaignId, enrollment.StatusReasonId.ToString());

			// Determine handling based on error reason
			switch (enrollment.StatusReasonId)
			{
				// Known non-retriable errors
				case PipelineStatusReason.InvalidEmailAddress:
				case PipelineStatusReason.MissingEmailAddress:
				case PipelineStatusReason.MissingEmailValidation:
				case PipelineStatusReason.MissingRequiredFields:
				case PipelineStatusReason.ExceededNumberOfRetries:
				case PipelineStatusReason.ContactOptedOut:
				case PipelineStatusReason.UkGovernmentEmailDomain:
				case PipelineStatusReason.DataFieldLookupFailed:
				case PipelineStatusReason.MissingCampaignMetadata:
				case PipelineStatusReason.MarketingCloudPublishFailed:
				case PipelineStatusReason.InvalidContact:
					// Just log it to the database and do not re-queue
					enrollmentsToLog.Add(enrollment);
					break;
				default:
					// For other errors, simply re-queue (from the beginning of the pipeline)
					result = ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Retrying);
					break;
			}

			if (result != null)
			{
				yield return result;
			}
		}

		// Logs all enrollments that were not re-queued
		if (enrollmentsToLog.Count > 0)
		{

			try
			{
				// This will skip recording the enrollments that are being retried and log the error message in the catch block
				ArgumentNullException.ThrowIfNull(EnrollmentService);

				await EnrollmentService.RecordProcessingFailedAsync(enrollmentsToLog, WorkerId, cancellationToken);
			}
			catch (Exception ex)
			{
				logger.LogError(ex, "[{WorkerName}] Failed to log {Count} failed enrollments.", WorkerName, enrollmentsToLog.Count);

				// TODO: Decide if the following is really the best approach for handling logging failures. We don't want the enrollment to get lost.
				// If it fails to log, we can't do much more than just send it back to the beginning of the pipeline for retry.
			}

			foreach (var enrollment in enrollmentsToLog)
			{
				// Produce result indicating completion after logging (this will be the end of the pipeline for these enrollments)
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Completed)
					.WithMessage("Enrollment processing failed and was logged by error-handler.");
			}
		}
	}
}
