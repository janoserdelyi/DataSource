using System.Text.Json.Serialization;

namespace MarketingCloudPublisher.Models;

/// <summary>
/// Model representing Salesforce Marketing Cloud credentials retrieved from Redis cache or AWS Secrets Manager.
/// </summary>
public class MarketingCloudCredential
{
	[JsonPropertyName("account_id")]
    public string AccountId { get; set; } = string.Empty;
    [JsonPropertyName("account_name")]
    public string AccountName { get; set; } = string.Empty;
    [JsonPropertyName("client_id")]
    public string ClientId { get; set; } = string.Empty;
    [JsonPropertyName("client_secret")]
    public string ClientSecret { get; set; } = string.Empty;
    [JsonPropertyName("subdomain")]
    public string Subdomain { get; set; } = string.Empty;
	[JsonPropertyName("grant_type")]
    public string GrantType { get; set; } = string.Empty;
    [JsonPropertyName("source_application_extension_id")]
    public string SourceApplicationExtensionId { get; set; } = string.Empty;
}
