namespace MarketingCloudPublisher.Models;

/// <summary>
/// Result of a Marketing Cloud Data Extension publish operation
/// </summary>
public class MarketingCloudPublishResult
{
    /// <summary>
    /// Indicates whether the publish operation was successful
    /// </summary>
    public bool Success { get; set; }

    /// <summary>
    /// Number of enrollments successfully published
    /// </summary>
    public int PublishedCount { get; set; }

    /// <summary>
    /// Error message if the operation failed
    /// </summary>
    public string? ErrorMessage { get; set; }
}
