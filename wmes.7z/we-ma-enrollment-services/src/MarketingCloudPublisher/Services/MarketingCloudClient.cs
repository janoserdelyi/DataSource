using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MarketingCloudApi;
using MarketingCloudApi.Enums;
using MarketingCloudPublisher.Extensions;
using MarketingCloudPublisher.Models;
using Microsoft.Extensions.Caching.Memory;
using StackExchange.Redis;

namespace MarketingCloudPublisher.Services;

public interface IMarketingCloudClient
{
	/// <summary>
	/// Upserts data into a Marketing Cloud Data Extension.
	/// </summary>
	/// <param name="accountId">Marketing Cloud Account ID</param>
	/// <param name="dataExtensionId">Marketing Cloud Data Extension ID</param>
	/// <param name="keyFieldName">Key field name for the data extension</param>
	/// <param name="uploadObjects">List of objects to upload. Each object is a dictionary of string key-value pairs for all the data fields for each contact.</param>
	/// <returns><see cref="DataExtensionInsertUpdateResponse"/></returns>
	Task<DataExtensionInsertUpdateResponse> UpsertData(string accountId, string dataExtensionId, string keyFieldName, List<Dictionary<string, string?>> uploadObjects);
}

public class MarketingCloudClient(
	[FromKeyedServices(ServiceKeys.ValkeyCache)] IConnectionMultiplexer valkey,
	ILogger<IMarketingCloudClient> logger,
	IConfiguration configuration,
	IMemoryCache memoryCache
) : IMarketingCloudClient
{
	private const string CacheKeyPrefix = "mc_client_";
	private static readonly TimeSpan CacheSlidingExpiration = TimeSpan.FromHours(1);

	public async Task<DataExtensionInsertUpdateResponse> UpsertData(
		string accountId
		, string dataExtensionId
		, string keyFieldName
		, List<Dictionary<string, string?>> uploadObjects
	)
	{
		// Ensure that keyFieldName exists in all uploadObjects
		if (uploadObjects.Any(obj => !obj.ContainsKey(keyFieldName)))
		{
			// Fail individual upload objects if they are missing the key field
			throw new ArgumentException($"Upload object is missing required key field: {keyFieldName}");
		}

		var stopwatch = Stopwatch.StartNew();

		logger.LogDebug($"[{nameof(UpsertData)}] - Starting to Add Data - {stopwatch.Elapsed}");

		var marketingCloud = await GetAuthedClient(accountId);

		logger.LogDebug($"[{nameof(UpsertData)}] - Got Authed Client - {stopwatch.Elapsed}");

		// Retrieves the Data Extension by its ID
		var dataExtension = await marketingCloud
			.DataExtension()
			.Get(DataExtensionSelectField.ObjectId, dataExtensionId);

		logger.LogDebug($"[{nameof(UpsertData)}] - Got Data Extension - {stopwatch.Elapsed}");

		// Checks if the Data Extension exists and has a CustomerKey
		if (string.IsNullOrWhiteSpace(dataExtension?.CustomerKey))
		{
			throw new KeyNotFoundException("Data Extension not found.");
		}

		// Upserts the data into the Data Extension
		var result = await marketingCloud.DataExtension().UpsertData(
			dataExtension.CustomerKey,
			keyFieldName,
			uploadObjects
		);

		logger.LogDebug($"[{nameof(UpsertData)}] - Added Data Chunked - {stopwatch.Elapsed}");

		// Checks if it's an invalid response
		if (result == null || (result.Errors.Count == 0 && result.Oks.Count == 0))
		{
			// Something went wrong if there are no errors and no successful inserts/updates
			throw new Exception("Adding data to Data Extension failed");
		}

		return result;
	}

	private async Task<MarketingCloud> GetAuthedClient(string accountId)
	{
		var cacheKey = $"{CacheKeyPrefix}{accountId}";

		var client = await memoryCache.GetOrCreateAsync(cacheKey, async entry =>
		{
			logger.LogDebug($"[{nameof(GetAuthedClient)}] - Creating new MarketingCloud client for AccountId: {accountId}");

            // Configures cache entry options
            entry.SlidingExpiration = CacheSlidingExpiration;
			entry.Priority = CacheItemPriority.High;

			try
			{
                // Retrieves account credentials
                var accountCredentials = await GetAccountCredentialsById(accountId);

				var credentials = new AuthParams(
					accountId,
					accountCredentials.Subdomain,
					$"https://{accountCredentials.Subdomain}.auth.marketingcloudapis.com",
					accountCredentials.ClientId,
					accountCredentials.ClientSecret,
					accountCredentials.GrantType
				);

                // Creates and returns the new MarketingCloud client
                return new MarketingCloud(credentials);
			}
			catch (Exception ex)
			{
				logger.LogError(ex, $"[{nameof(GetAuthedClient)}] - Failed to create MarketingCloud client for AccountId: {accountId}");
				throw;
			}
		});

		ArgumentNullException.ThrowIfNull(client, $"Failed to get or create MarketingCloud client for account ID: {accountId}");

		return client;
	}

	private async Task<MarketingCloudCredential> GetAccountCredentialsById(string accountId)
	{
		var allCreds = await GetAllMarketingCloudAccountCredentials();
		var accountCredentials = allCreds.Find(cred => cred.AccountId == accountId);

		var logPrefix = $"{nameof(GetAccountCredentialsById)} - AccountId: {accountId}";

		if (accountCredentials == null)
		{
			throw new Exception($"{logPrefix} - credentials not found");
		}

		if (string.IsNullOrEmpty(accountCredentials.Subdomain))
		{
			throw new Exception($"{logPrefix} - missing Subdomain");
		}

		if (string.IsNullOrEmpty(accountCredentials.ClientId))
		{
			throw new Exception($"{logPrefix} - missing Client Id");
		}

		if (string.IsNullOrEmpty(accountCredentials.ClientSecret))
		{
			throw new Exception($"{logPrefix} - missing Client Secret");
		}

		if (string.IsNullOrEmpty(accountCredentials.GrantType))
		{
			throw new Exception($"{logPrefix} - missing Grant Type");
		}

		return accountCredentials;
	}

	private async Task<List<MarketingCloudCredential>> GetAllMarketingCloudAccountCredentials()
	{
		var secretKeyName = configuration.GetSection("MarketingCloud")["SecretKeyName"];

		ArgumentNullException.ThrowIfNull(secretKeyName);

		var encryptedSecret = await valkey.GetDatabase().StringGetAsync(secretKeyName);
		if (encryptedSecret.IsNullOrEmpty)
		{
			throw new Exception("Marketing Cloud secret not found in Valkey cache");
		}

		var secrets = DecryptSecret(encryptedSecret!.ToString());
		var accountSecretsModel = JsonSerializer.Deserialize<List<MarketingCloudCredential>>(secrets);

		ArgumentNullException.ThrowIfNull(accountSecretsModel);

		return accountSecretsModel;
	}

	private string DecryptSecret(string encryptedText)
	{
		var encryptionKey = configuration.GetSection("MarketingCloud")["EncryptionKey"];
		ArgumentNullException.ThrowIfNull(encryptionKey);
		var encryptionKeyBytes = Encoding.UTF8.GetBytes(encryptionKey);

		var encryptedTextBytes = Convert.FromBase64String (encryptedText);
		var iv = new byte[16];
		var cipher = new byte[encryptedTextBytes.Length - iv.Length];
		Buffer.BlockCopy(encryptedTextBytes, 0, iv, 0, iv.Length);
		Buffer.BlockCopy(encryptedTextBytes, iv.Length, cipher, 0, cipher.Length);

		using var aesAlgorithm = Aes.Create();
		using var decrypter = aesAlgorithm.CreateDecryptor(encryptionKeyBytes, iv);
		using var msDecrypt = new MemoryStream (cipher);
		using var csDecrypt = new CryptoStream (msDecrypt, decrypter, CryptoStreamMode.Read);
		using var srDecrypt = new StreamReader (csDecrypt);

		return srDecrypt.ReadToEnd();
	}
}
