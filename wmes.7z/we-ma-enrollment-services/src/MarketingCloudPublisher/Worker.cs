using System.Runtime.CompilerServices;
using EnrollmentPipeline;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Repositories;
using MarketingCloudApi;
using MarketingCloudPublisher.Services;
using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;

namespace MarketingCloudPublisher;

/// <summary>
/// Implementation of StreamPipelineWorker for publishing enrollments to Salesforce Marketing Cloud
/// This is the final step in the enrollment pipeline - publishes validated enrollments to Data Extensions
/// Uses Redis Streams for automatic load balancing and guaranteed delivery
/// </summary>
public class Worker(
	IConnectionMultiplexer redis,
	IStreamMessagePublisher publisher,
	ILogger<Worker> logger,
	IServiceScopeFactory scopeFactory,
	IConfiguration configuration,
	HybridCache hybridCache
	) : StreamPipelineWorker(redis, publisher, logger, scopeFactory, configuration, hybridCache)
{
	public override string WorkerName => "marketing-cloud-publisher";
	protected override int MaxBatchSize => 5000;
	protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);
	private readonly IServiceScopeFactory _scopeFactory = scopeFactory;

	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		var startTime = DateTimeOffset.UtcNow;

		using var scope = _scopeFactory.CreateScope();

		var client = scope.ServiceProvider.GetRequiredService<IMarketingCloudClient>();
		var campaignRepository = scope.ServiceProvider.GetRequiredService<ICampaignRepository>();

		// Group enrollments by campaign
		var groupedEnrollments = enrollments
            // Just in case there are duplicate enrollments, we only want to process each unique enrollment once
            .DistinctBy(enrollment => enrollment.Id)
			.GroupBy(e => e.MarketingCampaignId);

		foreach (var campaignGroup in groupedEnrollments)
		{
			cancellationToken.ThrowIfCancellationRequested();

			var campaign = await campaignRepository.GetCampaignByIdAsync(campaignGroup.Key);

			// Fail all enrollments if campaign metadata is missing
			if (campaign?.DataExtensionId == null || campaign.MarketingCloudAccountId == null)
			{
				foreach (var enrollment in campaignGroup)
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Failed)
						.WithReason(PipelineStatusReason.MissingCampaignMetadata)
						.WithMessage($"Missing campaign metadata for Campaign ID {campaignGroup.Key}");
				}
				// Skips to next campaign group
				continue;
			}

			// List representing each contact's data as a dictionary
			var campaignContacts = campaignGroup
				.Select(enrollment => enrollment.DataFields.ToDictionary(field => field.Key, field => field.Value?.ToString()))
				.ToList();

			DataExtensionInsertUpdateResponse? result = null;

			try
			{
				// Publish batch to Marketing Cloud Data Extension
				result = await client.UpsertData(campaign.MarketingCloudAccountId?.ToString()!,
					campaign.DataExtensionId, "ContactID", campaignContacts);
			}
			catch (Exception ex)
			{
				// TODO: Handle a failed call to MarketingCloud in a better way?
				logger.LogError(ex, "Error publishing {Contacts} contacts to Marketing Cloud for Campaign ID {CampaignId}", campaignGroup.Count(), campaignGroup.Key);
			}

			// If result is null, fail all enrollments in the group
			if (result == null)
			{
				foreach (var enrollment in campaignGroup)
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Failed)
						.WithReason(PipelineStatusReason.MarketingCloudPublishFailed)
						.WithMessage($"Failed to publish to Marketing Cloud for Campaign ID {campaignGroup.Key}");
				}
				// Skips to next campaign group
				continue;
			}

			foreach (var error in result.Errors)
			{
				var enrollment = campaignGroup.First(e => e.ContactId.ToString() == error.Key);

				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Failed)
					.WithReason(PipelineStatusReason.MarketingCloudPublishFailed)
					.WithMessage($"Failed to publish to Marketing Cloud: {error.Value.ErrorMessage}");
			}

			foreach (var ok in result.Oks)
			{
				var enrollment = campaignGroup.First(e => e.ContactId.ToString() == ok.Key);

				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Success);
			}
		}
	}
}
