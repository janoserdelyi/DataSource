﻿using StackExchange.Redis;

namespace MarketingCloudPublisher.Extensions;

public enum ServiceKeys
{
	ValkeyCache,
}

public static class ServiceCollectionExtensions
{
	public static void AddValkeyCache(this WebApplicationBuilder builder)
	{
		builder.Services.AddKeyedSingleton<IConnectionMultiplexer>(
			ServiceKeys.ValkeyCache,
			(serviceProvider, _) =>
			{
				var config = serviceProvider.GetRequiredService<IConfiguration>();
				var connectionString = config.GetConnectionString("ValkeyCache");

				ArgumentNullException.ThrowIfNull(connectionString, "ValkeyCache connection string is not configured.");

				var isAWS = connectionString.Contains("amazonaws.com");

				var configuration = ConfigurationOptions.Parse(connectionString);
				configuration.AbortOnConnectFail = false;
				configuration.ConnectTimeout = 5000;
				configuration.DefaultDatabase = 0;
				configuration.Ssl = isAWS; // Only use SSL for AWS instances

				return ConnectionMultiplexer.Connect(configuration);
			});
	}
}
