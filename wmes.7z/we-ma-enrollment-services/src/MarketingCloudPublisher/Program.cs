using EnrollmentPipeline.Extensions;
using MarketingCloudPublisher;
using MarketingCloudPublisher.Extensions;
using MarketingCloudPublisher.Services;
using EnrollmentPipeline.Builder;

var app = PipelineWorkerBuilder.Create<Worker>(
	args,
	builder =>
	{
        // Add required vault secrets
        builder.AddVaultSecrets("encryption-key");
        // Add memory cache for MarketingCloud client caching
        builder.Services.AddMemoryCache();
        // Add Valkey Redis cache connection
        builder.AddValkeyCache();
        // Add OpenSearch Client
        builder.AddOpenSearchClient();
        // Register MarketingCloud client as singleton (it manages its own caching via IMemoryCache)
        builder.Services.AddSingleton<IMarketingCloudClient, MarketingCloudClient>();
	}
);

// Run the application
await app.RunAsync();
