using System.Text.Json.Serialization;

namespace EmailValidationCheck.Models;

/// <summary>
/// Request to create a list of emails for bulk validation
/// </summary>
public class InternalEmailValidationListCreationRequest
{
    /// <summary>
    /// Array of email addresses to validate
    /// </summary>
    [JsonPropertyName("emailAddresses")]
    public required string[]? EmailAddresses { get; set; }
}

/// <summary>
/// Response when creating a list for bulk email validation
/// </summary>
public class InternalEmailValidationListCreationResponse
{
    /// <summary>
    /// The unique identifier for the created validation list
    /// </summary>
    [JsonPropertyName("listID")]
    public string? ListID { get; set; }

    /// <summary>
    /// Number of email addresses in the list
    /// </summary>
    [JsonPropertyName("emailCount")]
    public int EmailCount { get; set; }
}