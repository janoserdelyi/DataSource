using System.Text.Json.Serialization;

namespace EmailValidationCheck.Models;

/// <summary>
/// Result of bulk email validation list processing
/// </summary>
public class EmailValidationListResult
{
    /// <summary>
    /// The unique identifier of the validation list
    /// </summary>
    [JsonPropertyName("listId")]
    public string? ListId { get; set; }

    /// <summary>
    /// Indicates if the validation process has completed
    /// </summary>
    [JsonPropertyName("isCompleted")]
    public bool IsCompleted { get; set; }

    /// <summary>
    /// Total number of emails in the list (read-only)
    /// </summary>
    [JsonPropertyName("emailCount")]
    public int EmailCount { get; set; }

    /// <summary>
    /// Array of individual email validation results
    /// </summary>
    [JsonPropertyName("results")]
    public EmailValidationResult[]? Results { get; set; }

    /// <summary>
    /// Overall status of the validation list
    /// </summary>
    [JsonPropertyName("status")]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public EmailValidationStatus Status { get; set; }
}