using System.Text.Json.Serialization;

namespace EmailValidationCheck.Models;

/// <summary>
/// Result of validating a single email address
/// </summary>
public class EmailValidationResult
{
    /// <summary>
    /// The email address that was validated
    /// </summary>
    public string? EmailAddress { get; set; }
    /// <summary>
    /// The validation status of the email
    /// </summary>
    public EmailValidationStatus Status { get; set; }
    /// <summary>
    /// The date and time when the email was last validated.
    /// </summary>
    public DateTimeOffset LastValidatedDate { get; set; }
    /// <summary>
    /// Additional status reason information
    /// </summary>
    public string? StatusReason { get; set; }
    /// <summary>
    /// Indicates whether emails should be sent to this address
    /// </summary>
    public bool ShouldSendEmail { get; set; }
    /// <summary>
    /// Indicates whether the email should be revalidated on the next check
    /// </summary>
    public bool ShouldRevalidate { get; set; }

}