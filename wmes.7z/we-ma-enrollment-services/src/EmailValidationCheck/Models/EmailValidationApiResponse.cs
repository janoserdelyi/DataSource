using System.Text.Json.Serialization;

namespace EmailValidationCheck.Models;

/// <summary>
/// Generic API response wrapper used by the email validation API
/// </summary>
/// <typeparam name="T">The type of the result data</typeparam>
public class EmailValidationApiResponse<T>
{
    /// <summary>
    /// Indicates if the operation was successful
    /// </summary>
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    /// <summary>
    /// Error code if operation failed
    /// </summary>
    [JsonPropertyName("errorCode")]
    public string? ErrorCode { get; set; }

    /// <summary>
    /// Error message if operation failed
    /// </summary>
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    /// <summary>
    /// The result data if operation was successful
    /// </summary>
    [JsonPropertyName("result")]
    public T? Result { get; set; }
}

/// <summary>
/// Email validation status enumeration
/// </summary>
public enum EmailValidationStatus
{
    not_processed = 0,
    pending = 1,
    valid = 2,
    invalid = 3,
    accept_all = 4,
    unknown = 5,
    email_address_invalid = 6,
    email_domain_invalid = 7,
    email_account_invalid = 8,
    mailbox_full = 9,
    disposable = 10,
    role_address = 11,
    open = 12,
    verifying = 13,
    complete = 14,
    terminated = 15,
    error = 16,
    timeout = 17,
    unable_to_verify = 18,
    failed_local_validation = 19
}