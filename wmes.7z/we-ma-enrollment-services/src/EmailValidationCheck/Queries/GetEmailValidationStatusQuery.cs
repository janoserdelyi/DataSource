using System.Data;
using Dapper;
using EmailValidationCheck.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace EmailValidationCheck.Queries;

public class GetEmailValidationStatusQuery
{
    // List of email addresses to check (uses HashSet to avoid duplicates)
    public required HashSet<string> EmailAddresses { get; set; }
}

public class GetEmailValidationStatusQueryResult
{
    public required IEnumerable<EmailValidationResult> ValidationResults { get; set; }
}

public class GetEmailValidationStatusQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetEmailValidationStatusQueryHandler> logger
) : QueryHandler<GetEmailValidationStatusQuery, GetEmailValidationStatusQueryResult>(logger)
{
    protected override async Task<GetEmailValidationStatusQueryResult> Handle(GetEmailValidationStatusQuery query)
    {
        var emails = new DataTable();

        emails.Columns.Add("value", typeof(string));

        // Populate table with email addresses
        foreach (var email in query.EmailAddresses)
        {
            emails.Rows.Add(email);
        }

        var parameters = new DynamicParameters();
        parameters.Add("pContacts", emails.AsTableValuedParameter("StringList"));

        var results = await connection.QueryAsync<EmailValidationResult>(
                "[platform].[uspGetEmailsVerified]", parameters,
                commandType: CommandType.StoredProcedure).ConfigureAwait(false);

        return new GetEmailValidationStatusQueryResult
        {
            ValidationResults = results
        };
    }
}
