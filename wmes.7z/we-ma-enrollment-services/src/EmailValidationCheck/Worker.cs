using System.Runtime.CompilerServices;
using EnrollmentPipeline;
using StackExchange.Redis;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Caching.Hybrid;
using EmailValidationCheck.Services;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Enums;

namespace EmailValidationCheck;

/// <summary>
/// Implementation of StreamPipelineWorker for email validation processing
/// Validates email addresses and contact data before enrollment
/// Uses Redis Streams for automatic load balancing and guaranteed delivery
/// </summary>
public class Worker(
	IConnectionMultiplexer redis,
	IStreamMessagePublisher publisher,
	ILogger<Worker> logger,
	IServiceScopeFactory scopeFactory,
	IConfiguration configuration,
	HybridCache hybridCache)
	: StreamPipelineWorker(redis, publisher, logger, scopeFactory, configuration, hybridCache)
{
	private readonly IServiceScopeFactory _scopeFactory = scopeFactory;
	public override string WorkerName => "email-validation-check";
	protected override int MaxBatchSize => 5000;
	protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);

	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		using var scope = _scopeFactory.CreateScope();

		var emailValidationService = scope.ServiceProvider.GetRequiredService<IEmailValidationService>();

		var startTime = DateTimeOffset.UtcNow;
		var batch = new Dictionary<string, HashSet<StagedEnrollment>>();

		foreach (var enrollment in enrollments)
		{
			cancellationToken.ThrowIfCancellationRequested();

			var email = enrollment.GetEmailAddress();

			if (email == null)
			{
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Failed)
					.WithReason(PipelineStatusReason.MissingEmailAddress)
					.WithMessage($"Missing EmailAddress");
			}
			else
			{
				if (!batch.ContainsKey(email))
				{
					batch[email] = new HashSet<StagedEnrollment>();
				}
				batch[email].Add(enrollment);
			}
		}

		if (batch.Count == 0)
		{
			yield break; // No valid emails to process
		}

		// Use email validation service to query validation statuses
		var validationResults = await emailValidationService.GetEmailValidationStatus(batch.Keys, cancellationToken);

		// Process validation results
		foreach (var result in validationResults)
		{
			if (batch.TryGetValue(result.EmailAddress!, out var enrollmentsWithEmailAddress))
			{
				foreach (var enrollment in enrollmentsWithEmailAddress)
				{
					if (result.ShouldSendEmail)
					{
						yield return ProduceResult(enrollment, startTime)
							.WithStatus(PipelineStatus.Success);
					}
					else
					{
						yield return ProduceResult(enrollment, startTime)
							.WithStatus(PipelineStatus.Failed)
							.WithReason(PipelineStatusReason.InvalidEmailAddress)
							.WithMessage($"Invalid email address: [Status: {result.Status}] {result.StatusReason}");
					}
				}

				// Remove processed enrollments from batch (using email as key)
				batch.Remove(result.EmailAddress!);
			}
			else
			{
				// Log warning for unexpected email address in results (mismatched data)
				logger.LogWarning(
					"[{MethodName}] Received validation result for unknown email address: {EmailAddress}",
					nameof(ProcessBatch),
					result.EmailAddress);
			}
		}

		// Handle any emails that did not receive a validation result
		foreach (var remainingEmail in batch.Keys)
		{
			var enrollmentsWithEmailAddress = batch[remainingEmail];

			foreach (var enrollment in enrollmentsWithEmailAddress)
			{
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Failed)
					.WithReason(PipelineStatusReason.MissingEmailValidation)
					.WithMessage("No validation result found for email address.");
			}
		}
	}
}
