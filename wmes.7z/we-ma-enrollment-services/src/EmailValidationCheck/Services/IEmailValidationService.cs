using EmailValidationCheck.Models;

namespace EmailValidationCheck.Services;

/// <summary>
/// Service for validating email addresses using external API
/// </summary>
public interface IEmailValidationService
{
    /// <summary>
    /// Gets the email validation status for a list of email addresses from the database.
    /// </summary>
    /// <param name="emails"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    Task<IEnumerable<EmailValidationResult>> GetEmailValidationStatus(
        IEnumerable<string> emails, 
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Validates a single email address
    /// </summary>
    /// <param name="email">Email address to validate</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Email validation result</returns>
    Task<EmailValidationApiResponse<EmailValidationResult>> ValidateSingleEmailAsync(string email, CancellationToken cancellationToken = default);

    /// <summary>
    /// Creates a list of emails for bulk validation
    /// </summary>
    /// <param name="request">List creation request with email addresses</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>List creation response with list ID</returns>
    Task<EmailValidationApiResponse<InternalEmailValidationListCreationResponse>> CreateEmailValidationListAsync(
        InternalEmailValidationListCreationRequest request, 
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the validation results for a previously created list
    /// </summary>
    /// <param name="listId">List ID returned from create list operation</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>List validation results</returns>
    Task<EmailValidationApiResponse<EmailValidationListResult>> GetListValidationResultAsync(
        Guid listId, 
        CancellationToken cancellationToken = default);
}