using System.Text;
using System.Text.Json;
using EmailValidationCheck.Models;
using EmailValidationCheck.Queries;
using EnrollmentPipeline.DataAccess.Queries;

namespace EmailValidationCheck.Services;

/// <summary>
/// Service implementation for validating email addresses using external API
/// </summary>
public class EmailValidationService(
    HttpClient httpClient, 
    IQueryDispatcher queryDispatcher, 
    ILogger<EmailValidationService> logger
) : IEmailValidationService
{
    private readonly JsonSerializerOptions _jsonOptions = new()
	{
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };

	public async Task<IEnumerable<EmailValidationResult>> GetEmailValidationStatus(IEnumerable<string> emails, CancellationToken cancellationToken = default)
    {
        // TODO: Bulk fetch email validation statuses from OpenSearch to optimize performance
        // TODO: Add caching layer to reduce number of lookups
        
        // Queries database for email validation status
        var result = await queryDispatcher.Dispatch<GetEmailValidationStatusQuery, GetEmailValidationStatusQueryResult>(
            new GetEmailValidationStatusQuery
            {
                EmailAddresses = [.. emails]
			}, cancellationToken);

        return result.ValidationResults;
    }

    /// <inheritdoc />
    public async Task<EmailValidationApiResponse<EmailValidationResult>> ValidateSingleEmailAsync(
        string email, 
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            throw new ArgumentException("Email address cannot be null or empty.", nameof(email));
        }

        try
        {
            logger.LogInformation("Validating single email address: {Email}", email);

            var encodedEmail = Uri.EscapeDataString(email);
            var requestUri = $"/email-validation/single?email={encodedEmail}";

            var response = await httpClient.GetAsync(requestUri, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync(cancellationToken);
                var result = JsonSerializer.Deserialize<EmailValidationApiResponse<EmailValidationResult>>(content, _jsonOptions);
                
                logger.LogInformation("Successfully validated email {Email} with status {Status}", 
                    email, result?.Result?.Status);
                
                return result ?? new EmailValidationApiResponse<EmailValidationResult>
                {
                    Success = false,
                    Message = "Failed to deserialize response"
                };
            }

            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            logger.LogWarning("Email validation failed for {Email}. Status: {StatusCode}, Content: {Content}", 
                email, response.StatusCode, errorContent);

            return new EmailValidationApiResponse<EmailValidationResult>
            {
                Success = false,
                Message = $"HTTP {response.StatusCode}: {response.ReasonPhrase}",
                ErrorCode = response.StatusCode.ToString()
            };
        }
        catch (HttpRequestException ex)
        {
            logger.LogError(ex, "HTTP request failed while validating email {Email}", email);
            return new EmailValidationApiResponse<EmailValidationResult>
            {
                Success = false,
                Message = $"HTTP request failed: {ex.Message}",
                ErrorCode = "HttpRequestException"
            };
        }
        catch (TaskCanceledException ex) when (ex.CancellationToken.IsCancellationRequested)
        {
            logger.LogWarning("Email validation request was cancelled for {Email}", email);
            return new EmailValidationApiResponse<EmailValidationResult>
            {
                Success = false,
                Message = "Request was cancelled",
                ErrorCode = "RequestCancelled"
            };
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error while validating email {Email}", email);
            return new EmailValidationApiResponse<EmailValidationResult>
            {
                Success = false,
                Message = $"Unexpected error: {ex.Message}",
                ErrorCode = "UnexpectedError"
            };
        }
    }

    /// <inheritdoc />
    public async Task<EmailValidationApiResponse<InternalEmailValidationListCreationResponse>> CreateEmailValidationListAsync(
        InternalEmailValidationListCreationRequest request, 
        CancellationToken cancellationToken = default)
    {
        if (request?.EmailAddresses == null || !request.EmailAddresses.Any())
        {
            throw new ArgumentException("Email addresses list cannot be null or empty.", nameof(request));
        }

        try
        {
            logger.LogInformation("Creating email validation list with {Count} emails", request.EmailAddresses.Length);

            var jsonContent = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            var response = await httpClient.PostAsync("/email-validation/create-list", content, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
                var result = JsonSerializer.Deserialize<EmailValidationApiResponse<InternalEmailValidationListCreationResponse>>(responseContent, _jsonOptions);
                
                logger.LogInformation("Successfully created email validation list with ID {ListId} containing {Count} emails", 
                    result?.Result?.ListID, result?.Result?.EmailCount);
                
                return result ?? new EmailValidationApiResponse<InternalEmailValidationListCreationResponse>
                {
                    Success = false,
                    Message = "Failed to deserialize response"
                };
            }

            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            logger.LogWarning("Email validation list creation failed. Status: {StatusCode}, Content: {Content}", 
                response.StatusCode, errorContent);

            return new EmailValidationApiResponse<InternalEmailValidationListCreationResponse>
            {
                Success = false,
                Message = $"HTTP {response.StatusCode}: {response.ReasonPhrase}",
                ErrorCode = response.StatusCode.ToString()
            };
        }
        catch (HttpRequestException ex)
        {
            logger.LogError(ex, "HTTP request failed while creating email validation list");
            return new EmailValidationApiResponse<InternalEmailValidationListCreationResponse>
            {
                Success = false,
                Message = $"HTTP request failed: {ex.Message}",
                ErrorCode = "HttpRequestException"
            };
        }
        catch (TaskCanceledException ex) when (ex.CancellationToken.IsCancellationRequested)
        {
            logger.LogWarning("Email validation list creation request was cancelled");
            return new EmailValidationApiResponse<InternalEmailValidationListCreationResponse>
            {
                Success = false,
                Message = "Request was cancelled",
                ErrorCode = "RequestCancelled"
            };
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error while creating email validation list");
            return new EmailValidationApiResponse<InternalEmailValidationListCreationResponse>
            {
                Success = false,
                Message = $"Unexpected error: {ex.Message}",
                ErrorCode = "UnexpectedError"
            };
        }
    }

    /// <inheritdoc />
    public async Task<EmailValidationApiResponse<EmailValidationListResult>> GetListValidationResultAsync(
        Guid listId, 
        CancellationToken cancellationToken = default)
    {
        if (listId == Guid.Empty)
        {
            throw new ArgumentException("List ID cannot be empty.", nameof(listId));
        }

        try
        {
            logger.LogInformation("Getting validation results for list {ListId}", listId);

            var requestUri = $"/email-validation/get-list-result?listId={listId}";

            var response = await httpClient.GetAsync(requestUri, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync(cancellationToken);
                var result = JsonSerializer.Deserialize<EmailValidationApiResponse<EmailValidationListResult>>(content, _jsonOptions);
                
                logger.LogInformation("Successfully retrieved validation results for list {ListId}. Completed: {IsCompleted}, Email count: {EmailCount}", 
                    listId, result?.Result?.IsCompleted, result?.Result?.EmailCount);
                
                return result ?? new EmailValidationApiResponse<EmailValidationListResult>
                {
                    Success = false,
                    Message = "Failed to deserialize response"
                };
            }

            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            logger.LogWarning("Failed to get validation results for list {ListId}. Status: {StatusCode}, Content: {Content}", 
                listId, response.StatusCode, errorContent);

            return new EmailValidationApiResponse<EmailValidationListResult>
            {
                Success = false,
                Message = $"HTTP {response.StatusCode}: {response.ReasonPhrase}",
                ErrorCode = response.StatusCode.ToString()
            };
        }
        catch (HttpRequestException ex)
        {
            logger.LogError(ex, "HTTP request failed while getting validation results for list {ListId}", listId);
            return new EmailValidationApiResponse<EmailValidationListResult>
            {
                Success = false,
                Message = $"HTTP request failed: {ex.Message}",
                ErrorCode = "HttpRequestException"
            };
        }
        catch (TaskCanceledException ex) when (ex.CancellationToken.IsCancellationRequested)
        {
            logger.LogWarning("Get validation results request was cancelled for list {ListId}", listId);
            return new EmailValidationApiResponse<EmailValidationListResult>
            {
                Success = false,
                Message = "Request was cancelled",
                ErrorCode = "RequestCancelled"
            };
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error while getting validation results for list {ListId}", listId);
            return new EmailValidationApiResponse<EmailValidationListResult>
            {
                Success = false,
                Message = $"Unexpected error: {ex.Message}",
                ErrorCode = "UnexpectedError"
            };
        }
    }
}