using EnrollmentPipeline.Extensions;
using EmailValidationCheck;
using EmailValidationCheck.Services;
using EnrollmentPipeline.Builder;

var app = PipelineWorkerBuilder.Create<Worker>(
	args,
	builder =>
	{
        // Add SQL Server database integration
        builder.AddSqlServerDatabase();
        // Add Query and Command Dispatcher
        builder.AddQueryAndCommandDispatcher();

        // Configure EmailValidationService HTTP client
        var emailValidationApiBaseUrl = builder.Configuration.GetValue<string>("Services:EmailValidationApi")
			?? throw new InvalidOperationException("EmailValidationApi base URL is not configured in appsettings.json");

		builder.Services.AddHttpClient<IEmailValidationService, EmailValidationService>(client =>
		{
			client.BaseAddress = new Uri(emailValidationApiBaseUrl);
			client.DefaultRequestHeaders.Add("User-Agent", "EmailValidation/1.0");
			client.Timeout = TimeSpan.FromMinutes(5); // Allow longer timeout for bulk operations
        });

        // Register the EmailValidationService
        builder.Services.AddScoped<IEmailValidationService, EmailValidationService>();
	}
);

// Run the application
await app.RunAsync();
