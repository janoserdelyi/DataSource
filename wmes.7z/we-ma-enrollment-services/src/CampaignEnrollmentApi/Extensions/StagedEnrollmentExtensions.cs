using EnrollmentPipeline.Models;
using CampaignEnrollmentApi.Models;

namespace CampaignEnrollmentApi.Extensions;

/// <summary>
/// Extension methods and factory methods for StagedEnrollment specific to CampaignEnrollmentApi.
/// </summary>
public static class StagedEnrollmentExtensions
{
    /// <summary>
    /// Creates a new StagedEnrollment from an EnrollmentContact.
    /// </summary>
    public static StagedEnrollment FromContact(
        EnrollmentContact contact,
        MarketingCampaign campaign,
        PipelineVersion pipelineVersion
    )
    {
        return new StagedEnrollment(
            contact.Id,
            contact.DataFields ?? [],
            campaign,
            pipelineVersion
        );
    }
}