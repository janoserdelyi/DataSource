using System.Text.Json.Nodes;
using Microsoft.OpenApi;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace CampaignEnrollmentApi.Extensions;

/// <summary>
/// Schema filter to represent JsonObject and JsonNode as a dictionary of string key-value pairs in Swagger.
/// </summary>
public class JsonObjectSchemaFilter : ISchemaFilter
{
    public void Apply(IOpenApiSchema schema, SchemaFilterContext context)
    {
        if (schema is not OpenApiSchema concrete)
        {
            return;
        }

        // Only run for fields that are a Dictionary<Enum, TValue>
        if (context.Type != typeof(JsonObject) && context.Type != typeof(JsonNode))
        {
            return;
        }

        concrete.Example = new JsonObject
        {
            ["key1"] = "value1",
            ["key2"] = "value2"
        };
    }
}
