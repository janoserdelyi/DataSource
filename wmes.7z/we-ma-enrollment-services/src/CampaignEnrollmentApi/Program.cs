using CampaignEnrollmentApi.Services;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Builder;
using CampaignEnrollmentApi.Services.Background;
using CampaignEnrollmentApi.Extensions;
using System.Threading.Channels;
using EnrollmentPipeline.Models;

var app = PipelineWorkerBuilder.Create (
    args,
    builder =>
    {
        // Add OpenSearch integration
        builder.AddOpenSearchClient();
        // Add services to the container
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen(options =>
        {
            options.SchemaFilter<JsonObjectSchemaFilter>();
        });
        // Register the message publisher service
        builder.Services.AddScoped<IMessagePublisherService, MessagePublisherService>();
		// Creates queue for dispatchable actions
        // TODO: Consider using a Bounded channel?
		builder.Services.AddSingleton (Channel.CreateUnbounded<EnrollmentBatch> ());
		// Adds action dispatcher background service
		builder.Services.AddHostedService<EnrollmentPublisher> ();
    }
);

app.UseSwagger();
app.UseSwaggerUI();
app.UseRouting();
app.MapControllers();

await app.RunAsync();
