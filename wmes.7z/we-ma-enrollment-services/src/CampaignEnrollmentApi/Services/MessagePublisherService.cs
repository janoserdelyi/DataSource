using EnrollmentPipeline;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using StackExchange.Redis;
using EnrollmentPipeline.Repositories;
using CampaignEnrollmentApi.Models;
using EnrollmentPipeline.Enums;

namespace CampaignEnrollmentApi.Services;

public interface IMessagePublisherService
{
	/// <summary>
	/// Creates an enrollment for the given contact and campaign.
	/// This method does not publish the enrollment to the message queue.
	/// If version or campaign doesn't exist or is not active, or the contact fails validation, an exception will be thrown.
	/// </summary>
	/// <param name="contact">The contact to publish.</param>
	/// <param name="campaignId">The ID of the campaign associated with the contact.</param>
	/// <param name="pipelineVersion">(Optional) The version of the pipeline to use.</param>
	/// <returns>The created staged enrollment object.</returns>
	Task<StagedEnrollment> CreateEnrollmentAsync(
		EnrollmentContact contact,
		int campaignId,
		PipelineVersion? pipelineVersion = null
	);
	/// <summary>
	/// Creates a batch of enrollments for the campaign id.
	/// This method does not publish the enrollments to the message queue.
	/// If version or campaign doesn't exist or is not active, an exception will be thrown.
	/// If the contact fails validation, an enrollment will still be created and the Status/StatusReason fields will indicate failure for that contact.
	/// </summary>
	/// <param name="contacts">Array of contacts to publish.</param>
	/// <param name="campaignId">The ID of the campaign associated with the contacts.</param>
	/// <param name="pipelineVersion">(Optional) The version of the pipeline to use.</param>
	/// <returns>A tuple with the batch and a read-only collection of invalid enrollments.</returns>
	Task<(EnrollmentBatch batch, IReadOnlyCollection<StagedEnrollment> invalidEnrollments)> CreateEnrollmentBatchAsync(
		EnrollmentContact[] contacts,
		int campaignId,
		PipelineVersion? pipelineVersion = null
	);
	/// <summary>
	/// Publishes a contact to the message queue.
	/// </summary>
	/// <param name="enrollment">The enrollment to publish.</param>
	Task<string> PublishEnrollmentAsync(StagedEnrollment enrollment);
	/// <summary>
	/// Publishes a contact to the message queue.
	/// </summary>
	/// <param name="contact">The contact to publish.</param>
	/// <param name="campaignId">The ID of the campaign associated with the contact.</param>
	/// <param name="pipelineVersion">(Optional) The version of the pipeline to use.</param>
	Task<string> PublishEnrollmentAsync(
		EnrollmentContact contact,
		int campaignId,
		PipelineVersion? pipelineVersion = null
	);
	/// <summary>
	/// Publishes a batch of contacts to the message queue.
	/// </summary>
	/// <param name="enrollments">Array of enrollments to publish.</param>
	/// <returns>A tuple with the successful and failed enrollments.</returns>
	Task<(IReadOnlyCollection<StagedEnrollment> successful, IReadOnlyCollection<StagedEnrollment> failed)> PublishEnrollmentBatchAsync(
		IReadOnlyCollection<StagedEnrollment> enrollments
	);
	/// <summary>
	/// Publishes a batch of contacts to the message queue.
	/// </summary>
	/// <param name="contacts">Array of contacts to publish.</param>
	/// <param name="campaignId">The ID of the campaign associated with the contacts.</param>
	/// <param name="batchId">(Optional) The batch identifier for grouping enrollments.</param>
	/// <param name="pipelineVersion">(Optional) The version of the pipeline to use.</param>
	/// <returns>A dictionary mapping each contact ID to its StagedEnrollment object. StagedEnrollment object will be null for the contacts that fail to publish.</returns>
	Task<Dictionary<int, StagedEnrollment?>> PublishEnrollmentBatchAsync(
		EnrollmentContact[] contacts,
		int campaignId,
		Guid? batchId = null,
		PipelineVersion? pipelineVersion = null
	);
}

public class MessagePublisherService(
	IStreamMessagePublisher publisher,
	ILogger<MessagePublisherService> logger,
	ICampaignRepository campaignRepository,
	IContactRepository contactRepository,
	IPipelineService pipelineService) : IMessagePublisherService
{
	public async Task<StagedEnrollment> CreateEnrollmentAsync(
		EnrollmentContact contact,
		int campaignId,
		PipelineVersion? pipelineVersion = null
	)
	{
		// Checks if campaign exist and is active
		var campaign = await campaignRepository.GetCampaignByIdAsync(campaignId);

		if (campaign == null || !campaign.IsCampaignActive)
		{
			throw new ArgumentException($"Campaign does not exist or is no longer active.");
		}

		if (pipelineVersion == null)
		{
			// Gets latest Pipeline Version from DB for the given brand
			pipelineVersion = await pipelineService.GetLatestVersionAsync(campaign.MarketingBrandId);
		}

		if (!pipelineVersion.Active)
		{
			throw new ArgumentException($"The pipeline version with ID {pipelineVersion.Id} is not active.");
		}

		// Gets the stream name from the first worker in the pipeline
		var firstWorker = pipelineVersion.GetNextWorker();

		ArgumentNullException.ThrowIfNull(firstWorker, "Pipeline version has no workers configured.");

		// Checks if pipeline version is compatible with the campaign's brand
		if (pipelineVersion.BrandId != null && pipelineVersion.BrandId != campaign.MarketingBrandId)
		{
			throw new ArgumentException($"Pipeline version with ID {pipelineVersion.Id} is not compatible with campaign with ID {campaign.Id}.");
		}

		var contactExists = await contactRepository.ContactExistsAsync(contact.Id);

		if (!contactExists)
		{
			throw new ArgumentException("Contact does not exist.");
		}

		return new StagedEnrollment(
			contact.Id,
			contact.DataFields ?? [],
			campaign,
			pipelineVersion
		)
		{
			IsHighPriority = true // Single enrollments are always high priority
		};
	}

	public async Task<(EnrollmentBatch batch, IReadOnlyCollection<StagedEnrollment> invalidEnrollments)> CreateEnrollmentBatchAsync(
		EnrollmentContact[] contacts,
		int campaignId,
		PipelineVersion? pipelineVersion = null
	)
	{
		// Checks if campaign exist and is active
		var campaign = await campaignRepository.GetCampaignByIdAsync(campaignId);

		if (campaign == null || !campaign.IsCampaignActive)
		{
			throw new ArgumentException($"Campaign does not exist or is no longer active.");
		}

		if (pipelineVersion == null)
		{
			// Gets latest Pipeline Version from DB for the given brand
			pipelineVersion = await pipelineService.GetLatestVersionAsync(campaign.MarketingBrandId);
		}

		if (!pipelineVersion.Active)
		{
			throw new ArgumentException($"The pipeline version with ID {pipelineVersion.Id} is not active.");
		}

		// Gets the stream name from the first worker in the pipeline
		var firstWorker = pipelineVersion.GetNextWorker();

		ArgumentNullException.ThrowIfNull(firstWorker, "Pipeline version has no workers configured.");

		// Checks if pipeline version is compatible with the campaign's brand
		if (pipelineVersion.BrandId != null && pipelineVersion.BrandId != campaign.MarketingBrandId)
		{
			throw new ArgumentException($"Pipeline version with ID {pipelineVersion.Id} is not compatible with campaign with ID {campaign.Id}.");
		}

		// Converts it to a hashset to get rid of duplicates and then back to array for repository call
		var contactIds = contacts.Select(c => c.Id).Distinct().ToArray();

		if (contactIds.Length < contacts.Length)
		{
			throw new ArgumentException("Duplicate contact IDs found in the request. Please remove duplicates and try again.");
		}

		var contactExists = await contactRepository.ContactExistsAsync(contactIds);
		// List of enrollments to process
		var enrollmentsToProcess = new List<StagedEnrollment>();
		// List of invalid enrollments
		var invalidEnrollments = new List<StagedEnrollment>();
		// Batch ID for grouping enrollments
		var batchId = Guid.NewGuid();

		foreach (var contact in contacts)
		{
			if (contactExists[contact.Id])
			{
				// Creates an enrollment for the contact
				var enrollment = new StagedEnrollment
				(
					contact.Id,
					contact.DataFields ?? [],
					campaign,
					pipelineVersion
				)
				{
					BatchId = batchId
				};

				enrollmentsToProcess.Add(enrollment);
			}
			else
			{
				// Creates an enrollment for the contact
				var enrollment = new StagedEnrollment
				(
					contact.Id,
					contact.DataFields ?? [],
					campaign,
					pipelineVersion
				)
				{
					BatchId = batchId,
					StatusId = PipelineStatus.Failed,
					StatusReasonId = PipelineStatusReason.InvalidContact,
					StatusMessage = "Contact not found."
				};

				invalidEnrollments.Add(enrollment);
			}
		}

		var batch = new EnrollmentBatch(batchId, enrollmentsToProcess);

		return (batch, invalidEnrollments);
	}

	public async Task<string> PublishEnrollmentAsync(EnrollmentContact contact, int campaignId, PipelineVersion? pipelineVersion = null)
	{
		// Checks if campaign exist and is active
		var campaign = await campaignRepository.GetCampaignByIdAsync(campaignId);

		if (campaign == null || !campaign.IsCampaignActive)
		{
			throw new ArgumentException($"Campaign does not exist or is no longer active.");
		}

		if (pipelineVersion == null)
		{
			// Gets latest Pipeline Version from DB for the given brand
			pipelineVersion = await pipelineService.GetLatestVersionAsync(campaign.MarketingBrandId);
		}

		if (!pipelineVersion.Active)
		{
			throw new ArgumentException($"The pipeline version with ID {pipelineVersion.Id} is not active.");
		}

		// Gets the stream name from the first worker in the pipeline
		var firstWorker = pipelineVersion.GetNextWorker();

		ArgumentNullException.ThrowIfNull(firstWorker, "Pipeline version has no workers configured.");

		// Checks if pipeline version is compatible with the campaign's brand
		if (pipelineVersion.BrandId != null && pipelineVersion.BrandId != campaign.MarketingBrandId)
		{
			throw new ArgumentException($"Pipeline version with ID {pipelineVersion.Id} is not compatible with campaign with ID {campaign.Id}.");
		}

		var contactExists = await contactRepository.ContactExistsAsync(contact.Id);

		if (!contactExists)
		{
			throw new ArgumentException($"Contact does not exist.");
		}

		try
		{
			var enrollment = new StagedEnrollment
			(
				contact.Id,
				contact.DataFields ?? [],
				campaign,
				pipelineVersion
			)
			{
				IsHighPriority = true // Single enrollments are always high priority
			};

			var messageId = await publisher.PublishEnrollmentAsync(firstWorker, enrollment);

			logger.LogDebug("Published contact {ContactId} from campaign {CampaignId} to stream {StreamName} with message ID {MessageId}",
				enrollment.ContactId, enrollment.MarketingCampaignId, firstWorker.HighPriorityStreamName, messageId);

			return messageId.ToString();
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Failed to publish contact {ContactId} from campaign {CampaignId} to stream {StreamName}",
				contact.Id, campaignId, firstWorker.HighPriorityStreamName);
			throw;
		}
	}

	public async Task<string> PublishEnrollmentAsync(StagedEnrollment enrollment)
	{
		if (enrollment.PipelineVersion == null)
		{
			throw new ArgumentException($"The pipeline version has not been set for the enrollment.");
		}

		if (!enrollment.PipelineVersion.Active)
		{
			throw new ArgumentException($"The pipeline version with ID {enrollment.PipelineVersion.Id} is not active.");
		}

		if (enrollment.Campaign == null)
		{
			throw new ArgumentException($"The campaign has not been set for the enrollment.");
		}

		// Gets the stream name from the first worker in the pipeline
		var firstWorker = enrollment.PipelineVersion.GetNextWorker();

		ArgumentNullException.ThrowIfNull(firstWorker, "Pipeline version has no workers configured.");

		// Checks if pipeline version is compatible with the campaign's brand
		if (enrollment.PipelineVersion.BrandId != null && enrollment.PipelineVersion.BrandId != enrollment.Campaign.MarketingBrandId)
		{
			throw new ArgumentException(
				$"Pipeline version with ID {enrollment.PipelineVersion.Id} is not compatible with campaign with ID {enrollment.Campaign.Id}.");
		}

		try
		{
			var messageId = await publisher.PublishEnrollmentAsync(firstWorker, enrollment);

			enrollment.MessageId = messageId;

			return messageId.ToString();
		}
		catch (Exception ex)
		{
			logger.LogError(ex,
				"Failed to publish contact {ContactId} from campaign {CampaignId} to stream {StreamName}",
				enrollment.ContactId, enrollment.MarketingCampaignId, firstWorker.HighPriorityStreamName);
			throw;
		}
	}

	public async Task<Dictionary<int, StagedEnrollment?>> PublishEnrollmentBatchAsync(EnrollmentContact[] contacts, int campaignId, Guid? batchId = null, PipelineVersion? pipelineVersion = null)
	{
		// Checks if campaign exist and is active
		var campaign = await campaignRepository.GetCampaignByIdAsync(campaignId);

		if (campaign == null || !campaign.IsCampaignActive)
		{
			throw new ArgumentException($"Campaign does not exist or is no longer active.");
		}

		if (pipelineVersion == null)
		{
			// Gets latest Pipeline Version from DB for the given brand
			pipelineVersion = await pipelineService.GetLatestVersionAsync(campaign.MarketingBrandId);
		}

		if (!pipelineVersion.Active)
		{
			throw new ArgumentException($"The pipeline version with ID {pipelineVersion.Id} is not active.");
		}

		// Gets the stream name from the first worker in the pipeline
		var firstWorker = pipelineVersion.GetNextWorker();

		ArgumentNullException.ThrowIfNull(firstWorker, "Pipeline version has no workers configured.");

		// Checks if pipeline version is compatible with the campaign's brand
		if (pipelineVersion.BrandId != null && pipelineVersion.BrandId != campaign.MarketingBrandId)
		{
			throw new ArgumentException($"Pipeline version with ID {pipelineVersion.Id} is not compatible with campaign with ID {campaign.Id}.");
		}

		var contactIds = contacts.Select(c => c.Id).ToArray();
		var contactExists = await contactRepository.ContactExistsAsync(contactIds);
		// List of final results
		var results = new Dictionary<int, StagedEnrollment?>();
		// List of enrollments to process
		var enrollmentsToProcess = new List<StagedEnrollment>();

		foreach (var contact in contacts)
		{
			if (contactExists[contact.Id])
			{
				// Creates an enrollment for the contact
				var enrollment = new StagedEnrollment
				(
					contact.Id,
					contact.DataFields ?? [],
					campaign,
					pipelineVersion
				)
				{
					BatchId = batchId ?? Guid.NewGuid()
				};

				enrollmentsToProcess.Add(enrollment);
			}
			else
			{
				logger.LogDebug("Contact with ID {ContactId} does not exist.", contact.Id);
				// No result since contact does not exist
				results[contact.Id] = null;
			}
		}

		var messageIds = await publisher.PublishEnrollmentBatchAsync(firstWorker, enrollmentsToProcess);

		foreach (var kvp in messageIds)
		{
			var enrollment = kvp.Key;
			var messageId = kvp.Value;

			if (messageId != RedisValue.Null)
			{
				results[enrollment.ContactId] = enrollment;
			}
		}

		return results;
	}

	public async Task<(IReadOnlyCollection<StagedEnrollment>, IReadOnlyCollection<StagedEnrollment>)> PublishEnrollmentBatchAsync(IReadOnlyCollection<StagedEnrollment> enrollments)
	{
		var successful = new List<StagedEnrollment>();
		var failed = new List<StagedEnrollment>();

		foreach (var enrollment in enrollments)
		{
			try
			{
				await PublishEnrollmentAsync(enrollment);
				successful.Add(enrollment);
			}
			catch (Exception ex)
			{
				logger.LogError(ex, "Failed to publish enrollment for contact ID {ContactId} in campaign ID {CampaignId}.",
					enrollment.ContactId, enrollment.MarketingCampaignId);
				failed.Add(enrollment);
			}
		}

		return (successful, failed);
	}
}
