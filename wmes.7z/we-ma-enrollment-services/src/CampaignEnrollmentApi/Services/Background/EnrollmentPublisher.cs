using System.Threading.Channels;
using EnrollmentPipeline.Models;

namespace CampaignEnrollmentApi.Services.Background;

public class EnrollmentPublisher(
    IServiceScopeFactory serviceScopeFactory,
    ILogger<EnrollmentPublisher> logger,
    Channel<EnrollmentBatch> channel
) : BackgroundService
{
    // TODO: Make this a system setting in appsettings.json
    private const int MAX_CONCURRENT_PUBLISHERS = 10;

    private readonly List<Task> _runningPublishers = [];

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = serviceScopeFactory.CreateScope ();

        var publisherService = scope.ServiceProvider.GetRequiredService<IMessagePublisherService> ();

        var semaphore = new SemaphoreSlim (MAX_CONCURRENT_PUBLISHERS);

        while (!stoppingToken.IsCancellationRequested && !channel.Reader.Completion.IsCompleted)
        {
            var batch = await channel.Reader.ReadAsync (stoppingToken);
            Task task = semaphore.WaitAsync (stoppingToken)
                // TODO: Save failed to DB maybe?
                .ContinueWith (_ => publisherService.PublishEnrollmentBatchAsync (batch.Enrollments), stoppingToken)
                .ContinueWith (previousTask =>
                {
                    if (previousTask.IsFaulted)
                    {
                        logger.LogError (previousTask.Exception, "Error publishing enrollment batch: {BatchId}", batch.Id);
                    }
                }, stoppingToken)
                .ContinueWith (_ => semaphore.Release (), stoppingToken);

            // Saves a reference to the new task
            _runningPublishers.Add(task);

            // Cleans-up references to finished tasks
            _runningPublishers.RemoveAll(publisher => publisher.IsCompleted);
        }

        // Waits until all tasks are completed before returning
        await Task.WhenAll(_runningPublishers);
    }
}
