using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using CampaignEnrollmentApi.Models;
using CampaignEnrollmentApi.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Channels;

namespace CampaignEnrollmentApi.Controllers;

[ApiController]
[Route("api/publisher")]
public class PublisherController(
	IMessagePublisherService publisherService,
	IPipelineService pipelineService,
	ILogger<PublisherController> logger,
	Channel<EnrollmentBatch> channel
) : ControllerBase
{

	[HttpPost("single")]
	[ProducesResponseType(typeof(PublishSingleContactResponse), StatusCodes.Status200OK)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
	public async Task<ActionResult<PublishSingleContactResponse>> PublishContact(
		[FromBody] PublishSingleContactRequest request)
	{
		try
		{
			PipelineVersion? pipelineVersion = null;

			// Try to retrieve the specified pipeline version
			if (request.PipelineVersionId.HasValue)
			{
				pipelineVersion = await pipelineService.GetVersionByIdAsync(request.PipelineVersionId.Value);

				if (pipelineVersion == null || !pipelineVersion.Active)
				{
					return BadRequest(new ErrorResponse($"Pipeline version with ID {request.PipelineVersionId.Value} does not exist or has been disabled."));
				}
			}

			var enrollment = await publisherService.CreateEnrollmentAsync(request.Contact, request.CampaignId, pipelineVersion);
			var messageId = await publisherService.PublishEnrollmentAsync(enrollment);

			return Ok(new PublishSingleContactResponse(
				MessageId: messageId,
				Status: "Published",
				Priority: "High"
			));
		}
		catch (ArgumentException ex)
		{
			return BadRequest(new ErrorResponse(ex.Message));
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Failed to create enrollment.");
			return StatusCode(500, new ErrorResponse(ex.Message));
		}
	}

	[HttpPost("batch")]
	[ProducesResponseType(typeof(PublishBatchResponse), StatusCodes.Status200OK)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
	public async Task<ActionResult<PublishBatchResponse>> PublishContactBatch([FromBody] PublishBatchRequest request)
	{
		try
		{
			PipelineVersion? pipelineVersion = null;

			// Try to retrieve the specified pipeline version
			if (request.PipelineVersionId.HasValue)
			{
				pipelineVersion = await pipelineService.GetVersionByIdAsync(request.PipelineVersionId.Value);

				if (pipelineVersion == null || !pipelineVersion.Active)
				{
					return BadRequest(new ErrorResponse($"Pipeline version with ID {request.PipelineVersionId.Value} does not exist or has been disabled."));
				}
			}

			// Validate batch and remove duplicates before publishing to pipeline
			var (batch, invalidEnrollments) = await publisherService.CreateEnrollmentBatchAsync(request.Contacts, request.CampaignId, pipelineVersion);

			var (successful, failed) = await publisherService.PublishEnrollmentBatchAsync(batch.Enrollments);

			var failedEnrollments = invalidEnrollments.Concat(failed);

			return Ok(new PublishBatchResponse(
				BatchId: batch.Id,
				Published: successful.Count,
				Failed: failedEnrollments.Select(e => new FailedEnrollmentResponse(
					Id: e.ContactId,
					Status: e.StatusReasonId.ToString(),
					Error: e.StatusMessage
				))
			));
		}
		catch (ArgumentException ex)
		{
			return BadRequest(new ErrorResponse(ex.Message));
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Failed to publish contact batch");
			return StatusCode(500, new ErrorResponse(ex.Message));
		}
	}

	[HttpPost("batch/async")]
	[ProducesResponseType(typeof(PublishBatchAsyncResponse), StatusCodes.Status200OK)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
	public async Task<ActionResult<PublishBatchAsyncResponse>> PublishContactBatchAsync([FromBody] PublishBatchRequest request)
	{
		try
		{
			PipelineVersion? pipelineVersion = null;

			// Try to retrieve the specified pipeline version
			if (request.PipelineVersionId.HasValue)
			{
				pipelineVersion = await pipelineService.GetVersionByIdAsync(request.PipelineVersionId.Value);

				if (pipelineVersion == null || !pipelineVersion.Active)
				{
					return BadRequest(new ErrorResponse($"Pipeline version with ID {request.PipelineVersionId.Value} does not exist or has been disabled."));
				}
			}

			// Validate batch and remove duplicates before publishing to pipeline
			var (batch, invalidEnrollments) = await publisherService.CreateEnrollmentBatchAsync(request.Contacts, request.CampaignId, pipelineVersion);

			// Add batch to queue for background processing
			await channel.Writer.WriteAsync(batch);

			return Ok(new PublishBatchAsyncResponse(
				BatchId: batch.Id,
				Queued: batch.Enrollments.Count,
				Failed: invalidEnrollments.Select(e => new FailedEnrollmentResponse(
					Id: e.ContactId,
					Status: e.StatusReasonId.ToString(),
					Error: e.StatusMessage
				))
			));
		}
		catch (ArgumentException ex)
		{
			return BadRequest(new ErrorResponse(ex.Message));
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Failed to publish contact batch");
			return StatusCode(500, new ErrorResponse(ex.Message));
		}
	}

	[HttpGet("batch/{batchId}")]
	[ProducesResponseType(StatusCodes.Status200OK)]
	[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status501NotImplemented)]
	public async Task<IActionResult> GetBatchStatus(Guid batchId)
	{
		// TODO: Check the status of a batch by its identifier.

		return StatusCode(501, new ErrorResponse("Not implemented yet."));
	}
}
