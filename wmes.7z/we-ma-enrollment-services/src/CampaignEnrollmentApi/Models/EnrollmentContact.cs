using System.Text.Json.Nodes;

namespace CampaignEnrollmentApi.Models;

public record EnrollmentContact(
    // The Contact ID
    int Id,
    // Additional data fields for the contact
    JsonObject? DataFields = null
);