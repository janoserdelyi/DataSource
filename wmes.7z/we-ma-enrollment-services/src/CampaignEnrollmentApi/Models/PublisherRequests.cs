namespace CampaignEnrollmentApi.Models;

public record PublishSingleContactRequest(
    EnrollmentContact Contact,
    int CampaignId,
    short? PipelineVersionId = null
);

public record PublishBatchRequest(
    EnrollmentContact[] Contacts,
    int CampaignId,
    short? PipelineVersionId = null
);