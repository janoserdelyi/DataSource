namespace CampaignEnrollmentApi.Models;

/// <summary>
/// Response for a single contact enrollment publication.
/// </summary>
public record PublishSingleContactResponse(
    string MessageId,
    string Status,
    string Priority
);

/// <summary>
/// Response for a batch enrollment publication (synchronous).
/// </summary>
public record PublishBatchResponse(
    Guid BatchId,
    int Published,
    IEnumerable<FailedEnrollmentResponse> Failed
);

/// <summary>
/// Response for a batch enrollment publication (asynchronous/queued).
/// </summary>
public record PublishBatchAsyncResponse(
    Guid BatchId,
    int Queued,
    IEnumerable<FailedEnrollmentResponse> Failed
);

/// <summary>
/// Details about a failed enrollment.
/// </summary>
public record FailedEnrollmentResponse(
    int Id,
    string? Status,
    string? Error
);

/// <summary>
/// Generic error response.
/// </summary>
public record ErrorResponse(string Error);
