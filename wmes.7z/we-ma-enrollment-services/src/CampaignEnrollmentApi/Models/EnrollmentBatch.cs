using EnrollmentPipeline.Models;

public class EnrollmentBatch
{
    public Guid Id { get; set; }
    public IReadOnlyCollection<StagedEnrollment> Enrollments { get; set; }

    public EnrollmentBatch(Guid id, IReadOnlyCollection<StagedEnrollment> enrollments)
    {
        Id = id;
        Enrollments = enrollments;
    }
}