using Enterprise.Data.Services.Contacts;
using Enterprise.Data.Services.Contacts.Operations;
using Enterprise.Data.Values;

namespace DataFieldProvider.Extensions;

public static class ContactGetAttachmentResponseExtensions
{
	private const string CONTACT_ATTACHMENT_SIZE = "110";
	public static AttachmentReference? GetPrimaryPhoto(this ContactGetAttachmentsResponse response)
	{
		if (response == null || response.Attachments == null) return null;

		return response.Attachments
			.FirstOrDefault(a => a.AttachmentType == AttachmentType.PrimaryContactPhoto);
	}

	/// <summary>
	/// Gets the URL of the primary photo of the given contact
	/// Returns null if there are no primary photo attachments for the giving contact
	/// </summary>
	public static string? GetPrimaryPhotoUri(this ContactGetAttachmentsResponse response)
	{
		var primaryPhoto = response.GetPrimaryPhoto();
		return primaryPhoto?.GetAttachmentUri();
	}

	private static string? GetAttachmentUri(this AttachmentReference request)
	{
		if (request == null) return null;

		return request.Uri.Replace("{s}", CONTACT_ATTACHMENT_SIZE).Replace("{f}", "photo");
	}
}
