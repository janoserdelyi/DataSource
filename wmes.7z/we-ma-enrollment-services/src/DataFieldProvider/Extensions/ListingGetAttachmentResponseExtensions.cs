using Enterprise.Data.Services.Listings.Commercial;
using Enterprise.Data.Services.Listings.Commercial.Operations;
using Enterprise.Data.Values;

namespace DataFieldProvider.Extensions;

public static class ListingGetAttachmentResponseExtensions
{
	private const string LISTING_ATTACHMENT_SIZE = "110";
	public static ListingAttachmentReference? GetPrimaryPhoto(this ListingGetAttachmentsResponse response)
	{
		if (response.Attachments == null) return null;

		return response.Attachments
			.SelectMany(kvp => kvp.Value)
			.FirstOrDefault(a => a.AttachmentType == AttachmentType.PrimaryPhoto);
	}

	/// <summary>
	/// Gets the URL of the thumbnail sized image of a listing
	/// Returns null if there are no primary photo attachments for the giving listing
	/// </summary>
	public static string? GetPrimaryPhotoUri(this ListingGetAttachmentsResponse response)
	{
		var primaryPhoto = response.GetPrimaryPhoto();
		if(primaryPhoto == null ) return null;
		return primaryPhoto?.GetAttachmentUri();
	}

	public static List<ListingLPRImage>? GetLPRImages(this ListingSummaryResult response)
	{
		var listingImages = new List<ListingLPRImage>();

		foreach (var listing in response.Listings)
		{
			if (listing == null) continue;

			if (listing.Attachments != null && listing.Attachments.Count > 0)
			{
				listingImages.Add(new ListingLPRImage
				{
					ListingID = listing.Id,
					ImageURL = listing.Attachments[0].Uri.Replace("{s}", LISTING_ATTACHMENT_SIZE).Replace("{f}", "photo")
				});
			}
		}

		return listingImages;
	}

	private static string? GetAttachmentUri(this ListingAttachmentReference request)
	{
		if (request == null) return null;

		return request.Uri.Replace("{s}", LISTING_ATTACHMENT_SIZE).Replace("{f}", "photo");
	}
}

public class ListingLPRImage
{
    public required int ListingID { get; set; }
    public required string ImageURL { get; set; }
}