using System.Net.Http.Headers;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Services;
using EnrollmentPipeline.Extensions;
using Enterprise.Data.Services.Contacts;
using Enterprise.Data.Services.Listings.Commercial;

namespace DataFieldProvider.Extensions;

public static class ServiceCollectionExtensions
{
    public static void AddCampaignDataFieldService(this WebApplicationBuilder builder)
    {
        var assembly = AppDomain.CurrentDomain.GetAssemblies()
            .First(a => a.GetName().Name == "DataFieldProvider");

        var dataFieldProviders = assembly
            .GetTypes()
            .Where(t => t
                .GetInterfaces()
                .Any(i => i == typeof(IDataFieldProvider))
                && !t.IsAbstract
                && !t.IsInterface
            )
            .ToList();

        // Registers all IDataFieldProvider implementations in DI
        foreach (var providerType in dataFieldProviders)
        {
            builder.Services.AddScoped(providerType);
        }

        builder.Services.AddScoped<ICampaignDataFieldService, CampaignDataFieldService>();
    }

    public static void AddEdsService(this WebApplicationBuilder builder)
    {
        // Register the EDS client dependencies first
        builder.Services.AddScoped<ICommercialListingHttpClient, CommercialListingHttpClient>();
        builder.Services.AddScoped<IContactHttpClient, ContactHttpClient>();

        // Add HttpClient for EDSService with typed client registration
        builder.Services.AddHttpClient<IEDSService, EDSService>((serviceProvider, client) =>
        {
            var edsBaseUrl = builder.Configuration.GetValue<string>("Services:EDS");

            ArgumentNullException.ThrowIfNull(edsBaseUrl, nameof(edsBaseUrl));

            client.BaseAddress = new Uri(edsBaseUrl);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
            );
        });
    }

    public static void AddSalesAeService(this WebApplicationBuilder builder)
    {
        builder.Services.AddScoped<ISalesAEService, SalesAEService>();
    }

    public static void AddHomesTokenService(this WebApplicationBuilder builder)
    {
        builder.AddVaultSecrets("homes-token");
        builder.Services.AddScoped<IHomesTokenService, HomesTokenService>();
    }

    public static void AddPreferencesService(this WebApplicationBuilder builder)
    {
        // Add HttpClient for PreferencesService
        builder.Services.AddHttpClient<IPreferencesService, PreferencesService>(client =>
        {
            var preferencesBaseUrl = builder.Configuration.GetValue<string>("Services:UserPreferenceService");

            ArgumentNullException.ThrowIfNull(preferencesBaseUrl, nameof(preferencesBaseUrl));

            client.BaseAddress = new Uri(preferencesBaseUrl);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
            );
        });
    }

    public static void AddListingMarketAnalyticsService(this WebApplicationBuilder builder)
    {
        builder.Services.AddHttpClient<IListingMarketAnalyticsClient, ListingMarketAnalyticsClient>(client =>
        {
            // Used to be LoopNet:analyticsService
            var baseUrl = builder.Configuration.GetValue<string>("Services:ListingMarketAnalytics");
            ArgumentNullException.ThrowIfNull(baseUrl, nameof(baseUrl));
            client.BaseAddress = new Uri(baseUrl);
        });
    }

    public static void AddHttpClients(this WebApplicationBuilder builder)
    {
        // Add HttpClient for PDS
        builder.Services.AddHttpClient("PDS", client =>
        {
            var pdsBaseUrl = builder.Configuration.GetValue<string>("Services:PDS")?.TrimEnd('/');

            ArgumentNullException.ThrowIfNull(pdsBaseUrl, nameof(pdsBaseUrl));

            client.BaseAddress = new Uri(pdsBaseUrl);
            client.DefaultRequestHeaders.Add("Marketing-Brand-ID", "1");
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
            );
        });

        // Remove this when all classes have been refactored to use the OpenSearch client
        builder.Services.AddHttpClient("OpenSearchClient", client =>
        {
            var openSearchUrl = builder.Configuration.GetValue<string>("ConnectionStrings:OpenSearch")?.TrimEnd('/');

            ArgumentNullException.ThrowIfNull(openSearchUrl, nameof(openSearchUrl));

            client.BaseAddress = new Uri(openSearchUrl);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
            );
        });
    }
}
