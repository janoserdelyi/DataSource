using DataFieldProvider.Providers.Core;
using DataFieldProvider.Models.Loopnet.NewListingPremium;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.DataAccess.Queries;
using DataFieldProvider.DataAccess.Queries;

namespace DataFieldProvider.Providers;

public class LoopNetPremiumListerDataFieldProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<LoopNetPremiumListerDataFieldProvider> logger
) : DataFieldProvider<LoopnetPremiumLister>(logger)
{
	protected override async Task<IEnumerable<LoopnetPremiumLister>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var query = new GetPremiumListersInfoQuery { ListerIds = enrollments.Select(c => c.ContactId).ToList() };

		var results = (await queryDispatcher
			.Dispatch<GetPremiumListersInfoQuery, GetPremiumListersInfoQueryResult>(query, cancellationToken)
		).Listers.ToList();

		return results;
	}
}
