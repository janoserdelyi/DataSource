using System.Collections.Concurrent;
using DataFieldProvider.Extensions;
using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models.Loopnet;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Services;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Models.CostarSync;
using EnrollmentPipeline.Services;
using Enterprise.Data.Services.Listings.Commercial;
using Enterprise.Data.Services.Listings.Commercial.Operations;
using DataPlane.Client.CoStar.CommercialListingAnalytics.ListingEvent.Models;

namespace DataFieldProvider.Providers;

public class LoopNetListingDetailsDataFieldProvider(
	IEDSService edsService,
	IQueryDispatcher queryDispatcher,
	IDataPlaneService dataPlaneService,
	IListingMarketAnalyticsClient listingMarketAnalyticsClient,
	ILogger<LoopNetListingDetailsDataFieldProvider> logger
) : DataFieldProvider<LoopNetListingDetails>(logger)
{
	private readonly ConcurrentDictionary<int, string> _listingImages = new();
	private readonly ConcurrentDictionary<int, string> _listingPerformanceUrls = new();

	protected override int ChunkSize => 300;
	protected override int MaxConcurrentChunks => 3;

	protected override async Task<IEnumerable<LoopNetListingDetails>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var contactListingDetails = new List<LoopNetListingDetails>();

		var listingIds = enrollments
			// Looks for the listing id of each contact
			.Select(enrollment => enrollment.DataFields["ListingId"])
			// Uses TryParse here to make sure the value is a valid integer
			.Where(value => value != null && int.TryParse(value.ToString(), out _))
			// Uses explicit cast since we know it's a parseable integer
			.Select(value => (int)value!)
			.ToList();

		var listingDetailsDict = (await queryDispatcher
			.Dispatch<GetLoopNetListingBasicDetailsQuery, GetLoopNetListingBasicDetailsQueryResult>(
				new GetLoopNetListingBasicDetailsQuery { ListingIds = listingIds },
				cancellationToken: cancellationToken)
			)
			.ListingDetailsList
			.ToDictionary(listing => listing.ListingId);

		foreach (var contact in enrollments)
		{
			var listingIdPropValue = (string?)contact.DataFields["ListingId"];

			// If listing ID fails to parse (null, empty, or invalid value), then skip to next contact
			if (listingIdPropValue == null || !int.TryParse(listingIdPropValue, out var listingId))
			{
				logger.LogWarning($"Campaign (#{contact.MarketingCampaignId}) requires Loopnet Listing data fields but contact (#{contact.ContactId}) did not include Listing ID.");
				continue;
			}

			// If no details were found for the given listing id, then skip to next contact
			if (!listingDetailsDict.TryGetValue(listingId, out var listingDetails))
				continue;

			var thumbnailUrl = await GetListingThumbnail(listingId);
			var lprUrl = await GetListingPerformanceReportUrl(listingId);
			var activityPerformanceData = await GetListingActivity(listingId);

			contactListingDetails.Add(new LoopNetListingDetails
			{
				ContactID = contact.ContactId,
				ListingId = listingDetails.ListingId,
				ResearchMarketName = listingDetails.ResearchMarketName,
				ListingCity = listingDetails.ListingCity,
				ListingState = listingDetails.ListingState,
				ListingAddress = listingDetails.ListingAddress,
				ListingImageUrl = thumbnailUrl,
				ListingPerformanceReportUrl = lprUrl,
				UniqueVisitorCount = listingDetails.UniqueVisitorCount,
				LDPViewsThirtyDaysCSLN = activityPerformanceData.TotalDetailViews,
				ViewCount30DaysCSLN = activityPerformanceData.TotalViews
			});
		}

		return contactListingDetails;
	}

	private async Task<PerformanceData> GetListingActivity(int listingId)
	{
		var listingActivity30Days = await GetListingActivitiesForPastThirtyDays(listingId);
		if (listingActivity30Days != null)
		{
			var activityData = listingActivity30Days.ByStartDates?.FirstOrDefault()?.ByEventSourceGroups?.FirstOrDefault()?.PerformanceData;
			if (activityData != null)
				return activityData;
		}
		return new PerformanceData();
	}

	private async Task<string> GetListingThumbnail(int listingId)
	{
		if (_listingImages.TryGetValue(listingId, out var value))
		{
			return value;
		}

		var attachments = await edsService.GetListingAttachmentsAsync(new ListingGetAttachmentsHttpRequest { Id = listingId });

		var listingImage = attachments?.GetPrimaryPhotoUri();

		// We added a fallback here for ListingImage when we could not find the primary image from previous call.
		// This might need to be deleted later once Costar Sync has all the attachments information. 5/20/2025
		if (string.IsNullOrEmpty(listingImage))
		{
			var authorizedListings = await edsService.GetAuthorizedListingAsync(
				new ListingGetAuthorizedHttpRequest
				{
					Criteria = new ListingFilterCriteria
					{
						SearchKeys = new List<int> { listingId }
					}
				});
			listingImage = authorizedListings?.Result.GetLPRImages()?.FirstOrDefault()?.ImageURL;
		}

		// you'd think i wouldnt need to seperate this logic, but it was failing until i split and designated string.Empty
		_listingImages.TryAdd(listingId, !string.IsNullOrWhiteSpace(listingImage) ? listingImage : string.Empty);

		return _listingImages[listingId];
	}

	private async Task<string> GetListingPerformanceReportUrl(int listingId)
	{
		if (_listingPerformanceUrls.TryGetValue(listingId, out var cachedLprUrl))
		{
			return cachedLprUrl;
		}

		// Gets Listing Performance Report URL
		var result = await listingMarketAnalyticsClient.GetListingPerformanceUrl([listingId]);

		var lprUrl = result[0].Url;

		if (string.IsNullOrEmpty(lprUrl))
		{
			return string.Empty;
		}

		_listingPerformanceUrls.TryAdd(listingId, lprUrl);

		return lprUrl;
	}

	private async Task<ListingActivity> GetListingActivitiesForPastThirtyDays(int listingId)
	{
		var listingActivities = await dataPlaneService.GetAsync<ByForeignKeyResponse>($"commerciallistinganalytics/ro/listingactivity-by-lid/{listingId}");

		if (listingActivities != null)
		{
			var thirtyDaykey = listingActivities.ModelKeys.FirstOrDefault(key => key.k != null && key.k.Contains("PastThirtyDays"))?.k;
			var listingActivity = await dataPlaneService.GetAsync<ListingActivity>($"commerciallistinganalytics/ro/listingactivity/{thirtyDaykey}");

			if (listingActivity != null)
			{
				return listingActivity;
			}
		}

		return new ListingActivity()
		{
			Id = null,
			ListingId = listingId,
		};
	}
}
