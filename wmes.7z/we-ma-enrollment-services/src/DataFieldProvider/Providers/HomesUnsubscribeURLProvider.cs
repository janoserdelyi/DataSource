using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using DataFieldProvider.Services;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Models;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class HomesUnsubscribeURLProvider(
    IHomesTokenService tokenService,
    ILogger<HomesUnsubscribeURLProvider> logger
) : DataFieldProvider<UnsubscribeURL>(logger)
{
    private readonly string HOMES_MARKETING_EMAIL_TOPIC = "8jn4b91";

    protected override Task<IEnumerable<UnsubscribeURL>> GetData(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        CancellationToken cancellationToken)
    {
        var unsubscribeUrls = enrollments.Select(enrollment =>
        {
            var emailAddress = enrollment.GetEmailAddress();

            if (string.IsNullOrEmpty(emailAddress))
            {
                return new UnsubscribeURL
                {
                    ContactID = enrollment.ContactId,
                    Link = string.Empty
                };
            }

            var link = GenerateUnsubscribeLink(emailAddress);

            return new UnsubscribeURL
            {
                ContactID = enrollment.ContactId,
                Link = link
            };
        });

        return Task.FromResult(unsubscribeUrls);
    }

    private string GenerateUnsubscribeLink(string emailAddress)
    {
        var claims = CreateClaims(emailAddress);
        var token = tokenService.GenerateToken(claims, TimeSpan.FromDays(365));
        var template = $"{tokenService.Issuer}/market/unsub/?t={{0}}&p={HOMES_MARKETING_EMAIL_TOPIC}";

        return string.Format(template, token);
    }

    private static Claim[] CreateClaims(string email)
    {
        return [
			new Claim(JwtRegisteredClaimNames.Email, email),
            new Claim(JwtRegisteredClaimNames.Typ, "v1")
        ];
    }
}