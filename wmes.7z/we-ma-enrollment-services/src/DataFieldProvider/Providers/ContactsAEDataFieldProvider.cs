using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Services;
using DataFieldProvider.Extensions;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using Enterprise.Data.Services.Contacts.Operations;

namespace DataFieldProvider.Providers;

public class ContactsAEDataFieldProvider(
	IEDSService edsService,
	IQueryDispatcher queryDispatcher,
	ISalesAEService salesAECacheService,
	ILogger<ContactsAEDataFieldProvider> logger
) : DataFieldProvider<ContactAE>(logger)
{
	private ContactAE? _defaultLoopnetAE;
	private static readonly Dictionary<int, string> _aeContactPhotoUrl = new Dictionary<int, string>();

	protected override int ChunkSize => 100;
	protected override int MaxConcurrentChunks => 3;

	protected override async Task<IEnumerable<ContactAE>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		// TODO: The stored proc this uses calls a function and it's painfully slow. Find a better way.
		var aeList = await salesAECacheService.GetSalesPeopleInformationForMarketingCloud(enrollments);
		for (var i = 0; i < aeList.Count; i++)
		{
			var ae = aeList[i]; 
			// Checks if AE needs to be replaced with default one
			if (ae.AEContactID <= 0)
			{
				if(ae.MarketingBrand == Marketing.Enums.MarketingBrands.LoopNet)
				{
					ae = await GetDefaultLoopNetAE(ae.ContactID);
					// Updates list with new AE object
					aeList[i] = ae;
				}
				else
				{
					aeList.Remove(ae);
				}
			}

			// Updates AE image
			if(ae.AEContactID > 0) ae.AEImageURL = GetAEPhotoUrl(ae.AEContactID);

		}

		return aeList;
	}

	private string GetAEPhotoUrl(int contactId)
	{
		if (!_aeContactPhotoUrl.ContainsKey(contactId))
		{
			string photoUrl = string.Empty;
			try
			{
				var attachments = edsService.GetContactAttachmentsAsync(new ContactGetAttachmentsHttpRequest { Id = contactId }).Result;
				photoUrl = attachments?.GetPrimaryPhotoUri() ?? string.Empty;
			}
			catch
			{
				// logging already handled within the service. default to empty string
			}
			_aeContactPhotoUrl[contactId] = photoUrl;
		}

		return _aeContactPhotoUrl[contactId];
	}

	/// <summary>
	/// Retrieves the default Loopnet AE and associates it with given <paramref name="contactId"/>.
	/// </summary>
	/// <param name="contactId"></param>
	/// <returns></returns>
	private async Task<ContactAE> GetDefaultLoopNetAE(int contactId)
	{
		if (_defaultLoopnetAE == null)
		{
			/* this is paul newman, he is the loopnet UK sales manager. He will be the default AE if we fail to find one through other methods */
			var defaultLoopnetAEContactId = 116012591;
			var contact = await queryDispatcher.Dispatch<ContactInfoQuery, ContactInfoQueryResult>(
					new ContactInfoQuery { ContactId = defaultLoopnetAEContactId });

			_defaultLoopnetAE = new ContactAE
			{
				AEContactID = defaultLoopnetAEContactId,
				AEFirstName = contact.FirstName ?? string.Empty,
				AELastName = contact.LastName ?? string.Empty,
				AEEmailAddress = contact.EmailAddress ?? string.Empty,
				AEPhoneNumber = contact.PhoneNumber ?? string.Empty,
				AEPhoneExt = contact.PhoneExt ?? string.Empty,
				AEPhoneNumberCountryCode = contact.CountryCode ?? string.Empty,
				AEJobTitle = contact.JobTitle ?? string.Empty
			};
		}

		return new ContactAE
		{
			ContactID = contactId,
			AEContactID = _defaultLoopnetAE.AEContactID,
			AEFirstName = _defaultLoopnetAE.AEFirstName,
			AELastName = _defaultLoopnetAE.AELastName,
			AEEmailAddress = _defaultLoopnetAE.AEEmailAddress,
			AEPhoneNumber = _defaultLoopnetAE.AEPhoneNumber,
			AEPhoneExt = _defaultLoopnetAE.AEPhoneExt,
			AEPhoneNumberCountryCode = _defaultLoopnetAE.AEPhoneNumberCountryCode,
			AEJobTitle = _defaultLoopnetAE.AEJobTitle
		};

	}
}
