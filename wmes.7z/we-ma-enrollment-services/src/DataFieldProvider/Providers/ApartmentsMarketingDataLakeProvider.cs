using DataFieldProvider.Providers.Core;
using DataFieldProvider.Models.Apartments;
using EnrollmentPipeline.Models;
using OpenSearch.Client;

namespace DataFieldProvider.Providers;

public class ApartmentsMarketingDataLakeProvider(
    IOpenSearchClient client,
    ILogger<ApartmentsMarketingDataLakeProvider> logger
) : DataFieldProvider<ApartmentsMarketingDataLake>(logger)
{
    protected override int ChunkSize => 2000;
    protected override int MaxConcurrentChunks => 3;

    protected override async Task<IEnumerable<ApartmentsMarketingDataLake>> GetData(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        CancellationToken cancellationToken)
    {
        var request = new SearchRequest<ApartmentsMarketingDataLake>("apartments-marketing-data-lake.reader")
        {
            Size = ChunkSize,
            Query = new TermsQuery
            {
                Field = "_id",
                Terms = enrollments.Select(contact => contact.ContactId.ToString()).ToList()
            }
        };

        var response = await client.SearchAsync<ApartmentsMarketingDataLake>(request);
        return response.Documents;
    }
}
