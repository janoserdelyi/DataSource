using DataFieldProvider.DataAccess.Queries.Preferences;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class ContactPreferencesDataFieldProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<ContactPreferencesDataFieldProvider> logger
) : DataFieldProvider<CanEmailContact>(logger)
{
	public override int LookupPriority => 2;
	protected override int ChunkSize => 5000;
	protected override int MaxConcurrentChunks => 1; // Limit concurrency to avoid overwhelming the database

	/// <inheritdoc />
	protected override async Task<IEnumerable<CanEmailContact>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var query = new CanEmailContactsQuery { Contacts = enrollments };
		var result = await queryDispatcher
			.Dispatch<CanEmailContactsQuery, CanEmailContactsQueryResult>(query, cancellationToken)
			.ConfigureAwait(false);

		return result.CanEmailContacts;
	}
}
