using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Models.Loopnet;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Services;
using DataPlane.Client.CoStar.Contact.L2.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using Nexus.Extensions;
using OpenSearch.Client;

namespace DataFieldProvider.Providers;

public class LoopNetSignatureAdListingsDataFieldProvider(
	IOpenSearchClient openSearchClient,
	IQueryDispatcher queryDispatcher,
	IDataPlaneService dataPlaneService,
	IListingMarketAnalyticsClient listingMarketAnalyticsClient,
	ILogger<LoopNetSignatureAdListingsDataFieldProvider> logger
) : DataFieldProvider<LoopNetSignatureAdListingFields>(logger)
{
	private const string COMMERCIAL_LISTINGS_SERVICING_INDEX = "crm-commercial-listings-servicing.reader";
	private const string WE_SYNC_COMMERCIAL_LISTINGS_SEARCH_INDEX = "we.sync.commerciallistingsearch.reader";
	private const string LISTING_ATTACHMENT_SIZE = "110";

	protected override int ChunkSize => 300;
	protected override int MaxConcurrentChunks => 3;

	protected override async Task<IEnumerable<LoopNetSignatureAdListingFields>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var LoopNetSignatureAdListingFieldsList = new List<LoopNetSignatureAdListingFields>();

		var listingIDslist = enrollments
			.Select(enrollment => enrollment.DataFields?["ListingId"])
			.Where(id => id != null)
			.Select(id => id!.ToString())
			.ToList();

		var listingIDs = listingIDslist.Where(l => l != string.Empty).Select(l => int.Parse(l)).ToList();

		var loopNetSignatureAdFields = (await queryDispatcher.Dispatch<LoopNetSignatureAdListingDetailFieldsQuery, LoopNetSignatureAdListingDetailFieldsQueryResult>(
										new LoopNetSignatureAdListingDetailFieldsQuery { ListingIDs = listingIDs })).LoopNetSignatureAdListingDetailFieldsList;

		foreach (var item in enrollments)
		{
			var listingID = item.DataFields?["ListingId"]?.ToString();
			var contactType = item.DataFields?["ContactType"]?.ToString();

			if (listingID == null) { continue; }

			var fields = loopNetSignatureAdFields.FirstOrDefault(l => l.ListingID == int.Parse(listingID));

			// Retrieves the (geographically) closest competitor's address
			var competitorAddress = await GetClosestCompetitorListingAddress(fields);

			// Retrieves the Virtual Tours and Listing Impressions count
			var listingActivity = await GetListingActivityLastMonth(int.Parse(listingID));

			// Retrieves extra info about the listing that is stored in an Elastic index
			var commercialListingData = await GetCommercialListingDataFromElastic(int.Parse(listingID));

			var salesRepInfo = await GetContactDetailAsync(commercialListingData?.SalePersonContactId);

			LoopNetSignatureAdListingFieldsList.Add(new LoopNetSignatureAdListingFields
			{
				ContactID = item.ContactId,
				ContactType = contactType,
				BillingStartDate = fields?.BillingStartDate,
				ExposureLevel = fields?.ExposureLevel,
				CompetitorAddress = competitorAddress,
				ListingImpressionCount = (listingActivity?.TotalViews ?? 0).ToString(),
				ListingVirtualTourCount = (listingActivity?.VirtualTours ?? 0).ToString(),
				ServicingRepEmail = salesRepInfo?.EmailAddress,
				ServicingRepName = !string.IsNullOrEmpty(salesRepInfo?.FirstName) && !string.IsNullOrEmpty(salesRepInfo?.LastName) ? $"{salesRepInfo.FirstName} {salesRepInfo.LastName}" : string.Empty,
			});

		}
		return LoopNetSignatureAdListingFieldsList;
	}

	private async Task<string?> GetClosestCompetitorListingAddress(LoopNetSignatureAdListingDetailFields? listingFields)
	{
		if (listingFields == null) return string.Empty;
		// Calls /Listing/Competitor to get competitor listing IDs
		var competitorListingIds = await listingMarketAnalyticsClient.GetCompetitorListings(
			listingFields.ListingID,
			listingFields.ResearchMarketId,
			listingFields.SubMarketId,
			listingFields.PropertyTypeId
		);

		// If no competitors were found, return an empty string
		if (competitorListingIds == null || competitorListingIds.Count == 0)
		{
			return string.Empty;
		}

		CommercialListingSearch? competitorListing = null;

		// If there's only one competitor, then look for its address
		if (competitorListingIds.Count == 1)
		{
			// Queries Elastic to get the one competitor listing details
			var competitor = (await openSearchClient.SearchAsync<CommercialListingSearch>(s => s
				.Index(WE_SYNC_COMMERCIAL_LISTINGS_SEARCH_INDEX)
				.Query(q => q
					.Ids(i => i.Values(competitorListingIds[0]))
				)
			)).Documents?.ToList();

			if (competitor?.Count > 0)
			{
				competitorListing = competitor[0];
			}
		}
		else
		{
			// Queries Elastic to get the listing's coordinates to use as reference
			var listingInfo = (await openSearchClient.SearchAsync<CommercialListingSearch>(s => s
				.Index(WE_SYNC_COMMERCIAL_LISTINGS_SEARCH_INDEX)
				.Query(q => q
					.Ids(i => i.Values(listingFields.ListingID))
				)
			)).Documents?.ToList();

			if (listingInfo?.Count > 0)
			{
				// Queries Elastic to get the geographically closest competitor listing
				var closestCompetitors = (await openSearchClient.SearchAsync<CommercialListingSearch>(s => s
					.Index(WE_SYNC_COMMERCIAL_LISTINGS_SEARCH_INDEX)
					.Sort(sort => sort
						.GeoDistance(g => g
							.Field("geoLocation")
							.Points(listingInfo[0].GeoLocation)
							.Ascending()
						)
					)
					.Query(q => q
						.Ids(i => i.Values(competitorListingIds.Select(num => (long)num).ToArray()))
					)
				)).Documents?.ToList();

				if (closestCompetitors?.Count > 0)
				{
					// Returns the address for the closest competitor's address
					competitorListing = closestCompetitors[0];
				}
			}
		}

		if (competitorListing == null)
		{
			return string.Empty;
		}

		return $"{competitorListing.Document?.AddressStreetNumber} {competitorListing.Document?.AddressStreetName} {competitorListing.Document?.AddressStreetType}";
	}

	private async Task<ListingActivitySummary?> GetListingActivityLastMonth(int listingId)
	{
		var monthAgo = DateTime.Today.AddMonths(-1);

		return await listingMarketAnalyticsClient.GetListingActivitySummary(listingId, monthAgo, DateTime.Now);
	}

	private async Task<CommercialListingServicing?> GetCommercialListingDataFromElastic(int listingId)
	{
		// Queries the `crm-commercial-listings-servicing.reader` index by listing ID
		var result = await openSearchClient.SearchAsync<CommercialListingServicing>(s => s
				.Index(COMMERCIAL_LISTINGS_SERVICING_INDEX)
				.Query(q => q
					.Ids(i => i.Values(listingId))
				)
		);

		CommercialListingServicing? listingInfo = result.Documents?.ToList().FirstOrDefault();

		// Updates every attachment URL to include proper size and filename
		listingInfo?.Attachments?.ForEach(attachment =>
		{
			if (attachment.Uri != null)
			{
				attachment.Uri = attachment.Uri
					.Replace("{s}", LISTING_ATTACHMENT_SIZE)
					.Replace("{f}", "photo");
			}
		});

		return listingInfo;
	}

	private async Task<ContactDetail?> GetContactDetailAsync(int? contactId)
	{
		if (contactId == null)
			return null;

		return await dataPlaneService.GetAsync<ContactDetail>($"contact/ro/contactdetail/{contactId}");
	}
}
