using DataFieldProvider.DataAccess.Queries.Platform;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class ResearchMarketAreaProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<ResearchMarketAreaProvider> logger
) : DataFieldProvider<ResearchMarketAreaModel>(logger)
{
	public override int LookupPriority => 7;

	protected override async Task<IEnumerable<ResearchMarketAreaModel>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var query = new GetResearchMarketingAreaBulkQuery
		{
			Locations = enrollments.Select(e => new ContactLocationPair
			{
				ContactId = e.ContactId,
				LocationId = e.GetLocationId() ?? 0
			}).ToList()
		};

		var queryResult = await queryDispatcher.Dispatch<
			GetResearchMarketingAreaBulkQuery,
			GetResearchMarketingAreaBulkQueryResult
		>(query);

		return queryResult.ResearchMarketAreas;
	}
}
