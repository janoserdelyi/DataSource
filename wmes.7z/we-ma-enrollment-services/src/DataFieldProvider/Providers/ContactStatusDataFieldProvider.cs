using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using DataPlane.Client.Enterprise.Sync.Models.AccountDomain;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Models.CostarSync;
using EnrollmentPipeline.Services;
using Marketing.Enums;

namespace DataFieldProvider.Providers;

/// <summary>
/// Data field provider for contact status information
/// </summary>
public class ContactStatusDataFieldProvider(
	IDataPlaneService dataPlaneService,
	ILogger<ContactStatusDataFieldProvider> logger
) : DataFieldProvider<ContactStatusModel>(logger)
{
	protected override int ChunkSize => 300;
	protected override int MaxConcurrentChunks => 3;

	protected override async Task<IEnumerable<ContactStatusModel>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		// Batch Get Contact Accounts
		var contactAccounts = await dataPlaneService.GetBatchSyncModelAll<ContactAccount>(
			enrollments.Select(e => e.ContactId.ToString()), 
			BatchType.ContactAccount
		);

		// Create a lookup dictionary 
		var contactAccountLookup = contactAccounts.ToDictionary(ca => ca.ContactId, ca => ca);

		var results = new List<ContactStatusModel>();

		foreach (var enrollment in enrollments)
		{
			// Use the batched contact account data
			contactAccountLookup.TryGetValue(enrollment.ContactId, out var contactAccount);

			var statusModel = new ContactStatusModel
			{
				ContactID = enrollment.ContactId,
				ContactStatus = GetContactStatus(contactAccount, enrollment.BrandId).ToString()
			};

			results.Add(statusModel);
		}

		return results;
	}

	/// <summary>
	/// Determines contact status for a given contact account and marketing brand
	/// </summary>
	/// <param name="contactAccount">Contact account data</param>
	/// <param name="brand">Marketing brand to determine status logic</param>
	/// <returns>Contact status enum value</returns>
	private static ContactStatus GetContactStatus(ContactAccount? contactAccount, MarketingBrands brand)
	{
		//As we add logic for more brands, we can expand this switch statement
		switch (brand)
		{
			case MarketingBrands.Costar:
				// Check if the contact has a suite subscription
				if (contactAccount?.HasInfo == true)
				{
					return ContactStatus.Subscriber;
				}
				return ContactStatus.Prospect;
			default:
				return ContactStatus.Prospect;
		}
	}
}

public enum ContactStatus
{
	Prospect = 1,
	Subscriber = 2
}