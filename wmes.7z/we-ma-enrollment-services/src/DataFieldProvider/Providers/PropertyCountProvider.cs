using System.Text;
using System.Text.Json;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

/// <summary>
/// A provider that retrieves, via an ElasticSearch query, 
/// the count of properties associated with each contact.
/// </summary>
public class PropertyCountProvider(
	IHttpClientFactory clientFactory,
	ILogger<PropertyCountProvider> logger
) : DataFieldProvider<PropertyCountModel>(logger)
{
	private const string IndexName = "crm-commercial-properties.reader";

	public override int LookupPriority => 6;

	protected override async Task<IEnumerable<PropertyCountModel>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var contactIds = enrollments.Select(e => e.ContactId).Distinct().ToList();

		var countsByContact = await GetPropertyCountsForContactsAsync(contactIds, cancellationToken);

		return countsByContact;
	}

	/// <summary>
	/// Builds and sends an ElasticSearch aggregation query
	/// to get property counts for the specified contact IDs.
	/// </summary>
	private async Task<List<PropertyCountModel>> GetPropertyCountsForContactsAsync(
		List<int> contactIds,
		CancellationToken cancellationToken)
	{
		// TODO: Update this provider to use an IOpenSearchClient instance
		// instead of raw HttpClient calls for better error handling
		var client = clientFactory.CreateClient("OpenSearchClient");

		var requestUrl = $"{IndexName}/_search";

		var elasticQuery = BuildElasticSearchPayload(contactIds);

		var content = new StringContent(
			JsonSerializer.Serialize(elasticQuery),
			Encoding.UTF8,
			"application/json"
		);

		try
		{
			var response = await client.PostAsync(requestUrl, content, cancellationToken);
			response.EnsureSuccessStatusCode();

			var responseJson = await response.Content.ReadAsStringAsync(cancellationToken);
			return ParseElasticResponse(responseJson);
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Error retrieving property counts from ElasticSearch");
			throw;
		}
	}

	private object BuildElasticSearchPayload(List<int> contactIds)
	{
		return new
		{
			size = 0,
			query = new
			{
				nested = new
				{
					path = "contactDetails",
					query = new
					{
						terms = new Dictionary<string, IEnumerable<int>>
					{
						{ "contactDetails.contactId", contactIds }
					}
					}
				}
			},
			aggs = new
			{
				by_contact = new
				{
					nested = new
					{
						path = "contactDetails"
					},
					aggs = new
					{
						contacts = new
						{
							terms = new
							{
								field = "contactDetails.contactId",
								size = contactIds.Count
							}
						}
					}
				}
			}
		};
	}

	private List<PropertyCountModel> ParseElasticResponse(string responseJson)
	{
		var result = new List<PropertyCountModel>();
		var esResponse = JsonDocument.Parse(responseJson);

		try
		{
			var buckets = esResponse.RootElement.GetProperty("aggregations")
				.GetProperty("by_contact")
				.GetProperty("contacts")
				.GetProperty("buckets")
				.EnumerateArray();

			foreach (var bucket in buckets)
			{
				var contactId = bucket.GetProperty("key").GetInt32();
				var propertyCount = bucket.GetProperty("doc_count").GetInt32();

				result.Add(new PropertyCountModel
				{
					ContactID = contactId,
					CSOwnerSize = propertyCount
				});
			}

			return result;
		}
		catch (Exception ex)
		{
			logger.LogError(ex, "Error parsing ElasticSearch response for property counts");
			return result;
		}
	}
}
