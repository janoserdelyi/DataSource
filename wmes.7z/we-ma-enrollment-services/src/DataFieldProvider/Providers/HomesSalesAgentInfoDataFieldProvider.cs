using CoStar.Attachment.Entities;
using CoStar.Attachment.UriContracts;
using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using DataFieldProvider.Services;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using Nexus.Extensions;
using OpenSearch.Client;

namespace DataFieldProvider.Providers;

public class HomesSalesAgentInfoDataFieldProvider(
    IConfiguration configuration,
    ISalesAEService salesAeService,
    IQueryDispatcher queryDispatcher,
	ILogger<HomesSalesAgentInfoDataFieldProvider> logger
) : DataFieldProvider<HomesAccountExecutiveInfo>(logger)
{
    public override int LookupPriority => 2;
    protected override int ChunkSize => 2000;
    protected override int MaxConcurrentChunks => 5;

    private readonly FileUriTemplateFactory _fileUriFactory = new FileUriTemplateFactory(
            configuration["Attachments:Key"],
            configuration["Attachments:Vector"],
            [ configuration["Attachments:HostName"]! ]
        );

    protected override async Task<IEnumerable<HomesAccountExecutiveInfo>> GetData(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        CancellationToken cancellationToken)
    {
        var contactsWithSalesPeople = await salesAeService.GetSalesPeopleInformationForMarketingCloud(enrollments);

        if (contactsWithSalesPeople.Count == 0)
        {
            return [];
        }

        var result = new List<HomesAccountExecutiveInfo>();
        var salesPeopleInfo = await GetHomesSalesAgentInfo(contactsWithSalesPeople);

        foreach (var contact in contactsWithSalesPeople)
        {
            var salesPerson = salesPeopleInfo.FirstOrDefault(c => c.ContactId == contact.AEContactID);

            if (salesPerson != null)
            {
                result.Add(
                    new HomesAccountExecutiveInfo
                    {
                        ContactID = contact.ContactID,
                        AccountExecutive = salesPerson.GetFullName(),
                        AccountExecutivePhone = salesPerson.PhoneNumber,
                        AccountExecutiveEmail = salesPerson.EmailAddress,
                        AccountExecutiveAddress = salesPerson.GetFormattedAddress(),
                        AccountExecutivePhotoUri = GetSalesAgentPhotoUri(salesPerson)
                    }
                );
            }
        }

        return result;
    }

    private async Task<List<SalesAgentInfo>> GetHomesSalesAgentInfo(List<ContactAE> contactAEs)
    {
        var query = new GetSalesAgentsInfoByContactIdsQuery
        {
            ContactIds = contactAEs
                            .Select(c => c.AEContactID)
                            .Distinct()
                            .ToList()
        };

        var queryResult = await queryDispatcher.Dispatch<GetSalesAgentsInfoByContactIdsQuery, GetSalesAgentsInfoByContactIdsQueryResult>(query);

        return queryResult.SalesAgents;
    }

    private string? GetSalesAgentPhotoUri(SalesAgentInfo salesAgent)
    {
        if (salesAgent?.AttachmentMasterID == null || salesAgent?.AttachmentTypeExtensionID == null || 
            salesAgent?.AttachmentSourceID == null || string.IsNullOrEmpty(salesAgent?.CloudFolder))
        {
            logger.LogWarning($"Missing required attachment information for sales agent photo.");
            return null;
        }

        var extensionString = salesAgent.AttachmentTypeExtensionID?.ToString();
        if (string.IsNullOrEmpty(extensionString))
        {
            logger.LogWarning($"Invalid attachment extension for sales agent photo.");
            return null;
        }

        var fileReference = new AttachmentMaster((int)salesAgent.AttachmentMasterID, extensionString, salesAgent.CloudFolder)
        {
            IsWatermarkPreferred = false,
            AttachmentType = AttachmentType.PrimaryContactPhoto,
            AttachmentSource = (AttachmentSource)salesAgent.AttachmentSourceID,
        };

        var uriTemplate = _fileUriFactory?.CreateTemplateString(fileReference);

        return uriTemplate?.Replace("http://", "https://").Replace("{s}", ((int)ImageSize.H588W984).ToString());
    }
}