using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;
using OpenSearch.Client;

namespace DataFieldProvider.Providers;

public class MarketingContactDataLakeProvider(
    IOpenSearchClient openSearchClient,
    ILogger<MarketingContactDataLakeProvider> logger
) : DataFieldProvider<MarketingContactDataLake>(logger)
{
    /// <summary>
	/// Look up contact information first (things like EmailAddress, First/Last, Location, CountryCode, etc.)
	/// </summary>
	public override int LookupPriority => 1;
    protected override int ChunkSize => 2000;
    protected override int MaxConcurrentChunks => 3;

    protected override async Task<IEnumerable<MarketingContactDataLake>> GetData(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        CancellationToken cancellationToken)
    {
        var request = new SearchRequest<MarketingContactDataLake>("marketing-contact-data-lake.reader")
        {
            Size = this.ChunkSize,
            Query = new TermsQuery
            {
                Field = "_id",
                Terms = enrollments.Select(enrollment => enrollment.ContactId.ToString()).ToList()
            }
        };

        var response = await openSearchClient.SearchAsync<MarketingContactDataLake>(request);
        return response.Documents;
    }
}
