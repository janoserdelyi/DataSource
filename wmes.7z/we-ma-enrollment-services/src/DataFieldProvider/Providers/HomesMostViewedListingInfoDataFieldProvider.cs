using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;
using OpenSearch.Client;

namespace DataFieldProvider.Providers;

public class HomesMostViewedListingInfoDataFieldProvider (
    IOpenSearchClient openSearchClient,
	ILogger<HomesMostViewedListingInfoDataFieldProvider> logger
) : DataFieldProvider<HomesMostViewedListingInfo>(logger)
{
    public override int LookupPriority => 2;
    protected override int ChunkSize => 2000;
    protected override int MaxConcurrentChunks => 5;

    protected override async Task<IEnumerable<HomesMostViewedListingInfo>> GetData(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        CancellationToken cancellationToken)
    {
        var result = new List<HomesMostViewedListingInfo>();
        var request = new SearchRequest<HomesListing>("homes-listing.reader")
        {
            Query = new BoolQuery { 
                Should = enrollments.Select(enrollment => (QueryContainer)new NestedQuery
                {
                    Path = "agents",
                    Query = new MatchQuery
                    {
                        Field = "agents.contactId",
                        Query = enrollment.ContactId.ToString()
                    }
                })
                },
            Size = ChunkSize
        };

        var response = await openSearchClient.SearchAsync<HomesListing>(request);
        
        if (!response.IsValid)
        {
            logger.LogError(response.OriginalException, $"[{nameof(HomesMostViewedListingInfoDataFieldProvider)}] OpenSearch query failed: {response.OriginalException.Message}");
            return [];
        }

        foreach (var enrollment in enrollments)
        {
            var mostViewedListing = response.Documents
                .Where(listing => listing.Agents != null && listing.Agents.Any(agent => agent.ContactId == enrollment.ContactId))
                .OrderByDescending(listing => listing.ViewCountSevenDays)
                .FirstOrDefault(); // Get the most viewed listing

            var listingInfo = new HomesMostViewedListingInfo
            {
                ContactID = enrollment.ContactId,
                AgentRole = mostViewedListing?.GetAgentRole(enrollment.ContactId),
                TransactionType = mostViewedListing?.TransactionType?.ToString(),
                ListingPropertyUrl = mostViewedListing?.PropertyHomesUrl,
                ListingPrimaryImageUrl = mostViewedListing?.GetPrimaryListingImageUrl(),
                ListingStreet = mostViewedListing?.GetFormattedAddress(),
                ListingCity = mostViewedListing?.Address?.City,
                ListingState = mostViewedListing?.Address?.State,
                ListingZip = mostViewedListing?.Address?.Postcode
            };

            result.Add(listingInfo);
        }

        return result;
    }
}