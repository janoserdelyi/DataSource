using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Repositories;

namespace DataFieldProvider.Providers;

public class CampaignDataFieldProvider(
  ICampaignRepository campaignRepository,
  ILogger<CampaignDataFieldProvider> logger
) : DataFieldProvider<Campaign>(logger)
{
  protected override async Task<IEnumerable<Campaign>> GetData(
    IReadOnlyCollection<StagedEnrollment> enrollments,
    CancellationToken cancellationToken)
  {
    var campaignIds = enrollments.Select(c => c.MarketingCampaignId).Distinct().ToArray();
    var campaigns = await campaignRepository.GetCampaignsByIdAsync(campaignIds, useCache: true);

    return enrollments.Select(enrollment => {
      var marketingCampaign = campaigns.First(campaign => campaign.Id == enrollment.MarketingCampaignId);

      ArgumentNullException.ThrowIfNull(marketingCampaign);

      return new Campaign(marketingCampaign)
        .ForContact(enrollment.ContactId);
    });
  }
}
