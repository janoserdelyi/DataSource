using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Services;
using DataFieldProvider.Models;
using EnrollmentPipeline.Models;
using System.Text.Json;
using EnrollmentPipeline.Models.CostarSync;
using DataPlane.Client.Enterprise.Sync.Models.LocationDomain;

namespace DataFieldProvider.Providers;

/// <summary>
/// Retrieve the underlying location profiles, then return
/// the corresponding LocationProfileBusinessTypeModel objects
/// for each contact.
/// </summary>
public class LocationProfileProvider(
	IDataPlaneService dataPlaneService,
	HttpClient httpClient,
	ILogger<LocationProfileProvider> logger
) : DataFieldProvider<LocationProfileBusinessTypeModel>(logger)
{
	public override int LookupPriority => 7;

	protected override async Task<IEnumerable<LocationProfileBusinessTypeModel>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		// fetch all location profiles
		var locationIds = enrollments
			.Select(c => c.GetLocationId()?.ToString())
			.Where(id => id != null)
			.Select(id => id!)
			.Distinct()
			.ToList();

		var locationProfiles = await dataPlaneService
			.GetBatchSyncModelAll<LocationProfile>(locationIds, BatchType.LocationProfile)
			.ConfigureAwait(false);

		// figure out which languages we need
		var languages = enrollments
			.Select(enrollment => {
				var preferredLanguage = enrollment.DataFields["PreferredLanguage"]?.ToString();

				return string.IsNullOrWhiteSpace(preferredLanguage)
					? "en-US"
					: preferredLanguage;
			})
			.Distinct();

		// for each language, fetch the BusinessType translations
		var translationsByLang = new Dictionary<string, Dictionary<string, string>>();
		foreach (var lang in languages)
		{
			var httpResponse = await httpClient
				.GetAsync($"/localization/resources/BusinessType/allNames?c={lang}", cancellationToken)
				.ConfigureAwait(false);

			httpResponse.EnsureSuccessStatusCode();

			var json = await httpResponse.Content
				.ReadAsStringAsync()
				.ConfigureAwait(false);

			var resp = JsonSerializer
				.Deserialize<BusinessTypeResourceResponse>(json)
				?? throw new JsonException(
					$"Failed to deserialize BusinessTypeResourceResponse for '{lang}'");

			translationsByLang[lang] = resp.Resources;
		}

		// map each contact, profile, localized business type
		var results = new List<LocationProfileBusinessTypeModel>();
		foreach (var enrollment in enrollments)
		{
			var preferredLanguage = enrollment.DataFields["PreferredLanguage"]?.ToString();

			var lang = string.IsNullOrWhiteSpace(preferredLanguage)
				? "en-US"
				: preferredLanguage;

			var profile = locationProfiles
				.FirstOrDefault(p => p.LocationId == (enrollment.GetLocationId() ?? 0));
			if (profile == null) continue;

			var key = ((byte)profile.BusinessType).ToString();
			var translated = translationsByLang.TryGetValue(lang, out var map)
							 && map.TryGetValue(key, out var val)
				? val
				: profile.BusinessType.ToString();

			results.Add(new LocationProfileBusinessTypeModel
			{
				ContactID = enrollment.ContactId,
				BusinessType = translated
			});
		}

		return results;
	}
}
