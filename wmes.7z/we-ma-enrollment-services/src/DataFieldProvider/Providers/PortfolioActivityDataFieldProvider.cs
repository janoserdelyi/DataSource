﻿using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class PortfolioActivityDataFieldProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<PortfolioActivityDataFieldProvider> logger
) : DataFieldProvider<PortfolioActivity>(logger)
{
	protected override async Task<IEnumerable<PortfolioActivity>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments, 
		CancellationToken cancellationToken)
	{
		var query = new GetPortfolioActivityStatsQuery { ContactIds = enrollments.Select(e => e.ContactId).ToList() };

		var results = (await queryDispatcher
				.Dispatch<GetPortfolioActivityStatsQuery, IEnumerable<PortfolioActivity>>(query, cancellationToken)
			).ToList();

		return results;
	}
}
