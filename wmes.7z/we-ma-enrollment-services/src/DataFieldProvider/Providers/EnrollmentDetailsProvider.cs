using DataFieldProvider.Providers.Core;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using DataFieldProvider.DataAccess.Queries;

namespace DataFieldProvider.Providers;

public class EnrollmentDetailsProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<EnrollmentDetailsProvider> logger
) : DataFieldProvider<EnrollmentDetails>(logger)
{
	public override int LookupPriority => 10;

	protected override async Task<IEnumerable<EnrollmentDetails>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var contactEnrollmentDetails = await queryDispatcher.Dispatch<EnrollmentDetailsQuery, EnrollmentDetailsQueryResult>(new EnrollmentDetailsQuery { Contacts = enrollments });
		return contactEnrollmentDetails.ContactEnrollmentDetails;
	}
}
