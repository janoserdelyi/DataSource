using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class LoopNetBasicListerDataFieldProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<LoopNetBasicListerDataFieldProvider> logger
) : DataFieldProvider<BasicListerDetails>(logger)
{
	protected override async Task<IEnumerable<BasicListerDetails>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var query = new GetBasicListerDetailsListQuery { ContactListingIDs = [] };

		foreach (var enrollment in enrollments)
		{
			// If listing ID fails to parse (could be null or empty), then skip to next contact
			if (!int.TryParse(enrollment.DataFields["ListingId"]?.ToString(), out int listingId))
			{
				logger.LogWarning($"({nameof(this.GetData)}) Campaign (#{enrollment.MarketingCampaignId}) requires Loopnet Listing data fields but contact (#{enrollment.ContactId}) did not include Listing ID.");
				continue;
			}

			query.ContactListingIDs.Add(Tuple.Create(enrollment.ContactId, listingId));
		}

		var result = await queryDispatcher
			.Dispatch<GetBasicListerDetailsListQuery, GetBasicListerDetailsListQueryResult>(query, cancellationToken);

		return result.BasicListerDetailsList;
	}
}
