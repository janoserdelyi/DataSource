using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class ContactsResearcherDataFieldProvider(
	IQueryDispatcher queryDispatcher,
	ILogger<ContactsResearcherDataFieldProvider> logger
) : DataFieldProvider<ContactResearcher>(logger)
{
	protected override async Task<IEnumerable<ContactResearcher>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		CancellationToken cancellationToken)
	{
		var result = await queryDispatcher.Dispatch<GetContactsResearcherQuery, GetContactsResearcherQueryResult>(
			new GetContactsResearcherQuery { ContactIds = enrollments.Select(c => c.ContactId).ToList() });

		return result.ContactsResearchers;
	}
}
