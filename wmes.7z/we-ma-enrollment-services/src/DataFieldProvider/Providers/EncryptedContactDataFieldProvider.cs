using System.Security.Cryptography;
using System.Text;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers;

public class EncryptedContactDataFieldProvider(
	IConfiguration configuration,
	ILogger<EncryptedContactDataFieldProvider> logger
) : DataFieldProvider<EncryptedContact>(logger)
{
	private readonly string _encryptionKey = configuration.GetValue<string>("DataFieldProviders:EncryptedContact:key") ?? string.Empty;

	protected override Task<IEnumerable<EncryptedContact>> GetData(
		IReadOnlyCollection<StagedEnrollment> enrollment,
		CancellationToken cancellationToken)
	{
		return Task.FromResult(enrollment.Select(e => new EncryptedContact
		{
			ContactID = e.ContactId,
			EncryptedContactId = Encrypt(e.ContactId.ToString(), _encryptionKey)
		}));
	}

	private static string Encrypt(string text, string initializationVector)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(text);
		ArgumentException.ThrowIfNullOrWhiteSpace(initializationVector);

		var ivBytes = Encoding.UTF8.GetBytes(initializationVector);

		if (ivBytes.Length != 16)
		{
			throw new ArgumentException("Initialization vector must be 16 bytes");
		}

		using var aesAlgorithm = Aes.Create();
		using var encrypter = aesAlgorithm.CreateEncryptor(ivBytes, aesAlgorithm.IV);
		using var msEncrypt = new MemoryStream();
		using var csEncrypt = new CryptoStream(msEncrypt, encrypter, CryptoStreamMode.Write);
		using var swEncrypt = new StreamWriter(csEncrypt);

		swEncrypt.Write(text);
		swEncrypt.Flush();
		csEncrypt.FlushFinalBlock();

		var iv = aesAlgorithm.IV;
		var encryptedContent = msEncrypt.ToArray();

		// our full message is the IV followed by the encrypted bytes
		var result = new byte[iv.Length + encryptedContent.Length];
		Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
		Buffer.BlockCopy(encryptedContent, 0, result, iv.Length, encryptedContent.Length);

		return Convert.ToBase64String(result);
	}
}
