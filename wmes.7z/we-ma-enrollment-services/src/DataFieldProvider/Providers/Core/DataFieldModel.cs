﻿using System.Reflection;
using Marketing.Enums;

namespace DataFieldProvider.Providers.Core;

/// <summary>
/// Defines a model that contains Data Fields (fields marked with a <b>[CampaignDataField]</b> attribute)
/// which data is provided by a class that extends <see cref="DataFieldProvider{T}"/>.
/// <br/>
/// It has a mandatory `ContactId` field as it is used to link the data fields to a contact.
/// </summary>
public abstract class DataFieldModel
{
	/// <summary>
	/// Contact ID whose information in the model belongs to.
	/// </summary>
	public virtual int ContactID { get; set; }

	/// <summary>
	/// This method will recursively check all the properties of a type and return all that have the <see cref="DataFieldAttribute"/>.
	/// </summary>
	/// <returns>A <see cref="Dictionary{TKey,TValue}"/> where the DataField name is the key and the value is the field value.</returns>
	public Dictionary<string, object?> GetDataFieldsForBrand(MarketingBrands brand)
	{
		var dataFields = GetAllDataFields();
		var filteredFields = dataFields
					// Filters out fields that are not assignable to current brand
					.Where(field => field.Key.IsAssignableToBrand(brand))
					// Orders list to make the brand specific fields come first (overrides generic fields with the same name)
					.OrderByDescending(field => field.Key.Brands.Contains(brand))
					// Converts the filtered fields to a dictionary
					.ToDictionary(field => field.Key.FieldName, field => field.Value);

		return filteredFields;
	}

	/// <summary>
	/// This method will recursively check all the properties of a type and return all that have the <see cref="DataFieldAttribute"/>.
	/// </summary>
	/// <returns>A <see cref="Dictionary{TKey,TValue}"/> where the DataField attribute object is the key and the
	/// value is the field value</returns>
	public Dictionary<CampaignDataFieldAttribute, object?> GetAllDataFields()
	{
		var result = new Dictionary<CampaignDataFieldAttribute, object?>();

		var type = this.GetType();

		foreach (var property in type.GetProperties())
		{
			var attrs = property
				.GetCustomAttributes<CampaignDataFieldAttribute>()
				.ToList()
				.AsReadOnly();

			// If the property has one or more DataFieldLookup attributes
			if (attrs.Count > 0)
			{
				var value = property.GetValue(this);

				// Adds DataFields and value to result set
				foreach (var attr in attrs)
				{
					result.TryAdd(attr, value);
				}
				continue;
			}

			// If property is NOT of a type that extends DataFieldModel, then skip to next property
			if (!property.PropertyType.IsSubclassOf(typeof(DataFieldModel)))
				continue;

			var propertyValue = (DataFieldModel?)property.GetValue(this);

			// Gets the available Data Fields from the property
			var objectProps = propertyValue?
				.GetAllDataFields()
				.ToList();

			// Adds fields to result set
			objectProps?.ForEach(prop =>
			{
				result.TryAdd(prop.Key, prop.Value);
			});
		}

		return result;
	}
}
