namespace DataFieldProvider.Providers.Core;

public class DataFieldResult
{
	public required int ContactId { get; set; }
	public required int MarketingCampaignId { get; set; }
	public Dictionary<string, object?> DataFields { get; } = [];
}
