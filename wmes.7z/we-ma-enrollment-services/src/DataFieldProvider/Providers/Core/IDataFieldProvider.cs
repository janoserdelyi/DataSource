using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers.Core;

/// <summary>
/// A data provider for data fields marked with the [CampaignDataField] attribute.
/// </summary>
public interface IDataFieldProvider
{
	/// <summary>
	/// Returns the data model (Type) provided by the provider.
	/// </summary>
	public Type ModelType { get; }
	/// <summary>
	/// Defines the order in which the data field providers are called to look up data fields. The lower the number, the
	/// higher the priority. The higher priority (closer to 0) providers will be called first.
	/// Default: 5
	/// </summary>
	public int LookupPriority => 5;

	/// <summary>
	/// Retrieves the data fields for a given list of enrollments.
	/// </summary>
	/// <param name="enrollments">List of enrollments</param>
	/// <param name="cancellationToken"></param>
	/// <returns></returns>
	public Task<IEnumerable<DataFieldResult>> GetDataFields(IReadOnlyCollection<StagedEnrollment> enrollments, CancellationToken cancellationToken = default);
}
