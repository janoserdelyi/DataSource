﻿using System.Reflection;
using Marketing.Enums;

namespace DataFieldProvider.Providers.Core;

/// <summary>
/// Defines a <i>DataField</i> for marketing campaigns whose data will be provided by a <see cref="IDataFieldProvider"/> class.
/// The property's parent type <b>must</b> extend the <see cref="DataFieldModel"/> class.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
public class CampaignDataFieldAttribute : Attribute
{
	public string FieldName { get; }
	public List<MarketingBrands> Brands { get; } = [];

	public CampaignDataFieldAttribute(string fieldName, params MarketingBrands[] marketingBrands)
	{
		FieldName = fieldName;
		Brands.AddRange(marketingBrands);
	}

	/// <summary>
	/// Returns `true` when the Data Field caters to all or to the given brand.
	/// </summary>
	/// <param name="brand">Brand to look for</param>
	/// <returns></returns>
	public bool IsAssignableToBrand(MarketingBrands brand)
	{
		return Brands.Count == 0 || Brands.Contains(brand);
	}
}

/// <summary>
/// Set of extension methods to support the DataField operations.
/// </summary>
public static class CampaignDataFieldExtensions
{
	/// <summary>
	/// Checks if <paramref name="type"/> has a Data Field with the given name for the given brand.
	/// <br/>
	/// Throws an <see cref="ArgumentException"/> if <paramref name="type"/> does not inherit from
	/// <see cref="DataFieldModel"/> (directly or indirectly).
	/// </summary>
	/// <param name="type">Type <b>must</b> inherit from DataFieldModel</param>
	/// <param name="fieldName">Data field name</param>
	/// <param name="brand">Brand to look for</param>
	/// <returns></returns>
	public static bool HasDataFieldForBrand(this Type type, string fieldName, MarketingBrands brand)
	{
		if (!type.IsSubclassOf(typeof(DataFieldModel)))
		{
			throw new ArgumentException($"Type '{type.FullName}' is not a subclass of DataFieldModel.");
		}

		var props = type.GetProperties();

		return props.Any(prop => prop
			.GetCustomAttributes<CampaignDataFieldAttribute>()
			.Any(attr => attr.FieldName == fieldName && attr.IsAssignableToBrand(brand))
		);
	}
}
