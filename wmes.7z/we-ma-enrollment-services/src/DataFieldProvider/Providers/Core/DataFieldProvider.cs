using EnrollmentPipeline.Models;

namespace DataFieldProvider.Providers.Core;

/// <summary>
/// A DataFieldProvider provides data for the fields marked with the [CampaignDataField] attribute in the <typeparamref name="T">model</typeparamref>.
/// </summary>
/// <typeparam name="T">The model containing the data fields provided by this provider.
/// It must extend <see cref="DataFieldModel"/>.</typeparam>
public abstract class DataFieldProvider<T>(
	ILogger<DataFieldProvider<T>> logger
) : IDataFieldProvider where T : DataFieldModel
{
	/// <inheritdoc />
	public Type ModelType => typeof(T);

	/// <inheritdoc />
	public virtual int LookupPriority => 5;

	/// <summary>
	/// Maximum number of concurrent chunks.
	/// Default: 5
	/// </summary>
	protected virtual int MaxConcurrentChunks => 5;

	/// <summary>
	/// Number of contacts to be processed per chunk.
	/// Default: 5000
	/// </summary>
	protected virtual int ChunkSize => 5000;

	/// <inheritdoc />
	public async Task<IEnumerable<DataFieldResult>> GetDataFields(
		IReadOnlyCollection<StagedEnrollment> enrollments, CancellationToken cancellationToken = default)
	{
		var throttle = new SemaphoreSlim(MaxConcurrentChunks);
		var chunks = enrollments.Chunk(ChunkSize);

		var tasks = chunks.Select(async chunk =>
		{
			using (logger.BeginScope(
				new Dictionary<string, object?>
				{
					{"DataFieldProvider", GetType().FullName},
					{"ChunkSize", chunk.Length}
				}
			))
			{
				try
				{
					await throttle.WaitAsync(cancellationToken);

					return await GetData(chunk, cancellationToken);
				}
				catch (Exception ex)
				{
					logger.LogError(ex, $"Exception in DataFieldProvider {GetType().FullName}");
					
					// Returns an empty list on error to avoid failing the entire process
					return [];
				}
				finally
				{
					throttle.Release();
				}
			}
		});

		var allResults = (await Task.WhenAll(tasks)).SelectMany(result => result).ToList();

		// For each contact, retrieves the data fields and creates the DataFieldResult object
		var results = enrollments.Select(enrollment =>
		{
			var fieldResult = new DataFieldResult
			{
				ContactId = enrollment.ContactId,
				MarketingCampaignId = enrollment.MarketingCampaignId
			};

			var dataFieldsForContact = allResults.FirstOrDefault(res => res.ContactID == enrollment.ContactId)?.GetDataFieldsForBrand(enrollment.BrandId);

			if (dataFieldsForContact != null && dataFieldsForContact.Count > 0)
			{
				foreach (var field in dataFieldsForContact)
				{
					// Tries adding field to result (fails silently if a field with the same name already exists)
					fieldResult.DataFields.TryAdd(field.Key, field.Value);
				}
			}

			return fieldResult;
		});

		return results;
	}

	/// <summary>
	/// Retrieves the data models for a given list of contacts.
	/// </summary>
	/// <param name="enrollments"></param>
	/// <param name="cancellationToken"></param>
	/// <returns>List of models containing the data fields provided by this provider.</returns>
	protected abstract Task<IEnumerable<T>> GetData(IReadOnlyCollection<StagedEnrollment> enrollments, CancellationToken cancellationToken);
}
