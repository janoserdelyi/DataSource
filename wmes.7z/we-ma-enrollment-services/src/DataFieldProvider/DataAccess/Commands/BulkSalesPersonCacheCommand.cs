using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Commands;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Commands;

public class BulkSalesPersonCacheCommand
{
    public required IEnumerable<SalesPersonDetails> SalesPeopleDetails { get; set; }
}

public class BulkSalesPersonCacheCommandHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<BulkSalesPersonCacheCommandHandler> logger
) : CommandHandler<BulkSalesPersonCacheCommand>(logger)
{
    protected override async Task Handle(BulkSalesPersonCacheCommand command)
    {
        if (command.SalesPeopleDetails.Any())
        {
            var peopleList = command.SalesPeopleDetails.ToList().Select(c => c).Distinct();
            var upsertParam = new DataTable();
            upsertParam.Columns.Add("LocationID");
            upsertParam.Columns.Add("ContactID");
            upsertParam.Columns.Add("MarketingBrandID");
            upsertParam.Columns.Add("CoStarAssignmentTypeID");
            upsertParam.Columns.Add("SalesPersonContactID");
            upsertParam.Columns.Add("SalesTerritoryID");
            upsertParam.Columns.Add("SalesBusinessUnitID");
            upsertParam.Columns.Add("SalesBusinessUnitDesc");
            upsertParam.Columns.Add("FirstName");
            upsertParam.Columns.Add("LastName");
            upsertParam.Columns.Add("EmailAddress");
            upsertParam.Columns.Add("PhoneNumber");
            upsertParam.Columns.Add("PhoneExt");
            upsertParam.Columns.Add("PhoneNumberCountryCode");
            upsertParam.Columns.Add("JobTitle");

            foreach (var person in peopleList)
            {
                upsertParam.Rows.Add(
                person.LocationID,
                person.ContactID == null || person.ContactID == 0 ? null : person.ContactID,
                (int?)person.MarketingBrandID,
                (int?)person.CoStarAssignmentTypeID ?? null,
                person.SalesPersonContactID,
                person.SalesTerritoryID,
                (int?)person.SalesBusinessUnitID,
                person.SalesBusinessUnitDesc,
                person.FirstName,
                person.LastName,
                person.EmailAddress,
                person.PhoneNumber,
                person.PhoneExt,
                person.PhoneNumberCountryCode);
            }

            await connection.ExecuteAsync(
                "[dbo].[uspBulkSalesPersonCache]", new
                {
                    pSalesPeople = upsertParam
                },
                commandType: CommandType.StoredProcedure
                , commandTimeout: 300).ConfigureAwait(false);
        }
    }
}