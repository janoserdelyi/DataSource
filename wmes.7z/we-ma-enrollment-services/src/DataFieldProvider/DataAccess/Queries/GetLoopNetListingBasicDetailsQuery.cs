using System.Data;
using Dapper;
using DataFieldProvider.Models.Loopnet;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetLoopNetListingBasicDetailsQuery
{
    public required IReadOnlyCollection<int> ListingIds { get; set; }
}

public class GetLoopNetListingBasicDetailsQueryResult
{
    public required List<LoopNetListingDetails> ListingDetailsList { get; set; }
}

public class GetLoopNetListingBasicDetailsQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetLoopNetListingBasicDetailsQueryHandler> logger
) : QueryHandler<GetLoopNetListingBasicDetailsQuery, GetLoopNetListingBasicDetailsQueryResult>(logger)
{
    protected override async Task<GetLoopNetListingBasicDetailsQueryResult> Handle(GetLoopNetListingBasicDetailsQuery query)
    {
        var listingIds = new DataTable();
        listingIds.Columns.Add("Id", typeof(int));

        foreach (var id in query.ListingIds)
        {
            listingIds.Rows.Add(id);
        }

        var result = (await connection.QueryAsync<LoopNetListingDetails>(
                "loopnet.uspGetLoopNetBasicListingDetailsFields"
                , new { pListings = listingIds.AsTableValuedParameter("IdArrayType") }
                , commandType: CommandType.StoredProcedure
                , commandTimeout: (int?)TimeSpan.FromMinutes(5).TotalSeconds
            )
        ).ToList();

        return new GetLoopNetListingBasicDetailsQueryResult { ListingDetailsList = result };
    }
}