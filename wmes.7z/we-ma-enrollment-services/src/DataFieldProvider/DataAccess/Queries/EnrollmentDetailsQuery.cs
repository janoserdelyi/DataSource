using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.DataAccess.Queries;

public class EnrollmentDetailsQuery
{
	public required IEnumerable<StagedEnrollment> Contacts { get; set; }
}

public class EnrollmentDetailsQueryResult
{
	public required IEnumerable<EnrollmentDetails> ContactEnrollmentDetails { get; set; }
}

public class EnrollmentDetailsQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<EnrollmentDetailsQueryHandler> logger
) : QueryHandler<EnrollmentDetailsQuery, EnrollmentDetailsQueryResult>(logger)
{

	protected override async Task<EnrollmentDetailsQueryResult> Handle(EnrollmentDetailsQuery query)
	{
		var dtContacts = new DataTable();
		dtContacts.Columns.Add("Id", typeof(int));

		query.Contacts.ToList().ForEach(contact => dtContacts.Rows.Add(contact.ContactId));

		var result = await connection.QueryAsync<EnrollmentDetails>(
			"dbo.uspGetEnrollmentDetails"
			, new { ContactIds = dtContacts.AsTableValuedParameter("IdArrayType") }
			, commandType: CommandType.StoredProcedure
			, commandTimeout: (int)TimeSpan.FromMinutes(5).TotalSeconds
		);

		return new EnrollmentDetailsQueryResult { ContactEnrollmentDetails = result };
	}
}
