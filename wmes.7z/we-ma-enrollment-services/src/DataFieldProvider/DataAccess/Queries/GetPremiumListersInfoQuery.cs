using System.Data;
using Dapper;
using DataFieldProvider.Models.Loopnet.NewListingPremium;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetPremiumListersInfoQuery
{
	public required IReadOnlyCollection<int> ListerIds { get; set; }
}

public class GetPremiumListersInfoQueryResult
{
	public required IEnumerable<LoopnetPremiumLister> Listers { get; set; }
}

public class GetPremiumListersInfoQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetPremiumListersInfoQueryHandler> logger
) : QueryHandler<GetPremiumListersInfoQuery, GetPremiumListersInfoQueryResult>(logger)
{
	protected override async Task<GetPremiumListersInfoQueryResult> Handle(GetPremiumListersInfoQuery infoQuery)
	{
		var listerIds = new DataTable();
		listerIds.Columns.Add("Id");
		foreach(var listerId in infoQuery.ListerIds)
		{
			listerIds.Rows.Add(listerId);
		}

		var result = await connection.QueryAsync<LoopnetPremiumLister>(
			"[loopnet].[uspGetPremiumListersInfo]",
			new
			{
				listerIds = listerIds.AsTableValuedParameter("IdArrayType")
			},
			commandType: CommandType.StoredProcedure
		).ConfigureAwait(false);

		return new GetPremiumListersInfoQueryResult { Listers = result };
	}
}
