using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;

namespace DataFieldProvider.DataAccess.Queries;

public class GetSalesAgentsInfoByContactIdsQuery
{
    public required List<int> ContactIds { get; set; }
}

public class GetSalesAgentsInfoByContactIdsQueryResult
{
    public required List<SalesAgentInfo> SalesAgents { get; set; }
}

public class GetSalesAgentsInfoByContactIdsQueryHandler(
    IDbConnection connection,
    ILogger<GetSalesAgentsInfoByContactIdsQueryHandler> logger
) : QueryHandler<GetSalesAgentsInfoByContactIdsQuery, GetSalesAgentsInfoByContactIdsQueryResult>(logger)
{
    protected override async Task<GetSalesAgentsInfoByContactIdsQueryResult> Handle(GetSalesAgentsInfoByContactIdsQuery query)
    {
        var pContacts = new DataTable();
        pContacts.Columns.Add("Id");

        foreach (var id in query.ContactIds)
        {
            pContacts.Rows.Add(id);
        }
        
        var result = await connection.QueryAsync<SalesAgentInfo>(
            "[dbo].[uspGetSalesContacts]",
            new { pContacts },
            commandType: CommandType.StoredProcedure
        ).ConfigureAwait(false);

        return new GetSalesAgentsInfoByContactIdsQueryResult { SalesAgents = result.AsList() };
    }
}