using System.Data;
using Dapper;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;
using Marketing.Enums;

namespace DataFieldProvider.DataAccess.Queries;

public class ContactInfoQuery
{
    public int ContactId { get; set; }
}

public class ContactInfoQueryResult
{
    public int? ContactID { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? EmailAddress { get; set; }
    public string? LocationName { get; set; }
    public int? LocationId { get; set; }
    public string? CountryCode { get; set; }
    public string? State { get; set; }
    public Guid? Subject { get; set; }
    public string? PhoneNumber { get; set; }
    public string? PhoneExt { get; set; }
    public string? JobTitle { get; set; }
    public MarketingBrands? DeptBrand { get; set; }
}

public class ContactInfoQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<ContactInfoQueryHandler> logger
) : QueryHandler<ContactInfoQuery, ContactInfoQueryResult?>(logger)
{
    protected override async Task<ContactInfoQueryResult?> Handle(ContactInfoQuery query)
    {
        var result = await connection.QueryFirstOrDefaultAsync<ContactInfoQueryResult>(
            $"SELECT * FROM dbo.fnGetContactInfo({query.ContactId})",
            commandTimeout: 20 * 60, // 20 minute timeout
            commandType: CommandType.Text);

        return result;
    }
}