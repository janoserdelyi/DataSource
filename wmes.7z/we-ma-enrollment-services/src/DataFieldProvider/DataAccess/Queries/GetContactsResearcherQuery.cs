using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetContactsResearcherQuery
{
    public required List<int> ContactIds { get; set; }
}

public class GetContactsResearcherQueryResult
{
    public required List<ContactResearcher> ContactsResearchers { get; set; }
}

public class GetContactsResearcherQueryHandler (
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetContactsResearcherQueryHandler> logger
) : QueryHandler<GetContactsResearcherQuery, GetContactsResearcherQueryResult>(logger)
{
    protected override async Task<GetContactsResearcherQueryResult> Handle(GetContactsResearcherQuery query)
    {
        var contactIds = new DataTable();
        contactIds.Columns.Add("Id", typeof(int));
        query.ContactIds.ForEach(i => contactIds.Rows.Add(i));

        var result = await connection.QueryAsync<ContactResearcher>(
                "platform.uspGetContactsResearchers"
                , new { pContactIds = contactIds.AsTableValuedParameter("IdArrayType") }
                , commandType: CommandType.StoredProcedure
                , commandTimeout: (int?)TimeSpan.FromMinutes(5).TotalSeconds
            );

        return new GetContactsResearcherQueryResult { ContactsResearchers = result.ToList() };
    }
}
