using System.Data;
using Dapper;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class LoopNetSignatureAdListingDetailFields
{
    public int ListingID { get; set; }
    public int? PropertyTypeId { get; set; }
    public int? SubMarketId { get; set; }
    public int? ResearchMarketId { get; set; }
    public string? ExposureLevel { get; set; }
    public string? BillingStartDate { get; set; }
    public decimal? SalesPrice { get; set; }
}

public class LoopNetSignatureAdListingDetailFieldsQuery 
{
    public required List<int> ListingIDs { get; set; }
}

public class LoopNetSignatureAdListingDetailFieldsQueryResult
{
    public required List<LoopNetSignatureAdListingDetailFields> LoopNetSignatureAdListingDetailFieldsList { get; set; }
}

public class LoopNetSignatureAdListingDetailFieldsQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<LoopNetSignatureAdListingDetailFieldsQueryHandler> logger
) : QueryHandler<LoopNetSignatureAdListingDetailFieldsQuery, LoopNetSignatureAdListingDetailFieldsQueryResult>(logger)
{
    protected override async Task<LoopNetSignatureAdListingDetailFieldsQueryResult> Handle(LoopNetSignatureAdListingDetailFieldsQuery query)
    {
        var listingIDs = new DataTable();
        listingIDs.Columns.Add("Id", typeof(int));
        query.ListingIDs.ForEach(i => listingIDs.Rows.Add(i));

        var result = await connection.QueryAsync<LoopNetSignatureAdListingDetailFields>(
                "loopnet.uspGetSignatureAdListingsInLastDayFields"
                , new { pListings = listingIDs.AsTableValuedParameter("IdArrayType") }
                , commandType: CommandType.StoredProcedure
                , commandTimeout: (int?)TimeSpan.FromMinutes(5).TotalSeconds
            );

        return new LoopNetSignatureAdListingDetailFieldsQueryResult { LoopNetSignatureAdListingDetailFieldsList = result.ToList() };
    }
}