using System.Data;
using Dapper;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetCultureQuery
{
    public required int ContactID { get; set; }
    public required string Country { get; set; }
    public required string Subdivision { get; set; }
}

public class GetCultureQueryResult
{
    public string? Culture { get; set; }
}

public class GetCultureQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetCultureQueryHandler> logger
) : QueryHandler<GetCultureQuery, GetCultureQueryResult>(logger)
{
    protected override async Task<GetCultureQueryResult> Handle(GetCultureQuery query)
    {
        return new GetCultureQueryResult
        {
            Culture = await connection.QueryFirstOrDefaultAsync<string>(
                "platform.uspGetCulture"
                , param: new
                {
                    pContactID =  query.ContactID
                    , pCountry = query.Country
                    , pSubdivision = query.Subdivision
                }
                , commandType: CommandType.StoredProcedure
            )
        };
    }
}