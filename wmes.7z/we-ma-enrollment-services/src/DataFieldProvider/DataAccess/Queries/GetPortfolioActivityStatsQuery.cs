using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetPortfolioActivityStatsQuery
{
	public required IEnumerable<int> ContactIds { get; set; }
}

public class GetPortfolioActivityStatsQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetPortfolioActivityStatsQueryHandler> logger
) : QueryHandler<GetPortfolioActivityStatsQuery, IEnumerable<PortfolioActivity>>(logger)
{
	protected override async Task<IEnumerable<PortfolioActivity>> Handle(GetPortfolioActivityStatsQuery query)
	{
		var contactIds = new DataTable();
		contactIds.Columns.Add("Id");
		foreach(var contactId in query.ContactIds)
		{
			contactIds.Rows.Add(contactId);
		}

		var result = await connection.QueryAsync<PortfolioActivity>(
			"[loopnet].[uspGetPortfolioActivityStats]",
			new
			{
				contactIds = contactIds.AsTableValuedParameter("IdArrayType")
			},
			commandType: CommandType.StoredProcedure
		).ConfigureAwait(false);

		return result;
	}
}
