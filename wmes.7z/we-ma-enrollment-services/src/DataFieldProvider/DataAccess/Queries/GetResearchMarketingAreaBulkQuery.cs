using System.Data;
using Dapper;
using DataFieldProvider.Models;
using DataFieldProvider.Providers;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries.Platform;

public class GetResearchMarketingAreaBulkQuery
{
	public required List<ContactLocationPair> Locations { get; set; }
}

public class GetResearchMarketingAreaBulkQueryResult
{
	public required List<ResearchMarketAreaModel> ResearchMarketAreas { get; set; }
}

public class GetResearchMarketingAreaBulkQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetResearchMarketingAreaBulkQueryHandler> logger
) : QueryHandler<GetResearchMarketingAreaBulkQuery, GetResearchMarketingAreaBulkQueryResult>(logger)
{
	protected override async Task<GetResearchMarketingAreaBulkQueryResult> Handle(GetResearchMarketingAreaBulkQuery query)
	{
		var dt = new DataTable();
		dt.Columns.Add("ContactID", typeof(int));
		dt.Columns.Add("LocationID", typeof(int));

		foreach (var location in query.Locations)
		{
			dt.Rows.Add(location.ContactId, location.LocationId);
		}

		var dp = new DynamicParameters();
		dp.Add("Locations", dt.AsTableValuedParameter("dbo.ContactLocationType"));

		var marketAreas = await connection.QueryAsync<ResearchMarketAreaModel>("[platform].[uspGetResearchMarketAreaByLocationBulk]", param: dp, commandType: CommandType.StoredProcedure).ConfigureAwait(false);

		return new GetResearchMarketingAreaBulkQueryResult { ResearchMarketAreas = marketAreas.ToList() };
	}
}
