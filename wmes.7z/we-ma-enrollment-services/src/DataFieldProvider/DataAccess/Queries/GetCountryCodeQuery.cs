using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetCountryCultureQuery { }

public class GetCountryCultureQueryResult
{
    public required IEnumerable<CountryCultureResults> CountryCultures { get; set; }
}

public class GetCountryCultureQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetCountryCultureQueryHandler> logger
) : QueryHandler<GetCountryCultureQuery, GetCountryCultureQueryResult>(logger)
{
    protected override async Task<GetCountryCultureQueryResult> Handle(GetCountryCultureQuery query)
    {
        return new GetCountryCultureQueryResult
        {
            CountryCultures = await connection.QueryAsync<CountryCultureResults>(
                "platform.uspGetAllDefaultCultures", commandType: CommandType.StoredProcedure)
        };
    }
}