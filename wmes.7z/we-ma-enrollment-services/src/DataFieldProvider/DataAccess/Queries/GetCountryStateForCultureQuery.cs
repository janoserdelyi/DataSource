using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetCountryStateForCultureQuery {
    public required IEnumerable<int> ContactIds { get; set; }
}

public class GetCountryStateForCultureQueryResult
{
    public required IEnumerable<ContactCountryState> ContactCountryStates { get; set; }
}

public class GetCountryStateForCultureQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetCountryStateForCultureQueryHandler> logger
) : QueryHandler<GetCountryStateForCultureQuery, GetCountryStateForCultureQueryResult>(logger)
{
    protected override async Task<GetCountryStateForCultureQueryResult> Handle(GetCountryStateForCultureQuery query)
    {
        var ids = new DataTable();
        ids.Columns.Add("Id", typeof(int));
        query.ContactIds.ToList().ForEach(c => ids.Rows.Add(c));

        var pars = new DynamicParameters();
        pars.Add("pContactIds", ids.AsTableValuedParameter("IdArrayType"));

        var result = await connection.QueryAsync<ContactCountryState>(
            "platform.uspCountryStateForCulture"
            , pars
            , commandTimeout: 300 // 5 minute timeout
            , commandType: CommandType.StoredProcedure
        ).ConfigureAwait(false);

        return new GetCountryStateForCultureQueryResult
        {
            ContactCountryStates = result
        };
    }
}