﻿using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class CampaignDataFieldQuery
{
	public required int MarketingCampaignId { get; set; }
}

public class CampaignDataFieldQueryResult
{
	public required IEnumerable<CampaignDataField> CampaignDataFields { get; set; }
}

public class CampaignDataFieldQueryHandler(
	[FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
	ILogger<CampaignDataFieldQueryHandler> logger
	) : QueryHandler<CampaignDataFieldQuery, CampaignDataFieldQueryResult>(logger)
{
	protected override async Task<CampaignDataFieldQueryResult> Handle(CampaignDataFieldQuery query)
	{
		var result = await connection.QueryAsync<CampaignDataField>(
			"platform.uspGetMarketingCampaignDataField"
			, new { pMarketingCampaignId = query.MarketingCampaignId }
			, commandType: CommandType.StoredProcedure
		);

		return new CampaignDataFieldQueryResult { CampaignDataFields = result.AsList() };
	}
}
