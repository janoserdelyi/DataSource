using System.Data;
using Dapper;
using DataFieldProvider.Models;
using DataFieldProvider.Providers;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetSalesPeopleDetailsForHomeQuery
{
    public required IEnumerable<ContactLocationPair> ContactLocations { get; set; }
}

public class GetSalesPeopleDetailsForHomeQueryResult
{
    public IEnumerable<SalesPersonDetails> SalesPeopleDetails { get; set; } = [];
}

public class GetSalesPeopleDetailsForHomeQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetSalesPeopleDetailsForHomeQueryHandler> logger) 
    : QueryHandler<GetSalesPeopleDetailsForHomeQuery, GetSalesPeopleDetailsForHomeQueryResult>(logger)
{
    protected override async Task<GetSalesPeopleDetailsForHomeQueryResult> Handle(GetSalesPeopleDetailsForHomeQuery query)
    {
        if (query.ContactLocations.Any())
        {
            var upsertParam = new DataTable();
            upsertParam.Columns.Add("ContactID");
            upsertParam.Columns.Add("LocationID");

            foreach (var c in query.ContactLocations)
            {
                upsertParam.Rows.Add(
                c.ContactId,
                c.LocationId);
            }

            var result = await connection.QueryAsync<SalesPersonDetails>(
            "platform.uspGetHomeSalesPeople"
            , new
            {
                pContactLocations = upsertParam
            }
            , commandTimeout: 300 // 5 minute timeout
            , commandType: CommandType.StoredProcedure
            ).ConfigureAwait(false);

            return new GetSalesPeopleDetailsForHomeQueryResult
            {
                SalesPeopleDetails = result
            };
        }

        return new GetSalesPeopleDetailsForHomeQueryResult();
    }
}