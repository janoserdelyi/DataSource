using System.Data;
using Dapper;
using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetBasicListerDetailsListQuery
{
    public required List<Tuple<int, int>> ContactListingIDs { get; set; }
}

public class GetBasicListerDetailsListQueryResult
{
    public required List<BasicListerDetails> BasicListerDetailsList { get; set; }
}

public class GetBasicListerDetailsListQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetBasicListerDetailsListQueryHandler> logger
) : QueryHandler<GetBasicListerDetailsListQuery, GetBasicListerDetailsListQueryResult>(logger)
{

    protected override async Task<GetBasicListerDetailsListQueryResult> Handle(GetBasicListerDetailsListQuery query)
    {
        var contactListingIds = new DataTable();
        contactListingIds.Columns.Add("FirstId");
        contactListingIds.Columns.Add("SecondId");

        query.ContactListingIDs.ToList().ForEach(c =>
            contactListingIds.Rows.Add(c.Item1,
                                        c.Item2));

        var result = await connection.QueryAsync<BasicListerDetails>(
                "loopnet.uspGetLoopnetUpsellBasicFields"
                , new { pContactsWithListingID = contactListingIds.AsTableValuedParameter("IdWithIdArray") }
                , commandType: CommandType.StoredProcedure
                , commandTimeout: (int?)TimeSpan.FromMinutes(5).TotalSeconds
            );

        return new GetBasicListerDetailsListQueryResult { BasicListerDetailsList = result.ToList() };
    }
}