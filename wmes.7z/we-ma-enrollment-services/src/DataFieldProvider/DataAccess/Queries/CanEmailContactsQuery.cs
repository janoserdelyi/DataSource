using System.Data;
using Dapper;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries.Preferences;

public class CanEmailContactsQuery
{
	public required IEnumerable<StagedEnrollment> Contacts { get; set; }
}

public class CanEmailContact : DataFieldModel
{
	public int MarketingCampaignID { get; set; }
	public int MarketingBrandSegmentID { get; set; }
	public required string EmailAddress { get; set; }
	public required string CountryCode { get; set; }
	[CampaignDataField("CanEmail")]
	public bool CanEmail { get; set; }
	[CampaignDataField("IsUserSuppressed")]
	public bool IsUserSuppressed => !CanEmail;
}

public class CanEmailContactsQueryResult
{
	public required IEnumerable<CanEmailContact> CanEmailContacts { get; set; }
}

public class CanEmailContactsQueryHandler(
	[FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
	ILogger<CanEmailContactsQueryHandler> logger)
	: QueryHandler<CanEmailContactsQuery, CanEmailContactsQueryResult> (logger)
{

	protected override async Task<CanEmailContactsQueryResult> Handle(CanEmailContactsQuery query)
	{
		var dtContacts = new DataTable();
		dtContacts.Columns.Add("MarketingCampaignID", typeof(int));
		dtContacts.Columns.Add("ContactID", typeof(int));
		dtContacts.Columns.Add("EmailAddress", typeof(string));

		query.Contacts.ToList().ForEach(c => dtContacts.Rows.Add(c.MarketingCampaignId, c.ContactId, c.GetEmailAddress()));

		var result = await connection
			.QueryAsync<CanEmailContact>(
				"prefs.uspCanEmailContacts"
				, new { pCampaignContacts = dtContacts.AsTableValuedParameter("CampaignContactEmailType") }
				, commandType: CommandType.StoredProcedure
				, commandTimeout: (int)TimeSpan.FromMinutes(5).TotalSeconds
			);

		return new CanEmailContactsQueryResult { CanEmailContacts = result };
	}
}
