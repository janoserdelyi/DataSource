using System.Data;
using Dapper;
using DataFieldProvider.Models;
using DataPlane.Client.CoStar.WE.SalesTerritory.Enums;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Extensions;

namespace DataFieldProvider.DataAccess.Queries;

public class GetSalesPeopleDetailsByLocationIDsQuery {
    public required SalesBusinessUnit SalesBusinessUnit { get; set; }	
    public required IEnumerable<int> LocationIDs { get; set; }
}

public class GetSalesPeopleDetailsByLocationIDsQueryResult
{
    public required IEnumerable<SalesPersonDetails> SalesPeopleDetails { get; set; }
}

public class GetSalesPeopleDetailsByLocationIDsQueryHandler(
    [FromKeyedServices(DbConnectionType.SqlServer)] IDbConnection connection,
    ILogger<GetSalesPeopleDetailsByLocationIDsQueryHandler> logger
) : QueryHandler<GetSalesPeopleDetailsByLocationIDsQuery, GetSalesPeopleDetailsByLocationIDsQueryResult>(logger)
{

    protected override async Task<GetSalesPeopleDetailsByLocationIDsQueryResult> Handle(GetSalesPeopleDetailsByLocationIDsQuery query)
    {
        var ids = new DataTable();
        ids.Columns.Add("Id", typeof(int));
        query.LocationIDs.ToList().ForEach(c => ids.Rows.Add(c));

        var pars = new DynamicParameters();
        pars.Add("pLocationIDs", ids.AsTableValuedParameter("IdArrayType"));
        pars.Add("pSalesBusinessUnit", (int)query.SalesBusinessUnit);

        var result = await connection.QueryAsync<SalesPersonDetails>(
        "platform.uspGetLocationsAEs"
        , pars
        , commandTimeout: 300 // 5 minute timeout
        , commandType: CommandType.StoredProcedure
        ).ConfigureAwait(false);

        return new GetSalesPeopleDetailsByLocationIDsQueryResult
        {
            SalesPeopleDetails = result
        };

    }
}