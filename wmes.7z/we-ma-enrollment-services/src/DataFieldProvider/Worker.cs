using System.Runtime.CompilerServices;
using DataFieldProvider.Services;
using EnrollmentPipeline;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;

namespace DataFieldProvider;

/// <summary>
/// Implementation of StreamPipelineWorker for data field enrichment processing.
/// Retrieves and populates campaign-specific data fields for enrollments.
/// Uses Redis Streams for automatic load balancing and guaranteed delivery.
/// </summary>
public class Worker(
	IConnectionMultiplexer redis,
	IStreamMessagePublisher publisher,
	ILogger<Worker> logger,
	IServiceScopeFactory scopeFactory,
	IConfiguration configuration,
	HybridCache hybridCache
) : StreamPipelineWorker(redis, publisher, logger, scopeFactory, configuration, hybridCache)
{
	private readonly IServiceScopeFactory _scopeFactory = scopeFactory;
	public override string WorkerName => "data-field-provider";
	protected override int MaxBatchSize => 5000;
	protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);

	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		using var scope = _scopeFactory.CreateScope();
		var dataFieldService = scope.ServiceProvider.GetRequiredService<ICampaignDataFieldService>();
		var startTime = DateTimeOffset.UtcNow;

		// Stream results as they become available instead of waiting for entire batch
		await foreach (var enrollment in dataFieldService.RetrieveDataFields(enrollments, cancellationToken))
		{
			// If no data fields were populated, mark as failed
			if (enrollment.DataFields.Count == 0)
			{
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Failed)
					.WithReason(PipelineStatusReason.DataFieldLookupFailed)
					.WithMessage("No data fields were found for the enrollment.");
			}
			else
			{
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Success);
			}
		}
	}
}
