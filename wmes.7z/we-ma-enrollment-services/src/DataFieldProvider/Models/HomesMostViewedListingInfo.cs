using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class HomesMostViewedListingInfo : DataFieldModel
{
	public override required int ContactID { get => base.ContactID; set => base.ContactID = value; }
    [CampaignDataField("RoleOnListing", MarketingBrands.Homes)]
    public required string? AgentRole { get; set; }
    [CampaignDataField("TransactionType", MarketingBrands.Homes)]
    public required string? TransactionType { get; set; }
    [CampaignDataField("MostViewedListing7DaysPropertyURL", MarketingBrands.Homes)]
    public required string? ListingPropertyUrl { get; set; }
    [CampaignDataField("MostViewedListing7DaysPrimaryImageURL", MarketingBrands.Homes)]
    public required string? ListingPrimaryImageUrl { get; set; }
    [CampaignDataField("MostViewedListing7DaysStreetAddress", MarketingBrands.Homes)]
    public required string? ListingStreet { get; set; }
    [CampaignDataField("MostViewedListing7DaysCity", MarketingBrands.Homes)]
    public required string? ListingCity { get; set; }
    [CampaignDataField("MostViewedListing7DaysState", MarketingBrands.Homes)]
    public required string? ListingState { get; set; }
    [CampaignDataField("MostViewedListing7DaysZip", MarketingBrands.Homes)]
    public required string? ListingZip { get; set; }
}