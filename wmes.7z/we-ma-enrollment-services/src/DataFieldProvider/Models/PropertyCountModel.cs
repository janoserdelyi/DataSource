using DataFieldProvider.Providers.Core;

namespace DataFieldProvider.Models;

public class PropertyCountModel : DataFieldModel
{
	[CampaignDataField("CSOwnerSize")]
	public int CSOwnerSize { get; set; }
}
