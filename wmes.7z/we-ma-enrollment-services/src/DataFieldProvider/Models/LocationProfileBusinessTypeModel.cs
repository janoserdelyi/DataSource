using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class LocationProfileBusinessTypeModel : DataFieldModel
{
	[CampaignDataField("BusinessType", MarketingBrands.Costar)]
	public required string BusinessType { get; set; }
}
