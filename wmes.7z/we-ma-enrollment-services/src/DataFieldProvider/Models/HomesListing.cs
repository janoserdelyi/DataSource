namespace DataFieldProvider.Models;

public class HomesListing
{
    public int? Id { get; set; }
    public int? EnterpriseListingId { get; set; }
    public int? MlsListingId { get; set; }
    public int? MlsId { get; set; }
    public string? MlsNumber { get; set; }
    public decimal? Price { get; set; }
    public bool? SoldPriceNotDisclosed { get; set; }
    public bool? Has3DTour { get; set; }
    public DateTimeOffset? ListDate { get; set; }
    public decimal? SoldPrice { get; set; }
    public int? ListingStatus { get; set; }
    public int? NeighborhoodId { get; set; }
    public string? Neighborhood { get; set; }
    public MlsListing[]? MlsListings { get; set; }
    public int? Beds { get; set; }
    public int? BathsFull { get; set; }
    public int? BathsHalf { get; set; }
    public int? Baths { get; set; }
    public int? SquareFootSize { get; set; }
    public decimal? LotSize { get; set; }
    public double? ViewCount { get; set; }
    public double? ViewCountSevenDays { get; set; }
    public double? FavoriteCount { get; set; }
    public double? ShareCount { get; set; }
    public double? ImpressionCount { get; set; }
    public double? LeadCountAllTime { get; set; }
    public double? LeadCount90Days { get; set; }
    public int? YearBuilt { get; set; }
    public ResidentialListingMedia[]? Images { get; set; }
    public int? PropertyTypeId { get; set; }
    public DateTimeOffset? SoldDate { get; set; }
    public ResidentialListingOpenHouse[]? OpenHouses { get; set; }
    public int? ExposureLevel { get; set; }
    public DateTimeOffset? UpdatedDate { get; set; }
    public HomesAgentSlim[]? Agents { get; set; }
    public ResidentialListingAddress? Address { get; set; }
    public long? PropertyId { get; set; }
    public string? PostCode { get; set; }
    public string? SearchField { get; set; }
    public int? TransactionType { get; set; }
    public string? PropertyHomesUrl { get; set; }
    public int? ForSaleListingStatus { get; set; }
    public long? ResidentialAssetId { get; set; }
    public long? ResidentialPropertyId { get; set; }

    public string? GetPrimaryListingImageUrl()
        => Images?
            .OrderBy(image => image?.DisplayOrder ?? int.MaxValue)
            .FirstOrDefault()?
            .Url;

    public string? GetAgentRole(int contactId)
        => Agents?
            .FirstOrDefault(a => a?.ContactId.ToString() == contactId.ToString())?
            .Role
            .ToString();

    public string GetFormattedAddress() 
        => $"{Address?.StreetNumber ?? string.Empty} {Address?.StreetDirection ?? string.Empty} {Address?.StreetName ?? string.Empty} {Address?.StreetType ?? Address?.StreetSuffix ?? string.Empty} {Address?.UnitNumber ?? string.Empty}"
            .Trim();
}

public class MlsListing
{
    public int ListingId { get; set; }
    public int? MlsId { get; set; }
}

public class ResidentialListingMedia
{
    public long Id { get; set; }
    public int SourceID { get; set; }
    public string? SourceKey { get; set; }
    public int? MediaType { get; set; }
    public string? Caption { get; set; }
    public int? Size { get; set; }
    public int? DoNotDisplayFlags { get; set; }
    public string? Description { get; set; }
    public int? DisplayOrder { get; set; }
    public int? Height { get; set; }
    public int? Width { get; set; }
    public string? Url { get; set; }
}

public class ResidentialListingOpenHouse
{
    public long Id { get; set; }
    public int SourceId { get; set; }
    public string? SourceKey { get; set; }
    public DateTimeOffset? OpenHouseBegins { get; set; }
    public DateTimeOffset? OpenHouseClose { get; set; }
    public DateTimeOffset OpenHouseDate { get; set; }
    public int IsPublic { get; set; }
    public byte? PermissionLevel { get; set; }
    public int? OpenHouseType { get; set; }
    public int? OpenHouseMethod { get; set; }
    public int? OpenHouseStatus { get; set; }
    public string? Remarks { get; set; }
    public string? Refreshments { get; set; }
    public string? VirtualUrl { get; set; }
    public int? TimeZoneId { get; set; }
    public DateTimeOffset? OpenHouseBeginsUtc { get; set; }
    public DateTimeOffset? OpenHouseCloseUtc { get; set; }
    public int? Status { get; set; }
    public bool? Expired { get; set; }
}

public class HomesAgentSlim
{
    public int? ContactId { get; set; }
    public int? LocationId { get; set; }
    public string? LocationName { get; set; }
    public int? InheritProfileFromLocationId { get; set; }
    public int? HeadquartersLocationId { get; set; }
    public int? Role { get; set; }
    public int[]? Roles { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
}

public class ResidentialListingAddress
{
    public string? StreetNumber { get; set; }
    public string? Postcode { get; set; }
    public int? CountyId { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? StreetDirection { get; set; }
    public string? StreetSuffix { get; set; }
    public string? StreetType { get; set; }
    public string? StreetName { get; set; }
    public string? UnitNumber { get; set; }
    public string? CountryCode { get; set; }
}