namespace DataFieldProvider.Models;

public class ContactGlobalPreferences
{
	public int ContactId { get; set; }
	public Guid? Subject { get; set; }
	public string? Culture { get; set; }
}
