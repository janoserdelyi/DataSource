namespace DataFieldProvider.Models;

public class ListingActivitySummary
{
    public int TotalViews { get; set; }
    public int ProfileViews { get; set; }
    public int Reach { get; set; }
    public int AverageTimeOnPage { get; set; }
    public int TotalVisitors { get; set; }
    public int VirtualTours { get; set; }
    public int Frequency { get; set; }
    public int TotalTimeOnPage { get; set; }
}