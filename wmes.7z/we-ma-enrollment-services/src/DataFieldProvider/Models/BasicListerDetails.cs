using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class BasicListerDetails : DataFieldModel
{
    public required string ListingID { get; set; }

    [CampaignDataField("TotalListingViewsPerMarket", MarketingBrands.LoopNet)]
    public long TotalListingViewsPerMarket { get; set; }
}