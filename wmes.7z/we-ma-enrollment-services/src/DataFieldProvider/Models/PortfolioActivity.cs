﻿using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

/// <summary>
/// All values represent the last 30 days from <see cref="LastRun"/>.
/// </summary>
public class PortfolioActivity : DataFieldModel
{
	public int MostViewedListingId { get; set; }
	[CampaignDataField("PortfolioSearcherCount", MarketingBrands.LoopNet)]
	public int UniqueVisitors { get; set; }
	[CampaignDataField("UniqueVisitorsByMarketThirtyDays", MarketingBrands.LoopNet)]
	public int UniqueListingCount { get; set; }
	public int TotalViews { get; set; }
	[CampaignDataField("PortfolioVirtualTourCount", MarketingBrands.LoopNet)]
	public int DetailPageViews { get; set; }
	public int SearchImpressionViews { get; set; }
	public int TimeOnPageInSeconds { get; set; }
	[CampaignDataField("PortfolioHoursViewing", MarketingBrands.LoopNet)]
	public int TimeOnPageInHours => TimeOnPageInSeconds / 3600;
	public DateTime LastRun { get; set; }
}
