namespace DataFieldProvider.Models;

public class GlobalPreference
{
    public required string Identifier { get; set; }
    public object? Value { get; set; }
    public bool? IsDefault { get; set; }
}

public class GlobalPreferencesRegistry
{
    public required IEnumerable<GlobalPreferencesManifest> Manifests { get; set; }
}

public class GlobalPreferencesManifest
{
	public int? AccessLevel { get; set; }
	public DateTime? UpdatedTime { get; set; }
	public int? CurrentStatus { get; set; }
	public int? Type { get; set; }
	public string? Identifier { get; set; }
	public IEnumerable<GlobalPreferencesAllowedValues>? AllowedValues { get; set; }
}

public class GlobalPreferencesAllowedValues
{
    public int? Id { get; set; }
    public object? Value { get; set; }
}

public class ContactGlobalPreferenceRequest
{
	public int ContactID { get; set; }
	public int? LocationID { get; set; }
	public string? CountryCode { get; set; }
	public string? State { get; set; }
}

public class GlobalPreferencesBulkResponse
{
	public IEnumerable<GlobalPreferencesBulkResponseUserPreferences> UserPreferences { get; set; } = [];
}

public class GlobalPreferencesBulkResponseUserPreferences
{
    public required string Uuid { get; set; }
    public required IEnumerable<GlobalPreference> Preferences { get; set; }
}

public class GlobalPreferencesBulkRequest
{
    public required GlobalPreferencesBulkRequestUserPreferences UserPreferences { get; set; }
}

public class GlobalPreferencesBulkRequestUserPreferences
{
	public required IEnumerable<string> Uuids { get; set; }
}