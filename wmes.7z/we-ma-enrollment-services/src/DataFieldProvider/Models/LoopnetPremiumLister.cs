using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models.Loopnet.NewListingPremium;

public class LoopnetPremiumLister : DataFieldModel
{
	[CampaignDataField("PaidListingsCount", MarketingBrands.LoopNet)]
	public int? PremiumListingCount { get; set; }
	[CampaignDataField("ActiveListingsCount", MarketingBrands.LoopNet)]
	public int? TotalActiveListings { get; set; }
}
