namespace DataFieldProvider.Models;

public class BusinessTypeResourceResponse
{
	public Dictionary<string, string> Resources { get; set; } = [];
}