using DataFieldProvider.Providers.Core;

namespace DataFieldProvider.Models;

public class WeeklyAdvertiserFields : DataFieldModel
{
	[CampaignDataField("ListingImageUrl")]
	public string? ListingImageUrl { get; set; }

	[CampaignDataField("LPRUniqueId")]
	public string? LPRUniqueId { get; set; }
}
