using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class ResearchMarketAreaModel : DataFieldModel
{
	[CampaignDataField("ResearchMarketArea", MarketingBrands.Costar)]
	public required string ResearchMarketArea { get; set; }
}
