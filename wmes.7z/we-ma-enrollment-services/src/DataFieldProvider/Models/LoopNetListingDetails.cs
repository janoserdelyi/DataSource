using System.Text.RegularExpressions;
using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models.Loopnet;

public class LoopNetListingDetails : DataFieldModel
{
	public int ListingId { get; set; }

	[CampaignDataField("MarketName", MarketingBrands.LoopNet)]
	[CampaignDataField("DominantMarket", MarketingBrands.LoopNet)]
	[CampaignDataField("ResearchMarketName", MarketingBrands.LoopNet)]
	public string? ResearchMarketName { get; set; }

	[CampaignDataField("UniqueViewerCountPerMarket", MarketingBrands.LoopNet)]
	public string? UniqueVisitorCount { get; set; }

	[CampaignDataField("ListingCity", MarketingBrands.LoopNet)]
	public string? ListingCity { get; set; }

	[CampaignDataField("ListingState", MarketingBrands.LoopNet)]
	public string? ListingState { get; set; }

	[CampaignDataField("ListingAddress", MarketingBrands.LoopNet)]
	public string? ListingAddress { get; set; }

	[CampaignDataField("ListingImageUrl", MarketingBrands.LoopNet)]
	public string? ListingImageUrl { get; set; }

	[CampaignDataField("LPRUrl", MarketingBrands.LoopNet)]
	public string? ListingPerformanceReportUrl { get; set; }

	[CampaignDataField("LDPViewsThirtyDaysCSLN", MarketingBrands.LoopNet, MarketingBrands.Costar)]
	public long LDPViewsThirtyDaysCSLN { get; set; }

	[CampaignDataField("ViewCount30DaysCSLN", MarketingBrands.LoopNet, MarketingBrands.Costar)]
	public long ViewCount30DaysCSLN { get; set; }

	[CampaignDataField("LPRUniqueId", MarketingBrands.LoopNet)]
	public string? LprUniqueId {
		get
		{
			if (string.IsNullOrEmpty(this.ListingPerformanceReportUrl))
			{
				return string.Empty;
			}

			// Example for the following URL:
			// https://listingmanager-tst-main.costar.com/listingperformancereport/shared/QbIdrY8GF66cfK9CoGcruQfznBpeIDuU4rWo_QojjQQpwiw6B3Kzebt11-RaqR2W
			// We want to return the unique ID after `listingperformancereport/shared/`
			var match = Regex.Match(this.ListingPerformanceReportUrl, "^(.*listingperformancereport/shared/)(.*)$");

			// The value in the second match group should be the unique ID
			var lprUniqueId = !string.IsNullOrEmpty(match.Groups[2]?.Value) ? match.Groups[2].Value : string.Empty;

			return lprUniqueId;
		}
	}
}
