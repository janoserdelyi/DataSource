using System.Text.Json.Serialization;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class CampaignDataField
{
	public required short MarketingCampaignId { get; set; }
	public required MarketingBrands MarketingBrandId { get; set; }
	public required string FieldName { get; set; }
}

public class CampaignDataFieldComparer : IEqualityComparer<CampaignDataField>
{
	public bool Equals(CampaignDataField? x, CampaignDataField? y)
	{
		if (x == null || y == null || x.GetType() != y.GetType())
			return false;

		if (ReferenceEquals(x, y))
			return true;

		return x.MarketingBrandId == y.MarketingBrandId && string.Equals(x.FieldName, y.FieldName, StringComparison.InvariantCultureIgnoreCase);
	}

	public int GetHashCode(CampaignDataField obj)
	{
		var hashCode = new HashCode();
		hashCode.Add(obj.FieldName, StringComparer.InvariantCultureIgnoreCase);
		hashCode.Add(obj.MarketingBrandId);

		return hashCode.ToHashCode();
	}
}
