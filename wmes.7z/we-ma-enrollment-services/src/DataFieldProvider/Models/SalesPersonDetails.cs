using DataPlane.Client.CoStar.WE.SalesTerritory.Enums;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class SalesPersonDetails
{
    public int LocationID { get; set; }
    public int? ContactID { get; set; }
    public int SalesPersonContactID { get; set; }
    public int? SalesTerritoryID { get; set; }
    public CoStarAssignmentType? CoStarAssignmentTypeID { get; set; }
    public SalesBusinessUnit SalesBusinessUnitID { get; set; }
    public string? SalesBusinessUnitDesc { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? EmailAddress { get; set; }
    public string? PhoneNumber { get; set; }
    public string? PhoneExt { get; set; }
    public string? PhoneNumberCountryCode { get; set; }
    public string? MobilePhone { get; set; }
    public string? MobilePhoneCountryCode { get; set; }
    public string? JobTitle { get; set; }
    public MarketingBrands? MarketingBrandID { get; set; }
    public bool IsFromCacheTable { get; set; }

    public ContactAE ToContactAE(int contactId)
	{
		return new ContactAE
		{
			ContactID = contactId,
			AEContactID = SalesPersonContactID,
			LocationID = LocationID,
			AEFirstName = FirstName ?? string.Empty,
			AELastName = LastName ?? string.Empty,
			AEEmailAddress = EmailAddress ?? string.Empty,
			AEPhoneNumber = PhoneNumber ?? string.Empty,
			AEPhoneExt = PhoneExt ?? string.Empty,
			AEPhoneNumberCountryCode = PhoneNumberCountryCode ?? string.Empty,
			AEMobilePhone = MobilePhone ?? string.Empty,
			AEMobilePhoneCountryCode = MobilePhoneCountryCode ?? string.Empty,
			AEJobTitle = JobTitle ?? string.Empty,
			MarketingBrand = MarketingBrandID
		};
	}
}