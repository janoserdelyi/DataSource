using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models.Loopnet;

public class LoopNetSignatureAdListingFields : DataFieldModel
{
	[CampaignDataField("ContactType", MarketingBrands.LoopNet)]
	public string? ContactType { get; set; }

	[CampaignDataField("ExposureLevel", MarketingBrands.LoopNet)]
	public string? ExposureLevel { get; set; }

	[CampaignDataField("BillingStartDate", MarketingBrands.LoopNet)]
	public string? BillingStartDate { get; set; }

	[CampaignDataField("ListingImpressionCount", MarketingBrands.LoopNet)]
	public string? ListingImpressionCount { get; set; }

	[CampaignDataField("ListingVirtualTourCount", MarketingBrands.LoopNet)]
	public string? ListingVirtualTourCount { get; set; }

	[CampaignDataField("CompetitorAddress", MarketingBrands.LoopNet)]
	public string? CompetitorAddress { get; set; }

	[CampaignDataField("ServicingRepEmail", MarketingBrands.LoopNet)]
	public string? ServicingRepEmail { get; set; }

	[CampaignDataField("ServicingRepName", MarketingBrands.LoopNet)]
	public string? ServicingRepName { get; set; }
}
