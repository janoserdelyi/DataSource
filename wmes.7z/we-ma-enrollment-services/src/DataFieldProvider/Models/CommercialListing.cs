using OpenSearch.Client;

namespace DataFieldProvider.Models;

public class CommercialListing
{
	public string? AddressStreetNumber;
	public string? AddressStreetType;
	public string? AddressStreetName;
}

public class CommercialListingSearch
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? StreetAddress { get; set; }
    public GeoLocation? GeoLocation { get; set; }
    public CommercialListing? Document { get; set; }
}

public class CommercialListingServicing
{
    public int Id { get; set; }
    public int SalePersonContactId { get; set; }
    public int? PrimarySubmarketId { get; set; }
    public string? PrimarySubmarketName { get; set; }
    public List<Broker>? Brokers { get; set; }
    public List<Attachment>? Attachments { get; set; }
}

public class Broker
{
	public int Id { get; set; }
	public int? LocationId { get; set; }
	public string? FirstName { get; set; }
	public string? LastName { get; set; }
	public string? PhoneNumber { get; set; }
	public string? PhoneNumberCountryCode { get; set; }
	public string? LocationName { get; set; }
}

public class Attachment
{
	public int AttachmentMasterId { get; set; }
	public int? AttachmentTypeId { get; set; }
	public int? AttachmentSourceId { get; set; }
	public int? AttachmentTypeExtensionId { get; set; }
	public string? Caption { get; set; }
	public string? Checksum { get; set; }
	public string? CloudFolder { get; set; }
	public string? Uri { get; set; }
	public bool IsPublished { get; set; }
}