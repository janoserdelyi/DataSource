using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.Models;
using Marketing.Enums;

namespace DataFieldProvider.Models
{
	/// <summary>
	/// MarketingCampaign Table Model
	/// </summary>
	public class Campaign(MarketingCampaign marketingCampaign) : DataFieldModel
	{
		public int MarketingCampaignID { get; set; } = marketingCampaign.MarketingCampaignId;
		[CampaignDataField("JourneyID")]
		public string? SFCampaignID { get; set; } = marketingCampaign.SfCampaignId;

		[CampaignDataField("CallTrackingNumber")]
		// TODO: Figure out how to handle multiple CTNs
		// For now, just take the first one if it exists
		public string? CallTrackingNumber { get; set; } = marketingCampaign.Ctns.FirstOrDefault()?.CallTrackingNumber;

		/// <summary>
		/// Sets ContactID to associate with this Campaign object (used by the DataFieldProvider)
		/// </summary>
		/// <param name="contactId"></param>
		/// <returns></returns>
		public Campaign ForContact(int contactId)
		{
			this.ContactID = contactId;
			return this;
		}
	}
}
