using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class ContactAE : DataFieldModel
{
    public int LocationID { get; set; }
    public MarketingBrands? MarketingBrand { get; set; }

    [CampaignDataField("AEContactID", MarketingBrands.LoopNet, MarketingBrands.Apartments)]
    public int AEContactID { get; set; }

    [CampaignDataField("AEFirstName", MarketingBrands.LoopNet, MarketingBrands.Costar)]
    public string? AEFirstName { get; set; }

    [CampaignDataField("AELastName", MarketingBrands.LoopNet, MarketingBrands.Costar)]
    public string? AELastName { get; set; }

    [CampaignDataField("AEEmailAddress", MarketingBrands.LoopNet, MarketingBrands.Costar)]
    public string? AEEmailAddress { get; set; }

    [CampaignDataField("AEPhone", MarketingBrands.LoopNet, MarketingBrands.Costar, MarketingBrands.Apartments)]
    public string? AEPhoneNumber { get; set; }

    [CampaignDataField("AEPhoneExtension", MarketingBrands.LoopNet, MarketingBrands.Apartments, MarketingBrands.Costar)]
    public string? AEPhoneExt { get; set; }

    [CampaignDataField("AEPhoneNumberCountryCode", MarketingBrands.LoopNet)]
    public string? AEPhoneNumberCountryCode { get; set; }

    [CampaignDataField("AEMobilePhone", MarketingBrands.Apartments)]
    public string? AEMobilePhone { get; set; }

    [CampaignDataField("AEMobilePhoneCountryCode", MarketingBrands.Apartments)]
    public string? AEMobilePhoneCountryCode { get; set; }

    [CampaignDataField("AETitle", MarketingBrands.LoopNet, MarketingBrands.Costar, MarketingBrands.Apartments)]
    public string? AEJobTitle { get; set; }

    [CampaignDataField("AEFullName", MarketingBrands.LoopNet, MarketingBrands.Apartments)]
    public string AEFullName => $"{AEFirstName} {AELastName}";

    [CampaignDataField("AEImageURL", MarketingBrands.LoopNet)]
    public string? AEImageURL { get; set; }
}
