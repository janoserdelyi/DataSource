namespace DataFieldProvider.Models;

public class CountryCultureResults
{
    public required string Country { get; set; }
    public required string CultureCode { get; set; }
    public string? Subdivision { get; set; }
}