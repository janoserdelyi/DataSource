using System;
using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models.Apartments;

public class ApartmentsMarketingDataLake : DataFieldModel
{
	public int? Id { get; set; }
	[CampaignDataField("PropertyID", MarketingBrands.Apartments)]
	public int? PropertyID { get; set; }
	[CampaignDataField("CommunityName", MarketingBrands.Apartments)]
	public string? CommunityName { get; set; }

	[CampaignDataField("CommunityCity", MarketingBrands.Apartments)]
	public string? CommunityCity { get; set; }
	[CampaignDataField("UnitCount", MarketingBrands.Apartments)]
	public int? UnitCount { get; set; }

	[CampaignDataField("BillingRenewalDate", MarketingBrands.Apartments)]
	public DateTime? BillingRenewalDate { get; set; }

	[CampaignDataField("BillingTerm", MarketingBrands.Apartments)]
	public string? BillingTerm { get; set; }

	[CampaignDataField("ContractStartDate", MarketingBrands.Apartments)]
	public DateTime? ContractStartDate { get; set; }

	[CampaignDataField("MembershipLevel", MarketingBrands.Apartments)]
	public string? MembershipLevel { get; set; }

	[CampaignDataField("ContactType", MarketingBrands.Apartments)]
	public long? ContactType { get; set; }
}
