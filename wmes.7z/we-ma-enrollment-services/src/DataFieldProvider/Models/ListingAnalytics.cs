namespace DataFieldProvider.Models;

public class ListingAnalytics
{
    public int ListingId { get; set; }
    public string? Url { get; set; }
}