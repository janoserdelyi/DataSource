namespace DataFieldProvider.Providers;

public class ContactLocationPair
{
    public int ContactId { get; set; }
    public int LocationId { get; set; }
}