using System.Text.RegularExpressions;

namespace DataFieldProvider.Models;

public class SalesAgentInfo
{
	public int ContactId { get; set; }
	public string? FirstName { get; set; }
	public string? LastName { get; set; }
	public string? PhoneNumber { get; set; }
	public string? EmailAddress { get; set; }
	public int? AttachmentMasterID { get; set; }
	public string? StreetNum { get; set; }
	public string? StreetDirection { get; set; }
	public string? StreetName { get; set; }
	public string? StreetType { get; set; }
	public string? StreetSuffix { get; set; }
	public string? City { get; set; }
	public string? PostalCode { get; set; }
	public string? State { get; set; }
	public string? CountryCode { get; set; }
	public int? AttachmentSourceID { get; set; }
	public int? AttachmentTypeExtensionID { get; set; }
	public string? CloudFolder { get; set; }

    public string GetFullName() => $"{FirstName} {LastName}".Trim();

    public string GetFormattedAddress() {
        var formattedAddress = $"{StreetName} {City} {State} {PostalCode}".Replace("null", "").Trim();

        return Regex.Replace(formattedAddress, @"\s+", " ");
    }
}
