namespace DataFieldProvider.Models;

public class ContactCountryState
{
    public int ContactID { get; set; }
    public string? CountryCode { get; set; }
    public string? State { get; set; }
}