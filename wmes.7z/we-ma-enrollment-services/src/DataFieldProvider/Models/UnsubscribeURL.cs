using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class UnsubscribeURL : DataFieldModel
{
    [CampaignDataField("UnsubscribeURL", MarketingBrands.Homes)]
    public string Link { get; set; } = string.Empty;
}