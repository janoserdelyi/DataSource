using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class EnrollmentDetails : DataFieldModel
{
	[CampaignDataField("EnrollmentMethod")]
	public string? EnrollmentMethod { get; set; }

	[CampaignDataField("EnrollmentSource")]
	public ChannelSource? EnrollmentSource { get; set; }

	[CampaignDataField("EnrollmentDate")]
	public DateTime EnrollmentDate { get; set; } = DateTime.Now;
}
