using DataFieldProvider.Providers.Core;
using Enterprise.Data.Values;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class MarketingContactDataLake : DataFieldModel
{
    [CampaignDataField("ContactID")]
    public required override int ContactID { get => Id; set => Id = value; }
    public int Id { get; set; }
    public string? FirstName { get; set; }
    public string? FirstNameLocal { get; set; } // Missing
    [CampaignDataField("FirstName")]
    public string? FirstNameValue => string.IsNullOrWhiteSpace(FirstNameLocal) ? FirstName : FirstNameLocal;
    public string? LastName { get; set; }
    public string? LastNameLocal { get; set; } // Missing
    [CampaignDataField("LastName")]
    public string? LastNameValue => string.IsNullOrWhiteSpace(LastNameLocal) ? LastName : LastNameLocal;
    public string? FullName { get; set; }
    [CampaignDataField("FullName")]
    public string? FullNameValue => !string.IsNullOrWhiteSpace(FullName) ? FullName : $"{FirstNameValue} {LastNameValue}".Trim();
    [CampaignDataField("EmailAddress")]
    public required string EmailAddress
    {
        get;
        set => field = string.IsNullOrEmpty(value) ? string.Empty : value.Trim().ToLowerInvariant();
    }
    [CampaignDataField("Title")]
    public string? JobTitle { get; set; }
    [CampaignDataField("Phone")]
    public string? Phone { get; set; }
    public string? PhoneCountryCode { get; set; }
    [CampaignDataField("Country")]
    [CampaignDataField("CountryCode")]
    public string? CountryCode { get; set; }
    [CampaignDataField("CreatedSource")]
    public ContactSourceType ContactSourceType { get; set; }
    [CampaignDataField("Subject")]
    public Guid? Subject { get; set; }
    public LocationDetails? LocationDetails { get; set; }
    public AddressDetails? AddressDetails { get; set; }
    public UserPreferences? UserPreferences { get; set; }
    public MarketingLocationAccount? MarketingLocationAccount { get; set; }

    [CampaignDataField("PreferredLanguage")]
    public string PreferredLanguage => UserPreferences?.CultureCode ?? "en-US"; // Default to "en-US" if not specified
    [CampaignDataField("State")]
    public string? State => AddressDetails?.State;
    [CampaignDataField("Zip")]
    [CampaignDataField("PostalCode")]
    public string? PostalCode => AddressDetails?.Postcode;
    [CampaignDataField("LocationID")]
    public int? LocationID => LocationDetails?.LocationID;
    [CampaignDataField("LocationName")]
    public string? LocationName => LocationDetails?.LocationName;
    [CampaignDataField("HQLocationID")]
    public long? HeadquartersLocationId => LocationDetails?.HeadquartersLocationId;
    [CampaignDataField("HQLocationName")]
    public string? HeadquartersLocationName => LocationDetails?.HeadquartersLocationName;
    [CampaignDataField("IsClient", MarketingBrands.BusinessImmo)]
    public bool? IsBusinessImmoClient => MarketingLocationAccount?.HasBusinessImmo;
}

public class UserPreferences
{
    public string? CultureCode { get; set; }
    public string? AreaUnit { get; set; }
    public string? Currency { get; set; }
    public string? DistanceUnit { get; set; }
    public List<Preference>? Preferences { get; set; }
}

public class Preference
{
    public string? Identifier { get; set; }
    public string? Value { get; set; }
    public bool IsDefault { get; set; }
    public string? Display { get; set; }
}

public class AddressDetails
{
    public string? City { get; set; }
    public string? Postcode { get; set; }
    public string? State { get; set; }
}

public class LocationDetails
{
    public int? LocationID { get; set; }
    public string? LocationName { get; set; }
    public int? BusinessSubtype { get; set; }
    public int? BusinessType { get; set; }
    public long? HeadquartersLocationId { get; set; }
    public string? HeadquartersLocationName { get; set; }
    public int? IndustryType { get; set; }
}

public class MarketingLocationAccount
{
    public bool? HasApts { get; set; }
    public bool? HasBusinessImmo { get; set; }
    public bool? HasCma { get; set; }
    public bool? HasComps { get; set; }
    public bool? HasInfo { get; set; }
    public bool? HasLoopNet { get; set; }
    public bool? HasPPR { get; set; }
    public bool? HasProperty { get; set; }
    public bool? HasRealEstateManager { get; set; }
    public bool? HasResidentialMembership { get; set; }
    public bool? HasStr { get; set; }
    public bool? HasTenant { get; set; }
    public bool? IsCustomer { get; set; }
    public bool? IsLoopNetEcom { get; set; }
}

