using DataFieldProvider.Providers.Core;

namespace DataFieldProvider.Models;

public class EncryptedContact : DataFieldModel
{
	[CampaignDataField("EncryptedContactId")]
	public required string EncryptedContactId { get; set; }
}

