using DataFieldProvider.Providers.Core;

namespace DataFieldProvider.Models;

public class ContactStatusModel : DataFieldModel
{
	public override int ContactID { get; set; }

	/// <summary>
	/// Status of the contact (Prospect or Subscriber) 
	/// </summary>
	[CampaignDataField("ContactStatus")]
	public string ContactStatus { get; set; } = string.Empty;
}
