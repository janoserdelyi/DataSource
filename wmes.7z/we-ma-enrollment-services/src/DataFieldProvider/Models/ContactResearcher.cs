using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class ContactResearcher : DataFieldModel
{
    [CampaignDataField("ResearcherFirstName", [MarketingBrands.LoopNet, MarketingBrands.Costar])]
    public string? ResearcherFirstName { get; set; }
    [CampaignDataField("ResearcherLastName", [MarketingBrands.LoopNet, MarketingBrands.Costar])]
    public string? ResearcherLastName { get; set; }
    [CampaignDataField("ResearcherEmail", MarketingBrands.Costar)]
    [CampaignDataField("LNResearcherEmail", MarketingBrands.LoopNet)]
    public string? ResearcherEmailAddress { get; set; }
    [CampaignDataField("ResearcherPhone", MarketingBrands.Costar)]
    public string? ResearcherPhoneNumber { get; set; }
    public string? ResearcherPhoneExt { get; set; }
    public string? ResearcherPhoneNumberCountryCode { get; set; }
}