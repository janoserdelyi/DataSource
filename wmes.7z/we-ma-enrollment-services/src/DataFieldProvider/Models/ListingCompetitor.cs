namespace DataFieldProvider.Models;

public class ListingCompetitor
{
    public List<int>? CompetitorListingIds { get; set; }
}