using DataFieldProvider.Providers.Core;
using Marketing.Enums;

namespace DataFieldProvider.Models;

public class HomesAccountExecutiveInfo : DataFieldModel
{
    public override required int ContactID { get => base.ContactID; set => base.ContactID = value; }
    [CampaignDataField("AssignedAE", MarketingBrands.Homes)]
    public required string AccountExecutive { get; set; }
    [CampaignDataField("AssignedAEPhone", MarketingBrands.Homes)]
    public required string? AccountExecutivePhone { get; set; }
    [CampaignDataField("AssignedAEEmail", MarketingBrands.Homes)]
    public required string? AccountExecutiveEmail { get; set; }
    [CampaignDataField("AssignedAEAddress", MarketingBrands.Homes)]
    public required string AccountExecutiveAddress { get; set; }
    [CampaignDataField("AssignedAEPhoto", MarketingBrands.Homes)]
    public required string? AccountExecutivePhotoUri { get; set; }

}