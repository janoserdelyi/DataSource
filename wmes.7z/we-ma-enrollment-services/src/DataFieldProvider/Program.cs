using DataFieldProvider.Extensions;
using EnrollmentPipeline.Extensions;
using DataFieldProvider;
using EnrollmentPipeline.Builder;

var app = PipelineWorkerBuilder.Create<Worker>(
	args,
	builder =>
	{
		// Add required vault secrets
		builder.AddVaultSecrets("contact-encryption-key");
		// Add SQL Server database integration
		builder.AddSqlServerDatabase();
		// Add DataPlane integration
		builder.AddDataPlaneService();
		// Add EDS integration
		builder.AddEdsService();
		// Add OpenSearch integration
		builder.AddOpenSearchClient();
		// Add Listing Market Analytics integration
		builder.AddListingMarketAnalyticsService();
		// Add Preferences integration
		builder.AddPreferencesService();
		// Add Sales AE Cache integration
		builder.AddSalesAeService();
		// Add Homes Token Service integration
		builder.AddHomesTokenService();
		// Add Query and Command Dispatcher
		builder.AddQueryAndCommandDispatcher();
		// Add Campaign Data Field Service
		builder.AddCampaignDataFieldService();
	}
);

// Run the application
await app.RunAsync();
