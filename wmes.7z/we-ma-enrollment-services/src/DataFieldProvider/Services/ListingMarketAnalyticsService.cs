using System.Text;
using System.Text.Json;
using DataFieldProvider.Models;

namespace DataFieldProvider.Services;

public interface IListingMarketAnalyticsClient
{
    /// <summary>
    /// Get Listing performance Url for a listing
    /// </summary>
    /// <param name="listingIds">listing ids</param>
    /// <returns></returns>
    Task<List<ListingAnalytics>> GetListingPerformanceUrl(List<int> listingIds);

    /// <summary>
    /// Get competitor listing IDs
    /// </summary>
    /// <param name="listingId">Listing ID</param>
    /// <param name="researchMarketId">Research Market ID</param>
    /// <param name="subMarketId">Sub Market ID</param>
    /// <param name="propertyTypeId">Property Type ID</param>
    /// <returns>List of competitor listing IDs</returns>
    Task<List<int>?> GetCompetitorListings(int listingId, int? researchMarketId, int? subMarketId, int? propertyTypeId);

    /// <summary>
    /// Get listing activity summary
    /// </summary>
    /// <param name="listingId">Listing ID</param>
    /// <param name="from">Date/time from</param>
    /// <param name="to">Date/time to</param>
    /// <returns>A ListingActivitySummary object with stats for the given listing</returns>
    Task<ListingActivitySummary?> GetListingActivitySummary(int listingId, DateTime from, DateTime? to);
}

public class ListingMarketAnalyticsClient(
    HttpClient client
) : IListingMarketAnalyticsClient
{
    private const int _timeFrameId = 45;

    /// inheritdoc
    public async Task<List<ListingAnalytics>> GetListingPerformanceUrl(List<int> listingIds)
    {
        var response = new List<ListingAnalytics>();
        foreach (var l in listingIds)
        {
            var urlResult = await client.GetStringAsync($"/Listing/Share/{l}/{_timeFrameId}").ConfigureAwait(false);
            response.Add(new ListingAnalytics()
            {
                ListingId = l,
                Url = urlResult
            });
        }

        return response;
    }

    /// inheritdoc
    public async Task<List<int>?> GetCompetitorListings(
        int listingId,
        int? researchMarketId,
        int? subMarketId,
        int? propertyTypeId
    )
    {
        var jsonPayload = new StringContent(
            JsonSerializer.Serialize(new
            {
                listingId,
                researchMarketId,
                subMarketId,
                propertyTypeId
            }
            ), Encoding.UTF8, "application/json");

        var result = await client.PostAsync($"Listing/Competitor", jsonPayload);
        var responseString = await result.Content.ReadAsStringAsync();
        var response = JsonSerializer.Deserialize<ListingCompetitor>(responseString);

        return response?.CompetitorListingIds;
    }

    public async Task<ListingActivitySummary?> GetListingActivitySummary(int listingId, DateTime from, DateTime? to)
    {
        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffZ";

        var json = JsonSerializer.Serialize(new
        {
            listingId,
            from = from.ToUniversalTime().ToString(dateFormat),
            to = to != null ? to?.ToUniversalTime().ToString(dateFormat) : null
        }
        );
        var jsonPayload = new StringContent(
            json, Encoding.UTF8, "application/json");

        var result = await client.PostAsync($"Listing/Summary", jsonPayload);
        var responseString = await result.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<ListingActivitySummary>(responseString);
    }
}