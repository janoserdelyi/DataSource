using DataFieldProvider.Models;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.DataAccess.Commands;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using Marketing.Enums;
using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.DataAccess.Commands;
using DataPlane.Client.CoStar.WE.SalesTerritory.Enums;
using DataPlane.Client.CoStar.SalesTerritory.SalesTerritoryViews.Models;
using EnrollmentPipeline.Models.CostarSync;
using DataFieldProvider.Providers;

namespace DataFieldProvider.Services;

public interface ISalesAEService
{
	public Task<List<ContactAE>> GetSalesPeopleInformationForMarketingCloud(IEnumerable<StagedEnrollment> contacts);
}

public class SalesAEService(
    ILogger<SalesAEService> logger
    , IQueryDispatcher queryDispatcher
    , IDataPlaneService dataPlaneService
    , ICommandDispatcher commandDispatcher) : ISalesAEService
{
	public async Task<List<ContactAE>> GetSalesPeopleInformationForMarketingCloud(IEnumerable<StagedEnrollment> contacts)
	{
		// Get AE for all other brands
		var AeNotHomesTask = GetSalesPeopleInformationForMarketingCloudOtherBrands(contacts.Where(c => (MarketingBrands)c.BrandId != MarketingBrands.Homes));

		//Get AEs for Homes
		var AeHomesTask = GetSalesPeopleInformationForMarketingCloudHomes(contacts.Where(c => (MarketingBrands)c.BrandId == MarketingBrands.Homes));

		await Task.WhenAll(AeNotHomesTask, AeHomesTask);

		var salesPeopleHomes = await AeHomesTask;
		var salesPeopleTheRest = await AeNotHomesTask;

		// Return Object
		var returnAeList = new List<ContactAE>();

		if (salesPeopleHomes != null && salesPeopleHomes.Count() > 0) returnAeList.AddRange(salesPeopleHomes);
		if (salesPeopleTheRest != null && salesPeopleTheRest.Count() > 0) returnAeList.AddRange(salesPeopleTheRest);

		return returnAeList;
	}

	#region private helpers


	private async Task<List<ContactAE>> GetSalesPeopleInformationForMarketingCloudOtherBrands(IEnumerable<StagedEnrollment> enrollments)
	{
		// Group contacts by brand
		var contactsByBrand = enrollments
			.GroupBy(c => c.BrandId)
			.ToList();

		// Kick off one GetSalesPeopleInformation call per brand-group in parallel
		var aeLists = await Task.WhenAll(contactsByBrand.Select(async brandGroup =>
		{
			try
			{
				return await GetSalesPeopleInformation(brandGroup, brandGroup.Key);
			}
			catch (Exception ex)
			{
				logger.LogError(ex, $"Failed to get sales people for brand {brandGroup.Key}");
				return [];
			}
		}));

		// Collect all AEs into one flat list
		var allAe = aeLists.SelectMany(a => a).ToList();

		// Remap each original contact to its AE, filtering out misses
		return enrollments
			.Select(enrollment =>
			{
				var match = allAe.FirstOrDefault(ae =>
					ae.LocationID == enrollment.GetLocationId() 
						&& ae.MarketingBrand == enrollment.BrandId);

                if (match == null) {
                    return new ContactAE
                    {
                        ContactID = enrollment.ContactId,
                        MarketingBrand = enrollment.BrandId
                    };
                }

                match.ContactID = enrollment.ContactId;

                return match;
			})
			.ToList()!;
	}

	private async Task<List<ContactAE>> GetSalesPeopleInformationForMarketingCloudHomes(IEnumerable<StagedEnrollment> homesContacts)
	{
		// Prepare only the contacts that have a LocationID
		var contacts = homesContacts
			.Where(c => c.GetLocationId() != null)
			.Select(c => new ContactLocationPair
			{
				ContactId = c.ContactId,
				LocationId = c.GetLocationId() ?? 0
			})
			.ToList();

		if (!contacts.Any())
			return new List<ContactAE>();

		// Fetch all SalesPersonDetails for these (contact,location) pairs in one go
		var queryResult = await queryDispatcher.Dispatch<GetSalesPeopleDetailsForHomeQuery, GetSalesPeopleDetailsForHomeQueryResult>(
            new GetSalesPeopleDetailsForHomeQuery
            {
                ContactLocations = contacts
            });

		var salesPeopleDetails = queryResult.SalesPeopleDetails;

		// For each contact, pick its primary AE
		var mappedAes = contacts
			.SelectMany(c =>
			{
				var candidates = salesPeopleDetails
					.Where(d => d.ContactID == c.ContactId && d.LocationID == c.LocationId)
					.ToList();

				var primary = GetPrimarySalesPerson(candidates, MarketingBrands.Homes);
				return primary is null
					? Enumerable.Empty<ContactAE>()
					: new[] { primary.ToContactAE(c.ContactId) };
			})
			.ToList();

		// Cache any fresh lookups
		await commandDispatcher.Dispatch(new BulkSalesPersonCacheCommand
		{
			SalesPeopleDetails = salesPeopleDetails
				.Where(d => !d.IsFromCacheTable)
				.ToList()
		});

		return mappedAes;
	}


	// This is the function to get SalesPeople(AEs) Information based on MarketingBrand and LocationIDs
	private async Task<List<ContactAE>> GetSalesPeopleInformation(
		IEnumerable<StagedEnrollment> contactsForBrand,
		MarketingBrands marketingBrand)
	{
		// fetch all sales people for these locations in one go
		var locationIds = contactsForBrand
			.Where(c => c.GetLocationId() != null)
			.Select(c => (int) c.GetLocationId()!)
			.Distinct()
			.ToList();

		var salesPeopleDetails = await GetSalesPeopleDetails(locationIds, marketingBrand);

		// group contacts by location, pick the primary AE for that location,
		// then map every contact in that bucket to that AE
		var result = contactsForBrand
			.Where(c => c.GetLocationId() != null)
			.GroupBy(c => c.GetLocationId())
			.SelectMany(group =>
			{
				var primaryAe = GetPrimarySalesPerson(
					salesPeopleDetails.Where(d => d.LocationID == group.Key).ToList(),
					marketingBrand);

				if (primaryAe is null)
					return Enumerable.Empty<ContactAE>();

				return group.Select(c => primaryAe.ToContactAE(c.ContactId));
			})
			.ToList();

		await commandDispatcher.Dispatch(new BulkSalesPersonCacheCommand
		{
			SalesPeopleDetails = salesPeopleDetails.Where(p => !p.IsFromCacheTable).ToList()
		});

		return result;
	}


	private async Task<IEnumerable<SalesPersonDetails>> GetSalesPeopleDetails(List<int> locationIDs, MarketingBrands marketingBrand)
	{
		// Get Sales People from CostarAssignmentWe/Prospect tables in EnterpriseSales Sub table
		var salesPeopleDetails = await GetInitialSalesPeopleDetails(locationIDs, marketingBrand);

		// Get SalesTerritories for the sales people without CostarAssignmentType
		var salesPeopleWithoutAssignmentType = salesPeopleDetails.Where(p => p.CoStarAssignmentTypeID == null && !p.IsFromCacheTable);
		var salesTerritories = await GetSalesTerritoriesFromDataPlane(salesPeopleWithoutAssignmentType);

		foreach (var salesPerson in salesPeopleDetails)
		{
			// Based on the sales territories along with sales people, then use them to assign Costar AssignmentIDs
			if (salesPerson.CoStarAssignmentTypeID == null && !salesPerson.IsFromCacheTable)
			{
				var salesTerritory = salesTerritories.FirstOrDefault(t => t.AssignedContact?.Id == salesPerson.SalesPersonContactID);
				salesPerson.CoStarAssignmentTypeID = salesTerritory?.Type;
				salesPerson.SalesTerritoryID = salesTerritory?.Id;
			}

			// Assign Marketing Brand based on CostarAssignmentID otherwise, use the input of markting brand.
			salesPerson.MarketingBrandID = salesPerson.CoStarAssignmentTypeID != null ? GetMarketingBrandByCostarAssignmentType(salesPerson.CoStarAssignmentTypeID) : marketingBrand;
		}

		return salesPeopleDetails;
	}

	private async Task<IEnumerable<SalesPersonDetails>> GetInitialSalesPeopleDetails(List<int> locationIDs, MarketingBrands marketingBrand)
	{
		var salesBusinessUnit = GetSalesTerritoryIDByMarketingBrandID(marketingBrand);
		var salesPeopleDetails = (await queryDispatcher
						.Dispatch<GetSalesPeopleDetailsByLocationIDsQuery, GetSalesPeopleDetailsByLocationIDsQueryResult>(
							new GetSalesPeopleDetailsByLocationIDsQuery { LocationIDs = locationIDs, SalesBusinessUnit = salesBusinessUnit }
						)).SalesPeopleDetails;

		return salesPeopleDetails;
	}

	private async Task<IEnumerable<SalesTerritorySummary>> GetSalesTerritoriesFromDataPlane(IEnumerable<SalesPersonDetails> peopleWihoutAssignmentTypes)
	{
		if (peopleWihoutAssignmentTypes != null && peopleWihoutAssignmentTypes.Count() > 0)
		{
			var contactIds = peopleWihoutAssignmentTypes.Select(p => p.SalesPersonContactID.ToString()).ToList();

			var salesTerritoryIDsMissingAssignmentTypes = await dataPlaneService
																.GetBatchSyncModelAll<ByForeignKeyResponse>(contactIds, BatchType.SalesTerritorySummaryKeysByContactID);

			var salesTerritoryIDs = salesTerritoryIDsMissingAssignmentTypes
				.SelectMany(t => t.ModelKeys.Select(m => m.k))
				.Where(id => id != null)
				.Select(id => id!)
				.ToList();

			if (salesTerritoryIDsMissingAssignmentTypes.Count() > 0)
			{
				var salesTerritories = await dataPlaneService.GetBatchSyncModelAll<SalesTerritorySummary>(salesTerritoryIDs, BatchType.SalesTerritorySummary);

				return salesTerritories;
			}
		}
		return new List<SalesTerritorySummary>();
	}

	private SalesPersonDetails? GetPrimarySalesPerson(List<SalesPersonDetails> salesPeople, MarketingBrands marketingBrand)
	{
		SalesPersonDetails? selectedSalesPerson = null;

		switch (marketingBrand)
		{
			case MarketingBrands.Costar:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.INFO);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.INFO_MAJOR);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID != CoStarAssignmentType.LENDER && p.SalesBusinessUnitID == SalesBusinessUnit.CoStar);
				break;
			case MarketingBrands.LoopNet:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.AD);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID != CoStarAssignmentType.TENX && p.SalesBusinessUnitID == SalesBusinessUnit.LoopNet);
				break;
			case MarketingBrands.TenX:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.TENX);
				break;
			case MarketingBrands.Apartments:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.MF);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.MMMF);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.MF_REG);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.MF_NAT);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID != CoStarAssignmentType.OFFCAMPUS && p.SalesBusinessUnitID == SalesBusinessUnit.Apartments);
				break;
			case MarketingBrands.STR:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.STR);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.SalesBusinessUnitID == SalesBusinessUnit.STR);
				break;
			case MarketingBrands.Homes:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.HOMES);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.HOMES_MAJOR);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID != CoStarAssignmentType.HOMES_SERV && p.SalesBusinessUnitID == SalesBusinessUnit.Homes);
				break;
			case MarketingBrands.BusinessImmo:
				selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID == CoStarAssignmentType.NEWS);
				if (selectedSalesPerson == null) selectedSalesPerson = salesPeople.FirstOrDefault(p => p.CoStarAssignmentTypeID != CoStarAssignmentType.BI_EVENT && p.SalesBusinessUnitID == SalesBusinessUnit.News);
				break;
			default:
				selectedSalesPerson = null;
				break;

		}

		return selectedSalesPerson;
	}

	private MarketingBrands GetMarketingBrandByCostarAssignmentType(CoStarAssignmentType? costarAssignmentType)
	{

		switch (costarAssignmentType)
		{
			case CoStarAssignmentType.INFO:
			case CoStarAssignmentType.INFO_MAJOR:
			case CoStarAssignmentType.LENDER:
				return MarketingBrands.Costar;
			case CoStarAssignmentType.AD_MAJOR:
			case CoStarAssignmentType.AD:
				return MarketingBrands.LoopNet;
			case CoStarAssignmentType.MMMF:
			case CoStarAssignmentType.MF:
			case CoStarAssignmentType.MF_REG:
			case CoStarAssignmentType.MF_NAT:
			case CoStarAssignmentType.MF_MIDLVL:
			case CoStarAssignmentType.OFFCAMPUS:
				return MarketingBrands.Apartments;
			case CoStarAssignmentType.TENX:
				return MarketingBrands.TenX;
			case CoStarAssignmentType.STR:
			case CoStarAssignmentType.STR_KEY:
				return MarketingBrands.STR;
			case CoStarAssignmentType.HOMES:
			case CoStarAssignmentType.HOMES_MAJOR:
			case CoStarAssignmentType.HOMES_SERV:
				return MarketingBrands.Homes;
			case CoStarAssignmentType.NEWS:
			case CoStarAssignmentType.BI_EVENT:
				return MarketingBrands.BusinessImmo;
			default:
				return MarketingBrands.Costar;
		}
	}

	private SalesBusinessUnit GetSalesTerritoryIDByMarketingBrandID(MarketingBrands brandID)
	{
		switch (brandID)
		{
			case MarketingBrands.Costar:
				return SalesBusinessUnit.CoStar;
			case MarketingBrands.LoopNet:
				return SalesBusinessUnit.LoopNet;
			case MarketingBrands.Apartments:
				return SalesBusinessUnit.Apartments;
			case MarketingBrands.TenX:
				return SalesBusinessUnit.LoopNet;
			case MarketingBrands.STR:
				return SalesBusinessUnit.STR;
			case MarketingBrands.Homes:
				return SalesBusinessUnit.Homes;
			case MarketingBrands.BusinessImmo:
				return SalesBusinessUnit.News;
			default:
				return SalesBusinessUnit.CoStar;
		}
	}

	#endregion
}
