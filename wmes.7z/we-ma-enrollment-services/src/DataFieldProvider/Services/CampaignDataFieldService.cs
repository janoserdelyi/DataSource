using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using DataFieldProvider.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.Providers.Core;
using EnrollmentPipeline.DataAccess.Queries;
using EnrollmentPipeline.Models;

namespace DataFieldProvider.Services;

public interface ICampaignDataFieldService
{
    /// <summary>
    /// Retrieves data fields for the specified enrollments. 
    /// It modifies the enrollment object in place hence why it returns void.
    /// </summary>
    /// <param name="enrollments"></param>
    Task RetrieveDataFields(IReadOnlyCollection<StagedEnrollment> enrollments);

    /// <summary>
    /// Retrieves data fields for enrollments in a streaming fashion.
    /// Yields results as they become available instead of waiting for entire batch.
    /// </summary>
    /// <param name="enrollments"></param>
    /// <returns>Stream of processed enrollments</returns>
    IAsyncEnumerable<StagedEnrollment> RetrieveDataFields(IReadOnlyCollection<StagedEnrollment> enrollments, CancellationToken cancellationToken = default);

    /// <summary>
    /// Executes the specified data field providers against the given enrollments.
    /// </summary>
    /// <param name="providers"></param>
    /// <param name="enrollments"></param>
    /// <returns>List of <see cref="DataFieldResult"/> objects.</returns>
    Task<IEnumerable<DataFieldResult>> ExecuteProviders(IEnumerable<IDataFieldProvider> providers, IReadOnlyCollection<StagedEnrollment> enrollments);

    /// <summary>
    /// Gets the data field providers required for the specified campaign.
    /// </summary>
    /// <param name="marketingCampaignId">Marketing Campaign ID</param>
    /// <returns>List of <see cref="IDataFieldProvider"/> objects.</returns>
    Task<IReadOnlyCollection<IDataFieldProvider>> GetProvidersForCampaign(int marketingCampaignId);

    /// <summary>
    /// Gets the list of data fields required for the specified campaign.
    /// </summary>
    /// <param name="marketingCampaignId">Marketing Campaign ID</param>
    /// <returns>List of <see cref="CampaignDataField"/> objects.</returns>
    Task<IReadOnlyCollection<CampaignDataField>> GetListOfDataFields(int marketingCampaignId);
}

public class CampaignDataFieldService(
    IQueryDispatcher queryDispatcher,
    ILogger<CampaignDataFieldService> logger,
    IServiceProvider serviceProvider) : ICampaignDataFieldService
{
    // Caches provider types to avoid repeated reflection
    private static readonly Lazy<IReadOnlyList<Type>> _providerTypes = new(() =>
    {
        return Assembly
            .GetExecutingAssembly()
            .GetTypes()
            .Where(t => !t.IsAbstract && !t.IsInterface && t.IsAssignableTo(typeof(IDataFieldProvider)))
            .ToList()
            .AsReadOnly();
    });

    public async Task RetrieveDataFields(IReadOnlyCollection<StagedEnrollment> enrollments)
    {
        if (enrollments.Count == 0)
        {
            return;
        }

        var stopwatch = Stopwatch.StartNew();

        // Groups enrollments by MarketingCampaignId
        var campaignGroups = enrollments
            .GroupBy(enrollment => enrollment.MarketingCampaignId)
            .ToList();

        foreach (var campaignGroup in campaignGroups)
        {
            await ProcessCampaignGroup(campaignGroup.Key, campaignGroup.ToList());
        }

        logger.LogDebug("Looked up {EnrollmentCount} contacts in {Elapsed}",
            enrollments.Count, stopwatch.Elapsed);
    }

    public async IAsyncEnumerable<StagedEnrollment> RetrieveDataFields(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        logger.LogDebug("Starting data field retrieval for {EnrollmentCount} enrollments", enrollments.Count);

        if (enrollments.Count == 0)
        {
            // No enrollments to process
            yield break;
        }

        // Groups enrollments by MarketingCampaignId
        var campaignGroups = enrollments
            .GroupBy(enrollment => enrollment.MarketingCampaignId)
            .ToList();

        foreach (var campaignGroup in campaignGroups)
        {
            using (logger.BeginScope(
                new Dictionary<string, object>
                {
                    {"CampaignId", campaignGroup.Key},
                    {"EnrollmentCount", campaignGroup.Count()}
                }
            ))
            {
                try
                {
                    await ProcessCampaignGroup(campaignGroup.Key, campaignGroup.ToList());
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "({ServiceName}) Failed to process campaign group for campaign {CampaignId}",
                        nameof(CampaignDataFieldService), campaignGroup.Key);
                }

                // Yield enrollments as soon as this campaign group is processed
                foreach (var enrollment in campaignGroup)
                {
                    yield return enrollment;
                }
            }
        }
    }

    /// <summary>
    /// Processes a single campaign group with O(1) lookups using HashSets and Dictionaries.
    /// </summary>
    private async Task ProcessCampaignGroup(int marketingCampaignId, IReadOnlyList<StagedEnrollment> enrollments)
    {
        // Gets a list of required fields for the campaign
        var campaignDataFields = await GetListOfDataFields(marketingCampaignId);

        if (campaignDataFields.Count == 0)
        {
            // No data fields were found for this campaign
            logger.LogWarning("({ServiceName}) No data fields were found for campaign {CampaignId}",
                nameof(CampaignDataFieldService), marketingCampaignId);
            return;
        }

        // Gets a list of providers that can provide the fields required by the campaign
        var providers = GetProvidersForDataFields(campaignDataFields);

        if (providers.Count == 0)
        {
            // No providers available for the required data fields
            logger.LogWarning("({ServiceName}) No providers found for campaign {CampaignId} though it requires {FieldCount} data fields. Check for missing data field provider implementation.",
                nameof(CampaignDataFieldService), marketingCampaignId, campaignDataFields.Count);
            return;
        }

        // Groups providers by priority
        var providerGroups = providers
            .GroupBy(provider => provider.LookupPriority)
            .OrderBy(group => group.Key)
            .ToList();

        // Build HashSet of required field names for O(1) lookup
        var requiredFieldNames = campaignDataFields
            .Select(f => f.FieldName)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        // Builds Dictionary for contact lookup by ID
        var enrollmentsByContactId = enrollments
            // This grouping is more a "just-in-case" measure in case there so happens to be duplicate enrollments 
            // for the same contact/campaign pair. In most cases this should be unnecessary as there should only 
            // be one enrollment per contact/campaign ids.
            .GroupBy(e => e.ContactId)
            .ToDictionary(g => g.Key, g => g.ToArray());

        foreach (var providerGroup in providerGroups)
        {
            using (logger.BeginScope(
                new Dictionary<string, object>
                {
                    {"ProviderGroupPriority", providerGroup.Key},
                    {"ProviderCount", providerGroup.Count()}
                }
            ))
            {
                var results = await ExecuteProviders(providerGroup, enrollments);

                logger.LogDebug("({ServiceName}) Provider group with priority {Priority} returned {ResultCount} results for campaign {CampaignId}",
                    nameof(CampaignDataFieldService), providerGroup.Key, results.Count(), marketingCampaignId);

                // Process results with dictionary lookups
                foreach (var result in results)
                {
                    // Skips if no data fields were returned
                    if (result.DataFields == null || result.DataFields.Count == 0)
                    {
                        continue;
                    }

                    if (!enrollmentsByContactId.TryGetValue(result.ContactId, out var contactEnrollments))
                    {
                        continue;
                    }

                    // Process each field returned from the provider
                    foreach (var field in result.DataFields)
                    {
                        if (!requiredFieldNames.Contains(field.Key))
                        {
                            continue;
                        }

                        var newValue = field.Value?.ToString();

                        // Update all enrollments for this contact
                        foreach (var enrollment in contactEnrollments)
                        {
                            var currentValue = enrollment.DataFields[field.Key]?.ToString();

                            // Only updates field value if new value is NOT null or empty/whitespaces
                            enrollment.DataFields[field.Key] = string.IsNullOrWhiteSpace(newValue)
                                ? currentValue
                                : newValue;
                        }
                    }
                }
            }
        }
    }

    public async Task<IEnumerable<DataFieldResult>> ExecuteProviders(
        IEnumerable<IDataFieldProvider> providers,
        IReadOnlyCollection<StagedEnrollment> enrollments)
    {
        var tasks = providers.Select(provider => provider.GetDataFields(enrollments));

        // Waits until all tasks have finished
        var results = (await Task.WhenAll(tasks))
            .SelectMany(result => result)
            .ToList();

        return results;
    }

    public async Task<IReadOnlyCollection<IDataFieldProvider>> GetProvidersForCampaign(int marketingCampaignId)
    {
        var campaignDataFields = await GetListOfDataFields(marketingCampaignId);

        if (campaignDataFields.Count == 0)
        {
            // Returns empty list if no data fields are required for the campaign
            return [];
        }

        return GetProvidersForDataFields(campaignDataFields);
    }

    public async Task<IReadOnlyCollection<CampaignDataField>> GetListOfDataFields(int marketingCampaignId)
    {
        // TODO: Use OpenSearch instead of DB for better performance/scalability
        var campaignDataFieldsResult = await queryDispatcher.Dispatch<CampaignDataFieldQuery, CampaignDataFieldQueryResult>(
            new CampaignDataFieldQuery { MarketingCampaignId = marketingCampaignId }
        );

        return campaignDataFieldsResult
            .CampaignDataFields
            .ToList()
            .AsReadOnly();
    }

    private IReadOnlyCollection<IDataFieldProvider> GetProvidersForDataFields(IReadOnlyCollection<CampaignDataField> campaignDataFields)
    {
        var providers = new List<IDataFieldProvider>();

        if (campaignDataFields.Count == 0)
        {
            return providers;
        }

        // Use cached provider types instead of reflection on every call
        var providerTypes = _providerTypes.Value;

        if (providerTypes.Count == 0)
        {
            logger.LogWarning("({ServiceName}) No provider types found", nameof(CampaignDataFieldService));
            return providers;
        }

        foreach (var providerType in providerTypes)
        {
            if (serviceProvider.GetService(providerType) is not IDataFieldProvider providerInstance)
            {
                logger.LogWarning("({ServiceName}) Failed to get an instance of provider type {ProviderType}",
                    nameof(CampaignDataFieldService), providerType.FullName);
                continue;
            }

            // Checks if the model provided by the provider contains any of the fields being looked for
            foreach (var field in campaignDataFields)
            {
                if (providerInstance.ModelType.HasDataFieldForBrand(field.FieldName, field.MarketingBrandId))
                {
                    providers.Add(providerInstance);
                    break;
                }
            }
        }

        return providers.AsReadOnly();
    }
}
