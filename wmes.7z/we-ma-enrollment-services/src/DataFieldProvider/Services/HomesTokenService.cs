using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace DataFieldProvider.Services;

public interface IHomesTokenService
{
    /// <summary>
    /// The issuer of the token.
    /// </summary>
    string Issuer { get; }
    /// <summary>
    /// Generates a JWT token with the specified claims and expiration.
    /// </summary>
    /// <param name="claims"></param>
    /// <param name="expiration"></param>
    /// <returns></returns>
    string GenerateToken(IEnumerable<Claim> claims, TimeSpan expiration);
}

public class HomesTokenService : IHomesTokenService
{
    private readonly SymmetricSecurityKey _securityKey;
    private readonly string _issuer;

    public HomesTokenService(IConfiguration configuration)
    {
        var config = configuration.GetRequiredSection("Homes:TokenGeneration");
        var issuer = config.GetValue<string>("issuer");
        var key = config.GetValue<string>("key");

        ArgumentNullException.ThrowIfNull(issuer, "Homes Token Issuer cannot be null");
        ArgumentNullException.ThrowIfNull(key, "Homes Token Key cannot be null");

        _securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        _issuer = issuer;
    }

    public string Issuer => _issuer;

    public string GenerateToken(IEnumerable<Claim> claims, TimeSpan expiration)
    {
        var now = DateTime.UtcNow;
        var expires = now.Add(expiration);

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Expires = expires,
            Issuer = _issuer,
            SigningCredentials = new SigningCredentials(_securityKey, SecurityAlgorithms.HmacSha256)
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }
}
