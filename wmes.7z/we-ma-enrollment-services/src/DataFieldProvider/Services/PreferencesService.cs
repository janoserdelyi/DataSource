using System.Text.Json;
using EnrollmentPipeline.DataAccess.Queries;
using DataFieldProvider.Models;
using DataFieldProvider.DataAccess.Queries;
using System.Net;
using System.Text;

namespace DataFieldProvider.Services;

public interface IPreferencesService
{
    public Task<string?> GetPreferenceValue(string identifier, int value);
    public Task<string> GetCultureCode(Guid? subject, string countryCode, string stateName, int contactId, int? locationId);
    public Task<IEnumerable<ContactGlobalPreferences>> GetDefaultPreferences(IEnumerable<ContactGlobalPreferenceRequest> contacts);
    public Task<GlobalPreferencesRegistry?> GetGlobalPreferencesRegistryAsync();
    public Task<GlobalPreferencesBulkResponse> GetGlobalPreferencesBulkAsync(GlobalPreferencesBulkRequest request);
}

public class PreferencesService(
    HttpClient client,
    ILogger<IPreferencesService> logger,
    IQueryDispatcher queryDispatcher
) : IPreferencesService
{
    private const string _cultureKey = "Culture";
    private GlobalPreferencesRegistry? _prefsRegistry = null;
    private List<CountryCultureResults> _allCountryCultures = [];

    internal static class ApiRoutes
    {
        public static readonly string Registry = "/registry/get";
        public static readonly string UserPreferencesBulkGet = "/user/preferences/bulk/get";
    }

    public async Task<string?> GetPreferenceValue(string identifier, int value)
    {
        var registry = await GetPreferenceRegistry();

        var manifest = registry.Manifests.FirstOrDefault(m => m.Identifier == identifier);
        var allowedValue = manifest?.AllowedValues?.FirstOrDefault(a => a.Id == value);

        return allowedValue?.Value?.ToString();
    }

    public async Task<string> GetCultureCode(Guid? subject, string countryCode, string stateName, int contactId, int? locationId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(subject.ToString()) || subject == default(Guid))
            {
                var contactList = new List<ContactGlobalPreferenceRequest>
                {
                    new ContactGlobalPreferenceRequest { ContactID = contactId, LocationID = locationId, CountryCode = countryCode, State = stateName }
                };

                var culture = (await GetDefaultPreferences(contactList)).ToList().FirstOrDefault();

                if (culture?.Culture != null)
                {
                    return culture.Culture;
                }
            }

            if (_prefsRegistry == null)
            {
                await GetPreferenceRegistry();
            }

            var preferenceResponse = await client.GetAsync($"/users/{subject}/preferences/get");
            preferenceResponse.EnsureSuccessStatusCode();
            var preferences = JsonSerializer.Deserialize<JsonElement>(await preferenceResponse.Content.ReadAsStringAsync());

            // Note: have to parse json this way becasue "value" fields can be int or string
            var cultureId = preferences.GetProperty("preferences").EnumerateArray()
                .First(el => el.GetProperty("identifier").GetString() == _cultureKey)
                .GetProperty("value").GetInt32();

            // Find the culture manifest in the registry
            var cultureManifest = _prefsRegistry?.Manifests?
                .FirstOrDefault(m => m.Identifier == _cultureKey);

            if (cultureManifest == null)
            {
                throw new InvalidOperationException($"Culture manifest not found for key: {_cultureKey}");
            }

            // Find the allowed value with the matching culture ID
            var cultureValue = cultureManifest.AllowedValues?
                .FirstOrDefault(av => av.Id == cultureId);

            if (cultureValue?.Value == null)
            {
                throw new InvalidOperationException($"Culture value not found for ID: {cultureId}");
            }

            return cultureValue.Value.ToString() ?? string.Empty;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, $"Failed to get culture code for subject={subject}");
            return string.Empty;
        }
    }

    public async Task<IEnumerable<ContactGlobalPreferences>> GetDefaultPreferences(IEnumerable<ContactGlobalPreferenceRequest> contacts)
    {
        var contactCountryStates = await GetCountryStateForCulture(contacts.Select(c => c.ContactID).ToList());

        // Get All Country Cultures from Default Culture Table
        if (_allCountryCultures == null || _allCountryCultures.Count == 0)
        {
            _allCountryCultures = (await GetCountryCultures()).ToList();
        }

        var defaultPreferences = new List<ContactGlobalPreferences>();

        foreach (var contact in contacts)
        {
            string defaultCulture = "en-US";
            var contactCountryState = contactCountryStates.FirstOrDefault(p => p.ContactID == contact.ContactID);

            if (contactCountryState != null)
            {
                // Apply this if LocationID is not null Or Contact's country code is not 'USA'
                // Note: We don't trust 'USA'country code in Contact table if location is miising
                if (contact?.LocationID != null || (contact?.CountryCode != "USA" && contact?.LocationID == null))
                {
                    if (!string.IsNullOrWhiteSpace(contact?.CountryCode))
                    {
                        contactCountryState.CountryCode = contact?.CountryCode;
                    }

                    if (!string.IsNullOrWhiteSpace(contact?.State))
                    {
                        contactCountryState.State = contact?.State;
                    }
                }

                // Get correct culture code based on Country and State
                var culture = _allCountryCultures.FirstOrDefault(c => c.Country == contactCountryState.CountryCode?.ToUpper()
                                                                    && c.Subdivision == contactCountryState.State?.ToUpper())?.CultureCode;
                // Get correct culture code based on Country if culture is empty/null above
                if (string.IsNullOrWhiteSpace(culture))
                {
                    culture = _allCountryCultures.FirstOrDefault(c => c.Country == contactCountryState.CountryCode?.ToUpper())?.CultureCode;
                }

                if (!string.IsNullOrWhiteSpace(culture))
                {
                    defaultCulture = culture;
                }
            }

            if (contact != null)
            {
                defaultPreferences.Add(new ContactGlobalPreferences
                {
                    ContactId = contact.ContactID,
                    Culture = defaultCulture
                });
            }
        }

        return defaultPreferences;
    }

    public async Task<GlobalPreferencesRegistry?> GetGlobalPreferencesRegistryAsync()
    {
        var result = await client.GetAsync(ApiRoutes.Registry);
        var content = await result.Content.ReadAsStringAsync();
        var contentObject = JsonSerializer.Deserialize<GlobalPreferencesRegistry>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return contentObject;
    }

    public async Task<GlobalPreferencesBulkResponse> GetGlobalPreferencesBulkAsync(GlobalPreferencesBulkRequest request)
    {
        if (!request.UserPreferences.Uuids.Any())
        {
            return new GlobalPreferencesBulkResponse();
        }

        HttpResponseMessage? result = null;
        var content = string.Empty;

        try
        {
            result = await client.PostAsync(ApiRoutes.UserPreferencesBulkGet,
                new StringContent(JsonSerializer.Serialize(request, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, WriteIndented = false }), Encoding.UTF8, "application/json"));

            content = await result.Content.ReadAsStringAsync();

            if (result.StatusCode != HttpStatusCode.OK)
            {
                logger.LogWarning($"[{nameof(GetGlobalPreferencesBulkAsync)}] Unexpected response code: {result.StatusCode}. Response content: {content}");
            }

            var response = JsonSerializer.Deserialize<GlobalPreferencesBulkResponse>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            ArgumentNullException.ThrowIfNull(response, "Failed to deserialize global preferences bulk response");

            return response;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, $"[{nameof(GetGlobalPreferencesBulkAsync)}] Failed to get global preferences bulk.");
            throw;
        }
    }

    #region Helpers

    private async Task<GlobalPreferencesRegistry> GetPreferenceRegistry()
    {
        if (_prefsRegistry != null)
        {
            return _prefsRegistry;
        }

        var registryResponse = await client.GetAsync(ApiRoutes.Registry);
        registryResponse.EnsureSuccessStatusCode();

        string content = await registryResponse.Content.ReadAsStringAsync();

        _prefsRegistry = JsonSerializer.Deserialize<GlobalPreferencesRegistry>(
            content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
        ) ?? throw new InvalidOperationException("Failed to deserialize preferences registry");

        return _prefsRegistry;
    }

    private async Task<IEnumerable<ContactCountryState>> GetCountryStateForCulture(List<int> contactIds)
    {
        var contactCountryStates = (await queryDispatcher
                    .Dispatch<GetCountryStateForCultureQuery, GetCountryStateForCultureQueryResult>(
                        new GetCountryStateForCultureQuery { ContactIds = contactIds }
                    )).ContactCountryStates;
        return contactCountryStates;
    }

    private async Task<IEnumerable<CountryCultureResults>> GetCountryCultures()
    {
        return (await queryDispatcher.Dispatch<GetCountryCultureQuery, GetCountryCultureQueryResult>(new GetCountryCultureQuery())).CountryCultures;
    }

    #endregion
}
