using Enterprise.Data.Services.Contacts;
using Enterprise.Data.Services.Contacts.Operations;
using Enterprise.Data.Services.Listings.Commercial;
using Enterprise.Data.Services.Listings.Commercial.Operations;

namespace DataFieldProvider.Services;

public interface IEDSService
{
	/// <summary>
	/// Get listings by listing keys: POST /api/listings/commercial/authorized/listing
	/// </summary>
	/// <param name="input"></param>
	/// <returns></returns>
	Task<ListingGetAuthorizedResponse?> GetAuthorizedListingAsync(ListingGetAuthorizedHttpRequest input);
	/// <summary>
	/// Get attachments: GET /api/listings/commercial/{id}/attachments
	/// </summary>
	/// <param name="input"></param>
	/// <returns></returns>
	public Task<ListingGetAttachmentsResponse?> GetListingAttachmentsAsync(ListingGetAttachmentsHttpRequest input);
	/// <summary>
	/// Get attachments for a contact: GET /api/contacts/{id}/attachments
	/// </summary>
	/// <param name="input"></param>
	/// <returns></returns>
	public Task<ContactGetAttachmentsResponse?> GetContactAttachmentsAsync(ContactGetAttachmentsHttpRequest input);
}

public class EDSService(
		HttpClient httpClient,
		IContactHttpClient contactClient,
		ICommercialListingHttpClient listingClient,
		ILogger<EDSService> logger) : IEDSService
{
	private readonly string _edsBaseUrl = httpClient.BaseAddress?.ToString() ?? throw new ArgumentNullException(nameof(httpClient));

	public async Task<ListingGetAuthorizedResponse?> GetAuthorizedListingAsync(ListingGetAuthorizedHttpRequest request)
	{
		request.Authority = _edsBaseUrl;
		return await SafeCallAsync(
			   request,
			   listingClient.GetAuthorizedListingAsync,
			   "Failed to fetch authorized listing for request")
			.ConfigureAwait(false);
	}

	public async Task<ListingGetAttachmentsResponse?> GetListingAttachmentsAsync(ListingGetAttachmentsHttpRequest request)
	{
		request.Authority = _edsBaseUrl;
		return await SafeCallAsync(
				request,
				listingClient.GetAttachmentsAsync,
				"Failed to fetch listing attachments for request")
			.ConfigureAwait(false);
	}

	public async Task<ContactGetAttachmentsResponse?> GetContactAttachmentsAsync(ContactGetAttachmentsHttpRequest request)
	{
		request.Authority = _edsBaseUrl;
		return await SafeCallAsync(
			   request,
			   contactClient.GetAttachmentsAsync,
			   "Failed to fetch contact attachments for request")
			.ConfigureAwait(false);
	}
	
	/// <summary>
	/// Centralizes try/catch, null‐check, logging and ConfigureAwait(false).
	/// </summary>
	private async Task<TResult?> SafeCallAsync<TRequest, TResult>(
		TRequest request,
		Func<TRequest, Task<TResult>> call,
		string errorMessage)
		where TRequest : class
		where TResult : class
	{
		if (request is null) throw new ArgumentNullException(nameof(request));

		try
		{
			return await call(request).ConfigureAwait(false);
		}
		catch (Exception ex)
		{
			logger.LogError(ex, errorMessage + " {@Request}", request);
			return null;
		}
	}

	#region Helpers

	/// <summary>
	/// Checks if a string contains Unicode characters (non-ASCII characters with code points > 127)
	/// </summary>
	/// <param name="input">The string to check</param>
	/// <returns>True if the string contains Unicode characters, false otherwise</returns>
	public static bool ContainsUnicodeCharacters(string input)
	{
		return !string.IsNullOrEmpty(input) && input.Any(c => c > 127);
	}

	#endregion
}
