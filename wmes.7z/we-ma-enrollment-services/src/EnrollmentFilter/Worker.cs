using System.Runtime.CompilerServices;
using EnrollmentFilter.Services;
using EnrollmentPipeline;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;

namespace EnrollmentFilter;

/// <summary>
/// Implementation of StreamPipelineWorker for enrollment filtering.
/// Filters out enrollments based on:
/// - Missing required fields (campaign-specific)
/// - Opt-out status (CanEmail field)
/// - UK government email domains
/// </summary>
public class Worker(
		IConnectionMultiplexer redis,
		IStreamMessagePublisher publisher,
		ILogger<Worker> logger,
		IServiceScopeFactory scopeFactory,
		IConfiguration configuration,
		HybridCache hybridCache)
		: StreamPipelineWorker(redis, publisher, logger, scopeFactory, configuration, hybridCache)
{
	private readonly IServiceScopeFactory _scopeFactory = scopeFactory;
	public override string WorkerName => "enrollment-filter";
	protected override int MaxBatchSize => 5000;
	protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);

	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> enrollments,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		using var scope = _scopeFactory.CreateScope();
		var filterService = scope.ServiceProvider.GetRequiredService<IEnrollmentFilterService>();

		var startTime = DateTimeOffset.UtcNow;

		foreach (var enrollment in enrollments)
		{
			using (logger.BeginScope(
				new Dictionary<string, object>
				{
					{"ContactId", enrollment.ContactId},
					{"CampaignId", enrollment.MarketingCampaignId},
					{"EnrollmentId", enrollment.Id},
				}
			))
			{
				cancellationToken.ThrowIfCancellationRequested();

				RequiredFieldsValidationResult? requiredFieldsResult = null;

				try
				{
					// Check required fields
					requiredFieldsResult = await filterService.HasRequiredFieldsAsync(enrollment, cancellationToken);
				}
				catch (Exception ex)
				{
					logger.LogError(ex, "[{WorkerName}] Error retrieving required fields for enrollment.", WorkerName);
				}

				if (requiredFieldsResult == null)
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Retrying)
						.WithMessage($"Failed to check for required campaign fields.");

					continue;
				}

				if (!requiredFieldsResult.HasRequiredFields)
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Failed)
						.WithReason(PipelineStatusReason.MissingRequiredFields)
						.WithMessage($"Enrollment filtered out: {requiredFieldsResult.Message}");

					continue;
				}

				var isOptedOut = true; // Assumes true in case of any exceptions to be safe
				var optOutReason = "Contact has opted out.";

				try
				{
					// Check opt-out status
					isOptedOut = filterService.IsOptedOut(enrollment);
				}
				catch (FormatException)
				{
					optOutReason = "CanEmail field value is invalid.";
				}
				catch (KeyNotFoundException)
				{
					optOutReason = "CanEmail field is missing.";
				}

				if (isOptedOut)
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Failed)
						.WithReason(PipelineStatusReason.ContactOptedOut)
						.WithMessage(optOutReason);
					continue;
				}

				// Check UK government email domains
				if (filterService.IsUkGovernmentEmail(enrollment))
				{
					yield return ProduceResult(enrollment, startTime)
						.WithStatus(PipelineStatus.Failed)
						.WithReason(PipelineStatusReason.UkGovernmentEmailDomain)
						.WithMessage("Enrollment filtered out due to UK government email domain");

					continue;
				}

				// All checks passed
				yield return ProduceResult(enrollment, startTime)
					.WithStatus(PipelineStatus.Success);
			}
		}
	}
}
