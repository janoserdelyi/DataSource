using EnrollmentPipeline;
using EnrollmentPipeline.Extensions;
using EnrollmentFilter;
using EnrollmentFilter.Services;
using EnrollmentPipeline.Builder;

var app = PipelineWorkerBuilder.Create<Worker>(
    args,
    builder =>
    {
        // Add OpenSearch integration
        builder.AddOpenSearchClient();

        // Register the filtering service
        builder.Services.AddScoped<IEnrollmentFilterService, EnrollmentFilterService>();
    }
);

// Run the application
await app.RunAsync();
