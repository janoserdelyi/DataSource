using EnrollmentPipeline.Models;
using EnrollmentPipeline.Repositories;

namespace EnrollmentFilter.Services;

/// <summary>
/// Implementation of enrollment filtering service
/// </summary>
public class EnrollmentFilterService(
    ICampaignRepository campaignRepository,
    ILogger<EnrollmentFilterService> logger
) : IEnrollmentFilterService
{
    // UK government email domains to filter
    private static readonly HashSet<string> UkGovernmentDomains = new(StringComparer.OrdinalIgnoreCase)
    {
        "@voa.gsi.gov.uk",
        "@voa.gov.uk"
    };

    /// <inheritdoc />
    public bool IsOptedOut(StagedEnrollment enrollment)
    {
        // Check if CanEmail field exists and is true
        if (enrollment.DataFields.TryGetPropertyValue("CanEmail", out var canEmailValue))
        {
            if (canEmailValue == null)
            {
                logger.LogDebug(
                    "Enrollment {EnrollmentId} has null CanEmail field",
                    enrollment.Id);

                throw new FormatException("CanEmail field is null");
            }

            // Handle both string and boolean values
            if (bool.TryParse(canEmailValue.ToString(), out var boolValue))
            {
                // If canEmail is false, the contact has opted out
                return !boolValue;
            }

            logger.LogDebug(
                "Enrollment {EnrollmentId} has invalid CanEmail field value: {CanEmailValue}",
                enrollment.Id,
                canEmailValue);

            throw new FormatException(
                $"Invalid CanEmail field value: {canEmailValue}");
        }

        // If CanEmail field is missing or invalid, consider as opted out
        logger.LogDebug(
            "Enrollment {EnrollmentId} missing CanEmail field or has invalid value",
            enrollment.Id);

        throw new KeyNotFoundException("CanEmail field is missing or invalid");
    }

    /// <inheritdoc />
    public bool IsUkGovernmentEmail(StagedEnrollment enrollment)
    {
        var email = enrollment.GetEmailAddress();

        if (string.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        // Check if email contains any UK government domains
        foreach (var domain in UkGovernmentDomains)
        {
            if (email.Contains(domain, StringComparison.OrdinalIgnoreCase))
            {
                logger.LogDebug(
                    "Enrollment {EnrollmentId} has UK government email: {Email}",
                    enrollment.Id,
                    email);
                return true;
            }
        }

        return false;
    }

    /// <inheritdoc />
    public async Task<RequiredFieldsValidationResult> HasRequiredFieldsAsync(
        StagedEnrollment enrollment,
        CancellationToken cancellationToken)
    {
        // Try to retrieve campaign
        var campaign = await campaignRepository.GetCachedCampaignByIdAsync(enrollment.MarketingCampaignId);

        if (campaign == null)
        {
            logger.LogWarning(
                "[{MethodName}] Campaign {CampaignId} not found",
                nameof(HasRequiredFieldsAsync),
                enrollment.MarketingCampaignId);
            return new RequiredFieldsValidationResult(
                HasRequiredFields: false,
                Message: $"Campaign {enrollment.MarketingCampaignId} not found");
        }

        var emptyRequiredFields = new HashSet<string>();
        var missingRequiredFields = new HashSet<string>();

        foreach (var field in campaign.RequiredDataFields)
        {
            if (!enrollment.DataFields.ContainsKey(field.FieldName))
            {
                logger.LogDebug(
                    "[{MethodName}] Enrollment {EnrollmentId} missing required field: {FieldName}",
                    nameof(HasRequiredFieldsAsync),
                    enrollment.Id,
                    field);

                missingRequiredFields.Add(field.FieldName);

                continue;
            }

            var fieldValue = enrollment.DataFields[field.FieldName];

            // Checks if value is null or empty string
            if (fieldValue == null || string.IsNullOrWhiteSpace(fieldValue.ToString()))
            {
                logger.LogDebug(
                    "[{MethodName}] Enrollment {EnrollmentId} has empty required field: {FieldName}",
                    nameof(HasRequiredFieldsAsync),
                    enrollment.Id,
                    field);

                emptyRequiredFields.Add(field.FieldName);
            }
        }

        if (emptyRequiredFields.Count > 0 || missingRequiredFields.Count > 0)
        {
            var messages = new List<string>();

            if (missingRequiredFields.Count > 0)
            {
                messages.Add($"Missing required fields ({string.Join(", ", missingRequiredFields)})");
            }
            if (emptyRequiredFields.Count > 0)
            {
                messages.Add($"Empty required fields ({string.Join(", ", emptyRequiredFields)})");
            }

            return new RequiredFieldsValidationResult(
                HasRequiredFields: false,
                Message: string.Join("; ", messages));
        }

        return new RequiredFieldsValidationResult(
            HasRequiredFields: true,
            Message: string.Empty
        );
    }

    public Task<bool> IsEmailAddressValidAsync(StagedEnrollment enrollment, CancellationToken cancellationToken)
    {
        // TODO: Check email validation status in OpenSearch index

        // Placeholder implementation - always returns true
        return Task.FromResult(true);
    }
}
