using EnrollmentPipeline.Models;

namespace EnrollmentFilter.Services;

/// <summary>
/// Service interface for filtering enrollments based on various criteria
/// </summary>
public interface IEnrollmentFilterService
{
    /// <summary>
    /// Checks if the contact has opted out of receiving marketing emails
    /// by checking the CanEmail field in DataFields
    /// </summary>
    /// <param name="enrollment">The enrollment to check</param>
    /// <returns>True if opted out, false otherwise</returns>
    bool IsOptedOut(StagedEnrollment enrollment);

    /// <summary>
    /// Checks if the email address is from a UK government domain
    /// </summary>
    /// <param name="enrollment">The enrollment to check</param>
    /// <returns>True if UK government email, false otherwise</returns>
    bool IsUkGovernmentEmail(StagedEnrollment enrollment);

    /// <summary>
    /// Checks the email validation status of the enrollment's email address to see if it has a sendable status (good validation result and/or no hard bounces).
    /// </summary>
    /// <param name="enrollment"></param>
    /// <param name="cancellationToken"></param>
    /// <returns>True if the email address is valid (or has a "sendable" status), false otherwise.</returns>
    Task<bool> IsEmailAddressValidAsync(
        StagedEnrollment enrollment,
        CancellationToken cancellationToken);

    /// <summary>
    /// Validates that the enrollment has all required fields for the campaign
    /// This is a placeholder for future implementation with campaign-specific logic
    /// </summary>
    /// <param name="enrollment">The enrollment to validate</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Validation result with success status and message</returns>
    Task<RequiredFieldsValidationResult> HasRequiredFieldsAsync(
        StagedEnrollment enrollment,
        CancellationToken cancellationToken);
}

/// <summary>
/// Result of required fields validation
/// </summary>
public record RequiredFieldsValidationResult(bool HasRequiredFields, string Message);
