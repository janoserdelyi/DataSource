# Enrollment Pipeline Services

A high-performance, event-driven enrollment pipeline built on Redis Streams for processing and enrolling contacts into marketing campaigns across all CoStar Group brands. This system is designed to handle a much higher load (compared to the previous version) with guaranteed delivery, automatic retries, and comprehensive observability.

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
  - [Pipeline Flow](#pipeline-flow)
  - [Pipeline Versions](#pipeline-versions)
  - [Workers](#workers)
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
  - [First-Time Setup](#first-time-setup)
  - [Running the Pipeline](#running-the-pipeline)
  - [Verifying the Setup](#verifying-the-setup)
- [Project Structure](#project-structure)
- [Testing](#testing)
  - [Running Tests](#running-tests)
  - [Running Benchmarks](#running-benchmarks)
- [Troubleshooting](#troubleshooting)
- [Deployment](#deployment)
- [Contributing](#contributing)
  - [Creating a New Worker](#creating-a-new-worker)
  - [Code Review Process](#code-review-process)

## Overview

The Enrollment Pipeline is the backend processing engine of the Marketing Automation platform. It processes enrollment requests and orchestrates the flow of contact data through various validation, enrichment, and publishing stages before enrollments reach Salesforce Marketing Cloud.

### Key Features

- **High Throughput**: Designed to process 100 million enrollments per day
- **Redis Streams**: Leverages Redis Streams for distributed message processing with consumer groups
- **Guaranteed Delivery**: At-least-once delivery semantics with automatic retry mechanisms
- **Auto-scaling**: Workers can be scaled horizontally for increased throughput
- **Observability**: Full OpenTelemetry instrumentation with metrics, traces, and structured logging
- **Pipeline Versioning**: Flexible routing allows different enrollment flows per brand or use case

### What This Repository Contains

This is a redesigned, standalone version of the original Enrollment Pipeline (previously part of `we-marketing-automation-event-queue`). It has been rebuilt from scratch with a focus on:

- Scalability and performance
- Modularity and maintainability
- Comprehensive testing and benchmarking
- Modern .NET 9 patterns and practices

## Architecture

### Pipeline Flow

The pipeline processes enrollments through a series of specialized workers. Each worker reads from a Redis Stream, processes messages in batches, and publishes results to the next worker's stream.

```
┌─────────────────┐
│ Campaign        │
│ Enrollment API  │ Entry point for enrollments (single/batch)
└────────┬────────┘
         │
         v
┌────────────────────────────────────────────────────────────────┐
│                      Pipeline Workers                          │
│                                                                │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │ Data Field   │───>│ Enrollment   │───>│ Email        │      │
│  │ Provider     │    │ Filter       │    │ Validation   │      │
│  └──────────────┘    └──────────────┘    └──────┬───────┘      │
│                                                 │              │
│                      ┌──────────────────────────┘              │
│                      │                                         │
│                      v                                         │
│              ┌──────────────┐                                  │
│              │ Marketing    │                                  │
│              │ Cloud        │                                  │
│              │ Publisher    │                                  │
│              └──────────────┘                                  │
│                                                                │
└────────────────────────────────────────────────────────────────┘
         │                                      │
         v                                      v
┌─────────────────┐                         ┌──────────────┐
│ Salesforce      │                         │ Error        │ Handles failures and retries
│ Marketing Cloud │ Final destination       │ Handler      │
└─────────────────┘                         └──────────────┘
```

> **Note**: Architecture diagrams with detailed flow charts will be added to [docs/architecture/](docs/architecture/) in a future update.

### Pipeline Versions

Pipeline Versions define the "path" an enrollment follows once it is created by the CampaignEnrollment API. Versions are configured in the database and determine:

- The sequence of workers an enrollment passes through
- Brand-specific routing rules
- Which error handler to use

**Example Versions:**

- **Version 1**: `CampaignEnrollment API → DataFieldProvider → EmailValidation → Marketing Cloud`
- **Version 2**: `CampaignEnrollment API → DataFieldProvider → EnrollmentFilter → EmailValidation → Marketing Cloud`
- **Brand-Specific**: Different paths can be configured for different CoStar Group brands

This flexibility allows us to:
- A/B test different processing pipelines
- Route specific brands through custom validation logic
- Gradually roll out new workers without affecting existing flows

### Workers

Each worker extends the `StreamPipelineWorker` base class and implements specific business logic:

| Worker | Description | Key Responsibilities |
|--------|-------------|---------------------|
| **CampaignEnrollmentApi** | Entry point for all enrollments | - Accepts single/batch enrollment requests<br>- Routes to appropriate pipeline version<br>- Publishes to first worker stream |
| **DataFieldProvider** | Enriches enrollments with campaign data | - Retrieves campaign-specific data fields<br>- Populates enrollment with required attributes<br>- Queries PostgreSQL for campaign configuration |
| **EnrollmentFilter** | Filters out invalid enrollments | - Checks opt-out status (CanEmail field)<br>- Validates required fields per campaign<br>- Filters UK government email domains |
| **EmailValidationCheck** | Validates email addresses | - Checks email format and deliverability<br>- Validates contact data integrity<br>- Marks invalid emails for rejection |
| **MarketingCloudPublisher** | Final publishing stage | - Publishes validated enrollments to Salesforce Marketing Cloud<br>- Manages Data Extension updates<br>- Handles API rate limiting |
| **ErrorHandler** | Graceful error handling | - Processes failed enrollments<br>- Implements retry logic with backoff<br>- Logs errors for monitoring and debugging |

## Prerequisites

Before you begin, ensure you have the following installed:

- **[.NET 10 SDK](https://dotnet.microsoft.com/download)** - Required for building and running the application
- **[Podman](https://podman.io/getting-started/installation)** - For running Redis (Valkey) and PostgreSQL containers
    - Use [this guide](https://costar-group-prod-dev.atlassian.net/wiki/spaces/devops/pages/192119969/Configuring+WSL+on+your+Windows+Workstation) on how to set up Podman with Zscaler:
        1. Follow the _`REQUIRED: Fix DNS Resolution in WSLv2`_ step based on your WSL version
            - To know your WSL version, run: `wsl --version`
        2. Follow the _`REQUIRED: Import the Zscaler SSL Certificate into WSL (Ubuntu 20.04x, 22.04x)`_ step
        3. Follow the _`Running Docker Containers in Windows`_ step
            - Use **Option 2: Setup Podman Desktop for Windows (using WSLv2)**
        4. **SKIP** the _`Install kubelogin (on-prem cluster authentication)`_ step
- **[Auth2AWS](https://costar-group-prod-dev.atlassian.net/wiki/spaces/devops/pages/192120177/auth2aws+v4)** - Required only if you are not running a PostgresSQL instance locally.
    - Quick install:
    ```powershell
    Set-ExecutionPolicy Bypass -Scope Process -Force;& ([scriptblock]::Create((irm "https://artifacts.prd.costargroup.com/artifactory/csgp-generic/auth2aws-release/install/windows.ps1")))
    ```
- **[Visual Studio Code](https://code.visualstudio.com/)** (Recommended) - Primary IDE with C# Dev Kit extension

## Getting Started

### First-Time Setup

Follow these steps to set up your local development environment:

#### 1. Clone the Repository

```bash
git clone https://tfs.prd.costargroup.com/CoStarCollection/CoStar%20One/_git/we-ma-enrollment-services
cd we-ma-enrollment-services
```

#### 2. Set Up Infrastructure

Start the required infrastructure services (Redis/Valkey):

```bash
# Using Podman
podman compose up -d valkey
```

This will start:
- **Valkey** (Redis) on `localhost:6379` - The message backbone for the pipeline
- **PostgreSQL** (if needed locally) - For pipeline worker configuration and metadata

> **Why Redis Streams?** Redis Streams provide a powerful message queue with consumer groups, automatic load balancing, message persistence, and at-least-once delivery guarantees. It's the backbone of our high-throughput pipeline architecture.

#### 3. Initialize the Database

Run the database initialization script to set up the required schema and tables:

```bash
# Connect to your local PostgreSQL instance and run:
psql -h localhost -U postgres -d enrollment -f scripts/init-db.sql
```

This script creates:
- The `enrollment` schema
- Pipeline configuration tables (`pipeline_status`, `pipeline_worker`, `pipeline_version`)
- Required seed data for pipeline operation

> **Why PostgreSQL?** PostgreSQL stores pipeline configuration and routing rules. Workers query this database to determine how to process enrollments based on brand settings and pipeline versions.

#### 4. Configure Application Settings

By default, the applications use settings from `appsettings.json` and `appsettings.local.json`. For local development, you typically don't need to change anything, but you can override settings by creating or modifying `appsettings.local.json` files in each worker project.

**Common overrides:**

```json
{
  "ConnectionStrings": {
    "Redis": "localhost:6379",
    "MarketingSupport": "your-connection-string-here"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Debug"
    }
  }
}
```

#### 5. Build the Solution

```bash
dotnet build we-ma-enrollment-services.sln
```

Or use the VS Code task: `Ctrl+Shift+B` → Select "build"

### Running the Pipeline

#### Option 1: Run Individual Workers (Recommended for Development)

Use the VS Code debugger to run individual workers:

1. Open the Debug panel (`Ctrl+Shift+D`)
2. Select a worker from the dropdown (e.g., "DataFieldProvider")
3. Press `F5` to start debugging

This allows you to:
- Set breakpoints and step through code
- See detailed logs in the Debug Console
- Test individual workers in isolation

#### Option 2: Run All Workers with the VS Code run configuration

1. Open the Debug panel (`Ctrl+Shift+D`)
2. In the dropdown, select "Debug: Full Pipeline"
3. Press `F5` to start debugging

This will ensure you are running required infrastructure locally (Redis and Postgres) as well as run all of the required services for the pipeline.

This also allows you to put breakpoints anywhere in the code (in any of the services), which in turns allows you to see an enrollment go through every step in the pipeline.

### Verifying the Setup

#### 1. Check Service Health

Once services are running, you can check their health endpoints:

```bash
# Campaign Enrollment API
curl http://localhost:5000/health

# Workers expose health endpoints on their configured ports
curl http://localhost:5001/health  # Example worker
```

#### 2. Monitor Redis Streams

Use the Valkey CLI to check stream status:

```bash
# Connect to Valkey container
podman exec -it valkey-dev valkey-cli

# List all streams
KEYS *stream*

# Check stream info
XINFO STREAM {worker-stream-id}
```

Where `{worker-stream-id}` is the registered ID of the worker. This is defined in the database and provided to the application via `appsettings.json`.

#### 3. Test an Enrollment

Send a test enrollment to the CampaignEnrollmentApi:

```bash
curl -X POST http://localhost:5000/api/enrollments \
  -H "Content-Type: application/json" \
  -d '{
    "contactId": 12345,
    "campaignId": 678,
    "pipelineVersion": 1
  }'
```

## Project Structure

```
we-ma-enrollment-services/
├── src/
│   ├── EnrollmentPipeline/          # Core library extended by all workers
│   │   ├── StreamPipelineWorker.cs  # Base worker class
│   │   ├── Models/                  # Shared models (StagedEnrollment, WorkerResult)
│   │   ├── Extensions/              # Service collection and telemetry extensions
│   │   ├── Services/                # Shared services (message publisher, health checks)
│   │   └── INTEGRATION_GUIDE.md     # Guide for implementing workers
│   │
│   ├── CampaignEnrollmentApi/       # API entry point for enrollments
│   ├── DataFieldProvider/           # Campaign data enrichment worker
│   ├── EnrollmentFilter/            # Enrollment filtering worker
│   ├── EmailValidationCheck/        # Email validation worker
│   ├── MarketingCloudPublisher/     # Marketing Cloud publishing worker
│   ├── ErrorHandler/                # Error handling and retry worker
│   └── DataPlane.Client/            # Client library for Data Plane service
│
├── tests/
│   ├── EnrollmentPipeline.Tests/    # Unit and integration tests
│   │   ├── Unit/                    # Unit tests for core library
│   │   └── Integration/             # Integration tests with Redis/PostgreSQL
│   │
│   ├── EnrollmentPipeline.Benchmarks/ # Performance benchmarking
│   │   ├── Workers/                 # Individual worker benchmarks
│   │   └── Integration/             # Full pipeline benchmarks
│   │
│   └── [Worker].Tests/              # Worker-specific test projects
│
├── infra/                           # Infrastructure as Code (Terraform)
│   ├── tf_shared/                   # Shared Terraform modules
│   └── [Worker]/                    # Worker-specific infrastructure
│       ├── helm/                    # Kubernetes Helm charts
│       ├── tf/                      # Terraform configurations
│       └── monitors/                # Monitoring configurations
│
├── scripts/                         # Helper scripts
│   ├── init-db.sql                  # Database initialization script
│   └── *.ps1 / *.sh                 # Development helper scripts
│
├── config/                          # Local development configuration
│   └── grafana/                     # Grafana dashboard configurations
│
└── docker-compose.yml               # Local development orchestration
```

## Testing

We maintain comprehensive test coverage across unit tests, integration tests, and performance benchmarks.

### Running Tests

#### Run All Tests

```bash
dotnet test
```

Or use VS Code task: `Ctrl+Shift+P` → "Tasks: Run Task" → "test"

#### Run Unit Tests Only

Unit tests are fast, isolated tests that don't require external dependencies:

```bash
dotnet test --filter "TestCategory=Unit"
```

Or use VS Code task: "test-unit"

### Running Benchmarks

Benchmarks are different from tests - they measure performance characteristics of workers under load.

#### What Are Benchmarks?

Benchmarks use [BenchmarkDotNet](https://benchmarkdotnet.org/) to:
- Measure throughput (enrollments/second)
- Measure latency (processing time per batch)
- Test under various load conditions
- Generate detailed performance reports

#### Running Worker Benchmarks

```bash
cd tests/EnrollmentPipeline.Benchmarks
dotnet run -c Release -- --filter *DataFieldProviderWorkerBenchmarks*
```

Available benchmark categories:
- **Worker Benchmarks**: Test individual worker performance with real dependencies
- **Integration Benchmarks**: Test multi-worker scenarios
- **End-to-End Benchmarks**: Full pipeline throughput tests

#### Interpreting Results

Benchmark results include:
- **Mean**: Average processing time
- **StdDev**: Standard deviation (consistency)
- **Median**: Middle value (typical performance)
- **Throughput**: Messages processed per second

## Troubleshooting

### Common Issues

#### Redis Connection Errors

**Symptom**: `StackExchange.Redis.RedisConnectionException: It was not possible to connect to the redis server(s)`

**Solutions**:
- Ensure Valkey container is running: `podman ps | grep valkey-dev`
- Check connection string in `appsettings.local.json` matches `localhost:6379`
- Verify port 6379 is not in use by another service

#### Worker Not Processing Messages

**Symptom**: Worker starts but doesn't process any enrollments

**Solutions**:
- Check if consumer group exists: `podman exec valkey-dev valkey-cli XINFO GROUPS <stream-name>`
- Verify messages are in the stream: `XLEN <stream-name>`
- Check worker logs for errors or lock contention warnings
- Ensure worker's `WorkerId` in configuration matches database entries

#### Database Connection Issues

**Symptom**: `Npgsql.NpgsqlException: Failed to connect to database`

**Solutions**:
- Ensure PostgreSQL container is running
- Run database initialization script: `psql -f scripts/init-db.sql`
- Verify connection string in `appsettings.local.json`
- Check if database exists: `psql -l | grep enrollment`

#### Build Errors After Pulling Latest

**Symptom**: Build fails with package or dependency errors

**Solutions**:
```bash
# Clean and restore packages
dotnet clean
dotnet restore
dotnet build
```

### Debugging Tips

- **Enable detailed logging**: Set `"Logging:LogLevel:Default": "Debug"` in `appsettings.local.json`
- **Use health endpoints**: Check `/health/detailed` for service status and dependencies
- **Monitor Redis streams**: Use `valkey-cli MONITOR` to watch real-time commands
- **Check metrics**: Workers expose OpenTelemetry metrics for monitoring

## Deployment

The Enrollment Pipeline is deployed to using Kubernetes and managed through Terraform and Helm charts.

### Infrastructure

- **Container Orchestration**: Kubernetes
- **Infrastructure as Code**: Terraform (see `infra/` directory)
- **Package Management**: Helm charts for each worker
- **Observability**: DataDog for metrics, traces, and logs (OpenTelemetry integration)

### Deployment Process

Deployments are automated through Azure DevOps pipelines:

1. **Build**: Docker images are built for each worker
2. **Test**: Automated tests run in CI/CD pipeline
3. **Deploy**: Helm charts deploy to Kubernetes clusters
4. **Verify**: Health checks and smoke tests validate deployment

See individual worker directories under `infra/` for service-specific configurations.

## Contributing

Here's how to get started:

### Development Workflow

1. **Create a feature branch** from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** following our code style:
   - Use declarative namespaces (`namespace EnrollmentPipeline;`)
   - Follow existing patterns in the codebase
   - Add XML documentation comments for public APIs
   - Write unit tests for new functionality

3. **Test your changes**:
   ```bash
   # Run unit tests
   dotnet test --filter "TestCategory=Unit"
   
   # Run integration tests
   dotnet test --filter "TestCategory=Integration"
   
   # Ensure benchmarks still run
   cd tests/EnrollmentPipeline.Benchmarks
   dotnet run -c Release
   ```

4. **Commit and push**:
   ```bash
   git add .
   git commit -m "feat: add new feature"
   git push origin feature/your-feature-name
   ```

5. **Create a Pull Request** on Azure DevOps

### Creating a New Worker

To create a new pipeline worker:

#### 1. Create the Worker Project

```bash
# Create project directory
mkdir src/MyNewWorker
cd src/MyNewWorker

# Create .csproj file
dotnet new console
```

#### 2. Add Project Reference

Add reference to EnrollmentPipeline library in your `.csproj`:

```xml
<ItemGroup>
  <ProjectReference Include="..\EnrollmentPipeline\EnrollmentPipeline.csproj" />
</ItemGroup>
```

#### 3. Implement the Worker

Create your worker class extending `StreamPipelineWorker`:

```csharp
using System.Runtime.CompilerServices;
using EnrollmentPipeline;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;

namespace MyNewWorker;

/// <summary>
/// Implementation of StreamPipelineWorker for [describe purpose]
/// </summary>
public class MyNewWorker(
    IConnectionMultiplexer redis,
    IStreamMessagePublisher publisher,
    ILogger<MyNewWorker> logger,
    IServiceScopeFactory scopeFactory,
    IConfiguration configuration,
    HybridCache hybridCache)
    : StreamPipelineWorker(redis, publisher, logger, scopeFactory, configuration, hybridCache)
{
    protected override int MaxBatchSize => 1000;
    protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(3);
    protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(2);

    public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
        IReadOnlyCollection<StagedEnrollment> enrollments,
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var startTime = DateTimeOffset.UtcNow;

        foreach (var enrollment in enrollments)
        {
            cancellationToken.ThrowIfCancellationRequested();

            // Your processing logic here
            
            yield return ProduceResult(enrollment, startTime)
                .WithSuccess(); // or .WithStatus(PipelineStatus.Failed)
        }
    }
}
```

#### 4. Set Up Program.cs

Create `Program.cs` with OpenTelemetry and Redis configuration:

```csharp
using EnrollmentPipeline.Extensions;
using MyNewWorker;

var builder = Host.CreateApplicationBuilder(args);

// Configure OpenTelemetry
builder.AddOpenTelemetry();

// Configure Redis with telemetry
var redisConnection = builder.Configuration.GetConnectionString("Redis")!;
builder.AddRedisWithTelemetry(redisConnection);

// Any any other services you may need here

// Register your worker
builder.Services.AddStreamPipelineWorker<MyNewWorker>();

var host = builder.Build();
await host.RunAsync();
```

#### 5. Add Configuration

Create `appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  },
  "ConnectionStrings": {
    "Redis": "localhost:6379"
  },
  "PipelineWorkers": {
    "MyNewWorker": "your-worker-guid-from-database"
  }
}
```

#### 6. Add Debug Configuration

Add your worker to `.vscode/launch.json`:

```json
{
  "name": "MyNewWorker",
  "type": "coreclr",
  "request": "launch",
  "program": "${workspaceFolder}/src/MyNewWorker/bin/Debug/net9.0/MyNewWorker.dll",
  "args": [],
  "cwd": "${workspaceFolder}/src/MyNewWorker",
  "env": {
    "ASPNETCORE_ENVIRONMENT": "local",
  }
}
```

#### 7. Write Tests

Create test project and add benchmarks following existing patterns in the repository.

### Code Review Process

1. All changes must go through a **Pull Request**
2. At least **one approval** required from a team member
3. All **tests must pass** in CI/CD pipeline
4. Code must meet **quality standards** and follow existing patterns
5. Use the pull request template in `docs/pull_request_template.md`

### Code Style Guidelines

- Use **declarative namespaces**
- Follow **C# naming conventions** (PascalCase for types, camelCase for parameters)
- Add **XML documentation** for public APIs
- Use **async/await** for I/O operations
- Keep methods **small and focused** (single responsibility)
- **Test your code** - aim for high coverage

---

**Questions or Issues?** Reach out to the Marketing Automation team on Microsoft Teams or check existing documentation in the `docs/` directory.
