The Enrollment Pipeline is a part of the Marketing Automation platform. It is used to process and enroll contacts into
marketing campaigns for all of the CoStar Group's brands. The Enrollment Pipeline is the backend piece, while the
Batch Enrollment Tool contains the user interface part which allows for file uploads and manual enrollment. The Batch
Enrollment Tool lives in a different repository. This version of the Enrollment Pipeline is a redesign of the original
Enrollment Pipeline which was part of the we-marketing-automation-event-queue
repository. This new version has been rebuilt from scratch to be a standalone service with very high scalability and 
throughput.

# General guidance
* Search our codebase for similar patterns before writing new code.
* If you don't have enough context to accurately respond, ask for more information. We like questions and prefer
  to provide more context than for you to guess at what you think we want.
* We aim for 100% test coverage, so please ask if we want to add and/or update tests for the code we're writing.
* Make sure you suggest code that's compatible with the versions of the languages, libraries, and frameworks we use.
* For larger requests, don't just write code for me — explain your plan first, and ask for approval before moving forward.

# Projects
The codebase is divided into several projects:

  * ./src/EnrollmentPipeline/ is the base library project. It contains the core functionality for the enrollment pipeline. All workers extend this library.
  * ./src/EnrollmentPipeline.Tests/ contains unit and integration tests for the EnrollmentPipeline library.
  * ./src/EnrollmentPipeline.Benchmarks/ contains comprehensive performance benchmarks for load testing individual workers, integration scenarios, and the full pipeline end-to-end. Worker benchmarks test ProcessBatch performance directly with real dependencies.
  * ./src/CampaignEnrollmentApi/ is responsible for publishing messages to the correct stream based on the Pipeline Version that is being used. It handles single and batch enrollments.
  * ./src/DataPlane.Client/ is a shared library for interacting with the Data Plane service.
  * The following projects are the workers that extend the EnrollmentPipeline library:
    * ./src/ErrorHandler/ is responsible for gracefully handling errors that occur within the enrollment pipeline and handling retries.
    * ./src/DataFieldProvider/ contains logic for sourcing and providing the campaign data fields for the enrollments.
    * ./src/EmailValidationCheck/ contains logic for checking if email addresses are valid.
    * ./src/EnrollmentFilter/ filters enrollments based on opt-out status (CanEmail field), UK government email domains, and campaign-specific required fields.
    * ./src/MarketingCloudPublisher/ is responsible for publishing enrollments to Salesforce Marketing Cloud.

# Core technologies
* C# 14
* .NET 10
* Redis Streams
* PostgreSQL
* OpenTelemetry
* Docker, Kubernetes, and AWS for hosting

# Testing
* xunit for unit and integration tests and for assertions  
* Moq for mocking dependencies
* BenchmarkDotNet for performance benchmarking and load testing

# Code style
* Always use declarative namespaces.

# Development tools
* Devs are using JetBrains Rider and or Visual Studio Code.
* We use git and feature branching off `main` for development.
* Our code is hosted on Azure DevOps at https://tfs.prd.costargroup.com/CoStarCollection/CoStar%20One/_git/we-ma-enrollment-services.
* We use pull requests for code reviews and merging changes into `main`.
* We use Azure Pipelines for CI/CD.

# Additional guidance
* When in agent mode, before starting implementation you **MUST** ask design questions and ask for confirmation before proceeding.
* When asked to create a new pipeline worker, you **MUST** follow **EVERY ONE** of the following steps:
  1. Identify the specific functionality the worker needs to implement by asking the developer design questions and getting confirmation.
  2. Create a new folder for the worker in the appropriate location (e.g., ./src/WorkerName/) and implement the worker by extending the EnrollmentPipeline library and following the existing patterns in the codebase. Make sure to include the Dockerfile for the worker (should be the same as others except for the worker name).
  3. Add the debug launch configuration for the worker in the .vscode/launch.json file
  4. Add the new project to the list above in the Projects section.
  5. Add comprehensive unit tests for the worker in the ./src/WorkerName.Tests/ project.
  6. Create the CI files for the worker in the .ci/ folder. Use one of the existing worker CI files as a template, the contents should be the same for the datadog-monitors.yaml, helm-pipeline.yaml, and terraform-pipeline.yaml files, except for the project name.
  7. Create the deployment files for the worker in the infra/ folder. Use one of the other existing folders in infra/ as a template. The contents should be exactly the same, except for the project name if applicable.
  8. Add the worker to the docker-compose.yml file at the root of the solution.

