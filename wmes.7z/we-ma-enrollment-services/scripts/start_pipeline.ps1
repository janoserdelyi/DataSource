# Pipeline Startup Script for Windows
# Run this with: .\scripts\start_pipeline.ps1

Write-Host "🚀 Starting Marketing Automation Pipeline with Podman" -ForegroundColor Green
Write-Host "====================================================" -ForegroundColor Green

# Check if podman-compose is available, otherwise use podman compose
$USE_PODMAN_COMPOSE = Get-Command podman-compose -ErrorAction SilentlyContinue
if ($USE_PODMAN_COMPOSE) {
    $COMPOSE_CMD = "podman-compose"
    Write-Host "Using podman-compose" -ForegroundColor Yellow
}
else {
    $COMPOSE_CMD = "podman"
    $COMPOSE_SUBCOMMAND = "compose"
    Write-Host "Using podman compose" -ForegroundColor Yellow
}

# Publish all projects first
Write-Host "📦 Publishing .NET projects..." -ForegroundColor Cyan
Write-Host "Publishing EmailValidation..." -ForegroundColor White
dotnet publish src/EmailValidation/EmailValidation.csproj -c Release

Write-Host "Publishing ErrorHandler..." -ForegroundColor White
dotnet publish src/ErrorHandler/ErrorHandler.csproj -c Release

Write-Host "Publishing CampaignEnrollmentApi..." -ForegroundColor White
dotnet publish src/CampaignEnrollmentApi/CampaignEnrollmentApi.csproj -c Release

Write-Host "✅ All projects published successfully!" -ForegroundColor Green
Write-Host ""

# Build and start all services
Write-Host "Building and starting services..." -ForegroundColor Cyan
if ($USE_PODMAN_COMPOSE) {
    & $COMPOSE_CMD up -d --build
}
else {
    & $COMPOSE_CMD $COMPOSE_SUBCOMMAND up -d --build
}

Write-Host "Waiting for services to be ready..." -ForegroundColor Cyan
Write-Host "This may take a few minutes on first run..." -ForegroundColor Yellow

# Wait for services to start up and initialize
Write-Host "Services are starting up..." -ForegroundColor Cyan
Start-Sleep -Seconds 30

Write-Host ""
Write-Host "✅ Pipeline services started!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 Available Services:" -ForegroundColor Cyan
Write-Host "- CampaignEnrollmentApi (Swagger UI): http://localhost:5000/swagger" -ForegroundColor White
Write-Host "- EmailValidation-1: http://localhost:5001" -ForegroundColor White
Write-Host "- EmailValidation-2: http://localhost:5002" -ForegroundColor White
Write-Host "- ErrorHandler: http://localhost:5006" -ForegroundColor White
Write-Host ""
Write-Host "🧪 Quick Test Commands:" -ForegroundColor Cyan
Write-Host "# Generate 10 test contacts:" -ForegroundColor Gray
Write-Host 'curl -X POST "http://localhost:5000/api/publisher/generate-test/10?campaignId=100"' -ForegroundColor White
Write-Host ""
Write-Host "# Generate 100 test contacts for load testing:" -ForegroundColor Gray
Write-Host 'curl -X POST "http://localhost:5000/api/publisher/generate-test/100?campaignId=101"' -ForegroundColor White
Write-Host ""
Write-Host "📊 To monitor the pipeline:" -ForegroundColor Cyan
Write-Host ".\scripts\monitor_pipeline.ps1" -ForegroundColor White
Write-Host ""
Write-Host "🛑 To stop the pipeline:" -ForegroundColor Cyan
if ($USE_PODMAN_COMPOSE) {
    Write-Host "$COMPOSE_CMD down" -ForegroundColor White
}
else {
    Write-Host "$COMPOSE_CMD $COMPOSE_SUBCOMMAND down" -ForegroundColor White
}
