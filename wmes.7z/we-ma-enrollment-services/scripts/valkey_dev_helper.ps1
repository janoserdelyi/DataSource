#!/usr/bin/env pwsh

<#
.SYNOPSIS
    Development helper script for the local Valkey (Redis) instance

.DESCRIPTION
    This script provides common development tasks for working with the local Valkey instance
    in the marketing automation pipeline.

.EXAMPLE
    .\scripts\valkey_dev_helper.ps1 status
    .\scripts\valkey_dev_helper.ps1 connect
    .\scripts\valkey_dev_helper.ps1 reset
#>

param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet("status", "connect", "reset", "logs", "help")]
    [string]$Action
)

function Show-Help {
    Write-Host "🛠️  Valkey Development Helper" -ForegroundColor Cyan
    Write-Host "=============================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Available commands:" -ForegroundColor Yellow
    Write-Host "  status  - Show Valkey container status and connection info"
    Write-Host "  connect - Connect to Valkey CLI for manual commands"
    Write-Host "  reset   - Reset Valkey data (clear all keys)"
    Write-Host "  logs    - Show Valkey container logs"
    Write-Host "  help    - Show this help message"
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Green
    Write-Host "  .\scripts\valkey_dev_helper.ps1 status"
    Write-Host "  .\scripts\valkey_dev_helper.ps1 connect"
    Write-Host ""
}

function Show-Status {
    Write-Host "📊 Valkey Development Instance Status" -ForegroundColor Cyan
    Write-Host "=====================================" -ForegroundColor Cyan
    Write-Host ""
    
    # Check if Valkey container is running
    Write-Host "🔍 Container Status:" -ForegroundColor Yellow
    podman compose ps valkey
    Write-Host ""
    
    # Test connection
    Write-Host "🌐 Connection Test:" -ForegroundColor Yellow
    $connectionTest = Test-NetConnection -ComputerName localhost -Port 6379 -WarningAction SilentlyContinue
    if ($connectionTest.TcpTestSucceeded) {
        Write-Host "✅ Valkey is accessible on localhost:6379" -ForegroundColor Green
    } else {
        Write-Host "❌ Cannot connect to Valkey on localhost:6379" -ForegroundColor Red
    }
    Write-Host ""
    
    Write-Host "📝 Connection Details:" -ForegroundColor Yellow
    Write-Host "  - Host: localhost"
    Write-Host "  - Port: 6379"
    Write-Host "  - Container service name: valkey"
    Write-Host "  - Data volume: valkey_data"
    Write-Host ""
    
    Write-Host "🔧 Quick Commands:" -ForegroundColor Yellow
    Write-Host "  - Connect to CLI: .\scripts\valkey_dev_helper.ps1 connect"
    Write-Host "  - View logs: .\scripts\valkey_dev_helper.ps1 logs"
    Write-Host "  - Reset data: .\scripts\valkey_dev_helper.ps1 reset"
}

function Connect-Valkey {
    Write-Host "🔗 Connecting to Valkey CLI..." -ForegroundColor Cyan
    Write-Host "Type 'exit' or press Ctrl+C to disconnect" -ForegroundColor Yellow
    Write-Host ""
    
    # Connect to Valkey CLI in the container
    podman exec -it valkey-dev valkey-cli
}

function Reset-Valkey {
    Write-Host "⚠️  WARNING: This will clear ALL data in Valkey!" -ForegroundColor Red
    $confirm = Read-Host "Are you sure you want to reset all data? (yes/no)"
    
    if ($confirm -eq "yes") {
        Write-Host "🧹 Clearing all Valkey data..." -ForegroundColor Yellow
        podman exec valkey-dev valkey-cli FLUSHALL
        Write-Host "✅ Valkey data cleared" -ForegroundColor Green
    } else {
        Write-Host "❌ Operation cancelled" -ForegroundColor Yellow
    }
}

function Show-Logs {
    Write-Host "📋 Valkey Container Logs" -ForegroundColor Cyan
    Write-Host "========================" -ForegroundColor Cyan
    Write-Host ""
    podman compose logs valkey --tail=50 -f
}

# Main execution
switch ($Action) {
    "status" { Show-Status }
    "connect" { Connect-Valkey }
    "reset" { Reset-Valkey }
    "logs" { Show-Logs }
    "help" { Show-Help }
}
