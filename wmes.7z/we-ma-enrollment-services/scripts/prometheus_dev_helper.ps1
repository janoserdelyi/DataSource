#!/usr/bin/env pwsh

<#
.SYNOPSIS
    Development helper script for Prometheus metrics monitoring

.DESCRIPTION
    This script provides common development tasks for working with Prometheus
    to monitor the marketing automation pipeline services.

.EXAMPLE
    .\scripts\prometheus_dev_helper.ps1 status
    .\scripts\prometheus_dev_helper.ps1 open
    .\scripts\prometheus_dev_helper.ps1 targets
#>

param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet("status", "open", "targets", "metrics", "help")]
    [string]$Action
)

function Show-Help {
    Write-Host "📊 Prometheus Development Helper" -ForegroundColor Cyan
    Write-Host "===============================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Available commands:" -ForegroundColor Yellow
    Write-Host "  status   - Show Prometheus container status and connection info"
    Write-Host "  open     - Open Prometheus web interface in browser"
    Write-Host "  targets  - Show all configured scrape targets"
    Write-Host "  metrics  - Show available metrics endpoints"
    Write-Host "  help     - Show this help message"
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Green
    Write-Host "  .\scripts\prometheus_dev_helper.ps1 status"
    Write-Host "  .\scripts\prometheus_dev_helper.ps1 open"
    Write-Host ""
}

function Show-Status {
    Write-Host "📊 Prometheus Development Instance Status" -ForegroundColor Cyan
    Write-Host "=========================================" -ForegroundColor Cyan
    Write-Host ""
    
    # Check if Prometheus container is running
    Write-Host "🔍 Container Status:" -ForegroundColor Yellow
    podman compose ps prometheus
    Write-Host ""
    
    # Test connection
    Write-Host "🌐 Connection Test:" -ForegroundColor Yellow
    $connectionTest = Test-NetConnection -ComputerName localhost -Port 9090 -WarningAction SilentlyContinue
    if ($connectionTest.TcpTestSucceeded) {
        Write-Host "✅ Prometheus is accessible on localhost:9090" -ForegroundColor Green
    }
    else {
        Write-Host "❌ Cannot connect to Prometheus on localhost:9090" -ForegroundColor Red
    }
    Write-Host ""
    
    # Test Redis Exporter
    Write-Host "🔍 Redis Exporter Status:" -ForegroundColor Yellow
    podman compose ps redis-exporter
    Write-Host ""
    
    $redisExporterTest = Test-NetConnection -ComputerName localhost -Port 9121 -WarningAction SilentlyContinue
    if ($redisExporterTest.TcpTestSucceeded) {
        Write-Host "✅ Redis Exporter is accessible on localhost:9121" -ForegroundColor Green
    }
    else {
        Write-Host "❌ Cannot connect to Redis Exporter on localhost:9121" -ForegroundColor Red
    }
    Write-Host ""
    
    Write-Host "📝 Connection Details:" -ForegroundColor Yellow
    Write-Host "  - Prometheus UI: http://localhost:9090"
    Write-Host "  - Redis Exporter: http://localhost:9121/metrics"
    Write-Host "  - Config file: ./config/prometheus.yml"
    Write-Host "  - Data volume: prometheus_data"
    Write-Host ""
    
    Write-Host "🔧 Quick Commands:" -ForegroundColor Yellow
    Write-Host "  - Open UI: .\scripts\prometheus_dev_helper.ps1 open"
    Write-Host "  - View targets: .\scripts\prometheus_dev_helper.ps1 targets"
    Write-Host "  - View metrics: .\scripts\prometheus_dev_helper.ps1 metrics"
}

function Open-PrometheusUI {
    Write-Host "🌐 Opening Prometheus web interface..." -ForegroundColor Cyan
    Start-Process "http://localhost:9090"
}

function Show-Targets {
    Write-Host "🎯 Prometheus Scrape Targets" -ForegroundColor Cyan
    Write-Host "============================" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Host "📊 Service Metrics Endpoints:" -ForegroundColor Yellow
    Write-Host "  - Campaign Enrollment API:  http://localhost:5000/metrics"
    Write-Host "  - Email Validation 1: http://localhost:5001/metrics"
    Write-Host "  - Email Validation 2: http://localhost:5002/metrics"
    Write-Host "  - Email Enrollment 1: http://localhost:5003/metrics"
    Write-Host "  - Email Enrollment 2: http://localhost:5004/metrics"
    Write-Host "  - Email Enrollment 3: http://localhost:5005/metrics"
    Write-Host "  - Error Processing:   http://localhost:5006/metrics"
    Write-Host ""
    
    Write-Host "🔧 Infrastructure Metrics:" -ForegroundColor Yellow
    Write-Host "  - Valkey (Redis):     http://localhost:9121/metrics"
    Write-Host "  - Prometheus:         http://localhost:9090/metrics"
    Write-Host ""
    
    Write-Host "🌐 Prometheus Targets Page:" -ForegroundColor Green
    Write-Host "  http://localhost:9090/targets"
}

function Show-Metrics {
    Write-Host "📈 Available Metrics Overview" -ForegroundColor Cyan
    Write-Host "=============================" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Host "🏗️ ASP.NET Core Metrics:" -ForegroundColor Yellow
    Write-Host "  - HTTP request metrics (duration, status codes)"
    Write-Host "  - Connection pool metrics"
    Write-Host "  - GC and memory metrics"
    Write-Host ""
    
    Write-Host "🔧 Custom Pipeline Metrics:" -ForegroundColor Yellow
    Write-Host "  - Stream processing metrics"
    Write-Host "  - Worker leadership metrics"
    Write-Host "  - Message throughput"
    Write-Host ""
    
    Write-Host "💾 Redis/Valkey Metrics:" -ForegroundColor Yellow
    Write-Host "  - Connection metrics"
    Write-Host "  - Memory usage"
    Write-Host "  - Command statistics"
    Write-Host "  - Stream metrics"
    Write-Host ""
    
    Write-Host "💡 Quick Prometheus Queries:" -ForegroundColor Green
    Write-Host "  - HTTP requests: http_requests_total"
    Write-Host "  - Memory usage: process_working_set_bytes"
    Write-Host "  - Redis connections: redis_connected_clients"
    Write-Host "  - GC collections: dotnet_collection_count_total"
    Write-Host ""
    
    Write-Host "🌐 Explore in Prometheus UI:" -ForegroundColor Green
    Write-Host "  http://localhost:9090/graph"
}

# Main execution
switch ($Action) {
    "status" { Show-Status }
    "open" { Open-PrometheusUI }
    "targets" { Show-Targets }
    "metrics" { Show-Metrics }
    "help" { Show-Help }
}
