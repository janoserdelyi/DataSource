# Pipeline Monitoring Script for    Write-Host ""
Write-Host "🔄 CONTAINER STATUS" -ForegroundColor Yellow
Write-Host "-----------------" -ForegroundColor Yellow
podman compose ps
    
Write-Host ""
Write-Host "📝 QUICK COMMANDS:" -ForegroundColor Cyan
Write-Host "- Generate 10 test contacts: curl -X POST `"http://localhost:5000/api/publisher/generate-test/10?campaignId=$((Get-Date).Ticks)`"" -ForegroundColor White
Write-Host "- View service logs: podman compose logs -f [service-name]" -ForegroundColor White
Write-Host "- Scale a service: podman compose up -d --scale email-enrollment=5" -ForegroundColor White this with: .\scripts\monitor_pipeline.ps1

# Function to get service health
function Get-ServiceHealth {
    param($ServiceName, $Port)
    Write-Host "🏥 Service: $ServiceName (Port: $Port)" -ForegroundColor Cyan
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$Port/health" -TimeoutSec 5 -ErrorAction SilentlyContinue
        $response.Content | Select-Object -First 1
    }
    catch {
        Write-Host "Service not responding" -ForegroundColor Red
    }
    Write-Host ""
}

while ($true) {
    Clear-Host
    Write-Host "🚀 Marketing Pipeline Monitoring Dashboard - $(Get-Date)" -ForegroundColor Green
    Write-Host "=================================================" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "🏥 SERVICE HEALTH STATUS" -ForegroundColor Yellow
    Write-Host "----------------------" -ForegroundColor Yellow
    Get-ServiceHealth "CampaignEnrollmentApi" "5000"
    Get-ServiceHealth "EmailValidation-1" "5001"
    Get-ServiceHealth "EmailValidation-2" "5002"
    Get-ServiceHealth "EmailEnrollment-1" "5003"
    Get-ServiceHealth "EmailEnrollment-2" "5004"
    Get-ServiceHealth "EmailEnrollment-3" "5005"
    Get-ServiceHealth "ErrorHandler" "5006"
    
    Write-Host ""
    Write-Host " CONTAINER STATUS" -ForegroundColor Yellow
    Write-Host "-----------------" -ForegroundColor Yellow
    if (Get-Command podman-compose -ErrorAction SilentlyContinue) {
        podman-compose ps
    }
    else {
        podman compose ps
    }
    
    Write-Host ""
    Write-Host "📝 QUICK COMMANDS:" -ForegroundColor Cyan
    $compose_command = if (Get-Command podman-compose -ErrorAction SilentlyContinue) { "podman-compose" } else { "podman compose" }
    Write-Host "- Generate 10 test contacts: curl -X POST `"http://localhost:5000/api/publisher/generate-test/10?campaignId=$((Get-Date).Ticks)`"" -ForegroundColor White
    Write-Host "- View service logs: $compose_command logs -f [service-name]" -ForegroundColor White
    Write-Host "- Scale a service: $compose_command up -d --scale email-enrollment=5" -ForegroundColor White
    Write-Host ""
    Write-Host "Press Ctrl+C to exit monitoring..." -ForegroundColor Gray
    Start-Sleep -Seconds 15
}
