#!/bin/bash
# Pipeline Startup Script

echo "🚀 Starting Marketing Automation Pipeline with Podman"
echo "===================================================="

# Check if podman-compose is available, otherwise use podman compose
if command -v podman-compose &> /dev/null; then
    COMPOSE_CMD="podman-compose"
else
    COMPOSE_CMD="podman compose"
fi

echo "Using compose command: $COMPOSE_CMD"

# Build and start all services
echo "Building and starting services..."
$COMPOSE_CMD up -d --build

echo "Waiting for services to be healthy..."
echo "This may take a few minutes on first run..."

# Wait for Redis and Postgres to be ready
echo "Checking Redis..."
for i in {1..30}; do
    if $COMPOSE_CMD exec redis redis-cli ping > /dev/null 2>&1; then
        echo "✅ Redis is ready!"
        break
    fi
    echo "Waiting for Redis... ($i/30)"
    sleep 5
done

echo "Checking PostgreSQL..."
for i in {1..30}; do
    if $COMPOSE_CMD exec postgres pg_isready -U pipeline_user -d enrollment_pipeline > /dev/null 2>&1; then
        echo "✅ PostgreSQL is ready!"
        break
    fi
    echo "Waiting for PostgreSQL... ($i/30)"
    sleep 5
done

# Wait a bit more for services to fully initialize
sleep 15

echo ""
echo "✅ Pipeline is ready!"
echo ""
echo "📋 Available Services:"
echo "- CampaignEnrollmentApi (Swagger UI): http://localhost:5000/swagger"
echo "- Redis Insight: http://localhost:8001"
echo "- EmailValidation-1: http://localhost:5001"
echo "- EmailValidation-2: http://localhost:5002"
echo "- EmailEnrollment-1: http://localhost:5003"
echo "- EmailEnrollment-2: http://localhost:5004"
echo "- EmailEnrollment-3: http://localhost:5005"
echo "- ErrorHandler: http://localhost:5006"
echo ""
echo "🧪 Quick Test Commands:"
echo "# Generate 10 test contacts:"
echo "curl -X POST \"http://localhost:5000/api/publisher/generate-test/10?campaignId=100\""
echo ""
echo "# Generate 100 test contacts for load testing:"
echo "curl -X POST \"http://localhost:5000/api/publisher/generate-test/100?campaignId=101\""
echo ""
echo "📊 To monitor the pipeline:"
echo "./scripts/monitor_pipeline.sh"
echo ""
echo "🛑 To stop the pipeline:"
echo "$COMPOSE_CMD down"
