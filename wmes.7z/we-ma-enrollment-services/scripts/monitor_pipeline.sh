#!/bin/bash
# Pipeline Monitoring Script

# Check if podman-compose is available, otherwise use podman compose
if command -v podman-compose &> /dev/null; then
    COMPOSE_CMD="podman-compose"
else
    COMPOSE_CMD="podman compose"
fi

# Function to get Redis stream info
get_stream_info() {
    local stream_name=$1
    echo "📊 Stream: $stream_name"
    $COMPOSE_CMD exec redis redis-cli XINFO STREAM $stream_name 2>/dev/null || echo "Stream not found or empty"
    echo ""
}

# Function to get service health
get_service_health() {
    local service_name=$1
    local port=$2
    echo "🏥 Service: $service_name (Port: $port)"
    curl -s --max-time 5 "http://localhost:$port/health" 2>/dev/null | head -n 1 || echo "Service not responding"
    echo ""
}

while true; do
    clear
    echo "🚀 Marketing Pipeline Monitoring Dashboard - $(date)"
    echo "================================================="
    
    echo ""
    echo "📈 REDIS STREAMS STATUS"
    echo "----------------------"
    get_stream_info "email-validation-worker-stream"
    get_stream_info "email-enrollment-stream" 
    get_stream_info "error-processing-stream"
    
    echo ""
    echo "🏥 SERVICE HEALTH STATUS"
    echo "----------------------"
    get_service_health "CampaignEnrollmentApi" "5000"
    get_service_health "EmailValidation-1" "5001"
    get_service_health "EmailValidation-2" "5002"
    get_service_health "EmailEnrollment-1" "5003"
    get_service_health "EmailEnrollment-2" "5004"
    get_service_health "EmailEnrollment-3" "5005"
    get_service_health "ErrorHandler" "5006"
    
    echo ""
    echo "📊 DATABASE STATUS"
    echo "----------------"
    $COMPOSE_CMD exec postgres psql -U pipeline_user -d enrollment_pipeline -c "
        SELECT 
            LastProcessorName, 
            StatusId, 
            COUNT(*) as Count,
            MAX(UpdatedAt) as LastProcessed
        FROM platform.CampaignEnrollment 
        GROUP BY LastProcessorName, StatusId 
        ORDER BY LastProcessorName, StatusId;
    " 2>/dev/null || echo "Database query failed"
    
    echo ""
    echo "📈 RECENT ACTIVITY (Last 10 records)"
    echo "-----------------------------------"
    $COMPOSE_CMD exec postgres psql -U pipeline_user -d enrollment_pipeline -c "
        SELECT ContactId, CampaignId, LastProcessorName, StatusId, UpdatedAt 
        FROM platform.CampaignEnrollment 
        ORDER BY UpdatedAt DESC 
        LIMIT 10;
    " 2>/dev/null || echo "Database query failed"
    
    echo ""
    echo "🔄 CONTAINER STATUS"
    echo "-----------------"
    $COMPOSE_CMD ps
    
    echo ""
    echo "📝 QUICK COMMANDS:"
    echo "- Generate 10 test contacts: curl -X POST \"http://localhost:5000/api/publisher/generate-test/10?campaignId=\$(date +%s)\""
    echo "- View service logs: $COMPOSE_CMD logs -f [service-name]"
    echo "- Scale a service: $COMPOSE_CMD up -d --scale email-enrollment=5"
    echo ""
    echo "Press Ctrl+C to exit monitoring..."
    sleep 15
done
