-- =====================================================
-- Enrollment Pipeline Database Initialization Script
-- =====================================================
    
-- -- Drop existing tables if they exist (for re-initialization purposes)
DROP TABLE IF EXISTS enrollment.failed;
DROP TABLE IF EXISTS enrollment.staged;
DROP TABLE IF EXISTS enrollment.pipeline_version_worker;
DROP TABLE IF EXISTS enrollment.pipeline_version;
DROP TABLE IF EXISTS enrollment.pipeline_worker;
DROP TABLE IF EXISTS enrollment.pipeline_status_reason;
DROP TABLE IF EXISTS enrollment.pipeline_status;

-- Create pipeline_status table
CREATE TABLE IF NOT EXISTS enrollment.pipeline_status (
    id           SMALLINT PRIMARY KEY NOT NULL,
    name         VARCHAR NOT NULL,
    description  TEXT,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by   INTEGER,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_by   INTEGER
);

-- Create pipeline_status_reason table
CREATE TABLE IF NOT EXISTS enrollment.pipeline_status_reason (
    id           SMALLINT PRIMARY KEY NOT NULL,
    name         VARCHAR NOT NULL,
    description  TEXT,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by   INTEGER,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_by   INTEGER
);

-- Create pipeline_worker table
CREATE TABLE IF NOT EXISTS enrollment.pipeline_worker (
    id           UUID DEFAULT gen_random_uuid() NOT NULL
        CONSTRAINT pipeline_worker_pk PRIMARY KEY,
    name         VARCHAR NOT NULL,
    description  TEXT,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by   INTEGER,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_by   INTEGER
);

-- Create pipeline_version table
CREATE TABLE IF NOT EXISTS enrollment.pipeline_version (
    id           SMALLINT PRIMARY KEY NOT NULL,
    brand_id     SMALLINT,
    active       BOOLEAN NOT NULL DEFAULT TRUE,
    error_handler_worker_id UUID
        CONSTRAINT pipeline_version_error_handler_worker_id_fk
            REFERENCES enrollment.pipeline_worker(id),
    created_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by   INTEGER
);

-- Create pipeline_version_worker junction table
CREATE TABLE IF NOT EXISTS enrollment.pipeline_version_worker (
    version_id   SMALLINT NOT NULL
        CONSTRAINT pipeline_version_worker_pipeline_version_id_fk
            REFERENCES enrollment.pipeline_version(id),
    worker_id    UUID NOT NULL
        CONSTRAINT pipeline_version_worker_pipeline_worker_id_fk
            REFERENCES enrollment.pipeline_worker(id),
    worker_order INTEGER NOT NULL,
    CONSTRAINT pipeline_version_worker_order_uk
        UNIQUE (version_id, worker_order),
    CONSTRAINT pipeline_version_worker_id_uk
        UNIQUE (version_id, worker_id)
);

-- Create staged enrollments table (main data table)
CREATE TABLE IF NOT EXISTS enrollment.staged (
    id                       UUID PRIMARY KEY NOT NULL,
    marketing_campaign_id   INTEGER NOT NULL,
    contact_id              INTEGER NOT NULL,
    json_message            JSONB,
    status_id               SMALLINT NOT NULL
        CONSTRAINT staged_status_id_fk
            REFERENCES enrollment.pipeline_status(id),
    status_reason_id        SMALLINT NOT NULL
        CONSTRAINT staged_status_reason_id_fk
            REFERENCES enrollment.pipeline_status_reason(id),
    status_message          TEXT,
    pipeline_version_id     SMALLINT NOT NULL
        CONSTRAINT staged_pipeline_version_id_fk
            REFERENCES enrollment.pipeline_version(id),
    created_date            TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_date            TIMESTAMP WITH TIME ZONE,
    updated_by_worker_id    UUID
        CONSTRAINT staged_updated_by_worker_id_fk
            REFERENCES enrollment.pipeline_worker(id)
);


-- Create failed enrollments table (observability data table)
CREATE TABLE IF NOT EXISTS enrollment.failed (
    id                      UUID PRIMARY KEY NOT NULL,
    marketing_campaign_id   INTEGER NOT NULL,
    contact_id              INTEGER NOT NULL,
    json_message            JSONB,
    status_id               SMALLINT NOT NULL
        CONSTRAINT failed_status_id_fk
            REFERENCES enrollment.pipeline_status(id),
    status_reason_id        SMALLINT NOT NULL
        CONSTRAINT failed_status_reason_id_fk
            REFERENCES enrollment.pipeline_status_reason(id),
    status_message          TEXT,
    pipeline_version_id     SMALLINT NOT NULL
        CONSTRAINT failed_pipeline_version_id_fk
            REFERENCES enrollment.pipeline_version(id),
    created_date            TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_date            TIMESTAMP WITH TIME ZONE
);

-- =====================================================
-- CREATE PERFORMANCE INDEXES
-- =====================================================

-- Index on name for status lookups
CREATE INDEX IF NOT EXISTS IX_PipelineStatus_Name
    ON enrollment.pipeline_status(name);

-- Index on name for worker lookups
CREATE INDEX IF NOT EXISTS IX_PipelineWorker_Name
    ON enrollment.pipeline_worker(name);

-- Index on created_date for version queries
CREATE INDEX IF NOT EXISTS IX_PipelineVersion_CreatedDate
    ON enrollment.pipeline_version(created_date);

-- Composite unique index on ContactId + MarketingCampaignId for efficient upserts
-- CREATE UNIQUE INDEX IF NOT EXISTS IX_StagedEnrollment_Contact_Campaign
--     ON enrollment.staged(contact_id, marketing_campaign_id);

-- Index on UpdatedByWorkerId for querying by worker
CREATE INDEX IF NOT EXISTS IX_StagedEnrollment_UpdatedByWorker
    ON enrollment.staged(updated_by_worker_id);

-- Index on StatusId for status-based queries
CREATE INDEX IF NOT EXISTS IX_StagedEnrollment_StatusId
    ON enrollment.staged(status_id);

-- Index on PipelineVersionId for version-based queries
CREATE INDEX IF NOT EXISTS IX_StagedEnrollment_PipelineVersionId
    ON enrollment.staged(pipeline_version_id);

-- Index on CreatedDate for time-based queries
CREATE INDEX IF NOT EXISTS IX_StagedEnrollment_CreatedDate
    ON enrollment.staged(created_date);

-- =====================================================
-- INSERT INITIAL DATA
-- =====================================================

-- Insert default pipeline statuses
INSERT INTO enrollment.pipeline_status (id, name, description, created_by)
VALUES
    (1, 'Created', 'Contact has been created and is awaiting processing', 1),
    (2, 'Processing', 'Contact is being processed through the pipeline', 1),
    (3, 'Success', 'Contact processing succeeded', 1),
    (4, 'Failed', 'Contact processing failed with errors', 1),
    (5, 'Completed', 'Contact processing completed successfully', 1),
    (6, 'Retrying', 'Contact processing is being retried after failure', 1)
ON CONFLICT DO NOTHING;

-- Insert default pipeline status reasons
INSERT INTO enrollment.pipeline_status_reason (id, name, description, created_by)
VALUES
    (1,  'ExceededNumberOfRetries'       , 'The enrollment has exceeded the maximum number of retries allowed.', 1),
    (2,  'MissingEmailAddress'           , 'The contact in the enrollment is missing an email address.', 1),
    (3,  'MissingRequiredFields'         , 'The contact in the enrollment is missing required fields.', 1),
    (4,  'InvalidEmailAddress'           , 'The email address in the enrollment is invalid.', 1),
    (5,  'DataFieldLookupFailed'         , 'The data field lookup process failed to retrieve any data fields.', 1),
    (6,  'MissingEmailValidation'        , 'Email address in the enrollment has not been verified.', 1),
    (7,  'ContactOptedOut'               , 'Failed to enroll due to contact has opted out.', 1),
    (8,  'UkGovernmentEmailDomain'       , 'Failed to enroll due to contact has UK government email domain.', 1),
    (9,  'MissingCampaignMetadata'       , 'Failed to enroll due to missing campaign metadata.', 1),
    (10, 'MarketingCloudPublishFailed'   , 'Failed to publish enrollment to Marketing Cloud.', 1),
    (11, 'InvalidContact'                , 'Invalid contact (contact not found in the initial lookup).', 1)
ON CONFLICT DO NOTHING;

-- Insert sample pipeline workers
INSERT INTO enrollment.pipeline_worker (id, name, description, created_by)
VALUES
    ('3099ab90-b236-4654-b7dd-6950e3c34b91'::UUID, 'Data Field Provider', 'Gathers required data fields for enrollments.', 1),
    ('ac8d25d4-ac01-4244-be5e-e60750c8854c'::UUID, 'Email Validation Check', 'Checks if email has been validated.', 1),
    ('876c9b60-a744-4ddb-a1f3-58e3e6427dd7'::UUID, 'Enrollment Filter', 'Filters out enrollments based on predefined criteria.', 1),
    ('a7317f42-e97a-41a1-a587-0646a3180736'::UUID, 'Marketing Cloud Publisher', 'Publishes enrollments to the Marketing Cloud Data Extension.', 1),
    ('83a6f01e-e81c-473f-83cc-06668d2a14bb'::UUID, 'Error Handler', 'Handles errors and retries failed enrollments.', 1)
ON CONFLICT (id) DO NOTHING;

-- Insert default pipeline version
INSERT INTO enrollment.pipeline_version (id, created_by, error_handler_worker_id)
VALUES (1, 1, '83a6f01e-e81c-473f-83cc-06668d2a14bb'::UUID)
ON CONFLICT DO NOTHING;

-- Link workers to default pipeline version
INSERT INTO enrollment.pipeline_version_worker (version_id, worker_id, worker_order)
VALUES
    (1, '3099ab90-b236-4654-b7dd-6950e3c34b91'::UUID, 1),
    (1, 'ac8d25d4-ac01-4244-be5e-e60750c8854c'::UUID, 2),
    (1, '876c9b60-a744-4ddb-a1f3-58e3e6427dd7'::UUID, 3),
    (1, 'a7317f42-e97a-41a1-a587-0646a3180736'::UUID, 4)
ON CONFLICT (version_id, worker_order) DO NOTHING;

-- =====================================================
-- VERIFICATION QUERIES (Commented out - uncomment to test)
-- =====================================================

/*
-- Verify schema creation
SELECT schemaname, tablename
FROM pg_tables
WHERE schemaname = 'enrollment'
ORDER BY tablename;

-- Verify initial data
SELECT 'pipeline_status' as table_name, COUNT(*) as record_count FROM enrollment.pipeline_status
UNION ALL
SELECT 'pipeline_worker', COUNT(*) FROM enrollment.pipeline_worker
UNION ALL
SELECT 'pipeline_version', COUNT(*) FROM enrollment.pipeline_version
UNION ALL
SELECT 'pipeline_version_worker', COUNT(*) FROM enrollment.pipeline_version_worker
UNION ALL
SELECT 'staged', COUNT(*) FROM enrollment.staged;
*/

COMMIT;
