# Scalable Redis Pipeline Workers

This document describes the scalable architecture implementation using Redis Streams for automatic load balancing and horizontal pod autoscaling.

## 🏗️ **Architecture Overview**

### **Traditional PipelineWorker**
- Uses Redis pub/sub with distributed locking
- Single worker processes messages at a time per channel
- Simple but limited scalability

### **StreamPipelineWorker** (New)
- Uses Redis Streams with consumer groups
- Automatic load balancing across multiple workers
- Guaranteed message delivery with acknowledgments
- Built-in auto-scaling capabilities
- Leader election for scaling decisions

## 🚀 **Key Features**

### **1. Redis Streams Benefits**
- **Automatic Load Balancing**: Messages are distributed across available workers
- **Guaranteed Delivery**: Messages are acknowledged only after successful processing
- **Consumer Groups**: Multiple workers share the load automatically
- **Message Persistence**: Messages survive worker restarts
- **Failure Recovery**: Failed messages can be claimed by other workers

### **2. Auto-Scaling Capabilities**
- **Metrics-Based Scaling**: Scales based on stream length and pending messages
- **Leader Election**: One worker monitors and makes scaling decisions
- **HPA Integration**: Kubernetes Horizontal Pod Autoscaler support
- **Custom Metrics**: Exports metrics for monitoring systems

### **3. Observability**
- **Comprehensive Metrics**: Stream length, pending messages, consumer lag
- **Distributed Tracing**: Full OpenTelemetry integration
- **Health Checks**: Stream and worker health monitoring
- **Scaling Recommendations**: Intelligent scaling suggestions

## 📊 **Scaling Metrics**

| Metric | Description | Usage |
|--------|-------------|-------|
| `pipeline_stream_length` | Current messages in stream | Scale up when high |
| `pipeline_stream_pending_messages` | Messages pending acknowledgment | Detect processing bottlenecks |
| `pipeline_stream_consumer_lag_total` | Consumer lag in milliseconds | Monitor processing delays |
| `pipeline_active_workers` | Recommended worker count | Auto-scaling decisions |

## 🐳 **Kubernetes Deployment**

### **1. Basic Deployment**
```bash
# Deploy the worker pods
kubectl apply -f kubernetes/deployment.yaml

# Deploy auto-scaling configuration  
kubectl apply -f kubernetes/hpa.yaml

# Configure custom metrics
kubectl apply -f kubernetes/metrics-config.yaml
```

### **2. Scaling Behavior**
- **Scale Up**: When stream length > 50 messages per pod
- **Scale Down**: When stream length < 20 messages per pod  
- **Min Replicas**: 2 (for redundancy)
- **Max Replicas**: 20 (configurable)
- **Stabilization**: 60s up, 300s down (prevents thrashing)

### **3. Monitoring Integration**
- **Prometheus**: Scrapes metrics from `/metrics` endpoint
- **Grafana**: Dashboards for stream monitoring
- **Alerts**: Configure alerts for high lag or scaling events

## 🔄 **Migration Guide**

### **From PipelineWorker to StreamPipelineWorker**

1. **Change Base Class**:
```csharp
// Old
public class EmailWorker : PipelineWorker

// New  
public class EmailWorker : StreamPipelineWorker
```

2. **Update Configuration**:
```csharp
// Old - Channel-based
protected override string ChannelName => "email-queue";

// New - Stream-based
protected override string StreamName => "email-stream";
protected override string ConsumerGroupName => "email-workers";
```

3. **Update Message Publishing**:
```csharp
// Old - Pub/Sub
await subscriber.PublishAsync("email-queue", message);

// New - Stream  
await publisher.PublishContactAsync("email-stream", contact);
```

## ⚡ **Performance Optimizations**

### **1. Batch Size Tuning**
- **Small Batches (10-25)**: Better responsiveness, higher throughput
- **Large Batches (50-100)**: Lower overhead, potential latency
- **Recommendation**: Start with 50, monitor and adjust

### **2. Worker Configuration**
```csharp
protected override int MaxBatchSize => 50;
protected override TimeSpan ReadTimeout => TimeSpan.FromSeconds(2);
protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);
```

### **3. Redis Configuration**
```bash
# Redis settings for optimal stream performance
maxmemory-policy allkeys-lru
stream-node-max-bytes 4096
stream-node-max-entries 100
```

## 🏃‍♂️ **Getting Started**

### **1. Use StreamPipelineWorker**
```csharp
public class EmailWorker : StreamPipelineWorker
{
    public EmailWorker(IConnectionMultiplexer redis, ILogger<StreamPipelineWorker> logger) 
        : base(redis, logger) { }

    protected override string StreamName => "email-stream";
    protected override string ConsumerGroupName => "email-workers";
    protected override string WorkerName => "EmailWorker";
    protected override int MaxBatchSize => 50;
    protected override TimeSpan ReadTimeout => TimeSpan.FromSeconds(2);
    protected override TimeSpan ProcessingTimeout => TimeSpan.FromMinutes(5);

    protected override async IAsyncEnumerable<CampaignContact> ProcessBatch(
        IReadOnlyCollection<CampaignContact> messages,
        CancellationToken cancellationToken)
    {
        foreach (var contact in messages)
        {
            // Process contact
            await ProcessContact(contact, cancellationToken);
            yield return contact;
        }
    }
}
```

### **2. Register Worker**
```csharp
// For scalable stream-based processing
builder.Services.AddHostedService<EmailWorker>();
```

### **3. Publish Messages**
```csharp
// Inject StreamMessagePublisher
var messageId = await publisher.PublishContactAsync("email-stream", contact);
```

### **4. Deploy with Auto-Scaling**
```bash
kubectl apply -f kubernetes/
```

## 📈 **Monitoring Dashboard**

Create Grafana dashboards with these key panels:
- Stream length over time
- Messages processed per second
- Consumer lag
- Active worker count
- Scaling events
- Error rates

## 🔧 **Troubleshooting**

### **Common Issues**
1. **High Consumer Lag**: Increase worker count or optimize processing
2. **Messages Not Processing**: Check consumer group registration
3. **Scaling Not Working**: Verify metrics are being exported
4. **Memory Issues**: Tune batch sizes and Redis memory settings

### **Debug Commands**
```bash
# Check stream status
redis-cli XINFO STREAM email-stream

# Check consumer group
redis-cli XINFO GROUPS email-stream

# View pending messages
redis-cli XPENDING email-stream email-workers
```

This scalable architecture provides automatic load balancing, guaranteed delivery, and intelligent auto-scaling for production workloads while maintaining simplicity and observability.
