# EnrollmentPipeline Health Checks

This document describes the comprehensive health check system implemented for the EnrollmentPipeline project.

## 🏥 Health Check Endpoints

The health check system provides multiple endpoints for different monitoring needs:

### Primary Endpoints

| Endpoint | Description | Use Case |
|----------|-------------|----------|
| `/health` | Basic health status with minimal details | Load balancer health checks |
| `/health/detailed` | Comprehensive health information | Debugging and detailed monitoring |
| `/health/ready` | Infrastructure readiness check | Kubernetes readiness probe |
| `/health/live` | Basic liveness check | Kubernetes liveness probe |

## 🔍 Health Checks Included

### 1. Redis Health Check
**Name**: `redis`  
**Tags**: `infrastructure`, `redis`

**What it checks**:
- Redis connectivity with ping test
- Basic read/write operations
- Connection status and server information
- Response time monitoring

**Response data**:
```json
{
  "ping_time_ms": 12.5,
  "connection_count": 3,
  "servers": [
    {
      "endpoint": "localhost:6379",
      "is_connected": true,
      "is_replica": false,
      "database_count": 16
    }
  ]
}
```

### 2. Pipeline Worker Health Check
**Name**: `pipeline-workers`  
**Tags**: `application`, `workers`

**What it checks**:
- Detection of registered pipeline workers
- Worker registration status
- Health percentage calculation

**Response data**:
```json
{
  "worker_count": 2,
  "healthy_workers": 2,
  "health_percentage": 100.0,
  "workers": [
    {
      "type": "EmailEnrollmentWorker",
      "status": "running",
      "assembly": "EnrollmentPipeline"
    }
  ]
}
```

### 3. System Resource Health Check
**Name**: `system-resources`  
**Tags**: `system`, `resources`

**What it checks**:
- Memory usage (working set and private memory)
- Thread count monitoring
- Process uptime
- CPU time tracking
- System information

**Response data**:
```json
{
  "working_set_mb": 125,
  "private_memory_mb": 98,
  "thread_count": 23,
  "uptime_minutes": 1440.5,
  "process_id": 12345,
  "machine_name": "SERVER01",
  "processor_count": 4
}
```

## 🔧 Integration Guide

### 1. Basic Setup

Add to your `Program.cs`:

```csharp
// Add health checks
builder.AddPipelineHealthChecks();

// Configure endpoints
app.UseHealthCheckEndpoints();
```

### 2. Custom Configuration

For advanced scenarios, you can customize the health checks:

```csharp
builder.Services.AddHealthChecks()
    .AddCheck<RedisHealthCheck>("redis")
    .AddCheck<PipelineWorkerHealthCheck>("workers")
    .AddCheck<SystemResourceHealthCheck>("system");
    
// Custom endpoint configuration
app.MapHealthChecks("/custom/health", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("critical"),
    ResponseWriter = async (context, report) => {
        // Custom response format
    }
});
```

### 3. Kubernetes Integration

#### Liveness Probe
```yaml
livenessProbe:
  httpGet:
    path: /health/live
    port: 8080
  initialDelaySeconds: 30
  periodSeconds: 10
```

#### Readiness Probe
```yaml
readinessProbe:
  httpGet:
    path: /health/ready
    port: 8080
  initialDelaySeconds: 5
  periodSeconds: 5
```

### 4. Load Balancer Configuration

For AWS Application Load Balancer:
```
Health check path: /health
Healthy threshold: 2
Unhealthy threshold: 3
Timeout: 5 seconds
Interval: 30 seconds
```

## 📊 Monitoring Integration

### Prometheus Metrics
The health checks integrate with OpenTelemetry metrics. Key metrics to monitor:

```promql
# Health check success rate
rate(healthcheck_duration_seconds_count{status="success"}[5m])

# Health check failure rate  
rate(healthcheck_duration_seconds_count{status="failure"}[5m])

# Average health check duration
rate(healthcheck_duration_seconds_sum[5m]) / rate(healthcheck_duration_seconds_count[5m])
```

### Grafana Dashboard
Create panels for:
- Health check status over time
- Response time trends
- Failure rate alerts
- System resource usage

## 🚨 Alerting Rules

### Critical Alerts
```yaml
- alert: RedisDown
  expr: healthcheck_status{name="redis"} != 1
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "Redis connectivity lost"

- alert: PipelineWorkersDown
  expr: healthcheck_status{name="pipeline-workers"} != 1
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "Pipeline workers unhealthy"
```

### Warning Alerts
```yaml
- alert: HighMemoryUsage
  expr: healthcheck_data{name="system-resources",key="working_set_mb"} > 500
  for: 10m
  labels:
    severity: warning
  annotations:
    summary: "High memory usage detected"
```

## 📋 Health Status Meanings

### Healthy ✅
- All checks pass
- System operating normally
- Ready to handle traffic

### Degraded ⚠️
- Some non-critical issues detected
- System still functional
- May have reduced performance

### Unhealthy ❌
- Critical issues detected
- System may not function properly
- Should not receive traffic

## 🔧 Configuration Options

### Environment Variables
```bash
# Health check timeouts
HEALTHCHECK_TIMEOUT_SECONDS=30

# Redis connection settings
REDIS_CONNECTION_STRING="localhost:6379"

# Resource thresholds
MEMORY_THRESHOLD_MB=500
THREAD_THRESHOLD_COUNT=50
```

### appsettings.json
```json
{
  "HealthChecks": {
    "Redis": {
      "TimeoutSeconds": 5,
      "TestOperations": true
    },
    "System": {
      "MemoryThresholdMB": 500,
      "ThreadThreshold": 50
    }
  }
}
```

## 🚀 Best Practices

1. **Use appropriate endpoints**: Use `/health/live` for liveness probes, `/health/ready` for readiness
2. **Monitor response times**: Set up alerts for slow health checks
3. **Test failure scenarios**: Regularly test health check behavior during failures
4. **Log health check results**: Enable logging for troubleshooting
5. **Cache expensive checks**: Consider caching for resource-intensive health checks

## 🛠️ Troubleshooting

### Common Issues

**Health checks timing out**:
- Check if Redis is accessible
- Verify network connectivity
- Review resource constraints

**False positives**:
- Adjust thresholds in configuration
- Review check logic for edge cases
- Consider adding retry logic

**Performance impact**:
- Monitor health check execution time
- Consider reducing check frequency
- Optimize expensive operations

### Debug Information
Enable detailed logging:
```csharp
builder.Services.Configure<HealthCheckServiceOptions>(options =>
{
    options.Registrations.Clear();
    // Add registrations with detailed logging
});
```

This health check system provides comprehensive monitoring capabilities for your EnrollmentPipeline application, ensuring high availability and reliability in production environments.
