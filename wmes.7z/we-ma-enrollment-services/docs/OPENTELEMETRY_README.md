# OpenTelemetry Integration for PipelineWorker

This document explains the comprehensive OpenTelemetry implementation added to the `PipelineWorker` class for enhanced observability in your Redis-based message processing pipeline.

## Features Added

### 🔍 Distributed Tracing
- **Activity Sources**: Tracks the complete message flow through the pipeline
- **Hierarchical Spans**: 
  - `pipeline-worker-execution`: Main worker lifecycle
  - `batch-processing-cycle`: Each batch processing cycle
  - `batch-lock-acquisition`: Lock acquisition for batch reading
  - `message-reading`: Individual message reading operations
  - `message-deserialization`: JSON parsing operations
  - `message-lock-acquisition`: Per-message lock operations
  - `batch-message-processing`: Batch processing execution
  - `message-lock-release`: Lock cleanup operations

### 📊 Metrics Collection
- **Counters**:
  - `pipeline_messages_processed_total`: Total messages successfully processed
  - `pipeline_messages_discarded_total`: Messages discarded due to lock contention
  - `pipeline_deserialization_errors_total`: JSON deserialization failures
  - `pipeline_lock_contention_total`: Lock contention events

- **Histograms**:
  - `pipeline_batch_processing_duration_seconds`: Batch processing time distribution
  - `pipeline_lock_acquisition_duration_seconds`: Lock acquisition time distribution

- **Gauges**:
  - `pipeline_batch_size`: Current batch size being processed

### 🗒️ Structured Logging
- Replaced `Console.WriteLine` with structured logging using `ILogger<T>`
- Contextual log messages with worker names, contact IDs, and campaign IDs
- Proper log levels (Debug, Information, Warning, Error)
- Correlation with distributed traces

### 🔧 Redis Integration
- Automatic Redis operation instrumentation
- Connection monitoring and performance tracking
- Lock operation visibility

## Configuration

### 1. Add Required NuGet Packages
The following packages are already included in `EnrollmentPipeline.csproj`:

```xml
<PackageReference Include="OpenTelemetry.Exporter.Console" Version="1.12.0" />
<PackageReference Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" Version="1.12.0" />
<PackageReference Include="OpenTelemetry.Extensions.Hosting" Version="1.12.0" />
<PackageReference Include="OpenTelemetry.Instrumentation.AspNetCore" Version="1.12.0" />
<PackageReference Include="OpenTelemetry.Instrumentation.Http" Version="1.12.0" />
<PackageReference Include="OpenTelemetry.Instrumentation.StackExchangeRedis" Version="1.12.0-beta.1" />
```

### 2. Application Setup
Use the provided extension methods in your `Program.cs`:

```csharp
var builder = Host.CreateApplicationBuilder(args);

// Configure OpenTelemetry
builder.AddOpenTelemetry();

// Configure Redis with telemetry
builder.AddRedisWithTelemetry("localhost:6379");

// Register your workers
builder.Services.AddHostedService<EmailEnrollmentWorker>();
builder.Services.AddHostedService<SmsEnrollmentWorker>();

var host = builder.Build();
await host.RunAsync();
```

### 3. Environment-Based Configuration
The telemetry configuration automatically adapts based on your environment:

- **Development**: Uses console exporters for traces, metrics, and logs
- **Production**: Uses OTLP exporters (configure endpoints via environment variables)

## Usage Examples

### Creating Custom Workers
Extend `PipelineWorker` and provide the required logger parameter:

```csharp
public class MyCustomWorker : PipelineWorker
{
    public MyCustomWorker(IConnectionMultiplexer redis, ILogger<PipelineWorker> logger) 
        : base(redis, logger)
    {
    }

    // Implement required abstract members...
    protected override async IAsyncEnumerable<CampaignContact> ProcessBatch(
        IReadOnlyCollection<CampaignContact> messages, 
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        foreach (var contact in messages)
        {
            // Your processing logic here
            yield return contact;
        }
    }
}
```

## Monitoring and Dashboards

### Key Metrics to Monitor
1. **Throughput**: `pipeline_messages_processed_total` rate
2. **Error Rate**: `pipeline_deserialization_errors_total` / total messages
3. **Lock Contention**: `pipeline_lock_contention_total` and `pipeline_messages_discarded_total`
4. **Latency**: P95/P99 of `pipeline_batch_processing_duration_seconds`
5. **Lock Performance**: `pipeline_lock_acquisition_duration_seconds` distribution

### Sample Queries (Prometheus/Grafana)
```promql
# Message processing rate (per second)
rate(pipeline_messages_processed_total[5m])

# Error percentage
(rate(pipeline_deserialization_errors_total[5m]) / rate(pipeline_messages_processed_total[5m])) * 100

# Average batch processing time
rate(pipeline_batch_processing_duration_seconds_sum[5m]) / rate(pipeline_batch_processing_duration_seconds_count[5m])

# Lock contention percentage
(rate(pipeline_lock_contention_total[5m]) / rate(pipeline_messages_processed_total[5m])) * 100
```

### Trace Analysis
Look for these patterns in your distributed traces:
- **Long lock acquisition times**: May indicate Redis performance issues
- **High lock contention**: Consider adjusting `BatchLockTimeout` or scaling workers
- **Batch processing bottlenecks**: Identify slow `ProcessBatch` implementations
- **Deserialization failures**: Monitor message format consistency

## Production Considerations

### 1. Export Configuration
For production deployments, configure OTLP endpoints:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=http://your-collector:4318
export OTEL_EXPORTER_OTLP_HEADERS="authorization=Bearer your-token"
```

### 2. Sampling
For high-throughput scenarios, consider trace sampling:

```csharp
tracing.SetSampler(new TraceIdRatioBasedSampler(0.1)); // 10% sampling
```

### 3. Resource Attribution
The telemetry automatically includes:
- Service name and version
- Environment name
- Host machine name
- Worker instance identification

### 4. Performance Impact
OpenTelemetry adds minimal overhead:
- Tracing: ~1-5% CPU overhead
- Metrics: ~0.1-1% CPU overhead
- Memory: ~10-50MB additional memory usage

## Troubleshooting

### Common Issues
1. **Missing traces**: Ensure activity sources are properly registered
2. **No metrics**: Verify meter registration and export configuration
3. **High cardinality**: Be careful with dynamic tag values (contact IDs, etc.)
4. **Memory leaks**: Ensure proper disposal of telemetry resources

### Debug Mode
Enable debug logging to troubleshoot telemetry issues:

```csharp
builder.Logging.SetMinimumLevel(LogLevel.Debug);
```

## Integration with Existing Tools

### Jaeger
```bash
docker run -d --name jaeger -p 16686:16686 -p 14250:14250 jaegertracing/all-in-one:latest
```

### Prometheus
```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'enrollment-pipeline'
    static_configs:
      - targets: ['localhost:9090']
```

### Grafana Dashboards
Consider using pre-built dashboards for:
- ASP.NET Core applications
- Redis monitoring
- OpenTelemetry overview

This comprehensive observability setup will give you deep insights into your message processing pipeline's performance, reliability, and behavior in production environments.
