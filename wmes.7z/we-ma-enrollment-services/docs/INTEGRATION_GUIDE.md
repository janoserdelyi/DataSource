# Using EnrollmentPipeline Health Checks in Other Projects

This guide shows how to integrate and use the EnrollmentPipeline health check endpoints in your applications.

## 🔧 Quick Setup

### 1. Add Project Reference
Add the EnrollmentPipeline project to your `.csproj`:

```xml
<ItemGroup>
  <ProjectReference Include="..\EnrollmentPipeline\EnrollmentPipeline.csproj" />
</ItemGroup>
```

### 2. Configure in Program.cs
```csharp
using EnrollmentPipeline;
using EnrollmentPipeline.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Configure OpenTelemetry and Redis (required for health checks)
builder.AddOpenTelemetry();
builder.AddRedisWithTelemetry("your-redis-connection-string");

// Add pipeline health checks
builder.AddPipelineHealthChecks();

var app = builder.Build();

// Enable health check endpoints
app.UseHealthCheckEndpoints();

app.Run();
```

## 🌐 Available Endpoints

### Health Check Endpoints
| Endpoint | Purpose | Response Format |
|----------|---------|-----------------|
| `GET /health` | Basic health status | JSON with minimal data |
| `GET /health/detailed` | Comprehensive health info | JSON with detailed data |
| `GET /health/ready` | Readiness probe | JSON (infrastructure checks only) |
| `GET /health/live` | Liveness probe | JSON (basic checks only) |

### Example Responses

#### Basic Health (`/health`)
```json
{
  "status": "Healthy",
  "timestamp": "2024-08-13T10:30:00Z",
  "duration": "00:00:00.1234567",
  "checks": [
    {
      "name": "redis",
      "status": "Healthy",
      "duration": "00:00:00.0500000",
      "description": "Redis is healthy"
    }
  ]
}
```

#### Detailed Health (`/health/detailed`)
```json
{
  "status": "Healthy",
  "timestamp": "2024-08-13T10:30:00Z",
  "duration": "00:00:00.1234567",
  "environment": "Production",
  "machineName": "SERVER01",
  "processId": 12345,
  "checks": [
    {
      "name": "redis",
      "status": "Healthy",
      "duration": "00:00:00.0500000",
      "description": "Redis is healthy",
      "data": {
        "ping_time_ms": 12.5,
        "connection_count": 3,
        "servers": [...]
      },
      "exception": null,
      "tags": ["infrastructure", "redis"]
    }
  ]
}
```

## 📡 Consuming Health Checks from Code

### HttpClient Example
```csharp
public class PipelineHealthService
{
    private readonly HttpClient _httpClient;
    
    public PipelineHealthService(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient();
    }
    
    public async Task<bool> IsPipelineHealthyAsync(string baseUrl)
    {
        try
        {
            var response = await _httpClient.GetAsync($"{baseUrl}/health");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
    
    public async Task<HealthReport> GetDetailedHealthAsync(string baseUrl)
    {
        var response = await _httpClient.GetAsync($"{baseUrl}/health/detailed");
        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<HealthReport>(json);
    }
}
```

### Using in Controllers
```csharp
[ApiController]
[Route("api/[controller]")]
public class SystemController : ControllerBase
{
    private readonly PipelineHealthService _healthService;
    
    public SystemController(PipelineHealthService healthService)
    {
        _healthService = healthService;
    }
    
    [HttpGet("pipeline-status")]
    public async Task<IActionResult> GetPipelineStatus()
    {
        var isHealthy = await _healthService.IsPipelineHealthyAsync("http://pipeline-service");
        
        if (!isHealthy)
        {
            return StatusCode(503, new { message = "Pipeline is unhealthy" });
        }
        
        return Ok(new { message = "Pipeline is healthy" });
    }
}
```

## 🔄 Integration Patterns

### 1. Circuit Breaker Pattern
```csharp
public class PipelineCircuitBreaker
{
    private DateTime _lastFailure = DateTime.MinValue;
    private int _failureCount = 0;
    private readonly TimeSpan _timeout = TimeSpan.FromMinutes(5);
    private readonly int _threshold = 3;
    
    public async Task<bool> CanProcessAsync(string pipelineUrl)
    {
        // If circuit is open, check if we should try again
        if (_failureCount >= _threshold)
        {
            if (DateTime.UtcNow - _lastFailure < _timeout)
            {
                return false; // Circuit still open
            }
        }
        
        // Check pipeline health
        var response = await httpClient.GetAsync($"{pipelineUrl}/health/ready");
        
        if (response.IsSuccessStatusCode)
        {
            _failureCount = 0; // Reset on success
            return true;
        }
        
        _failureCount++;
        _lastFailure = DateTime.UtcNow;
        return false;
    }
}
```

### 2. Dependency Health Check
```csharp
public class DependencyHealthCheck : IHealthCheck
{
    private readonly HttpClient _httpClient;
    private readonly string _pipelineUrl;
    
    public DependencyHealthCheck(HttpClient httpClient, string pipelineUrl)
    {
        _httpClient = httpClient;
        _pipelineUrl = pipelineUrl;
    }
    
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var response = await _httpClient.GetAsync($"{_pipelineUrl}/health", cancellationToken);
            
            if (response.IsSuccessStatusCode)
            {
                return HealthCheckResult.Healthy("Pipeline dependency is healthy");
            }
            
            return HealthCheckResult.Unhealthy($"Pipeline dependency returned {response.StatusCode}");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("Pipeline dependency is unreachable", ex);
        }
    }
}

// Register in Program.cs
builder.Services.AddHealthChecks()
    .AddCheck<DependencyHealthCheck>("pipeline-dependency");
```

### 3. Load Balancer Health Check
```csharp
public class LoadBalancerHealthService
{
    private readonly HttpClient _httpClient;
    private readonly List<string> _pipelineInstances;
    
    public async Task<string> GetHealthyInstanceAsync()
    {
        foreach (var instance in _pipelineInstances)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{instance}/health/ready");
                if (response.IsSuccessStatusCode)
                {
                    return instance;
                }
            }
            catch
            {
                // Try next instance
                continue;
            }
        }
        
        throw new InvalidOperationException("No healthy pipeline instances available");
    }
}
```

## 🐳 Docker Compose Example

```yaml
version: '3.8'
services:
  enrollment-pipeline:
    build: ./EnrollmentPipeline
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    
  api-gateway:
    build: ./ApiGateway
    depends_on:
      enrollment-pipeline:
        condition: service_healthy
    environment:
      - PIPELINE_URL=http://enrollment-pipeline:8080
```

## ☸️ Kubernetes Example

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: enrollment-pipeline
spec:
  replicas: 3
  selector:
    matchLabels:
      app: enrollment-pipeline
  template:
    metadata:
      labels:
        app: enrollment-pipeline
    spec:
      containers:
      - name: enrollment-pipeline
        image: enrollment-pipeline:latest
        ports:
        - containerPort: 8080
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: enrollment-pipeline-service
spec:
  selector:
    app: enrollment-pipeline
  ports:
  - port: 80
    targetPort: 8080
  type: ClusterIP
```

## 🔍 Monitoring Integration

### Prometheus Scraping
```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'enrollment-pipeline-health'
    metrics_path: '/health'
    scrape_interval: 30s
    static_configs:
      - targets: ['pipeline1:8080', 'pipeline2:8080']
```

### Grafana Dashboard Query Examples
```promql
# Health check success rate
sum(rate(healthcheck_status{job="enrollment-pipeline-health"}[5m])) by (instance)

# Response time
histogram_quantile(0.95, sum(rate(healthcheck_duration_seconds_bucket[5m])) by (le))
```

## 🚨 Error Handling Best Practices

### 1. Timeout Configuration
```csharp
builder.Services.Configure<HealthCheckServiceOptions>(options =>
{
    options.DefaultTimeout = TimeSpan.FromSeconds(10);
});
```

### 2. Retry Logic
```csharp
public async Task<bool> CheckHealthWithRetryAsync(string url, int maxRetries = 3)
{
    for (int i = 0; i < maxRetries; i++)
    {
        try
        {
            var response = await httpClient.GetAsync($"{url}/health");
            if (response.IsSuccessStatusCode)
                return true;
        }
        catch when (i < maxRetries - 1)
        {
            await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i))); // Exponential backoff
        }
    }
    return false;
}
```

### 3. Fallback Strategies
```csharp
public async Task<string> GetHealthyPipelineAsync()
{
    // Try primary pipeline
    if (await IsHealthyAsync(primaryPipeline))
        return primaryPipeline;
    
    // Try secondary pipeline
    if (await IsHealthyAsync(secondaryPipeline))
        return secondaryPipeline;
    
    // Fall back to cached last-known-good instance
    return fallbackPipeline;
}
```

This comprehensive integration guide provides everything needed to effectively use the EnrollmentPipeline health checks in other applications, ensuring robust and reliable distributed system monitoring.
