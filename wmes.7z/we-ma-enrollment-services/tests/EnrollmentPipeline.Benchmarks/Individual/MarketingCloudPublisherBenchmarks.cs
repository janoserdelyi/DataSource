using BenchmarkDotNet.Engines;
using EnrollmentPipeline.Benchmarks.Fixtures;
using EnrollmentPipeline.Benchmarks.Helpers;
using StackExchange.Redis;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;

namespace EnrollmentPipeline.Benchmarks.Individual;

/// <summary>
/// Benchmarks for MarketingCloudPublisher worker focusing on throughput and processing latency.
/// Tests real worker performance by publishing to its stream and monitoring completion via Prometheus metrics.
/// </summary>
[MemoryDiagnoser]
[SimpleJob(RunStrategy.Throughput, warmupCount: 1, iterationCount: 3)]
public class MarketingCloudPublisherBenchmarks : IAsyncDisposable
{
	private BenchmarkTestFixture? _fixture;
	private LoadGenerator? _loadGenerator;
	private MetricsCollector? _metricsCollector;
	private string? _workerStreamName;
	private string? _serviceUrl;
	private readonly Consumer _consumer = new();

	[Params(100, 500, 1000, 5000)]
	public int BatchSize { get; set; }

	[GlobalSetup]
	public async Task GlobalSetup()
	{
		_fixture = new BenchmarkTestFixture();
		await _fixture.InitializeAsync();

		// Get worker ID from configuration and construct stream name
		var workerIdString = _fixture.Configuration["PipelineWorker:Id"]
			?? throw new InvalidOperationException("PipelineWorker:Id not configured");
		_workerStreamName = workerIdString;

		// Get service URL for metrics
		_serviceUrl = _fixture.Configuration["Services:MarketingCloudPublisher"]
			?? throw new InvalidOperationException("Services:MarketingCloudPublisher not configured");

		_loadGenerator = new LoadGenerator(
			_fixture.Redis,
			_workerStreamName,
			_fixture.ContactRepository,
			_fixture.CampaignRepository,
			_fixture.Configuration);
		_metricsCollector = new MetricsCollector();

		// Verify worker is running
		var isAvailable = await _metricsCollector.IsServiceAvailable(_serviceUrl);
		if (!isAvailable)
		{
			throw new InvalidOperationException(
				$"MarketingCloudPublisher worker is not available at {_serviceUrl}. " +
				"Please ensure the worker is running before executing benchmarks.");
		}

		Console.WriteLine($"MarketingCloudPublisher worker verified at {_serviceUrl}");
	}

	[GlobalCleanup]
	public async Task GlobalCleanup()
	{
		_metricsCollector?.Dispose();
		if (_fixture != null)
		{
			await _fixture.DisposeAsync();
		}
	}

	[IterationSetup]
	public async Task IterationSetup()
	{
		_metricsCollector?.Reset();

		// Clean up the stream before each iteration
		if (_fixture != null && _workerStreamName != null)
		{
			var db = _fixture.Redis.GetDatabase();
			await db.KeyDeleteAsync(_workerStreamName);
		}
	}

	[Benchmark(Description = "MarketingCloudPublisher throughput test")]
	public async Task MarketingCloudPublisher_Throughput()
	{
		if (_loadGenerator == null || _fixture == null || _metricsCollector == null || _serviceUrl == null)
			return;

		var stopwatch = Stopwatch.StartNew();
		var startTime = DateTime.UtcNow;

		// Publish messages to the MarketingCloudPublisher stream
		await _loadGenerator.GenerateBatch(BatchSize, CancellationToken.None);

		// Calculate timeout based on batch size and configuration
		var timeoutSeconds = _fixture.Configuration.GetValue("BenchmarkSettings:ProcessingTimeoutSeconds", 300);
		var multiplier = _fixture.Configuration.GetValue("BenchmarkSettings:MaxWaitTimeMultiplier", 2.0);
		var timeout = TimeSpan.FromSeconds(timeoutSeconds * multiplier * (BatchSize / 1000.0));

		var pollingInterval = TimeSpan.FromSeconds(
			_fixture.Configuration.GetValue("BenchmarkSettings:MetricsPollingIntervalSeconds", 5));

		var metricsUrl = $"{_serviceUrl.TrimEnd('/')}/metrics";

		// Wait for all messages to be processed (pending messages == 0)
		var completed = await _metricsCollector.WaitForMetricCondition(
			metricsUrl,
			"pipeline_stream_pending_messages",
			value => value == 0,
			timeout,
			pollingInterval,
			CancellationToken.None);

		stopwatch.Stop();

		if (!completed)
		{
			Console.WriteLine($"WARNING: MarketingCloudPublisher did not complete processing {BatchSize} messages within {timeout.TotalSeconds}s");
		}

		// Collect metrics
		var throughput = BatchSize / stopwatch.Elapsed.TotalSeconds;
		var avgLatency = (stopwatch.Elapsed.TotalMilliseconds / BatchSize);

		Console.WriteLine($"Processed {BatchSize} messages in {stopwatch.Elapsed.TotalSeconds:F2}s");
		Console.WriteLine($"Throughput: {throughput:F2} msg/sec");
		Console.WriteLine($"Average latency: {avgLatency:F2}ms");

		_consumer.Consume(stopwatch.Elapsed);
	}

	public async ValueTask DisposeAsync()
	{
		await GlobalCleanup();
	}
}
