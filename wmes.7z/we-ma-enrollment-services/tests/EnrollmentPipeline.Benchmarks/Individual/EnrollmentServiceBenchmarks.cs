using System.Data;
using System.Data.Common;
using System.Text.Json.Nodes;
using BenchmarkDotNet.Engines;
using EnrollmentPipeline.Benchmarks.Fixtures;
using EnrollmentPipeline.Benchmarks.Helpers;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Extensions;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using Marketing.Enums;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Npgsql;

namespace EnrollmentPipeline.Benchmarks.Individual;

/// <summary>
/// Benchmarks for EnrollmentService database operations.
/// Tests the performance of individual CRUD operations and bulk operations.
/// </summary>
[MemoryDiagnoser]
[SimpleJob(RunStrategy.Throughput, warmupCount: 1, iterationCount: 3)]
public class EnrollmentServiceBenchmarks : BasePipelineBenchmark
{
    protected WebApplication? _app;
    protected IServiceScope? _scope;
    private IDbConnection? _dbConnection;
    private IEnrollmentService? _enrollmentService;
    private int _campaignId;
    private short _pipelineVersionId;
    private Guid _workerId = Guid.NewGuid();
    private readonly Consumer _consumer = new();
    private readonly List<Guid> _createdEnrollmentIds = [];

    [Params(1, 10, 100, 1000)] public int BatchSize { get; set; }

    [GlobalSetup]
    public async Task GlobalSetup()
    {
        // Use WebApplicationBuilder to leverage all extension methods
        var builder = CreateAppBuilder();

        // Build the service provider with real dependencies
        _app = BuildApp(builder);

        // Creates DI scope
        _scope = _app.Services.CreateScope();
        // Retrieve EnrollmentService instance
        _enrollmentService = _scope.ServiceProvider.GetRequiredService<IEnrollmentService>();
        // Retrieve a reference to DB connection for later manual cleanup
        _dbConnection = _scope.ServiceProvider.GetRequiredKeyedService<IDbConnection>(DbConnectionType.Postgres);

        var configuration = _scope.ServiceProvider.GetRequiredService<IConfiguration>();

        _campaignId = configuration.GetValue<int>("TestData:MarketingCampaignId");
        _pipelineVersionId = configuration.GetValue<short>("TestData:PipelineVersionId");
        _workerId = configuration.GetValue<Guid>("TestData:WorkerId");
    }

    [GlobalCleanup]
    public override async Task GlobalCleanup()
    {
        // Clean up created test data
        if (_dbConnection != null && _createdEnrollmentIds.Count > 0)
        {
            try
            {
                using var cmd = _dbConnection.CreateCommand();
                cmd.CommandText = "DELETE FROM enrollment.staged WHERE id = ANY(@Ids)";
                var parameter = cmd.CreateParameter();
                parameter.ParameterName = "@Ids";
                parameter.Value = _createdEnrollmentIds.ToArray();
                cmd.Parameters.Add(parameter);
                await ((NpgsqlCommand)cmd).ExecuteNonQueryAsync();

                Console.WriteLine($"Cleaned up {_createdEnrollmentIds.Count} test enrollment records");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Failed to clean up test data: {ex.Message}");
            }
        }

        if (_dbConnection != null)
        {
            _dbConnection.Dispose();
        }
    }

    [IterationCleanup]
    public void IterationCleanup()
    {
        // Clean up after each iteration to maintain consistent test conditions
        if (_dbConnection != null && _createdEnrollmentIds.Count > 0)
        {
            try
            {
                using var cmd = _dbConnection.CreateCommand();
                cmd.CommandText = "DELETE FROM enrollment.staged WHERE id = ANY(@Ids)";
                var parameter = cmd.CreateParameter();
                parameter.ParameterName = "@Ids";
                parameter.Value = _createdEnrollmentIds.ToArray();
                cmd.Parameters.Add(parameter);
                var result = ((NpgsqlCommand)cmd).ExecuteNonQueryAsync().GetAwaiter().GetResult();

                Console.WriteLine($"Cleaned up {result} enrollment records in iteration");

                _createdEnrollmentIds.Clear();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Failed to clean up iteration data: {ex.Message}");
            }
        }
    }

    // [Benchmark(Description = "GetEnrollmentAsync - Single query")]
    // public async Task GetEnrollmentAsync_SingleQuery()
    // {
    //     ArgumentNullException.ThrowIfNull(_enrollmentService);

    //     // Create a test enrollment first
    //     var testEnrollment = CreateTestEnrollment();
    //     await _enrollmentService.RecordProcessingStartAsync(testEnrollment, _workerId);
    //     _createdEnrollmentIds.Add(testEnrollment.Id!.Value);

    //     // Benchmark the retrieval
    //     var result = await _enrollmentService.GetEnrollmentAsync(testEnrollment.Id!.Value);

    //     if (result != null)
    //     {
    //         _consumer.Consume(result);
    //     }
    // }

    // [Benchmark(Description = "GetEnrollmentByContactAndCampaignIdAsync - Single query")]
    // public async Task GetEnrollmentByContactAndCampaignIdAsync_SingleQuery()
    // {
    //     ArgumentNullException.ThrowIfNull(_enrollmentService);

    //     // Create a test enrollment first
    //     var testEnrollment = CreateTestEnrollment();
    //     await _enrollmentService.RecordProcessingStartAsync(testEnrollment, _workerId);
    //     _createdEnrollmentIds.Add(testEnrollment.Id!.Value);

    //     // Benchmark the retrieval by contact and campaign
    //     var result = await _enrollmentService.GetEnrollmentByContactAndCampaignIdAsync(
    //         testEnrollment.ContactId, 
    //         testEnrollment.MarketingCampaignId);

    //     if (result != null)
    //     {
    //         _consumer.Consume(result);
    //     }
    // }

    [Benchmark(Description = "RecordProcessingStartAsync - Insert new enrollment")]
    public async Task RecordProcessingStartAsync_Insert()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        var enrollment = CreateTestEnrollment();

        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);

        _createdEnrollmentIds.Add(enrollment.Id);

        _consumer.Consume(enrollment);
    }

    [Benchmark(Description = "RecordProcessingStartAsync - Update existing enrollment")]
    public async Task RecordProcessingStartAsync_Update()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        // Create initial enrollment
        var enrollment = CreateTestEnrollment();
        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);
        _createdEnrollmentIds.Add(enrollment.Id);

        // Update the enrollment's data fields
        enrollment.DataFields["UpdatedField"] = "UpdatedValue";

        // Benchmark the update
        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);

        _consumer.Consume(enrollment);
    }

    [Benchmark(Description = "RecordProcessingStartAsync - Batch insert")]
    public async Task RecordProcessingStartAsync_BatchInsert()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        var enrollments = new List<StagedEnrollment>();
        for (int i = 0; i < BatchSize; i++)
        {
            enrollments.Add(CreateTestEnrollment(contactIdOffset: i));
        }

        await _enrollmentService.RecordProcessingStartAsync(enrollments, _workerId);

        _createdEnrollmentIds.AddRange(enrollments.Select(e => e.Id));

        _consumer.Consume(enrollments);
    }

    [Benchmark(Description = "RecordWorkerResultAsync - Single result")]
    public async Task RecordWorkerResultAsync_SingleResult()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        // Create and insert an enrollment first
        var enrollment = CreateTestEnrollment();
        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);
        _createdEnrollmentIds.Add(enrollment.Id);

        // Create a worker result
        var result = new WorkerResult
        {
            WorkerId = _workerId,
            Enrollment = enrollment,
            Status = PipelineStatus.Completed,
            Message = "Test completion",
            StartedAt = DateTimeOffset.UtcNow.AddSeconds(-5),
            EndedAt = DateTimeOffset.UtcNow
        };

        // Benchmark recording the result
        await _enrollmentService.RecordWorkerResultAsync(result);

        _consumer.Consume(result);
    }

    [Benchmark(Description = "BulkRecordProcessingCompletedAsync - Bulk update")]
    public async Task BulkRecordProcessingCompletedAsync_BulkUpdate()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        // Create and insert multiple enrollments
        var enrollments = new List<StagedEnrollment>();
        for (int i = 0; i < BatchSize; i++)
        {
            var enrollment = CreateTestEnrollment(contactIdOffset: i);
            // await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);
            enrollments.Add(enrollment);
            _createdEnrollmentIds.Add(enrollment.Id);
        }

        // Create worker results for all enrollments
        var results = enrollments.Select(e => new WorkerResult
        {
            WorkerId = _workerId,
            Enrollment = e,
            Status = PipelineStatus.Completed,
            Message = "Bulk test completion",
            StartedAt = DateTimeOffset.UtcNow.AddSeconds(-5),
            EndedAt = DateTimeOffset.UtcNow
        }).ToList();

        // Benchmark bulk recording
        await _enrollmentService.BulkRecordProcessingCompletedAsync(results);

        _consumer.Consume(results);
    }

    [Benchmark(Description = "Full enrollment lifecycle - Insert, Query, Update, Complete")]
    public async Task FullEnrollmentLifecycle()
    {
        ArgumentNullException.ThrowIfNull(_enrollmentService);

        // 1. Insert new enrollment
        var enrollment = CreateTestEnrollment();
        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);
        _createdEnrollmentIds.Add(enrollment.Id);

        // 2. Query by ID
        var retrieved = await _enrollmentService.GetEnrollmentAsync(enrollment.Id);

        // 3. Query by contact and campaign
        var retrievedByContact = await _enrollmentService.GetEnrollmentByContactAndCampaignIdAsync(
            enrollment.ContactId,
            enrollment.MarketingCampaignId);

        // 4. Update enrollment
        enrollment.DataFields["ProcessedField"] = "ProcessedValue";
        await _enrollmentService.RecordProcessingStartAsync(enrollment, _workerId);

        // 5. Complete enrollment
        var result = new WorkerResult
        {
            WorkerId = _workerId,
            Enrollment = enrollment,
            Status = PipelineStatus.Completed,
            Message = "Lifecycle test completed",
            StartedAt = DateTimeOffset.UtcNow.AddSeconds(-10),
            EndedAt = DateTimeOffset.UtcNow
        };
        await _enrollmentService.RecordWorkerResultAsync(result);

        _consumer.Consume(result);
    }

    protected override WebApplication BuildApp(WebApplicationBuilder builder)
    {
        // Add EnrollmentService-specific services using extension methods
        builder.AddPostgresDatabase();

        return builder.Build();
    }

    private StagedEnrollment CreateTestEnrollment(int contactIdOffset = 0)
    {
        return new StagedEnrollment
        (
            1000000 + contactIdOffset + Random.Shared.Next(1, 1000000),
            new JsonObject
            {
                ["EmailAddress"] = "test@example.com",
                ["FirstName"] = "Test",
                ["LastName"] = "User",
                ["TestField"] = "BenchmarkData"
            },
            _campaignId,
            MarketingBrands.LoopNet,
            _pipelineVersionId
        )
        {
            StatusId = PipelineStatus.Processing
        };
    }
}
