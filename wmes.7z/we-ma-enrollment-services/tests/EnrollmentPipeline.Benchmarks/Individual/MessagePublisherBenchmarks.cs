using BenchmarkDotNet.Engines;
using EnrollmentPipeline.Benchmarks.Fixtures;
using EnrollmentPipeline.Benchmarks.Helpers;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;
using System.Net.Http.Json;
using System.Text.Json;

namespace EnrollmentPipeline.Benchmarks.Individual;

/// <summary>
/// Benchmarks for CampaignEnrollmentApi API focusing on /batch endpoint throughput and latency.
/// Tests real API performance by calling the batch endpoint with real contact data.
/// </summary>
[MemoryDiagnoser]
[SimpleJob(RunStrategy.Throughput, warmupCount: 1, iterationCount: 3)]
public class MessagePublisherBenchmarks : IAsyncDisposable
{
    private BenchmarkTestFixture? _fixture;
    private MetricsCollector? _metricsCollector;
    private HttpClient? _httpClient;
    private string? _serviceUrl;
    private int _campaignId;
    private readonly Consumer _consumer = new();

    [Params(1000, 5000)]
    public int BatchSize { get; set; }

    [GlobalSetup]
    public async Task GlobalSetup()
    {
        _fixture = new BenchmarkTestFixture();
        await _fixture.InitializeAsync();

        _campaignId = _fixture.Configuration.GetValue<int>("TestData:MarketingCampaignId");

        _serviceUrl = _fixture.Configuration.GetValue<string>("Services:CampaignEnrollmentApi")
            ?? throw new InvalidOperationException("Services:CampaignEnrollmentApi not configured");

        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(_serviceUrl),
            Timeout = TimeSpan.FromMinutes(5)
        };

        _metricsCollector = new MetricsCollector();

        // Verify service is running
        var isAvailable = await _metricsCollector.IsServiceAvailable(_serviceUrl);
        if (!isAvailable)
        {
            throw new InvalidOperationException(
                $"CampaignEnrollmentApi service is not available at {_serviceUrl}. " +
                "Please ensure the service is running before executing benchmarks.");
        }

        Console.WriteLine($"CampaignEnrollmentApi service verified at {_serviceUrl}");
    }

    [GlobalCleanup]
    public async Task GlobalCleanup()
    {
        _metricsCollector?.Dispose();
        _httpClient?.Dispose();
        if (_fixture != null)
        {
            await _fixture.DisposeAsync();
        }
    }

    [IterationSetup]
    public void IterationSetup()
    {
        _metricsCollector?.Reset();
    }

    [Benchmark(Description = "CampaignEnrollmentApi - Single batch")]
    public async Task MessagePublisher_SingleBatch()
    {
        if (_fixture == null || _httpClient == null)
            return;

        var stopwatch = Stopwatch.StartNew();

        // Get real contact IDs from OpenSearch
        var contacts = await _fixture.ContactRepository.GetContactsByIdsAsync(
            Enumerable.Range(1, BatchSize).ToArray());

        var contactIds = contacts.Select(c => c.Id).ToArray();

        // Prepare batch request
        var batchRequest = new
        {
            ContactIds = contactIds,
            CampaignId = _campaignId
        };

        // Call /batch endpoint
        var response = await _httpClient.PostAsJsonAsync("/api/publisher/batch", batchRequest);

        if (!response.IsSuccessStatusCode)
        {
            Console.WriteLine($"ERROR: Batch request failed with status {response.StatusCode}");
            return;
        }

        var result = await response.Content.ReadFromJsonAsync<BatchPublishResponse>();

        stopwatch.Stop();

        // Validate published count matches expected
        if (result != null && result.Published != contactIds.Length)
        {
            Console.WriteLine($"WARNING: Expected {contactIds.Length} published, got {result.Published}");
        }

        var throughput = BatchSize / stopwatch.Elapsed.TotalSeconds;
        Console.WriteLine($"Published {BatchSize} messages in {stopwatch.Elapsed.TotalSeconds:F2}s");
        Console.WriteLine($"Throughput: {throughput:F2} msg/sec");

        _consumer.Consume(stopwatch.Elapsed);
    }

    [Benchmark(Description = "CampaignEnrollmentApi - Multiple batches")]
    public async Task MessagePublisher_MultipleBatches()
    {
        if (_fixture == null || _httpClient == null)
            return;

        var stopwatch = Stopwatch.StartNew();

        // Split into multiple small batches (100 contacts per batch)
        var smallBatchSize = 100;
        var numberOfBatches = Math.Max(1, BatchSize / smallBatchSize);

        // Get real contact IDs from OpenSearch
        var allContacts = await _fixture.ContactRepository.GetContactsByIdsAsync(
            Enumerable.Range(1, BatchSize).ToArray());

        var totalPublished = 0;

        // Process in small batches
        for (int i = 0; i < numberOfBatches; i++)
        {
            var batchContacts = allContacts
                .Skip(i * smallBatchSize)
                .Take(smallBatchSize)
                .Select(c => c.Id)
                .ToArray();

            var batchRequest = new
            {
                ContactIds = batchContacts,
                CampaignId = _campaignId
            };

            var response = await _httpClient.PostAsJsonAsync("/api/publisher/batch", batchRequest);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<BatchPublishResponse>();
                if (result != null)
                {
                    totalPublished += result.Published;
                }
            }
        }

        stopwatch.Stop();

        var throughput = totalPublished / stopwatch.Elapsed.TotalSeconds;
        Console.WriteLine($"Published {totalPublished} messages in {numberOfBatches} batches in {stopwatch.Elapsed.TotalSeconds:F2}s");
        Console.WriteLine($"Throughput: {throughput:F2} msg/sec");

        _consumer.Consume(stopwatch.Elapsed);
    }

    private class BatchPublishResponse
    {
        public int Published { get; set; }
        public int[]? Failed { get; set; }
    }

    public async ValueTask DisposeAsync()
    {
        await GlobalCleanup();
    }
}
