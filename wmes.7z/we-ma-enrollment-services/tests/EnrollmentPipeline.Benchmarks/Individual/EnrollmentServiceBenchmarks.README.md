# EnrollmentService Benchmarks

This document describes the benchmark tests for the `EnrollmentService` class in the EnrollmentPipeline library.

## Overview

The `EnrollmentServiceBenchmarks` class provides comprehensive performance testing for all database operations in the `EnrollmentService`, including:

- **Query operations**: Fetching enrollment records by ID or by contact/campaign combination
- **Insert operations**: Creating new enrollment records
- **Update operations**: Modifying existing enrollment records
- **Batch operations**: Processing multiple enrollments simultaneously
- **Result recording**: Tracking worker completion status
- **Full lifecycle**: Complete enrollment workflow from creation to completion

## Prerequisites

Before running these benchmarks, ensure you have:

1. **PostgreSQL database access** configured in `benchmark-config.json`:
   ```json
   {
     "AwsRds": {
       "Hostname": "your-postgres-host",
       "Port": 5432,
       "DatabaseName": "marketingprocessing",
       "Username": "your-username"
     }
   }
   ```

2. **AWS credentials** configured (if using AWS RDS with IAM authentication):
   ```powershell
   aws configure --profile aws_enterprise_dev_developers
   ```

3. **Database schema** is deployed with the `enrollment.staged` table and related objects.

## Running the Benchmarks

### Run All EnrollmentService Benchmarks

```powershell
cd src/tests/EnrollmentPipeline.Benchmarks
dotnet run -c Release --filter *EnrollmentService*
```

### Run Specific Benchmark Methods

#### Single Query Operations
```powershell
# Test GetEnrollmentAsync performance
dotnet run -c Release --filter *GetEnrollmentAsync_SingleQuery*

# Test GetEnrollmentByContactAndCampaignIdAsync performance
dotnet run -c Release --filter *GetEnrollmentByContactAndCampaignIdAsync_SingleQuery*
```

#### Insert and Update Operations
```powershell
# Test single enrollment insertion
dotnet run -c Release --filter *RecordProcessingStartAsync_Insert*

# Test single enrollment update
dotnet run -c Release --filter *RecordProcessingStartAsync_Update*

# Test batch insertion with various sizes
dotnet run -c Release --filter *RecordProcessingStartAsync_BatchInsert*
```

#### Result Recording Operations
```powershell
# Test single result recording
dotnet run -c Release --filter *RecordWorkerResultAsync_SingleResult*

# Test bulk result recording
dotnet run -c Release --filter *BulkRecordProcessingCompletedAsync_BulkUpdate*
```

#### Full Lifecycle Test
```powershell
# Test complete enrollment workflow
dotnet run -c Release --filter *FullEnrollmentLifecycle*
```

## Benchmark Parameters

The benchmarks use the `BatchSize` parameter to test different workload sizes:

- `BatchSize = 1`: Single record operations (baseline)
- `BatchSize = 10`: Small batch operations
- `BatchSize = 100`: Medium batch operations
- `BatchSize = 1000`: Large batch operations

BenchmarkDotNet will run each benchmark with all parameter values to show how performance scales.

## Benchmark Scenarios

### 1. GetEnrollmentAsync - Single Query
**Purpose**: Measure the performance of fetching an enrollment by ID with all related data.

**What it tests**:
- Database query execution time
- Data mapping and deserialization
- Network latency to database

**Expected results**:
- P50 latency: < 10ms (local database) or < 50ms (remote database)
- Memory allocation: < 5KB per operation

### 2. GetEnrollmentByContactAndCampaignIdAsync - Single Query
**Purpose**: Measure the performance of fetching an enrollment by contact and campaign ID.

**What it tests**:
- Indexed query performance
- Query optimization effectiveness

**Expected results**:
- Similar to GetEnrollmentAsync since both use indexed lookups

### 3. RecordProcessingStartAsync - Insert
**Purpose**: Measure the performance of inserting a new enrollment record.

**What it tests**:
- INSERT statement execution
- RETURNING clause handling
- Transaction overhead

**Expected results**:
- Throughput: > 1000 inserts/sec (single threaded)
- P95 latency: < 20ms

### 4. RecordProcessingStartAsync - Update
**Purpose**: Measure the performance of updating an existing enrollment record.

**What it tests**:
- UPDATE statement execution
- Primary key lookup performance
- JSONB field updates

**Expected results**:
- Slightly faster than INSERT due to no index maintenance
- P95 latency: < 15ms

### 5. RecordProcessingStartAsync - Batch Insert
**Purpose**: Measure the performance of batch enrollment insertion.

**What it tests**:
- Sequential insert performance
- Connection pooling efficiency
- Batch size impact on throughput

**Expected results**:
- Throughput scales linearly up to ~5000 records/sec
- Batch size of 100-1000 provides best throughput/latency balance

### 6. RecordWorkerResultAsync - Single Result
**Purpose**: Measure the performance of recording a single worker completion result.

**What it tests**:
- UPDATE statement with multiple columns
- Status tracking overhead

**Expected results**:
- P95 latency: < 15ms
- Memory allocation: < 2KB per operation

### 7. BulkRecordProcessingCompletedAsync - Bulk Update
**Purpose**: Measure the performance of bulk worker result recording.

**What it tests**:
- Dapper bulk update optimization
- Batch UPDATE performance vs individual updates
- Fallback logic on errors

**Expected results**:
- 5-10x faster than individual updates for large batches
- Optimal batch size: 500-1000 records

### 8. Full Enrollment Lifecycle
**Purpose**: Measure the complete enrollment workflow from creation to completion.

**What it tests**:
- Realistic usage pattern
- Combined operation overhead
- Round-trip times for complete workflow

**Workflow steps**:
1. Insert new enrollment
2. Query by ID
3. Query by contact and campaign
4. Update enrollment with data
5. Record completion result

**Expected results**:
- Total workflow time: < 100ms (local) or < 250ms (remote)
- Demonstrates real-world performance characteristics

## Interpreting Results

BenchmarkDotNet will generate a detailed report showing:

- **Mean**: Average execution time
- **Error**: Confidence interval
- **StdDev**: Standard deviation
- **Median**: 50th percentile
- **P95**: 95th percentile
- **P99**: 99th percentile
- **Gen0/Gen1/Gen2**: Garbage collection statistics
- **Allocated**: Memory allocated per operation

### Example Output
```
|                               Method | BatchSize |         Mean |     Error |    StdDev |       Median |  Gen0 | Allocated |
|------------------------------------- |---------- |-------------:|----------:|----------:|-------------:|------:|----------:|
|            GetEnrollmentAsync_Single |         1 |     12.34 ms |  0.234 ms |  0.189 ms |     12.21 ms | 0.015 |    4.2 KB |
| RecordProcessingStartAsync_BatchIns* |       100 |    152.67 ms |  2.341 ms |  2.076 ms |    151.89 ms | 1.250 |  124.5 KB |
| RecordProcessingStartAsync_BatchIns* |      1000 |  1,523.45 ms | 18.234 ms | 16.234 ms |  1,518.23 ms | 12.50 | 1245.2 KB |
```

## Performance Tips

Based on benchmark results, consider these optimizations:

1. **Batch operations**: Use batch methods when processing multiple enrollments (5-10x throughput improvement)
2. **Connection pooling**: Ensure proper connection pool sizing (default: 100 connections)
3. **Prepared statements**: Dapper automatically uses prepared statements for repeated queries
4. **JSONB fields**: Use JSONB operators instead of JSON for better performance
5. **Indexing**: Ensure proper indexes on `contact_id`, `marketing_campaign_id`, and `id`

## Troubleshooting

### Connection Issues
If you see connection errors:
```
AWS credentials are not configured
```

Solution: Configure AWS CLI profile or set environment variables:
```powershell
$env:AWS_PROFILE = "aws_enterprise_dev_developers"
```

### Slow Performance
If benchmarks are slower than expected:
1. Check database location (cross-region latency adds 50-150ms)
2. Verify database resources (CPU, IOPS)
3. Check for lock contention in shared environments
4. Review query execution plans

### Cleanup Issues
If cleanup fails, manually remove test data:
```sql
DELETE FROM enrollment.staged 
WHERE contact_id >= 1000000 
  AND created_date > NOW() - INTERVAL '1 hour';
```

## Integration with CI/CD

To run these benchmarks in CI/CD pipelines:

```powershell
# Run benchmarks and fail if SLOs are not met
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks `
  --filter *EnrollmentService* `
  --exporters json `
  --artifacts ./benchmark-results

# Parse results and validate against SLOs
# (implement custom validation logic based on exported JSON)
```

## Next Steps

After running benchmarks:

1. **Review results**: Compare against baseline performance
2. **Identify bottlenecks**: Focus on operations with high P99 latency
3. **Optimize queries**: Use EXPLAIN ANALYZE on slow queries
4. **Test at scale**: Run with production-sized datasets
5. **Monitor production**: Use similar metrics in production monitoring

## Related Documentation

- [EnrollmentService API Documentation](../../EnrollmentPipeline/Services/EnrollmentService.cs)
- [Database Schema](../../../scripts/db.sql)
- [Main Benchmarks README](./README.md)
- [BenchmarkDotNet Documentation](https://benchmarkdotnet.org/articles/overview.html)
