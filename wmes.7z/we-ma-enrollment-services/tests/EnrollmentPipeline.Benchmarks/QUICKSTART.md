# Quick Start Guide - Enrollment Pipeline Benchmarks

## Running Your First Benchmark

### 1. Quick Test (Individual Worker - 5 minutes)
```powershell
# Run CampaignEnrollmentApi benchmarks only
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *CampaignEnrollmentApi* --job short
```

### 2. Medium Test (All Individual Workers - 15 minutes)
```powershell
# Run all individual worker benchmarks
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *Individual*
```

### 3. Full Test (Complete Suite - 60+ minutes)
```powershell
# Run all benchmarks including end-to-end
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks
```

## Viewing Results

### Console Output
Results are displayed in real-time in the console with:
- Execution times
- Memory allocations
- Throughput metrics
- Statistical analysis

### HTML Report
Open the generated HTML report for interactive visualization:
```powershell
# Windows
start BenchmarkResults\results\*\report.html

# PowerShell
Invoke-Item BenchmarkResults\results\*\report.html
```

### Markdown Report
View the GitHub-compatible markdown summary:
```powershell
Get-Content BenchmarkResults\results\*\report.md
```

## Common Scenarios

### Compare Different Worker Counts
```powershell
# Will test with 1, 2, 4, and 8 workers automatically
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *FullPipeline*
```

### Test Specific Load Pattern
```powershell
# Run burst traffic tests only
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *Burst*
```

### Memory Profiling
```powershell
# Run with memory diagnostics
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --memory
```

## Monitoring Real-Time Metrics

### Start Monitoring Stack
```powershell
podman compose -f src/tests/EnrollmentPipeline.Benchmarks/docker-compose-benchmark.yml up -d
```

### Access Dashboards
- **Grafana**: http://localhost:3001 (admin/admin)
- **Prometheus**: http://localhost:9091

### Stop Monitoring Stack
```powershell
podman compose -f src/tests/EnrollmentPipeline.Benchmarks/docker-compose-benchmark.yml down
```

## Validating Performance

### Check SLO Compliance
Results automatically include SLO validation:
- ✅ Green checkmark = Meets SLO
- ❌ Red X = Failed SLO

### Key Metrics to Watch
1. **Throughput**: Should be ≥ 50 msg/sec per worker
2. **Latency P95**: Should be ≤ 500ms
3. **Success Rate**: Should be ≥ 99.9%

## Troubleshooting

### Benchmark Times Out
Reduce the message count in `benchmark-config.json`:
```json
{
  "Benchmarks": {
    "Loads": {
      "Light": 50,    // Reduced from 100
      "Medium": 500   // Reduced from 1000
    }
  }
}
```

### Out of Memory
Reduce worker counts or run benchmarks individually:
```powershell
# Run one benchmark at a time
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter MessagePublisherBenchmarks.PublishMessages_SingleBatch
```

### Services Not Starting
Check Docker/Podman is running:
```powershell
podman ps
# or
docker ps
```

## Next Steps

- Read the full [README.md](README.md) for comprehensive documentation
- Review [benchmark results](BenchmarkResults/) for historical data
- Check [Grafana dashboards](http://localhost:3001) for real-time metrics
- Review [Azure Pipeline](azure-pipelines-benchmark.yml) for CI/CD integration

## Quick Tips

✅ **DO:**
- Always run in Release mode (`-c Release`)
- Close unnecessary applications during benchmarks
- Run multiple iterations for accurate results
- Compare against baseline metrics

❌ **DON'T:**
- Run in Debug mode (adds significant overhead)
- Run benchmarks on a busy system
- Compare results from different machines
- Skip warmup iterations
