# Enrollment Pipeline Benchmarks

Comprehensive benchmark test suite for load testing the Enrollment Pipeline workers (CampaignEnrollmentApi, DataFieldProvider, MarketingCloudPublisher) individually and as an integrated system.

## 📊 Overview

This benchmark suite provides:
- **Individual Worker Benchmarks**: Test each worker in isolation
- **Integration Benchmarks**: Test worker interactions and data flow
- **End-to-End Benchmarks**: Test the complete pipeline under various load patterns
- **OpenTelemetry Integration**: Collect comprehensive metrics during benchmark runs
- **SLO Validation**: Automatically validate Service Level Objectives
- **Automated Reporting**: Generate detailed performance reports

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  Benchmark Test Suite                        │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ Individual  │  │  Integration │  │   End-to-End │       │
│  │   Worker    │  │    Worker    │  │   Pipeline   │       │
│  │ Benchmarks  │  │  Benchmarks  │  │  Benchmarks  │       │
│  └─────────────┘  └──────────────┘  └──────────────┘       │
│         │                  │                   │             │
│         └──────────────────┴───────────────────┘             │
│                            │                                 │
│                  ┌─────────▼─────────┐                      │
│                  │  Metrics Collector │                      │
│                  │  (OpenTelemetry)   │                      │
│                  └─────────┬─────────┘                      │
│                            │                                 │
│         ┌──────────────────┼──────────────────┐             │
│         │                  │                  │             │
│    ┌────▼────┐      ┌─────▼─────┐     ┌─────▼─────┐      │
│    │Prometheus│      │  Grafana  │     │  BDN      │      │
│    │ Metrics  │      │ Dashboard │     │  Reports  │      │
│    └──────────┘      └───────────┘     └───────────┘      │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Getting Started

### Prerequisites

- .NET 10.0 SDK
- Docker or Podman (for infrastructure containers)
- 8GB+ RAM recommended for full pipeline tests

### Installation

1. **Clone the repository**:
   ```powershell
   git clone <repository-url>
   cd we-ma-enrollment-services
   ```

2. **Build the benchmark project**:
   ```powershell
   dotnet build src/tests/EnrollmentPipeline.Benchmarks/EnrollmentPipeline.Benchmarks.csproj
   ```

3. **Start infrastructure** (optional, for manual testing):
   ```powershell
   podman compose -f src/tests/EnrollmentPipeline.Benchmarks/docker-compose-benchmark.yml up -d
   ```

## 📦 Benchmark Categories

### 1. Individual Worker Benchmarks

Test each worker in isolation to understand baseline performance.

#### CampaignEnrollmentApi Benchmarks
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *CampaignEnrollmentApi*
```

**Scenarios:**
- Single batch publishing
- Constant rate publishing
- Burst pattern publishing
- High-priority message handling

**Key Metrics:**
- Messages published per second
- Publishing latency (P50, P95, P99)
- Memory allocation per message
- Thread utilization

#### DataFieldProvider Benchmarks
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *DataFieldProvider*
```

**Scenarios:**
- Data lookup and enrichment
- Cache hit rate optimization
- Database query performance
- Parallel processing with multiple workers

**Key Metrics:**
- Enrichment throughput
- Database query latency
- Cache hit/miss ratio
- Memory usage for cached data

#### EnrollmentService Benchmarks
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *EnrollmentService*
```

**Scenarios:**
- Single enrollment query by ID
- Query by contact ID and campaign ID
- Insert new enrollment record
- Update existing enrollment record
- Batch enrollment insertion
- Single result recording
- Bulk result recording
- Full enrollment lifecycle

**Key Metrics:**
- Query latency (P50, P95, P99)
- Insert throughput
- Update throughput
- Batch operation performance
- Memory allocation per operation
- Database connection efficiency

#### MarketingCloudPublisher Benchmarks
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *MarketingCloudPublisher*
```

**Scenarios:**
- Batch API operations
- Retry logic performance
- Error handling overhead
- Parallel publishing

**Key Metrics:**
- API call throughput
- Retry success rate
- Error handling latency
- Concurrent connection usage

### 2. Integration Benchmarks

Test worker interactions and data flow between stages.

#### Publisher → Provider
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *PublisherToProvider*
```

**Scenarios:**
- End-to-end message flow
- Backpressure handling
- Cache-optimized processing

#### Provider → MC Publisher
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *ProviderToMcPublisher*
```

**Scenarios:**
- Enriched data publishing
- Retry logic integration
- Rate limiting effects

### 3. End-to-End Pipeline Benchmarks

Test the complete enrollment pipeline under realistic conditions.

```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *FullPipeline*
```

**Scenarios:**
- Normal load (steady state)
- Burst traffic (traffic spikes)
- Sustained load (30+ seconds)
- Error handling throughout pipeline
- Metrics collection and SLO validation

**Key Metrics:**
- End-to-end latency
- Overall throughput
- Worker scaling efficiency
- Error propagation
- Resource utilization

## 📈 Service Level Objectives (SLOs)

The benchmark suite validates the following SLOs:

| Category | Metric | Target | Description |
|----------|--------|--------|-------------|
| **Throughput** | Messages/sec per worker | ≥ 50 | Minimum processing rate |
| **Throughput** | Scaling efficiency | ≥ 70% | Linear scaling factor |
| **Latency** | P95 | ≤ 500ms | 95th percentile latency |
| **Latency** | P99 | ≤ 1000ms | 99th percentile latency |
| **Reliability** | Success rate | ≥ 99.9% | Successful message processing |
| **Reliability** | Error rate | ≤ 0.1% | Failed message rate |
| **Resources** | CPU per worker | ≤ 80% | CPU utilization per core |
| **Resources** | Memory per worker | ≤ 512MB | Memory usage per worker |

## 📊 Running Benchmarks

### Quick Start

Run all benchmarks:
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks
```

### Specific Benchmark Categories

Run individual worker benchmarks:
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *Individual*
```

Run integration benchmarks:
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *Integration*
```

Run end-to-end benchmarks:
```powershell
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --filter *EndToEnd*
```

### Custom Configuration

Run with specific parameters:
```powershell
# Short job (faster iterations)
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --job short

# With memory diagnostics
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --memory

# Export to specific format
dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks --exporters json,html,csv
```

## 📁 Benchmark Results

Results are automatically saved to `./BenchmarkResults/` with the following outputs:

- **HTML Reports**: Interactive performance reports
- **Markdown Reports**: GitHub-compatible summaries
- **CSV Data**: Raw data for further analysis
- **JSON**: Structured data for automation
- **Plots**: Performance visualization graphs

### Sample Report Structure

```
BenchmarkResults/
├── EnrollmentPipeline.Benchmarks.Individual.MessagePublisherBenchmarks-20250111-120000/
│   ├── report.html
│   ├── report.md
│   ├── results.csv
│   └── results.json
├── EnrollmentPipeline.Benchmarks.Integration.PublisherToProviderBenchmarks-20250111-120530/
│   └── ...
└── summary-report.md
```

## 📊 Monitoring with Prometheus & Grafana

### Starting Monitoring Stack

The benchmark suite includes a pre-configured monitoring stack:

```powershell
podman compose -f src/tests/EnrollmentPipeline.Benchmarks/docker-compose-benchmark.yml up -d
```

This starts:
- **Prometheus** (http://localhost:9090) - Metrics collection
- **Grafana** (http://localhost:3000) - Visualization
- **Redis Exporter** (http://localhost:9121) - Redis metrics

### Accessing Dashboards

1. **Grafana**: Navigate to http://localhost:3000
   - Username: `admin`
   - Password: `admin`

2. **Import Dashboard**: 
   - Go to Dashboards → Import
   - Upload `grafana-dashboard.json`
   - Select Prometheus as data source

3. **View Real-Time Metrics**:
   - Message throughput by worker
   - Latency percentiles (P50, P95, P99)
   - Error rates and success rates
   - Queue depths and consumer lag
   - Worker scaling behavior

### Key Prometheus Queries

```promql
# Message processing rate
rate(pipeline_stream_messages_processed_total[1m])

# P95 latency
histogram_quantile(0.95, rate(pipeline_stream_message_duration_seconds_bucket[1m]))

# Success rate
(rate(pipeline_stream_messages_processed_total[1m]) / 
 (rate(pipeline_stream_messages_processed_total[1m]) + 
  rate(pipeline_stream_messages_failed_total[1m]))) * 100

# Worker scaling efficiency
pipeline_active_workers
```

## 🔧 Configuration

### Benchmark Configuration

Edit `benchmark-config.json` to customize:

```json
{
  "Benchmarks": {
    "Warmup": {
      "Iterations": 3,
      "DurationSeconds": 5
    },
    "Measurement": {
      "Iterations": 10,
      "DurationSeconds": 30
    },
    "Workers": {
      "CampaignEnrollmentApi": [1, 2, 4, 8],
      "DataFieldProvider": [1, 2, 4],
      "MarketingCloudPublisher": [1, 2]
    },
    "Loads": {
      "Light": 100,
      "Medium": 1000,
      "Heavy": 5000,
      "Extreme": 10000
    }
  },
  "ServiceLevelObjectives": {
    "Throughput": {
      "MinMessagesPerSecondPerWorker": 50,
      "MinScalingEfficiency": 0.7
    },
    "Latency": {
      "MaxP95Milliseconds": 500,
      "MaxP99Milliseconds": 1000
    }
  }
}
```

## 🧪 Writing Custom Benchmarks

### Example Custom Benchmark

```csharp
[MemoryDiagnoser]
[SimpleJob(warmupCount: 3, iterationCount: 10)]
public class MyCustomBenchmark : IAsyncDisposable
{
    private BenchmarkTestFixture? _fixture;
    
    [Params(100, 1000)]
    public int MessageCount { get; set; }

    [GlobalSetup]
    public async Task GlobalSetup()
    {
        _fixture = new BenchmarkTestFixture();
        await _fixture.InitializeAsync();
    }

    [Benchmark]
    public async Task MyBenchmarkScenario()
    {
        // Your benchmark logic
    }

    [GlobalCleanup]
    public async Task GlobalCleanup()
    {
        if (_fixture != null)
        {
            await _fixture.DisposeAsync();
        }
    }

    public async ValueTask DisposeAsync()
    {
        await GlobalCleanup();
    }
}
```

## 🔄 CI/CD Integration

### Azure Pipelines

Add to your pipeline YAML:

```yaml
- task: DotNetCoreCLI@2
  displayName: 'Run Benchmark Tests'
  inputs:
    command: 'run'
    projects: 'src/tests/EnrollmentPipeline.Benchmarks/*.csproj'
    arguments: '-c Release --filter *FullPipeline*'

- task: PublishBuildArtifacts@1
  displayName: 'Publish Benchmark Results'
  inputs:
    PathtoPublish: 'BenchmarkResults'
    ArtifactName: 'benchmark-results'

- task: PowerShell@2
  displayName: 'Validate SLOs'
  inputs:
    targetType: 'inline'
    script: |
      $results = Get-Content 'BenchmarkResults/results.json' | ConvertFrom-Json
      if ($results.MeetsAllSLOs -eq $false) {
        Write-Error "Benchmark failed to meet SLOs"
        exit 1
      }
```

### GitHub Actions

```yaml
- name: Run Benchmarks
  run: |
    dotnet run -c Release --project src/tests/EnrollmentPipeline.Benchmarks

- name: Upload Results
  uses: actions/upload-artifact@v3
  with:
    name: benchmark-results
    path: BenchmarkResults/
```

## 📖 Best Practices

1. **Always run in Release mode**: Debug mode adds significant overhead
2. **Close unnecessary applications**: Minimize background noise
3. **Run multiple iterations**: Use warmup to stabilize JIT compilation
4. **Compare baselines**: Track performance over time
5. **Monitor system resources**: Ensure benchmarks aren't resource-constrained
6. **Validate SLOs**: Don't just measure, validate against targets
7. **Document changes**: Correlate performance changes with code changes

## 🐛 Troubleshooting

### Common Issues

**Issue**: Benchmarks timeout
- **Solution**: Reduce `MessageCount` or increase timeout in configuration

**Issue**: Out of memory errors
- **Solution**: Reduce worker count or batch sizes

**Issue**: Metrics not collected
- **Solution**: Ensure OpenTelemetry listeners are properly initialized

**Issue**: Prometheus showing no data
- **Solution**: Check that containers are running and metrics endpoints are accessible

## 📚 Additional Resources

- [BenchmarkDotNet Documentation](https://benchmarkdotnet.org/)
- [OpenTelemetry .NET Documentation](https://opentelemetry.io/docs/languages/net/)
- [Prometheus Query Documentation](https://prometheus.io/docs/prometheus/latest/querying/basics/)
- [Grafana Dashboard Documentation](https://grafana.com/docs/grafana/latest/dashboards/)

## 🤝 Contributing

When adding new benchmarks:
1. Follow the existing pattern (Individual/Integration/EndToEnd)
2. Include comprehensive scenarios
3. Validate against SLOs
4. Update documentation
5. Add dashboard panels if needed

## 📄 License

Copyright © 2025 CoStar Group, Inc. All rights reserved.
