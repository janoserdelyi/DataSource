using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Text.RegularExpressions;
using EnrollmentPipeline.Benchmarks.Models;

namespace EnrollmentPipeline.Benchmarks.Fixtures;

/// <summary>
/// Collects OpenTelemetry metrics during benchmark execution and scrapes Prometheus endpoints.
/// </summary>
public class MetricsCollector : IDisposable
{
    private readonly MeterListener _meterListener;
    private readonly ActivityListener _activityListener;
    private readonly Dictionary<string, List<double>> _measurements = new();
    private readonly Dictionary<string, List<(DateTime timestamp, double value)>> _timeSeriesMeasurements = new();
    private readonly HttpClient _httpClient = new();
    private readonly object _lock = new();

    public MetricsCollector()
    {
        _meterListener = new MeterListener
        {
            InstrumentPublished = (instrument, listener) =>
            {
                if (instrument.Meter.Name.Contains("EnrollmentPipeline") ||
                    instrument.Meter.Name.Contains("CampaignEnrollmentApi") ||
                    instrument.Meter.Name.Contains("DataFieldProvider") ||
                    instrument.Meter.Name.Contains("MarketingCloudPublisher"))
                {
                    listener.EnableMeasurementEvents(instrument);
                }
            }
        };

        _meterListener.SetMeasurementEventCallback<long>(OnMeasurementRecorded);
        _meterListener.SetMeasurementEventCallback<double>(OnMeasurementRecorded);
        _meterListener.Start();

        _activityListener = new ActivityListener
        {
            ShouldListenTo = source => source.Name.Contains("EnrollmentPipeline"),
            Sample = (ref ActivityCreationOptions<ActivityContext> _) => ActivitySamplingResult.AllDataAndRecorded
        };

        ActivitySource.AddActivityListener(_activityListener);
    }

    private void OnMeasurementRecorded<T>(Instrument instrument, T measurement, ReadOnlySpan<KeyValuePair<string, object?>> tags, object? state) where T : struct
    {
        lock (_lock)
        {
            var key = instrument.Name;
            if (!_measurements.ContainsKey(key))
            {
                _measurements[key] = new List<double>();
            }

            var value = Convert.ToDouble(measurement);
            _measurements[key].Add(value);
        }
    }

    public BenchmarkMetrics GetMetrics(string benchmarkName, int workerCount, DateTime startTime, DateTime endTime)
    {
        lock (_lock)
        {
            var metrics = new BenchmarkMetrics
            {
                BenchmarkName = benchmarkName,
                StartTime = startTime,
                EndTime = endTime,
                WorkerCount = workerCount
            };

            // Process throughput metrics
            if (_measurements.TryGetValue("pipeline_stream_messages_processed_total", out var processedMessages))
            {
                metrics.TotalMessagesProcessed = (long)processedMessages.Sum();
                metrics.MessagesPerSecond = metrics.TotalMessagesProcessed / metrics.Duration.TotalSeconds;
            }

            if (_measurements.TryGetValue("pipeline_stream_messages_failed_total", out var failedMessages))
            {
                metrics.TotalMessagesFailed = (long)failedMessages.Sum();
            }

            // Process latency metrics
            if (_measurements.TryGetValue("pipeline_stream_message_duration_seconds", out var latencies))
            {
                var sortedLatencies = latencies.OrderBy(x => x).ToList();
                if (sortedLatencies.Any())
                {
                    metrics.AverageLatencyMs = sortedLatencies.Average() * 1000;
                    metrics.MedianLatencyMs = GetPercentile(sortedLatencies, 0.50) * 1000;
                    metrics.P95LatencyMs = GetPercentile(sortedLatencies, 0.95) * 1000;
                    metrics.P99LatencyMs = GetPercentile(sortedLatencies, 0.99) * 1000;
                    metrics.MinLatencyMs = sortedLatencies.First() * 1000;
                    metrics.MaxLatencyMs = sortedLatencies.Last() * 1000;
                }
            }

            // Process batch metrics
            if (_measurements.TryGetValue("pipeline_stream_batch_duration_seconds", out var batchDurations))
            {
                var sortedBatch = batchDurations.OrderBy(x => x).ToList();
                if (sortedBatch.Any())
                {
                    metrics.AverageBatchDurationMs = sortedBatch.Average() * 1000;
                    metrics.P95BatchDurationMs = GetPercentile(sortedBatch, 0.95) * 1000;
                }
            }

            // Process queue metrics
            if (_measurements.TryGetValue("pipeline_stream_length", out var streamLengths))
            {
                metrics.AverageStreamLength = (long)streamLengths.Average();
                metrics.MaxStreamLength = (long)streamLengths.Max();
            }

            if (_measurements.TryGetValue("pipeline_stream_pending_messages", out var pendingMessages))
            {
                metrics.AveragePendingMessages = (long)pendingMessages.Average();
                metrics.MaxPendingMessages = (long)pendingMessages.Max();
            }

            if (_measurements.TryGetValue("pipeline_stream_consumer_lag_total", out var consumerLag))
            {
                metrics.AverageConsumerLag = consumerLag.Average();
            }

            return metrics;
        }
    }

    private static double GetPercentile(List<double> sortedData, double percentile)
    {
        if (sortedData.Count == 0)
            return 0;
        var index = (int)Math.Ceiling(percentile * sortedData.Count) - 1;
        return sortedData[Math.Max(0, Math.Min(index, sortedData.Count - 1))];
    }

    /// <summary>
    /// Scrapes Prometheus metrics endpoint and extracts a specific metric value.
    /// </summary>
    public async Task<double?> ScrapePrometheusMetric(string metricsUrl, string metricName, CancellationToken cancellationToken = default)
    {
        try
        {
            var response = await _httpClient.GetStringAsync(metricsUrl, cancellationToken);
            var lines = response.Split('\n');

            foreach (var line in lines)
            {
                if (line.StartsWith("#") || string.IsNullOrWhiteSpace(line))
                    continue;

                if (line.StartsWith(metricName))
                {
                    var match = Regex.Match(line, @"}\s+([\d.]+)");
                    if (!match.Success)
                    {
                        // Try without labels
                        match = Regex.Match(line, $@"{metricName}\s+([\d.]+)");
                    }

                    if (match.Success && double.TryParse(match.Groups[1].Value, out var value))
                    {
                        return value;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error scraping Prometheus metrics from {metricsUrl}: {ex.Message}");
        }

        return null;
    }

    /// <summary>
    /// Checks if a service is available by attempting to reach its metrics endpoint.
    /// </summary>
    public async Task<bool> IsServiceAvailable(string serviceUrl, CancellationToken cancellationToken = default)
    {
        try
        {
            var metricsUrl = $"{serviceUrl.TrimEnd('/')}/metrics";
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(5));

            var response = await _httpClient.GetAsync(metricsUrl, cts.Token);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Polls Prometheus endpoint for a specific metric until a condition is met or timeout occurs.
    /// </summary>
    public async Task<bool> WaitForMetricCondition(
        string metricsUrl,
        string metricName,
        Func<double, bool> condition,
        TimeSpan timeout,
        TimeSpan pollingInterval,
        CancellationToken cancellationToken = default)
    {
        var startTime = DateTime.UtcNow;

        while (DateTime.UtcNow - startTime < timeout && !cancellationToken.IsCancellationRequested)
        {
            var value = await ScrapePrometheusMetric(metricsUrl, metricName, cancellationToken);

            if (value.HasValue)
            {
                lock (_lock)
                {
                    if (!_timeSeriesMeasurements.ContainsKey(metricName))
                    {
                        _timeSeriesMeasurements[metricName] = new List<(DateTime, double)>();
                    }
                    _timeSeriesMeasurements[metricName].Add((DateTime.UtcNow, value.Value));
                }

                if (condition(value.Value))
                {
                    return true;
                }
            }

            await Task.Delay(pollingInterval, cancellationToken);
        }

        return false;
    }

    /// <summary>
    /// Gets time-series data for a specific metric collected during polling.
    /// </summary>
    public List<(DateTime timestamp, double value)> GetTimeSeriesData(string metricName)
    {
        lock (_lock)
        {
            return _timeSeriesMeasurements.TryGetValue(metricName, out var data)
                ? new List<(DateTime, double)>(data)
                : new List<(DateTime, double)>();
        }
    }

    public void Reset()
    {
        lock (_lock)
        {
            _measurements.Clear();
            _timeSeriesMeasurements.Clear();
        }
    }

    public void Dispose()
    {
        _meterListener?.Dispose();
        _activityListener?.Dispose();
        _httpClient?.Dispose();
    }
}
