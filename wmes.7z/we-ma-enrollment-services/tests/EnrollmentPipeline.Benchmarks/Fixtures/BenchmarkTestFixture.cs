using StackExchange.Redis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using OpenSearch.Client;
using OpenSearch.Client.JsonNetSerializer;
using OpenSearch.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using EnrollmentPipeline.Repositories;
using EnrollmentPipeline.Util;
using Npgsql;
using Microsoft.Extensions.Caching.Hybrid;
using Moq;

namespace EnrollmentPipeline.Benchmarks.Fixtures;

/// <summary>
/// Test fixture for setting up benchmark infrastructure using external services.
/// Expects Redis, PostgreSQL, and worker services to be running.
/// </summary>
public class BenchmarkTestFixture : IAsyncLifetime
{
	public IConnectionMultiplexer Redis { get; private set; } = null!;
	public string RedisConnectionString { get; private set; } = string.Empty;
	public string PostgresConnectionString { get; private set; } = string.Empty;
	public IConfiguration Configuration { get; private set; } = null!;
	public IOpenSearchClient OpenSearchClient { get; private set; } = null!;
	public IContactRepository ContactRepository { get; private set; } = null!;
	public ICampaignRepository CampaignRepository { get; private set; } = null!;

	public async Task InitializeAsync()
	{
		// Build configuration with explicit base path
		Configuration = new ConfigurationBuilder()
			.AddInMemoryCollection(new Dictionary<string, string?>
			{
                // Add any default configuration settings needed for benchmarks here
                { "ConnectionStrings:Redis", "localhost:6379" },
				{ "ConnectionStrings:OpenSearch", "https://vpc-crm-os-dev-2wdrllrcrvcfz66mjqcjuyrw6e.us-east-1.es.amazonaws.com" },
				{ "PipelineWorkers:Id", "c969e185-fc4f-4093-8458-b4c444f722cd" },
				{ "Services:CampaignEnrollmentApi", "http://localhost:5000" },
				{ "Services:DataFieldProvider", "http://localhost:5001" },
				{ "Services:MarketingCloudPublisher", "http://localhost:5002" },
				{ "TestData:MarketingCampaignId", "21983" },
				{ "TestData:PipelineVersionId", "1" },
			})
			.Build();

		// Initialize OpenSearch Client
		var openSearchConnectionString = Configuration.GetConnectionString("OpenSearch")
			?? throw new InvalidOperationException("OpenSearch connection string is not configured in appsettings.json");

		var pool = new SingleNodeConnectionPool(new Uri(openSearchConnectionString));
		var settings = new ConnectionSettings(
			pool,
			sourceSerializer: (builtin, connectionSettings) => new JsonNetSerializer(
				builtin,
				connectionSettings,
				() => new JsonSerializerSettings
				{
					ContractResolver = new SystemTextJsonPropertyNameContractResolver(),
					NullValueHandling = NullValueHandling.Include
				}
			)
		);

		OpenSearchClient = new OpenSearchClient(settings);

		// Initialize HybridCache mock for CampaignRepository (using Mock for benchmark simplicity)
		var mockHybridCache = new Mock<HybridCache>();

		// Initialize repositories with NullLogger to avoid benchmark noise
		ContactRepository = new ContactRepository(OpenSearchClient, NullLogger<ContactRepository>.Instance);
		CampaignRepository = new CampaignRepository(mockHybridCache.Object, OpenSearchClient, NullLogger<CampaignRepository>.Instance);

		// Connect to Redis using connection string from configuration
		RedisConnectionString = Configuration.GetConnectionString("Redis")
			?? throw new InvalidOperationException("Redis connection string is not configured in appsettings.json");
		Redis = await ConnectionMultiplexer.ConnectAsync(RedisConnectionString);
	}

	public async Task DisposeAsync()
	{
		if (Redis != null)
		{
			await Redis.DisposeAsync();
		}
	}
}
