using BenchmarkDotNet.Engines;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;
using System.Diagnostics;
using Marketing.Enums;
using Microsoft.AspNetCore.Builder;
using EnrollmentPipeline.Repositories;
using EnrollmentPipeline.Benchmarks.Helpers;

namespace EnrollmentPipeline.Benchmarks.Workers;

/// <summary>
/// Abstract base benchmark class for testing StreamPipelineWorker implementations.
/// Measures message processing throughput, latency, and error rates by directly calling ProcessBatch.
/// Supports configurable load sizes and high-priority message percentages.
/// </summary>
[MemoryDiagnoser]
[SimpleJob(RunStrategy.Throughput, warmupCount: 1, iterationCount: 3)]
public abstract class StreamPipelineWorkerBenchmark<TWorker> : BasePipelineBenchmark
    where TWorker : StreamPipelineWorker
{
    protected TWorker? _worker;
    protected WebApplication? _app;
    protected IServiceScope? _scope;
    protected IStreamMessagePublisher? _publisher;
    protected List<StagedEnrollment>? _testEnrollments;
    protected readonly Consumer _consumer = new();

    // Benchmark configuration parameters
    [Params(5000, 10000)]
    public int LoadSize { get; set; }

    [Params(0, 10)]
    public int HighPriorityPercentage { get; set; }

    // Metrics tracking
    protected long _messagesProcessed;
    protected long _messagesErrored;
    protected readonly List<double> _latencies = new();
    protected readonly object _metricsLock = new();

    [GlobalSetup]
    public async Task GlobalSetup()
    {
        Console.WriteLine($"[{typeof(TWorker).Name}] Starting GlobalSetup...");

        // Use WebApplicationBuilder to leverage all extension methods
        var builder = CreateAppBuilder();

        // Register the worker itself
        builder.Services.AddScoped<TWorker>();

        // Build the service provider with real dependencies
        _app = BuildApp(builder);
        // Creates DI scope
        _scope = _app.Services.CreateScope();
        // Create worker instance
        _worker = _scope.ServiceProvider.GetRequiredService<TWorker>();
        // Create stream message publisher
        _publisher = _scope.ServiceProvider.GetRequiredService<IStreamMessagePublisher>();

        ArgumentNullException.ThrowIfNull(_worker, nameof(_worker));

        // Clean Redis streams before starting
        await CleanRedisStreams();

        // Re-initialize streams for next run
        await InitializeRedisStreams();

        // Warmup: Process a small batch to ensure everything is initialized
        await WarmupWorker();

        Console.WriteLine($"[{typeof(TWorker).Name}] GlobalSetup complete - LoadSize: {LoadSize}, HighPriority: {HighPriorityPercentage}%");
    }

    [GlobalCleanup]
    public override async Task GlobalCleanup()
    {
        Console.WriteLine($"[{typeof(TWorker).Name}] Starting GlobalCleanup...");

        // Clean up Redis streams
        await CleanRedisStreams();

        if (_scope != null)
        {
            _scope.Dispose();
        }

        if (_app != null)
        {
            await _app.DisposeAsync();
        }
    }

    [IterationSetup]
    public void IterationSetup()
    {
        Console.WriteLine($"[{typeof(TWorker).Name}] Starting IterationSetup...");

        // Reset metrics
        _messagesProcessed = 0;
        _messagesErrored = 0;
        _latencies.Clear();

        // Generate test data for this iteration 
        // P.S.: using GetAwaiter().GetResult() because IterationSetup cannot be async. See: https://github.com/dotnet/BenchmarkDotNet/issues/2442
        _testEnrollments = GenerateTestEnrollments(LoadSize, HighPriorityPercentage).GetAwaiter().GetResult();

        Console.WriteLine("Writing enrollments to stream...");

        ArgumentNullException.ThrowIfNull(_publisher, nameof(_publisher));
        ArgumentNullException.ThrowIfNull(_worker, nameof(_worker));
        ArgumentNullException.ThrowIfNull(_testEnrollments, nameof(_testEnrollments));

        // Publish it to worker's stream
        _publisher.PublishEnrollmentBatchAsync(_worker.DefaultStreamName, _testEnrollments).GetAwaiter().GetResult();

        Console.WriteLine($"[{typeof(TWorker).Name}] IterationSetup - Generated {_testEnrollments.Count} enrollments " +
                          $"({_testEnrollments.Count(e => e.IsHighPriority)} high priority)");
    }

    [Benchmark(Description = "ProcessStreamMessages")]
    public async Task ProcessStreamMessages()
    {
        if (_scope == null || _worker == null || _testEnrollments == null)
            return;

        Console.WriteLine($"[{typeof(TWorker).Name}] Starting ProcessStreamMessages...");

        var stopwatch = Stopwatch.StartNew();

        var redisConnection = _scope.ServiceProvider.GetRequiredService<IConnectionMultiplexer>();
        var database = redisConnection.GetDatabase();
        try
        {
            await _worker.ProcessStreamMessages(database, CancellationToken.None);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[{typeof(TWorker).Name}] Error processing batch: {ex.Message}");
        }

        stopwatch.Stop();

        // Log batch metrics
        var throughput = _testEnrollments.Count / stopwatch.Elapsed.TotalSeconds;
        Console.WriteLine($"[{typeof(TWorker).Name}] Processed {_testEnrollments.Count} messages " +
                          $"in {stopwatch.Elapsed.TotalSeconds:F2}s ({throughput:F2} msg/s)");
    }

    // [Benchmark(Description = "ProcessBatch")]
    // public async Task ProcessBatch()
    // {
    //     if (_worker == null || _testEnrollments == null) return;

    //     Console.WriteLine($"[{typeof(TWorker).Name}] Starting ProcessBatch...");

    //     var stopwatch = Stopwatch.StartNew();
    //     var processedCount = 0;
    //     var errorCount = 0;

    //     try
    //     {
    //         foreach(var batch in _testEnrollments.Chunk(10000))
    //         {
    //             await foreach (var result in _worker.ProcessBatch(batch, CancellationToken.None))
    //             {
    //                 processedCount++;

    //                 var latencyMs = (result.EndedAt - result.StartedAt).TotalMilliseconds;

    //                 lock (_metricsLock)
    //                 {
    //                     _latencies.Add(latencyMs);
    //                     _messagesProcessed++;

    //                     if (result.Status == PipelineStatus.Failed)
    //                     {
    //                         _messagesErrored++;
    //                         errorCount++;
    //                     }
    //                 }
    //             }
    //         }
    //     }
    //     catch (Exception ex)
    //     {
    //         Console.WriteLine($"[{typeof(TWorker).Name}] Error processing batch: {ex.Message}");
    //         errorCount = _testEnrollments.Count - processedCount;

    //         lock (_metricsLock)
    //         {
    //             _messagesErrored += errorCount;
    //         }
    //     }

    //     stopwatch.Stop();

    //     // Log batch metrics
    //     var throughput = processedCount / stopwatch.Elapsed.TotalSeconds;
    //     Console.WriteLine($"[{typeof(TWorker).Name}] Processed {processedCount}/{_testEnrollments.Count} messages " +
    //                       $"in {stopwatch.Elapsed.TotalSeconds:F2}s ({throughput:F2} msg/s, {errorCount} errors)");
    // }

    /// <summary>
    /// Generates test enrollments with the specified load size and high-priority percentage.
    /// Uses real contact data from OpenSearch.
    /// </summary>
    protected async Task<List<StagedEnrollment>> GenerateTestEnrollments(int loadSize, int highPriorityPercentage)
    {
        if (_scope == null)
        {
            throw new InvalidOperationException("Scope not initialized");
        }

        var configuration = _scope.ServiceProvider.GetRequiredService<IConfiguration>();
        var contactRepository = _scope.ServiceProvider.GetRequiredService<IContactRepository>();

        var campaignId = configuration.GetValue<int>("TestData:MarketingCampaignId");
        var pipelineVersionId = configuration.GetValue<short>("TestData:PipelineVersionId");

        // Fetch real contacts from OpenSearch
        var contacts = await contactRepository.GetAllContacts(loadSize);

        var highPriorityCount = (int)(loadSize * highPriorityPercentage / 100.0);
        var index = 0;

        return contacts
            .Take(loadSize)
            .Select(contact => new StagedEnrollment
            (
                contact.Id,
                [],
                campaignId,
                MarketingBrands.Homes,
                pipelineVersionId
            )
            {
                IsHighPriority = index++ < highPriorityCount,
            })
            .ToList();
    }

    /// <summary>
    /// Initialize the Redis streams used by the worker.
    /// </summary>
    protected async Task InitializeRedisStreams()
    {
        if (_scope == null || _worker == null)
        {
            return;
        }

        var redisConnection = _scope.ServiceProvider.GetRequiredService<IConnectionMultiplexer>();
        var database = redisConnection.GetDatabase();

        try
        {
            await _worker.InitializeStreams(database);

            Console.WriteLine($"[{typeof(TWorker).Name}] Initialized Redis streams for worker {_worker.WorkerId}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[{typeof(TWorker).Name}] Error initializing Redis streams: {ex.Message}");
        }
    }

    /// <summary>
    /// Cleans Redis streams used by the worker.
    /// </summary>
    protected async Task CleanRedisStreams()
    {
        if (_scope == null || _worker == null)
        {
            return;
        }

        var redisConnection = _scope.ServiceProvider.GetRequiredService<IConnectionMultiplexer>();
        var database = redisConnection.GetDatabase();

        try
        {
            // Delete worker's stream and high-priority stream
            await database.KeyDeleteAsync(_worker.DefaultStreamName);
            await database.KeyDeleteAsync(_worker.HighPriorityStreamName);

            Console.WriteLine($"[{typeof(TWorker).Name}] Cleaned Redis streams for worker {_worker.WorkerId}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[{typeof(TWorker).Name}] Error cleaning Redis streams: {ex.Message}");
        }
    }

    /// <summary>
    /// Performs a warmup run with a small batch to initialize the worker.
    /// </summary>
    protected async Task WarmupWorker()
    {
        if (_worker == null)
        {
            return;
        }

        Console.WriteLine($"[{typeof(TWorker).Name}] Starting warmup...");

        // Generate a small batch for warmup
        var warmupEnrollments = await GenerateTestEnrollments(10, 5);

        try
        {
            var count = 0;
            await foreach (var _ in _worker.ProcessBatch(warmupEnrollments, CancellationToken.None))
            {
                count++;
            }

            Console.WriteLine($"[{typeof(TWorker).Name}] Warmup complete - Processed {count} messages");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[{typeof(TWorker).Name}] Warmup error: {ex.Message}");
        }
    }

    /// <summary>
    /// Prints summary metrics after all iterations complete.
    /// </summary>
    [IterationCleanup]
    public void PrintMetrics()
    {
        Console.WriteLine($"[{typeof(TWorker).Name}] Starting IterationCleanup...");
        lock (_metricsLock)
        {
            Console.WriteLine($"[{typeof(TWorker).Name}] {_latencies.Count} latencies recorded.");
            if (_latencies.Count == 0)
                return;

            var sortedLatencies = _latencies.OrderBy(l => l).ToList();
            var p50 = sortedLatencies[sortedLatencies.Count / 2];
            var p95 = sortedLatencies[(int)(sortedLatencies.Count * 0.95)];
            var p99 = sortedLatencies[(int)(sortedLatencies.Count * 0.99)];
            var errorRate = _messagesErrored / (double)_messagesProcessed * 100;

            Console.WriteLine($"[{typeof(TWorker).Name}] === Metrics Summary ===");
            Console.WriteLine($"  Total Processed: {_messagesProcessed}");
            Console.WriteLine($"  Total Errors: {_messagesErrored} ({errorRate:F2}%)");
            Console.WriteLine($"  Latency P50: {p50:F2}ms");
            Console.WriteLine($"  Latency P95: {p95:F2}ms");
            Console.WriteLine($"  Latency P99: {p99:F2}ms");
            Console.WriteLine($"  Avg Latency: {_latencies.Average():F2}ms");
        }
    }
}
