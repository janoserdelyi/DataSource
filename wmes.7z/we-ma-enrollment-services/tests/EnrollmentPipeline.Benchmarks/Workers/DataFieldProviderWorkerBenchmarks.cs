using DataFieldProvider;
using DataFieldProvider.Extensions;
using EnrollmentPipeline.Extensions;
using Microsoft.AspNetCore.Builder;

namespace EnrollmentPipeline.Benchmarks.Workers;

/// <summary>
/// Benchmark for DataFieldProviderWorker that tests data field retrieval and enrichment performance.
/// Uses real dependencies including Data Plane, EDS, OpenSearch, and other services.
/// </summary>
public class DataFieldProviderWorkerBenchmarks : StreamPipelineWorkerBenchmark<Worker>
{
    protected override WebApplication BuildApp(WebApplicationBuilder builder)
    {
        // Add DataFieldProvider-specific services using extension methods
        builder.AddPostgresDatabase();
        builder.AddSqlServerDatabase();
        builder.AddDataPlaneService();
        builder.AddEdsService();
        builder.AddListingMarketAnalyticsService();
        builder.AddPreferencesService();
        builder.AddSalesAeService();
        builder.AddHomesTokenService();
        builder.AddQueryAndCommandDispatcher();
        builder.AddCampaignDataFieldService();

        return builder.Build();
    }
}
