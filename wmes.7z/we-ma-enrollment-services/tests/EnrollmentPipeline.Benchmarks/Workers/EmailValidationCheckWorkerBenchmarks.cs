using EmailValidationCheck;
using EmailValidationCheck.Services;
using EnrollmentPipeline.Benchmarks.Fixtures;
using EnrollmentPipeline.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Benchmarks.Workers;

/// <summary>
/// Benchmark for EmailValidationCheckWorker that tests email validation performance.
/// Uses real dependencies including the Email Validation API service.
/// </summary>
public class EmailValidationCheckWorkerBenchmarks : StreamPipelineWorkerBenchmark<Worker>
{
    protected override WebApplication BuildApp(WebApplicationBuilder builder)
    {
        // Add Postgres database
        builder.AddPostgresDatabase();

        // Configure EmailValidationService HTTP client
        var emailValidationApiBaseUrl = builder.Configuration.GetValue<string>("Services:EmailValidationApi")
            ?? throw new InvalidOperationException("EmailValidationApi base URL is not configured");

        builder.Services.AddHttpClient<IEmailValidationService, EmailValidationService>(client =>
        {
            client.BaseAddress = new Uri(emailValidationApiBaseUrl);
            client.DefaultRequestHeaders.Add("User-Agent", "EmailValidation/1.0");
            client.Timeout = TimeSpan.FromMinutes(5); // Allow longer timeout for bulk operations
        });

        // Register the worker itself
        builder.Services.AddScoped<Worker>();

        return builder.Build();
    }
}
