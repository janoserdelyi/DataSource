using ErrorHandler;
using EnrollmentPipeline.Benchmarks.Fixtures;
using EnrollmentPipeline.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Builder;

namespace EnrollmentPipeline.Benchmarks.Workers;

/// <summary>
/// Benchmark for ErrorHandlerWorker that tests error processing and retry logic performance.
/// Uses real dependencies including AWS RDS database.
/// </summary>
public class ErrorHandlerWorkerBenchmarks : StreamPipelineWorkerBenchmark<Worker>
{
    protected override WebApplication BuildApp(WebApplicationBuilder builder)
    {
        // Add Postgres database
        builder.AddPostgresDatabase();

        // Register the worker itself
        builder.Services.AddScoped<Worker>();

        return builder.Build();
    }
}
