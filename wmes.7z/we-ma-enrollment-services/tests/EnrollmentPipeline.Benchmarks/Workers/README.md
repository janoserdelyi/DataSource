# StreamPipelineWorker Benchmarks

This directory contains benchmark tests for all `StreamPipelineWorker` implementations. These benchmarks measure message processing throughput, latency, and error rates by directly calling the `ProcessBatch` method with real dependencies.

## Architecture

### Base Class: `StreamPipelineWorkerBenchmark<TWorker>`

An abstract generic base class that provides:
- **Configurable load testing** via `LoadSize` parameter (1000, 10000, 20000 messages)
- **High-priority message testing** via `HighPriorityPercentage` parameter (default: 5%)
- **Real data generation** using contacts from OpenSearch
- **Metrics tracking**: messages/second, latency percentiles (P50, P95, P99), error rates
- **Redis stream cleanup** between iterations
- **Warmup runs** with small batches

### Concrete Implementations

#### 1. `DataFieldProviderWorkerBenchmarks`
Tests data field retrieval and enrichment performance with real dependencies:
- Data Plane service
- EDS (Enterprise Data Service)
- OpenSearch
- Listing Market Analytics
- Preferences service
- Sales AE Cache service
- Homes Token service
- AWS RDS PostgreSQL database

#### 2. `EmailValidationCheckWorkerBenchmarks`
Tests email validation performance with real dependencies:
- Email Validation API HTTP client
- AWS RDS PostgreSQL database

#### 3. `ErrorHandlerWorkerBenchmarks`
Tests error processing and retry logic with real dependencies:
- AWS RDS PostgreSQL database

## Running Benchmarks

### Prerequisites

1. **Infrastructure must be running**:
   ```powershell
   # Start local Redis/Valkey instance
   podman compose up -d valkey
   ```

2. **AWS credentials configured** (for RDS database access)

3. **Configuration** in `appsettings.json` or environment variables

### Run All Worker Benchmarks

```powershell
# From the benchmark project directory
cd src/tests/EnrollmentPipeline.Benchmarks

# Run all benchmarks
dotnet run -c Release

# Run specific worker benchmarks
dotnet run -c Release --filter *DataFieldProviderWorkerBenchmarks*
dotnet run -c Release --filter *EmailValidationCheckWorkerBenchmarks*
dotnet run -c Release --filter *ErrorHandlerWorkerBenchmarks*
```

### Run with Specific Parameters

```powershell
# Test with specific load size
dotnet run -c Release -- --filter *DataFieldProviderWorkerBenchmarks* --job short --runtimes net10.0 --warmupCount 1 --iterationCount 3

# Test only high-priority stream processing
dotnet run -c Release -- --filter *ProcessBatch_HighPriorityStream*
```

## Benchmark Methods

Each concrete benchmark class provides three benchmark methods:

### 1. `ProcessBatch_RegularStream`
Tests processing of regular (non-priority) messages only.

### 2. `ProcessBatch_HighPriorityStream`
Tests processing of high-priority messages only.

### 3. `ProcessBatch_MixedStreams`
Tests processing of mixed regular and high-priority messages (realistic scenario).

## Configuration

### Load Size
Controls the number of test messages generated per iteration:
```csharp
[Params(1000, 10000, 20000)]
public int LoadSize { get; set; }
```

### High Priority Percentage
Controls the percentage of messages marked as high-priority:
```csharp
[Params(5)]
public int HighPriorityPercentage { get; set; }
```

To test different percentages, modify the `Params` attribute:
```csharp
[Params(5, 10, 20)]  // Test 5%, 10%, and 20% high-priority
public int HighPriorityPercentage { get; set; }
```

## Metrics Reported

Each benchmark tracks and reports:

1. **Throughput**: Messages processed per second
2. **Latency Percentiles**:
   - P50 (median)
   - P95 
   - P99
   - Average
3. **Error Rate**: Percentage of failed messages
4. **Total Processed**: Total message count
5. **Total Errors**: Failed message count

### Sample Output

```
[DataFieldProviderWorker] === Metrics Summary ===
  Total Processed: 10000
  Total Errors: 0 (0.00%)
  Latency P50: 12.45ms
  Latency P95: 28.91ms
  Latency P99: 45.23ms
  Avg Latency: 15.67ms
```

## Adding a New Worker Benchmark

To benchmark a new `StreamPipelineWorker` implementation:

1. Create a new class inheriting from `StreamPipelineWorkerBenchmark<TWorker>`:

```csharp
public class MyNewWorkerBenchmarks : StreamPipelineWorkerBenchmark<MyNewWorker>
{
    protected override async Task<IServiceProvider> BuildServiceProvider(BenchmarkTestFixture fixture)
    {
        var webAppBuilder = Microsoft.AspNetCore.Builder.WebApplication.CreateBuilder();
        
        // Configure with fixture
        webAppBuilder.Configuration.Sources.Clear();
        webAppBuilder.Configuration.AddConfiguration(fixture.Configuration);
        
        // Add minimal logging
        webAppBuilder.Logging.ClearProviders();
        webAppBuilder.Logging.SetMinimumLevel(LogLevel.Warning);
        
        // Add Redis from fixture
        webAppBuilder.Services.AddSingleton(fixture.Redis);
        
        // Add worker-specific services here
        webAppBuilder.AddMyWorkerServices();
        
        // Register the worker
        webAppBuilder.Services.AddScoped<MyNewWorker>();
        
        var app = webAppBuilder.Build();
        return app.Services;
    }
}
```

2. Add project reference to `EnrollmentPipeline.Benchmarks.csproj`:

```xml
<ProjectReference Include="..\..\MyNewWorker\MyNewWorker.csproj" />
```

3. Run the benchmark:

```powershell
dotnet run -c Release -- --filter *MyNewWorkerBenchmarks*
```

## Best Practices

1. **Use Release configuration** for accurate performance measurements
2. **Ensure infrastructure is warmed up** before benchmarking
3. **Run multiple iterations** to get consistent results
4. **Monitor resource usage** (CPU, memory, network) during benchmarks
5. **Compare results** across different load sizes to identify bottlenecks
6. **Test both regular and high-priority streams** separately

## Troubleshooting

### "Service not available" errors
- Ensure all required services are running (Redis, databases, external APIs)
- Check configuration in `appsettings.json`
- Verify network connectivity

### "Invalid contact data" errors
- Ensure OpenSearch is accessible and contains test contacts
- Check connection string in configuration
- Verify contact IDs exist in the configured index

### High error rates
- Check worker logs for specific error messages
- Verify all required services are healthy
- Ensure proper AWS credentials for RDS access

## Related Documentation

- [EnrollmentPipeline.Benchmarks README](../README.md)
- [StreamPipelineWorker Documentation](../../EnrollmentPipeline/README.md)
- [Performance Tuning Guide](../SCALING.md)
