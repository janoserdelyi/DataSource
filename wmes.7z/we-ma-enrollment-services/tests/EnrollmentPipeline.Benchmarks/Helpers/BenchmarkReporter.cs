using System.Text;
using System.Text.Json;
using EnrollmentPipeline.Benchmarks.Models;

namespace EnrollmentPipeline.Benchmarks.Helpers;

/// <summary>
/// Generates comprehensive reports from benchmark results.
/// </summary>
public class BenchmarkReporter
{
    private readonly BenchmarkSLOs _slos;

    public BenchmarkReporter(BenchmarkSLOs? slos = null)
    {
        _slos = slos ?? new BenchmarkSLOs();
    }

    public string GenerateMarkdownReport(List<BenchmarkResult> results)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Enrollment Pipeline Benchmark Results");
        sb.AppendLine();
        sb.AppendLine($"Generated: {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss UTC}");
        sb.AppendLine();

        // Summary table
        sb.AppendLine("## Summary");
        sb.AppendLine();
        sb.AppendLine("| Benchmark | Workers | Messages | Throughput (msg/s) | P95 Latency (ms) | Success Rate | Meets SLOs |");
        sb.AppendLine("|-----------|---------|----------|-------------------|------------------|--------------|------------|");

        foreach (var result in results.OrderBy(r => r.Category).ThenBy(r => r.BenchmarkName))
        {
            var m = result.Metrics;
            var meetsAllSLOs = m.MeetsAllSLOs ? "✅" : "❌";
            sb.AppendLine($"| {result.BenchmarkName} | {m.WorkerCount} | {m.TotalMessagesProcessed:N0} | {m.MessagesPerSecond:F2} | {m.P95LatencyMs:F2} | {m.SuccessRate:P2} | {meetsAllSLOs} |");
        }

        sb.AppendLine();

        // Detailed results by category
        var categories = results.GroupBy(r => r.Category).OrderBy(g => g.Key);
        foreach (var category in categories)
        {
            sb.AppendLine($"## {category.Key} Benchmarks");
            sb.AppendLine();

            foreach (var result in category.OrderBy(r => r.BenchmarkName))
            {
                sb.AppendLine($"### {result.BenchmarkName}");
                sb.AppendLine();
                GenerateDetailedMetrics(sb, result);
                sb.AppendLine();
            }
        }

        // SLO compliance
        sb.AppendLine("## Service Level Objectives (SLOs)");
        sb.AppendLine();
        sb.AppendLine($"- **Throughput**: ≥ {_slos.MinThroughputPerWorker} msg/s per worker");
        sb.AppendLine($"- **Latency P95**: ≤ {_slos.MaxLatencyP95Ms} ms");
        sb.AppendLine($"- **Latency P99**: ≤ {_slos.MaxLatencyP99Ms} ms");
        sb.AppendLine($"- **Success Rate**: ≥ {_slos.MinSuccessRate:P2}");
        sb.AppendLine($"- **Max CPU**: ≤ {_slos.MaxCpuPerWorker * 100}% per worker");
        sb.AppendLine($"- **Max Memory**: ≤ {_slos.MaxMemoryPerWorker / 1024 / 1024} MB per worker");
        sb.AppendLine();

        var sloCompliant = results.Count(r => r.Metrics.MeetsAllSLOs);
        var sloPercentage = results.Any() ? (double)sloCompliant / results.Count * 100 : 0;
        sb.AppendLine($"**Overall SLO Compliance**: {sloCompliant}/{results.Count} ({sloPercentage:F1}%)");
        sb.AppendLine();

        return sb.ToString();
    }

    private void GenerateDetailedMetrics(StringBuilder sb, BenchmarkResult result)
    {
        var m = result.Metrics;

        sb.AppendLine("**Configuration:**");
        sb.AppendLine($"- Workers: {m.WorkerCount}");
        sb.AppendLine($"- Duration: {m.Duration.TotalSeconds:F2}s");
        sb.AppendLine($"- Messages: {m.TotalMessagesProcessed:N0} processed, {m.TotalMessagesFailed:N0} failed");
        sb.AppendLine();

        sb.AppendLine("**Throughput:**");
        sb.AppendLine($"- Overall: {m.MessagesPerSecond:F2} msg/s");
        sb.AppendLine($"- Per Worker: {m.MessagesPerSecond / m.WorkerCount:F2} msg/s");
        sb.AppendLine($"- Scaling Efficiency: {m.ScalingEfficiency:P1}");
        sb.AppendLine($"- SLO: {(m.MeetsThroughputSLO ? "✅" : "❌")}");
        sb.AppendLine();

        sb.AppendLine("**Latency:**");
        sb.AppendLine($"- Average: {m.AverageLatencyMs:F2} ms");
        sb.AppendLine($"- Median (P50): {m.MedianLatencyMs:F2} ms");
        sb.AppendLine($"- P95: {m.P95LatencyMs:F2} ms");
        sb.AppendLine($"- P99: {m.P99LatencyMs:F2} ms");
        sb.AppendLine($"- Min/Max: {m.MinLatencyMs:F2} / {m.MaxLatencyMs:F2} ms");
        sb.AppendLine($"- SLO: {(m.MeetsLatencySLO ? "✅" : "❌")}");
        sb.AppendLine();

        sb.AppendLine("**Reliability:**");
        sb.AppendLine($"- Success Rate: {m.SuccessRate:P2}");
        sb.AppendLine($"- Error Rate: {(1 - m.SuccessRate):P2}");
        sb.AppendLine($"- SLO: {(m.MeetsReliabilitySLO ? "✅" : "❌")}");
        sb.AppendLine();

        if (m.MaxCpuUsage > 0 || m.MaxMemoryBytes > 0)
        {
            sb.AppendLine("**Resources:**");
            sb.AppendLine($"- CPU: {m.AverageCpuUsage:F2} avg, {m.MaxCpuUsage:F2} max");
            sb.AppendLine($"- Memory: {m.AverageMemoryBytes / 1024 / 1024:N0} MB avg, {m.MaxMemoryBytes / 1024 / 1024:N0} MB max");
            sb.AppendLine($"- SLO: {(m.MeetsResourceSLO ? "✅" : "❌")}");
            sb.AppendLine();
        }

        if (m.MaxStreamLength > 0)
        {
            sb.AppendLine("**Queue Metrics:**");
            sb.AppendLine($"- Stream Length: {m.AverageStreamLength:N0} avg, {m.MaxStreamLength:N0} max");
            sb.AppendLine($"- Pending Messages: {m.AveragePendingMessages:N0} avg, {m.MaxPendingMessages:N0} max");
            sb.AppendLine($"- Consumer Lag: {m.AverageConsumerLag:F2} ms");
            sb.AppendLine();
        }
    }

    public void ExportToJson(List<BenchmarkResult> results, string filePath)
    {
        var json = JsonSerializer.Serialize(results, new JsonSerializerOptions
        {
            WriteIndented = true
        });
        File.WriteAllText(filePath, json);
    }

    public void ExportToCsv(List<BenchmarkResult> results, string filePath)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Benchmark,Category,Workers,Messages,Duration,Throughput,P95Latency,P99Latency,SuccessRate,MeetsAllSLOs");

        foreach (var result in results)
        {
            var m = result.Metrics;
            sb.AppendLine($"{result.BenchmarkName},{result.Category},{m.WorkerCount},{m.TotalMessagesProcessed}," +
                         $"{m.Duration.TotalSeconds:F2},{m.MessagesPerSecond:F2},{m.P95LatencyMs:F2}," +
                         $"{m.P99LatencyMs:F2},{m.SuccessRate:F4},{m.MeetsAllSLOs}");
        }

        File.WriteAllText(filePath, sb.ToString());
    }
}
