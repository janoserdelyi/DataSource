using EnrollmentPipeline.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace EnrollmentPipeline.Benchmarks.Helpers;

public abstract class BasePipelineBenchmark : IAsyncDisposable
{
    protected WebApplicationBuilder CreateAppBuilder()
    {
        var builder = WebApplication.CreateBuilder();

        // Clear default configuration sources and load benchmark-specific config (replaces appsettings.json )
        builder.Configuration.Sources.Clear();
        builder.Configuration.AddJsonFile("benchmark-config.json");

        // Configure logging with minimal output for benchmarking
        builder.Logging.ClearProviders();
        builder.Logging.SetMinimumLevel(LogLevel.Warning);
        builder.Logging.AddConsole();

        // Configure Redis connection with telemetry
        builder.AddRedis();
        // Add OpenSearch integration
        builder.AddOpenSearchClient();

        return builder;
    }

    /// <summary>
    /// Builds the application with real dependencies for the worker.
    /// Must be implemented by derived classes to register worker-specific services.
    /// </summary>
    /// <param name="builder">The WebApplicationBuilder with shared infrastructure</param>
    /// <returns>A configured WebApplication object</returns>
    protected abstract WebApplication BuildApp(WebApplicationBuilder builder);

    /// <summary>
    /// Performs global cleanup after all benchmarks have run.
    /// </summary>
    public abstract Task GlobalCleanup();

    public async ValueTask DisposeAsync()
    {
        await GlobalCleanup();
        GC.SuppressFinalize(this);
    }
}