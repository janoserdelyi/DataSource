using EnrollmentPipeline.Models;
using EnrollmentPipeline.Enums;
using StackExchange.Redis;
using System.Text.Json;
using EnrollmentPipeline.Repositories;
using System.Text.Json.Nodes;
using Marketing.Enums;
using DataFieldProvider.Models;
using Microsoft.Extensions.Configuration;

namespace EnrollmentPipeline.Benchmarks.Helpers;

/// <summary>
/// Generates various load patterns for benchmark testing using real contacts and campaigns from OpenSearch.
/// </summary>
public class LoadGenerator
{
    private readonly IConnectionMultiplexer _redis;
    private readonly string _streamName;
    private readonly IContactRepository _contactRepository;
    private readonly ICampaignRepository _campaignRepository;
    private readonly IConfiguration _configuration;

    private readonly MarketingCampaign _campaign;
    private readonly int _marketingCampaignId;
    private readonly short _pipelineVersionId;

    private readonly Dictionary<int, List<Contact>> _contactCache = new();
    private readonly object _cacheLock = new();

    public LoadGenerator(
        IConnectionMultiplexer redis,
        string streamName,
        IContactRepository contactRepository,
        ICampaignRepository campaignRepository,
        IConfiguration configuration)
    {
        _redis = redis ?? throw new ArgumentNullException(nameof(redis));
        _streamName = streamName ?? throw new ArgumentNullException(nameof(streamName));
        _contactRepository = contactRepository ?? throw new ArgumentNullException(nameof(contactRepository));
        _campaignRepository = campaignRepository ?? throw new ArgumentNullException(nameof(campaignRepository));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

        // Load campaign settings from configuration
        _marketingCampaignId = _configuration.GetValue<int>("TestData:MarketingCampaignId");
        _pipelineVersionId = _configuration.GetValue<short>("TestData:PipelineVersionId");

        if (_marketingCampaignId <= 0)
        {
            throw new InvalidOperationException("TestData:MarketingCampaignId must be configured and greater than 0");
        }

        if (_pipelineVersionId <= 0)
        {
            throw new InvalidOperationException("TestData:PipelineVersionId must be configured and greater than 0");
        }

        // Load campaign once from OpenSearch
        _campaign = _campaignRepository.GetCampaignByIdAsync(_marketingCampaignId).GetAwaiter().GetResult()
            ?? throw new InvalidOperationException($"Campaign with ID {_marketingCampaignId} not found in OpenSearch");
    }

    /// <summary>
    /// Generates a constant load at a steady message rate.
    /// </summary>
    public async Task GenerateConstantLoad(
        int messagesPerSecond,
        TimeSpan duration,
        CancellationToken cancellationToken = default)
    {
        var db = _redis.GetDatabase();
        var startTime = DateTime.UtcNow;
        var intervalMs = 1000.0 / messagesPerSecond;
        var totalMessages = (int)(messagesPerSecond * duration.TotalSeconds);

        var contacts = await GetContactsAsync(totalMessages);
        var messageCount = 0;

        while (DateTime.UtcNow - startTime < duration && !cancellationToken.IsCancellationRequested && messageCount < totalMessages)
        {
            var contact = contacts[messageCount];
            var enrollment = CreateTestEnrollment(contact, _campaign);
            var json = JsonSerializer.Serialize(enrollment);
            await db.StreamAddAsync(_streamName, SharedConstants.StreamFieldKey, json);

            messageCount++;
            var delay = TimeSpan.FromMilliseconds(intervalMs);
            await Task.Delay(delay, cancellationToken);
        }
    }

    /// <summary>
    /// Generates burst traffic with sudden spikes.
    /// </summary>
    public async Task GenerateBurstLoad(
        int normalRate,
        int burstRate,
        TimeSpan normalDuration,
        TimeSpan burstDuration,
        int numberOfBursts,
        CancellationToken cancellationToken = default)
    {
        for (int i = 0; i < numberOfBursts && !cancellationToken.IsCancellationRequested; i++)
        {
            // Normal load
            await GenerateConstantLoad(normalRate, normalDuration, cancellationToken);

            // Burst load
            await GenerateConstantLoad(burstRate, burstDuration, cancellationToken);
        }
    }

    /// <summary>
    /// Generates a ramp-up load pattern with gradually increasing rate.
    /// </summary>
    public async Task GenerateRampUpLoad(
        int startRate,
        int endRate,
        TimeSpan duration,
        CancellationToken cancellationToken = default)
    {
        var db = _redis.GetDatabase();
        var startTime = DateTime.UtcNow;
        var totalMessages = (int)((startRate + endRate) / 2.0 * duration.TotalSeconds); // Approximate
        var contacts = await GetContactsAsync(totalMessages);
        var messageCount = 0;
        var rateIncrement = (endRate - startRate) / duration.TotalSeconds;

        while (DateTime.UtcNow - startTime < duration && !cancellationToken.IsCancellationRequested && messageCount < totalMessages)
        {
            var elapsed = (DateTime.UtcNow - startTime).TotalSeconds;
            var currentRate = (int)(startRate + (rateIncrement * elapsed));
            var intervalMs = Math.Max(1, 1000.0 / currentRate);

            var contact = contacts[messageCount];
            var enrollment = CreateTestEnrollment(contact, _campaign);
            var json = JsonSerializer.Serialize(enrollment);
            await db.StreamAddAsync(_streamName, SharedConstants.StreamFieldKey, json);

            messageCount++;
            await Task.Delay(TimeSpan.FromMilliseconds(intervalMs), cancellationToken);
        }
    }

    /// <summary>
    /// Generates batch messages all at once.
    /// </summary>
    public async Task GenerateBatch(
        int messageCount,
        CancellationToken cancellationToken = default)
    {
        var db = _redis.GetDatabase();
        var tasks = new List<Task>();
        var contacts = await GetContactsAsync(messageCount);

        for (int i = 0; i < messageCount; i++)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                break;
            }

            var contact = contacts[i];
            var enrollment = CreateTestEnrollment(contact, _campaign);
            var json = JsonSerializer.Serialize(enrollment);
            tasks.Add(db.StreamAddAsync(_streamName, SharedConstants.StreamFieldKey, json));

            // Batch in groups of 100 to avoid overwhelming Redis
            if (tasks.Count >= 100)
            {
                await Task.WhenAll(tasks);
                tasks.Clear();
            }
        }

        if (tasks.Any())
        {
            await Task.WhenAll(tasks);
        }
    }

    /// <summary>
    /// Generates a realistic traffic pattern simulating business hours.
    /// </summary>
    public async Task GenerateRealisticPattern(
        Dictionary<int, int> hourlyRates, // Hour -> Messages per second
        TimeSpan duration,
        CancellationToken cancellationToken = default)
    {
        var db = _redis.GetDatabase();
        var startTime = DateTime.UtcNow;

        // Estimate total messages needed
        var avgRate = hourlyRates.Values.Any() ? (int)hourlyRates.Values.Average() : 10;
        var totalMessages = (int)(avgRate * duration.TotalSeconds);
        var contacts = await GetContactsAsync(totalMessages);
        var messageCount = 0;

        while (DateTime.UtcNow - startTime < duration && !cancellationToken.IsCancellationRequested && messageCount < totalMessages)
        {
            var currentHour = DateTime.UtcNow.Hour;
            var currentRate = hourlyRates.TryGetValue(currentHour, out var rate) ? rate : 10; // Default 10 msg/s
            var intervalMs = 1000.0 / currentRate;

            var contact = contacts[messageCount];
            var enrollment = CreateTestEnrollment(contact, _campaign);
            var json = JsonSerializer.Serialize(enrollment);
            await db.StreamAddAsync(_streamName, SharedConstants.StreamFieldKey, json);

            messageCount++;
            await Task.Delay(TimeSpan.FromMilliseconds(intervalMs), cancellationToken);
        }
    }

    /// <summary>
    /// Fetches contacts from OpenSearch and caches them by count.
    /// </summary>
    private async Task<List<Contact>> GetContactsAsync(int count)
    {
        lock (_cacheLock)
        {
            if (_contactCache.TryGetValue(count, out var cachedContacts))
            {
                return cachedContacts;
            }
        }

        // Fetch exactly the number of contacts needed
        var contacts = await _contactRepository.GetAllContacts(count);

        if (contacts == null || !contacts.Any())
        {
            throw new InvalidOperationException($"Failed to fetch {count} contacts from OpenSearch");
        }

        if (contacts.Count() < count)
        {
            throw new InvalidOperationException($"Requested {count} contacts but only {contacts.Count()} were returned from OpenSearch");
        }

        var contactList = contacts.ToList();

        lock (_cacheLock)
        {
            _contactCache[count] = contactList;
        }

        return contactList;
    }

    private static StagedEnrollment CreateTestEnrollment(Contact contact, MarketingCampaign campaign)
    {
        // Generate email from contact name
        var email = $"{contact.FirstName?.ToLower()}.{contact.LastName?.ToLower()}@costar.com";

        return new StagedEnrollment(
            contact.Id,
            new JsonObject
            {
                ["Zip"] = "23219",
                ["Phone"] = null,
                ["State"] = "VA",
                ["Country"] = contact.CountryCode ?? "USA",
                ["CanEmail"] = "True",
                ["LastName"] = contact.LastName,
                ["ContactID"] = contact.Id,
                ["FirstName"] = contact.FirstName,
                ["JourneyID"] = "574780aa-63bc-4445-b8e8-5926e477024e",
                ["LocationID"] = contact.Location?.Id,
                ["EmailAddress"] = email,
                ["LocationName"] = contact.Location?.Name,
                ["UnsubscribeURL"] = "https://www-dvm.homes.com/market/unsub/?t=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImJ0ZWxtYUBjb3N0YXIuY29tIiwidHlwIjoidjEiLCJuYmYiOjE3NjI4Nzk1OTQsImV4cCI6MTc5NDQxNTU5NCwiaWF0IjoxNzYyODc5NTk0LCJpc3MiOiJodHRwczovL3d3dy1kdm0uaG9tZXMuY29tIn0.KdHmE8xd0sr289SeRhs07RHmuoqHgmBwoeF8YXlCvnI&p=8jn4b91",
                ["IsUserSuppressed"] = "False",
                ["CallTrackingNumber"] = null
            },
            campaign.Id,
            campaign.MarketingBrandId,
            1
        );
    }
}
