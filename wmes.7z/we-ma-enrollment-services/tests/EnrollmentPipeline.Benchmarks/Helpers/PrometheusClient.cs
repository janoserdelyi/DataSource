using System.Net.Http.Json;
using EnrollmentPipeline.Benchmarks.Models;

namespace EnrollmentPipeline.Benchmarks.Helpers;

/// <summary>
/// Client for querying Prometheus metrics during benchmarks.
/// </summary>
public class PrometheusClient
{
    private readonly HttpClient _httpClient;
    private readonly string _endpoint;

    public PrometheusClient(string endpoint)
    {
        _endpoint = endpoint;
        _httpClient = new HttpClient { BaseAddress = new Uri(endpoint) };
    }

    public async Task<double> QueryMetric(string query, CancellationToken cancellationToken = default)
    {
        try
        {
            var url = $"/api/v1/query?query={Uri.EscapeDataString(query)}";
            var response = await _httpClient.GetFromJsonAsync<PrometheusResponse>(url, cancellationToken);

            if (response?.Data?.Result != null && response.Data.Result.Count > 0)
            {
                var result = response.Data.Result[0];
                if (result.Value != null && result.Value.Count > 1)
                {
                    if (double.TryParse(result.Value[1].ToString(), out var value))
                    {
                        return value;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error querying Prometheus: {ex.Message}");
        }

        return 0;
    }

    public async Task<List<(DateTime Time, double Value)>> QueryRange(
        string query,
        DateTime start,
        DateTime end,
        string step = "15s",
        CancellationToken cancellationToken = default)
    {
        var results = new List<(DateTime, double)>();

        try
        {
            var startTimestamp = new DateTimeOffset(start).ToUnixTimeSeconds();
            var endTimestamp = new DateTimeOffset(end).ToUnixTimeSeconds();
            var url = $"/api/v1/query_range?query={Uri.EscapeDataString(query)}&start={startTimestamp}&end={endTimestamp}&step={step}";

            var response = await _httpClient.GetFromJsonAsync<PrometheusRangeResponse>(url, cancellationToken);

            if (response?.Data?.Result != null && response.Data.Result.Count > 0)
            {
                var result = response.Data.Result[0];
                if (result.Values != null)
                {
                    foreach (var value in result.Values)
                    {
                        if (value.Count >= 2)
                        {
                            var timestamp = Convert.ToInt64(value[0]);
                            var dateTime = DateTimeOffset.FromUnixTimeSeconds(timestamp).DateTime;
                            if (double.TryParse(value[1].ToString(), out var metricValue))
                            {
                                results.Add((dateTime, metricValue));
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error querying Prometheus range: {ex.Message}");
        }

        return results;
    }

    private class PrometheusResponse
    {
        public string? Status { get; set; }
        public PrometheusData? Data { get; set; }
    }

    private class PrometheusRangeResponse
    {
        public string? Status { get; set; }
        public PrometheusRangeData? Data { get; set; }
    }

    private class PrometheusData
    {
        public string? ResultType { get; set; }
        public List<PrometheusResult>? Result { get; set; }
    }

    private class PrometheusRangeData
    {
        public string? ResultType { get; set; }
        public List<PrometheusRangeResult>? Result { get; set; }
    }

    private class PrometheusResult
    {
        public Dictionary<string, string>? Metric { get; set; }
        public List<object>? Value { get; set; }
    }

    private class PrometheusRangeResult
    {
        public Dictionary<string, string>? Metric { get; set; }
        public List<List<object>>? Values { get; set; }
    }
}
