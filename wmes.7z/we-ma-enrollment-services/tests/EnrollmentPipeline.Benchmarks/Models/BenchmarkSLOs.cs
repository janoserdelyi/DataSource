namespace EnrollmentPipeline.Benchmarks.Models;

/// <summary>
/// Service Level Objectives for benchmark tests.
/// </summary>
public class BenchmarkSLOs
{
    // Throughput SLOs
    public double MinThroughputPerWorker { get; set; } = 50; // msg/sec
    public double MinThroughputScalingEfficiency { get; set; } = 0.7; // 70% linear scaling
    
    // Latency SLOs
    public double MaxLatencyP95Ms { get; set; } = 500; // milliseconds
    public double MaxLatencyP99Ms { get; set; } = 1000; // milliseconds
    
    // Reliability SLOs
    public double MaxErrorRate { get; set; } = 0.001; // 0.1%
    public double MinSuccessRate { get; set; } = 0.999; // 99.9%
    
    // Resource SLOs
    public double MaxCpuPerWorker { get; set; } = 0.8; // 80% of 1 core
    public long MaxMemoryPerWorker { get; set; } = 512 * 1024 * 1024; // 512 MB

    public bool ValidateThroughput(BenchmarkMetrics metrics)
    {
        var throughputPerWorker = metrics.MessagesPerSecond / metrics.WorkerCount;
        return throughputPerWorker >= MinThroughputPerWorker;
    }

    public bool ValidateLatency(BenchmarkMetrics metrics)
    {
        return metrics.P95LatencyMs <= MaxLatencyP95Ms && 
               metrics.P99LatencyMs <= MaxLatencyP99Ms;
    }

    public bool ValidateReliability(BenchmarkMetrics metrics)
    {
        var errorRate = 1.0 - metrics.SuccessRate;
        return errorRate <= MaxErrorRate && metrics.SuccessRate >= MinSuccessRate;
    }

    public bool ValidateResources(BenchmarkMetrics metrics)
    {
        var cpuPerWorker = metrics.MaxCpuUsage / metrics.WorkerCount;
        var memoryPerWorker = metrics.MaxMemoryBytes / metrics.WorkerCount;
        return cpuPerWorker <= MaxCpuPerWorker && memoryPerWorker <= MaxMemoryPerWorker;
    }
}
