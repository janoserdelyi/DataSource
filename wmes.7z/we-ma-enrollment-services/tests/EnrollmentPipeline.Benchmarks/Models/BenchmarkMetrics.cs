namespace EnrollmentPipeline.Benchmarks.Models;

/// <summary>
/// Comprehensive metrics collected during a benchmark run.
/// </summary>
public class BenchmarkMetrics
{
    public string BenchmarkName { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public TimeSpan Duration => EndTime - StartTime;

    // Throughput Metrics
    public double MessagesPerSecond { get; set; }
    public long TotalMessagesProcessed { get; set; }
    public long TotalMessagesFailed { get; set; }
    public double SuccessRate => TotalMessagesProcessed > 0 
        ? (double)TotalMessagesProcessed / (TotalMessagesProcessed + TotalMessagesFailed) 
        : 0;

    // Latency Metrics
    public double AverageLatencyMs { get; set; }
    public double MedianLatencyMs { get; set; }
    public double P95LatencyMs { get; set; }
    public double P99LatencyMs { get; set; }
    public double MinLatencyMs { get; set; }
    public double MaxLatencyMs { get; set; }

    // Batch Processing Metrics
    public double AverageBatchDurationMs { get; set; }
    public double P95BatchDurationMs { get; set; }

    // Queue Metrics
    public long AverageStreamLength { get; set; }
    public long MaxStreamLength { get; set; }
    public long AveragePendingMessages { get; set; }
    public long MaxPendingMessages { get; set; }
    public double AverageConsumerLag { get; set; }

    // Worker Metrics
    public int WorkerCount { get; set; }
    public double ScalingEfficiency { get; set; }

    // Resource Metrics
    public double AverageCpuUsage { get; set; }
    public double MaxCpuUsage { get; set; }
    public long AverageMemoryBytes { get; set; }
    public long MaxMemoryBytes { get; set; }

    // SLO Compliance
    public bool MeetsThroughputSLO { get; set; }
    public bool MeetsLatencySLO { get; set; }
    public bool MeetsReliabilitySLO { get; set; }
    public bool MeetsResourceSLO { get; set; }
    public bool MeetsAllSLOs => MeetsThroughputSLO && MeetsLatencySLO && MeetsReliabilitySLO && MeetsResourceSLO;

    public Dictionary<string, object> CustomMetrics { get; set; } = new();
}
