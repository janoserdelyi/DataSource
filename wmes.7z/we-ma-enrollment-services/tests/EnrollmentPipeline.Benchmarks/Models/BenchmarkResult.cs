namespace EnrollmentPipeline.Benchmarks.Models;

/// <summary>
/// Result of a benchmark test run with detailed performance data.
/// </summary>
public class BenchmarkResult
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string BenchmarkName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty; // Individual, Integration, EndToEnd
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    
    public BenchmarkConfiguration Configuration { get; set; } = new();
    public BenchmarkMetrics Metrics { get; set; } = new();
    
    public List<string> Errors { get; set; } = new();
    public Dictionary<string, string> Tags { get; set; } = new();
}

public class BenchmarkConfiguration
{
    public int MessageCount { get; set; }
    public int WorkerCount { get; set; }
    public int BatchSize { get; set; }
    public string LoadPattern { get; set; } = string.Empty;
    public Dictionary<string, object> AdditionalSettings { get; set; } = new();
}
