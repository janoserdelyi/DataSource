using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using EnrollmentPipeline.Aws;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using System.ComponentModel.DataAnnotations;
using Amazon.Runtime.Credentials;

namespace EnrollmentPipeline.Tests.Integration;

/// <summary>
/// Integration tests for AWS RDS authentication.
/// These tests require actual AWS credentials and are skipped by default.
/// Configuration is loaded from appsettings.json for realistic testing.
/// </summary>
public class AwsRdsAuthIntegrationTests : IDisposable
{
    private readonly IServiceProvider _serviceProvider;
    private readonly AwsRdsConfiguration _config;
    private readonly ILogger<AwsRdsAuthIntegrationTests> _logger;

    public AwsRdsAuthIntegrationTests()
    {
        // Setup DI container with configuration
        var services = new ServiceCollection();

        // Add logging
        services.AddLogging(builder =>
        {
            builder.AddConsole();
            builder.SetMinimumLevel(LogLevel.Information);
        });

        // Load configuration from appsettings.json
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: true)
            .AddJsonFile("appsettings.Development.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        // Get AWS RDS configuration
        var awsConfig = configuration.GetSection("AwsRds").Get<AwsRdsConfiguration>();
        if (awsConfig == null)
        {
            throw new InvalidOperationException("AwsRds configuration not found in appsettings.json");
        }

        // Validate configuration
        var validationContext = new ValidationContext(awsConfig);
        var validationResults = new List<ValidationResult>();
        if (!Validator.TryValidateObject(awsConfig, validationContext, validationResults, true))
        {
            var errors = string.Join(", ", validationResults.Select(vr => vr.ErrorMessage));
            throw new InvalidOperationException($"Invalid AwsRds configuration: {errors}");
        }

        services.AddSingleton(awsConfig);
        _config = awsConfig;

        // Setup AWS credentials
        services.AddSingleton<AWSCredentials>(provider =>
        {
            var config = provider.GetRequiredService<AwsRdsConfiguration>();

            if (!string.IsNullOrEmpty(config.ProfileName))
            {
                var chain = new CredentialProfileStoreChain();
                if (chain.TryGetAWSCredentials(config.ProfileName, out var profileCredentials))
                {
                    return profileCredentials;
                }
                throw new InvalidOperationException($"AWS profile '{config.ProfileName}' not found");
            }

            return DefaultAWSCredentialsIdentityResolver.GetCredentials();
        });

        // Register auth service
        services.AddScoped<IAwsRdsAuthService, AwsRdsAuthService>();

        _serviceProvider = services.BuildServiceProvider();
        _logger = _serviceProvider.GetRequiredService<ILogger<AwsRdsAuthIntegrationTests>>();
    }

    [Fact(Skip = "Integration test - requires valid AWS credentials")]
    public async Task GenerateAuthToken_WithValidCredentials_ShouldReturnValidToken()
    {
        // Arrange
        _logger.LogInformation("Testing AWS RDS token generation with configuration from appsettings.json");
        _logger.LogInformation("Hostname: {Hostname}, Database: {Database}, Username: {Username}",
            _config.Hostname, _config.DatabaseName, _config.Username);

        var authService = _serviceProvider.GetRequiredService<IAwsRdsAuthService>();

        // Act
        var startTime = DateTime.UtcNow;
        var token = await authService.GenerateAuthTokenAsync();
        var duration = DateTime.UtcNow - startTime;

        // Assert
        Assert.False(string.IsNullOrEmpty(token));
        Assert.StartsWith("https://", token);
        Assert.True(token.Length > 100); // RDS tokens are quite long

        _logger.LogInformation("✅ Token generated successfully in {Duration}ms", duration.TotalMilliseconds);
        _logger.LogInformation("Token length: {Length} characters", token.Length);
    }

    [Fact(Skip = "Integration test - requires valid AWS credentials and network access to RDS")]
    public async Task ConnectToDatabase_WithGeneratedToken_ShouldSucceed()
    {
        // Arrange
        _logger.LogInformation("Testing actual database connection with AWS RDS IAM authentication");
        _logger.LogInformation("Connecting to: {Hostname}:{Port}/{Database} as {Username}",
            _config.Hostname, _config.Port, _config.DatabaseName, _config.Username);

        var authService = _serviceProvider.GetRequiredService<IAwsRdsAuthService>();

        // Generate RDS auth token
        var token = await authService.GenerateAuthTokenAsync();
        _logger.LogInformation("✅ Auth token generated, attempting database connection...");

        // Build connection string with the generated token as password
        var connectionString = new NpgsqlConnectionStringBuilder
        {
            Host = _config.Hostname,
            Port = _config.Port,
            Database = _config.DatabaseName,
            Username = _config.Username,
            Password = token, // Use the generated token as password
            SslMode = _config.EnableSsl ? SslMode.Require : SslMode.Disable,
            Timeout = _config.ConnectionTimeoutSeconds,
            CommandTimeout = _config.CommandTimeoutSeconds,
            ApplicationName = "EnrollmentPipeline.Tests"
        }.ToString();

        // Act & Assert
        using var connection = new NpgsqlConnection(connectionString);

        // Test connection opening
        var connectTask = connection.OpenAsync();
        await connectTask.WaitAsync(TimeSpan.FromSeconds(_config.ConnectionTimeoutSeconds));

        Assert.Equal(System.Data.ConnectionState.Open, connection.State);
        _logger.LogInformation("✅ Database connection opened successfully");

        // Test a simple query to verify authentication works
        using var command = new NpgsqlCommand("SELECT version(), current_user, current_database()", connection);
        using var reader = await command.ExecuteReaderAsync();

        Assert.NotNull(reader);
        var hasData = await reader.ReadAsync();
        Assert.True(hasData);

        var version = reader.GetString(0);
        var currentUser = reader.GetString(1);
        var currentDatabase = reader.GetString(2);

        Assert.False(string.IsNullOrEmpty(version));
        Assert.Equal(_config.Username, currentUser);
        Assert.Equal(_config.DatabaseName, currentDatabase);

        _logger.LogInformation("✅ Database query executed successfully");
        _logger.LogInformation("PostgreSQL Version: {Version}", version);
        _logger.LogInformation("Connected as user: {User}", currentUser);
        _logger.LogInformation("Connected to database: {Database}", currentDatabase);
    }

    [Fact(Skip = "Integration test - requires valid AWS credentials and network access to RDS")]
    public async Task ConnectionWithExpiredToken_ShouldFailGracefully()
    {
        // Arrange
        _logger.LogInformation("Testing connection behavior with expired/invalid token");

        // Use an obviously invalid token
        var invalidToken = "invalid-token-123";

        var connectionString = new NpgsqlConnectionStringBuilder
        {
            Host = _config.Hostname,
            Port = _config.Port,
            Database = _config.DatabaseName,
            Username = _config.Username,
            Password = invalidToken,
            SslMode = _config.EnableSsl ? SslMode.Require : SslMode.Disable,
            Timeout = 5, // Short timeout for this test
            ApplicationName = "EnrollmentPipeline.Tests"
        }.ToString();

        // Act & Assert
        using var connection = new NpgsqlConnection(connectionString);

        var connectAction = async () => await connection.OpenAsync();

        // Should throw authentication exception
        var ex = await Assert.ThrowsAsync<Exception>(connectAction);
        Assert.True(ex.Message.Contains("password") || ex.Message.Contains("authentication") || ex.Message.Contains("login"));

        _logger.LogInformation("✅ Invalid token correctly rejected by database");
    }

    [Fact]
    public void AwsCredentials_ProfileFallback_ShouldHandleProfileNotFound()
    {
        // Arrange
        var nonExistentProfile = "non-existent-profile-name";
        var chain = new CredentialProfileStoreChain();

        // Act & Assert
        var result = chain.TryGetAWSCredentials(nonExistentProfile, out var credentials);

        Assert.False(result);
        Assert.Null(credentials);

        _logger.LogInformation("✅ Profile not found scenario handled correctly");
    }

    [Fact]
    public void ConfigurationValidation_WithLoadedConfig_ShouldBeValid()
    {
        // Arrange & Act
        var validationContext = new ValidationContext(_config);
        var validationResults = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(_config, validationContext, validationResults, true);

        // Assert
        Assert.True(isValid);
        Assert.Empty(validationResults);

        _logger.LogInformation("✅ Loaded configuration is valid");
        _logger.LogInformation("Configuration: {Config}", System.Text.Json.JsonSerializer.Serialize(_config, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
    }

    [Fact]
    public void FallbackCredentials_DefaultChain_ShouldHandleMissingCredentials()
    {
        // Arrange & Act
        // The AWS SDK may throw when credentials are not available in CI/CD environments
        // This test verifies that the credential chain can be accessed without crashing
        try
        {
            var credentials = DefaultAWSCredentialsIdentityResolver.GetCredentials();
            
            // If we get here, credentials were found
            Assert.NotNull(credentials);
            _logger.LogInformation("✅ Default credential chain found valid credentials");
        }
        catch (AmazonClientException ex)
        {
            // This is expected behavior when running tests in environments without AWS credentials
            Assert.Contains("Failed to resolve AWS credentials", ex.Message);
            _logger.LogInformation("✅ Default credential chain properly throws AmazonClientException when credentials are not available");
        }
    }

    public void Dispose()
    {
        _serviceProvider?.GetService<IServiceScope>()?.Dispose();
        (_serviceProvider as IDisposable)?.Dispose();
    }
}
