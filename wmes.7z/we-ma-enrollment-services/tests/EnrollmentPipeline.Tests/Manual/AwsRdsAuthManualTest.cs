using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using EnrollmentPipeline.Aws;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using Amazon.Runtime.Credentials;

namespace EnrollmentPipeline.Tests.Manual;

/// <summary>
/// Simple console test to verify AWS RDS authentication works.
/// Run this to manually test your AWS credentials and RDS configuration.
/// </summary>
public static class AwsRdsAuthManualTest
{
    public static async Task RunAsync()
    {
        Console.WriteLine("🔐 AWS RDS Authentication Test");
        Console.WriteLine("================================");
        Console.WriteLine();

        try
        {
            // Setup DI container
            var services = new ServiceCollection();

            // Add logging
            services.AddLogging(builder =>
            {
                builder.AddConsole();
                builder.SetMinimumLevel(LogLevel.Information);
            });

            // Load configuration
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile("appsettings.Development.json", optional: true)
                .AddEnvironmentVariables()
                .Build();

            Console.WriteLine("📋 Loading configuration...");

            // Get AWS RDS configuration
            var awsConfig = configuration.GetSection("AwsRds").Get<AwsRdsConfiguration>();
            if (awsConfig == null)
            {
                Console.WriteLine("❌ No AwsRds configuration found in appsettings.json");
                Console.WriteLine("   Please ensure you have an AwsRds section in your configuration file.");
                return;
            }

            // Validate configuration
            var validationContext = new ValidationContext(awsConfig);
            var validationResults = new List<ValidationResult>();
            if (!Validator.TryValidateObject(awsConfig, validationContext, validationResults, true))
            {
                Console.WriteLine("❌ Configuration validation failed:");
                foreach (var error in validationResults)
                {
                    Console.WriteLine($"   • {error.ErrorMessage}");
                }
                return;
            }

            Console.WriteLine($"✅ Configuration loaded successfully");
            Console.WriteLine($"   • Hostname: {awsConfig.Hostname}");
            Console.WriteLine($"   • Port: {awsConfig.Port}");
            Console.WriteLine($"   • Database: {awsConfig.DatabaseName}");
            Console.WriteLine($"   • Username: {awsConfig.Username}");
            Console.WriteLine($"   • Region: {awsConfig.RegionSystemName}");
            Console.WriteLine($"   • Profile: {awsConfig.ProfileName ?? "(default credential chain)"}");
            Console.WriteLine();

            services.AddSingleton(awsConfig);

            // Setup AWS credentials
            Console.WriteLine("🔑 Setting up AWS credentials...");
            services.AddSingleton<AWSCredentials>(provider =>
            {
                var config = provider.GetRequiredService<AwsRdsConfiguration>();
                var logger = provider.GetRequiredService<ILogger<AwsRdsConfiguration>>();

                if (!string.IsNullOrEmpty(config.ProfileName))
                {
                    Console.WriteLine($"   Using AWS profile: {config.ProfileName}");
                    var chain = new CredentialProfileStoreChain();
                    if (chain.TryGetAWSCredentials(config.ProfileName, out var profileCredentials))
                    {
                        return profileCredentials;
                    }
                    throw new InvalidOperationException($"AWS profile '{config.ProfileName}' not found");
                }

                Console.WriteLine("   Using default AWS credential chain");
                return DefaultAWSCredentialsIdentityResolver.GetCredentials();
            });

            // Register auth service
            services.AddScoped<IAwsRdsAuthService, AwsRdsAuthService>();

            // Build service provider
            var serviceProvider = services.BuildServiceProvider();

            Console.WriteLine("✅ Services configured successfully");
            Console.WriteLine();

            // Test credential access
            Console.WriteLine("🧪 Testing AWS credential access...");
            try
            {
                var credentials = serviceProvider.GetRequiredService<AWSCredentials>();
                Console.WriteLine("✅ AWS credentials obtained successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to get AWS credentials: {ex.Message}");
                Console.WriteLine("   Please check your AWS configuration:");
                Console.WriteLine("   • AWS CLI configured (`aws configure`)");
                Console.WriteLine("   • Profile exists (if specified)");
                Console.WriteLine("   • Environment variables set");
                return;
            }

            // Test RDS token generation
            Console.WriteLine("🎫 Generating RDS authentication token...");
            var authService = serviceProvider.GetRequiredService<IAwsRdsAuthService>();

            var startTime = DateTime.UtcNow;
            var token = await authService.GenerateAuthTokenAsync();
            var duration = DateTime.UtcNow - startTime;

            Console.WriteLine($"✅ RDS token generated successfully!");
            Console.WriteLine($"   • Token length: {token.Length} characters");
            Console.WriteLine($"   • Generation time: {duration.TotalMilliseconds:F0}ms");
            // Console.WriteLine($"   • Token preview: {token.Substring(0, Math.Min(50, token.Length))}...");
            Console.WriteLine($"   • Token preview: {token}...");
            Console.WriteLine();

            Console.WriteLine("🎉 All tests passed! Your AWS RDS authentication is working correctly.");

        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Test failed with error:");
            Console.WriteLine($"   {ex.GetType().Name}: {ex.Message}");

            if (ex.InnerException != null)
            {
                Console.WriteLine($"   Inner: {ex.InnerException.Message}");
            }

            Console.WriteLine();
            Console.WriteLine("💡 Common solutions:");
            Console.WriteLine("   • Run `aws configure` to set up credentials");
            Console.WriteLine("   • Check your AWS profile name in appsettings.json");
            Console.WriteLine("   • Ensure your AWS user has RDS permissions");
            Console.WriteLine("   • Verify the RDS hostname and region are correct");
        }

        Console.WriteLine();
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}
