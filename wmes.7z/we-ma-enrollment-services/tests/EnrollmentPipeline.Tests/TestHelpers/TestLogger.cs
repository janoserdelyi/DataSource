namespace EnrollmentPipeline.Tests.TestHelpers;

/// <summary>
/// Simple test logger implementation
/// </summary>
public class TestLogger<T> : ILogger<T>
{
    private readonly List<(LogLevel Level, string Message, Exception? Exception)> _logs = new();

    public IReadOnlyList<(LogLevel Level, string Message, Exception? Exception)> Logs => _logs.AsReadOnly();

    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        _logs.Add((logLevel, formatter(state, exception), exception));
    }

    public void Clear() => _logs.Clear();

    public bool HasLogLevel(LogLevel level) => _logs.Any(l => l.Level == level);
    
    public bool HasLogContaining(string message) => _logs.Any(l => l.Message.Contains(message, StringComparison.OrdinalIgnoreCase));
}

