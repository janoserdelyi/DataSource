using System.Diagnostics.Metrics;

namespace EnrollmentPipeline.Tests.TestHelpers;

/// <summary>
/// Helper class for asserting metrics in tests
/// </summary>
public class MetricsCollector : IDisposable
{
    private readonly MeterListener _meterListener;
    private readonly Dictionary<string, List<MetricMeasurement>> _measurements = new();
    private readonly object _lock = new();

    public MetricsCollector()
    {
        _meterListener = new MeterListener();
        _meterListener.InstrumentPublished = (instrument, listener) =>
        {
            if (instrument.Meter.Name == "EnrollmentPipeline.StreamPipelineWorker")
            {
                listener.EnableMeasurementEvents(instrument, null);
            }
        };

        _meterListener.SetMeasurementEventCallback<long>(OnMeasurementRecorded);
        _meterListener.SetMeasurementEventCallback<double>(OnMeasurementRecorded);
        _meterListener.SetMeasurementEventCallback<int>(OnMeasurementRecorded);

        _meterListener.Start();
    }

    private void OnMeasurementRecorded<T>(Instrument instrument, T measurement, ReadOnlySpan<KeyValuePair<string, object?>> tags, object? state) where T : struct
    {
        lock (_lock)
        {
            if (!_measurements.TryGetValue(instrument.Name, out var measurements))
            {
                measurements = new List<MetricMeasurement>();
                _measurements[instrument.Name] = measurements;
            }

            measurements.Add(new MetricMeasurement
            {
                InstrumentName = instrument.Name,
                Value = Convert.ToDouble(measurement),
                Tags = tags.ToArray().ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.ToString() ?? ""),
                Timestamp = DateTimeOffset.UtcNow
            });
        }
    }

    public IReadOnlyList<MetricMeasurement> GetMeasurements(string instrumentName)
    {
        lock (_lock)
        {
            return _measurements.TryGetValue(instrumentName, out var measurements)
                ? measurements.AsReadOnly()
                : new List<MetricMeasurement>().AsReadOnly();
        }
    }

    public void Clear()
    {
        lock (_lock)
        {
            _measurements.Clear();
        }
    }

    public void Dispose()
    {
        _meterListener.Dispose();
    }

    public class MetricMeasurement
    {
        public string InstrumentName { get; set; } = string.Empty;
        public double Value { get; set; }
        public Dictionary<string, string> Tags { get; set; } = new();
        public DateTimeOffset Timestamp { get; set; }
    }
}

/// <summary>
/// Fluent assertions for metrics
/// </summary>
public static class MetricsAssertions
{
    public static void ShouldHaveCounter(this MetricsCollector collector, string counterName, long expectedValue)
    {
        var measurements = collector.GetMeasurements(counterName);
        Assert.NotEmpty(measurements);
        Assert.Equal(expectedValue, measurements.Sum(m => m.Value));
    }

    public static void ShouldHaveGauge(this MetricsCollector collector, string gaugeName, double expectedValue, string? tagFilter = null)
    {
        var measurements = collector.GetMeasurements(gaugeName);
        Assert.NotEmpty(measurements);

        var relevantMeasurements = string.IsNullOrEmpty(tagFilter)
            ? measurements
            : measurements.Where(m => m.Tags.Values.Any(v => v.Contains(tagFilter))).ToList();

        Assert.NotEmpty(relevantMeasurements);
        Assert.Equal(expectedValue, relevantMeasurements.Last().Value);
    }

    public static void ShouldHaveHistogram(this MetricsCollector collector, string histogramName, int minMeasurements = 1)
    {
        var measurements = collector.GetMeasurements(histogramName);
        Assert.True(measurements.Count >= minMeasurements);

        foreach (var measurement in measurements)
        {
            Assert.True(measurement.Value >= 0);
        }
    }
}

