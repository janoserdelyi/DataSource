using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Services;
using System.Collections.Concurrent;
using EnrollmentPipeline.Enums;

namespace EnrollmentPipeline.Tests.TestHelpers;

/// <summary>
/// Test fixture that provides fully mocked Redis infrastructure for unit testing.
/// All Redis operations are mocked to avoid external dependencies.
/// </summary>
public class RedisTestFixture : IAsyncLifetime
{
	private Mock<IConnectionMultiplexer>? _mockRedis;
	private Mock<IDatabase>? _mockDatabase;
	private Mock<IStreamMessagePublisher>? _mockPublisher;

	// Reusable worker ID for consistent test configuration
	private readonly Guid _testWorkerId = Guid.NewGuid();

	// In-memory storage for streams to simulate Redis behavior
	// Using ConcurrentDictionary<streamName, ConcurrentDictionary<messageId, StreamEntry>> for thread-safe operations
	private readonly ConcurrentDictionary<string, ConcurrentDictionary<string, StreamEntry>> _streams = new();
	private readonly ConcurrentDictionary<string, HashSet<string>> _consumerGroups = new();
	private readonly ConcurrentDictionary<string, HashSet<string>> _deliveredMessages = new();
	private long _messageIdCounter;

	/// <summary>
	/// Gets the mocked Redis connection multiplexer
	/// </summary>
	public IConnectionMultiplexer Redis => _mockRedis?.Object ?? throw new InvalidOperationException("Redis not initialized. Call InitializeAsync first.");

	/// <summary>
	/// Gets the mocked stream message publisher
	/// </summary>
	public IStreamMessagePublisher Publisher => _mockPublisher?.Object ?? throw new InvalidOperationException("Publisher not initialized. Call InitializeAsync first.");

	/// <summary>
	/// Initializes the mocked Redis infrastructure
	/// </summary>
	public Task InitializeAsync()
	{
		// Create mock Redis connection
		_mockRedis = new Mock<IConnectionMultiplexer>();
		_mockDatabase = new Mock<IDatabase>();

		// Setup GetDatabase to return our mock database (both overloads)
		_mockRedis.Setup(r => r.GetDatabase(It.IsAny<int>(), It.IsAny<object>()))
			.Returns(_mockDatabase.Object);
		_mockRedis.Setup(r => r.GetDatabase())
			.Returns(_mockDatabase.Object);

		// Setup StreamCreateConsumerGroupAsync to track consumer groups
		_mockDatabase.Setup(db => db.StreamCreateConsumerGroupAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<bool>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, bool, CommandFlags>((streamName, groupName, position, createStream, flags) =>
			{
				var stream = streamName.ToString();
				var group = groupName.ToString();

				if (!_consumerGroups.ContainsKey(stream))
				{
					_consumerGroups[stream] = new HashSet<string>();
				}

				if (_consumerGroups[stream].Contains(group))
				{
					throw new RedisServerException("BUSYGROUP Consumer Group name already exists");
				}

				_consumerGroups[stream].Add(group);
				return Task.FromResult(true);
			});

		// Setup StreamAddAsync to simulate adding messages to streams
		_mockDatabase.Setup(db => db.StreamAddAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue?>(),
				It.IsAny<int?>(),
				It.IsAny<bool>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, RedisValue?, int?, bool, CommandFlags>((streamName, field, value, messageId, maxLength, useApproximateMaxLength, flags) =>
			{
				var stream = streamName.ToString();
				var id = Interlocked.Increment(ref _messageIdCounter);
				var generatedMessageId = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{id}";

				// Store message with the provided field name (should be "enrollment" from SharedConstants.StreamFieldKey)
				var streamMessages = _streams.GetOrAdd(stream, _ => new ConcurrentDictionary<string, StreamEntry>());
				var entry = new StreamEntry(generatedMessageId, new[] { new NameValueEntry(field, value) });
				streamMessages[generatedMessageId] = entry;

				return Task.FromResult((RedisValue)generatedMessageId);
			});

		// Setup StreamDeleteAsync to simulate deleting messages from streams
		_mockDatabase.Setup(db => db.StreamDeleteAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue[]>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue[], CommandFlags>((streamName, messageIds, flags) =>
			{
				var stream = streamName.ToString();

				if (_streams.TryGetValue(stream, out var messages))
				{
					foreach (var messageId in messageIds)
					{
						messages.TryRemove(messageId.ToString(), out _);
					}
				}

				return Task.FromResult((long)messageIds.Length);
			});


		//
		// var newMessages = await database.StreamReadGroupAsync(
		// 		DefaultStreamName,
		// 		DefaultConsumerGroupName,
		// 		InstanceName,
		// 		">", // Read only new messages not delivered to any consumer
		//         MaxBatchSize);

		// Task<StreamEntry[]> StreamReadGroupAsync(RedisKey key, RedisValue groupName, RedisValue consumerName, RedisValue? position = null, int? count = null, bool noAck = false, CommandFlags flags = CommandFlags.None);

		// Setup StreamReadGroupAsync to simulate reading messages from streams
		// Handle both nullable and non-nullable overloads
		_mockDatabase.Setup(db => db.StreamReadGroupAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue?>(),
				It.IsAny<int?>(),
				It.IsAny<bool>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, RedisValue?, int?, bool, CommandFlags>((streamName, groupName, consumerName, position, count, noAck, flags) =>
			{
				return HandleStreamReadGroupAsync(streamName, groupName, consumerName, position?.ToString(), count, noAck);
			});

		// Also setup the non-nullable int overload
		_mockDatabase.Setup(db => db.StreamReadGroupAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<int>(),
				It.IsAny<bool>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, RedisValue, int, bool, CommandFlags>((streamName, groupName, consumerName, position, count, noAck, flags) =>
			{
				return HandleStreamReadGroupAsync(streamName, groupName, consumerName, position.ToString(), count, noAck);
			});

		// Also setup the 8-parameter overload with timeout
		_mockDatabase.Setup(db => db.StreamReadGroupAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<int>(),
				It.IsAny<bool>(),
				It.IsAny<TimeSpan?>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, RedisValue, int, bool, TimeSpan?, CommandFlags>((streamName, groupName, consumerName, position, count, noAck, timeout, flags) =>
			{
				return HandleStreamReadGroupAsync(streamName, groupName, consumerName, position.ToString(), count, noAck);
			});

		// Setup StreamLengthAsync to return stream length
		_mockDatabase.Setup(db => db.StreamLengthAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, CommandFlags>((streamName, flags) =>
			{
				var stream = streamName.ToString();
				var length = _streams.TryGetValue(stream, out var messages) ? messages.Count : 0;
				return Task.FromResult((long)length);
			});

		// Setup StreamAcknowledgeAsync
		_mockDatabase.Setup(db => db.StreamAcknowledgeAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, CommandFlags>((streamName, groupName, messageId, flags) =>
			{
				var stream = streamName.ToString();
				var msgId = messageId.ToString();

				// In real Redis, acknowledging removes from PEL but message stays in stream
				// For our mock, we just verify the message exists in the stream
				if (_streams.TryGetValue(stream, out var messages) && messages.ContainsKey(msgId))
				{
					return Task.FromResult(1L);
				}

				return Task.FromResult(0L);
			});

		// Setup StreamAcknowledgeAsync (array overload)
		_mockDatabase.Setup(db => db.StreamAcknowledgeAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue[]>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue[], CommandFlags>((streamName, groupName, messageIds, flags) =>
			{
				var stream = streamName.ToString();
				long acknowledgedCount = 0;

				// In real Redis, acknowledging removes from PEL but message stays in stream
				// For our mock, we just verify messages exist in the stream
				if (_streams.TryGetValue(stream, out var messages))
				{
					foreach (var messageId in messageIds)
					{
						var msgId = messageId.ToString();
						if (messages.ContainsKey(msgId))
						{
							acknowledgedCount++;
						}
					}
				}

				return Task.FromResult(acknowledgedCount);
			});

		// Setup StreamDeleteAsync
		_mockDatabase.Setup(db => db.StreamDeleteAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue[]>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue[], CommandFlags>((streamName, messageIds, flags) =>
			{
				return Task.FromResult((long)messageIds.Length);
			});

		// Setup StreamPendingAsync
		_mockDatabase.Setup(db => db.StreamPendingAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, CommandFlags>((streamName, groupName, flags) =>
			{
				// Return default pending info (no pending messages)
				return Task.FromResult(default(StreamPendingInfo));
			});

		// Setup StreamAutoClaimAsync
		_mockDatabase.Setup(db => db.StreamAutoClaimAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<RedisValue>(),
				It.IsAny<long>(),
				It.IsAny<RedisValue>(),
				It.IsAny<int?>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, RedisValue, long, RedisValue, int?, CommandFlags>((streamName, groupName, consumerName, minIdleTimeMs, start, count, flags) =>
			{
				// Return empty auto-claim result (no messages to claim)
				return Task.FromResult(default(StreamAutoClaimResult));
			});

		// Setup StreamInfoAsync
		_mockDatabase.Setup(db => db.StreamInfoAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, CommandFlags>((streamName, flags) =>
			{
				// Return default stream info
				return Task.FromResult(default(StreamInfo));
			});

		// Setup StreamGroupInfoAsync
		_mockDatabase.Setup(db => db.StreamGroupInfoAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, CommandFlags>((streamName, flags) =>
			{
				// Return empty group info array
				return Task.FromResult(Array.Empty<StreamGroupInfo>());
			});

		// Setup LockTakeAsync for leader election
		_mockDatabase.Setup(db => db.LockTakeAsync(
				It.IsAny<RedisKey>(),
				It.IsAny<RedisValue>(),
				It.IsAny<TimeSpan>(),
				It.IsAny<CommandFlags>()))
			.Returns<RedisKey, RedisValue, TimeSpan, CommandFlags>((key, value, expiry, flags) =>
			{
				// Always succeed in taking the lock (make this instance the leader)
				return Task.FromResult(true);
			});

		// Create mock publisher
		_mockPublisher = new Mock<IStreamMessagePublisher>();

		// Setup PublishEnrollmentAsync to directly add messages to our in-memory stream storage
		_mockPublisher.Setup(p => p.PublishEnrollmentAsync(
				It.IsAny<string>(),
				It.IsAny<StagedEnrollment>()))
			.Returns<string, StagedEnrollment>((streamName, enrollment) =>
			{
				var json = System.Text.Json.JsonSerializer.Serialize(enrollment);

				// Generate message ID (same logic as StreamAddAsync mock)
				var id = Interlocked.Increment(ref _messageIdCounter);
				var generatedMessageId = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{id}";

				// Add directly to in-memory storage using correct field key (SharedConstants.StreamFieldKey)
				var streamMessages = _streams.GetOrAdd(streamName, _ => new ConcurrentDictionary<string, StreamEntry>());
				var entry = new StreamEntry(generatedMessageId, new[] { new NameValueEntry(SharedConstants.StreamFieldKey, json) });
				streamMessages[generatedMessageId] = entry;

				return Task.FromResult((RedisValue)generatedMessageId);
			});

		return Task.CompletedTask;
	}

	/// <summary>
	/// Shared handler for StreamReadGroupAsync mocks (handles both nullable and non-nullable overloads)
	/// </summary>
	private Task<StreamEntry[]> HandleStreamReadGroupAsync(
		RedisKey streamName,
		RedisValue groupName,
		RedisValue consumerName,
		string? position,
		int? count,
		bool noAck)
	{
		var positionStr = position ?? ">";
		var stream = streamName.ToString();

		if (_streams.TryGetValue(stream, out var messages) && messages.Count > 0)
		{
			StreamEntry[] messagesToReturn;

			// Position ">" means read only NEW messages not delivered to any consumer
			// Position "0" means read messages in PEL for this specific consumer (backlog)
			if (positionStr == ">")
			{
				// Get the set of delivered messages for this stream
				var delivered = _deliveredMessages.GetOrAdd(stream, _ => new HashSet<string>());

				// Only return messages that haven't been delivered yet
				var undeliveredMessages = messages.Values
					.Where(msg => !delivered.Contains(msg.Id.ToString()))
					.ToArray();

				messagesToReturn = count.HasValue
					? undeliveredMessages.Take(count.Value).ToArray()
					: undeliveredMessages;

				// Mark these messages as delivered (add to PEL simulation)
				foreach (var msg in messagesToReturn)
				{
					delivered.Add(msg.Id.ToString());
				}
			}
			else
			{
				// For position "0" or other positions, return empty (we're not tracking per-consumer PEL)
				messagesToReturn = Array.Empty<StreamEntry>();
			}

			return Task.FromResult(messagesToReturn);
		}

		return Task.FromResult(Array.Empty<StreamEntry>());
	}

	/// <summary>
	/// Disposes the mocked Redis infrastructure
	/// </summary>
	public Task DisposeAsync()
	{
		_streams.Clear();
		_consumerGroups.Clear();
		_deliveredMessages.Clear();
		return Task.CompletedTask;
	}

	/// <summary>
	/// Cleans up all in-memory streams and consumer groups for a fresh test state
	/// </summary>
	public Task CleanupAsync()
	{
		_streams.Clear();
		_consumerGroups.Clear();
		_deliveredMessages.Clear();
		_messageIdCounter = 0;
		return Task.CompletedTask;
	}

	/// <summary>
	/// Initializes stream infrastructure for a worker by creating consumer groups
	/// </summary>
	public async Task InitializeWorkerStreamAsync(string streamName, string consumerGroupName)
	{
		await _mockDatabase!.Object.StreamCreateConsumerGroupAsync(
			streamName,
			consumerGroupName,
			StreamPosition.Beginning,
			createStream: true);
	}

	/// <summary>
	/// Creates a mock service scope factory for testing
	/// </summary>
	public IServiceScopeFactory CreateMockServiceScopeFactory()
	{
		var mockEnrollmentService = new Mock<IEnrollmentService>();
		var mockPipelineService = new Mock<IPipelineService>();

		// Setup basic service methods to do nothing (no-op)
		mockEnrollmentService.Setup(s => s.RecordProcessingStartAsync(
			It.IsAny<StagedEnrollment>(),
			It.IsAny<Guid>(),
			It.IsAny<CancellationToken>()))
			.Returns(Task.CompletedTask);

		mockEnrollmentService.Setup(s => s.RecordWorkerResultAsync(
			It.IsAny<WorkerResult>(),
			It.IsAny<CancellationToken>()))
			.Returns(Task.CompletedTask);

		// Setup GetWorkerByIdAsync to return a valid worker metadata
		mockPipelineService.Setup(s => s.GetWorkerByIdAsync(
			It.IsAny<Guid>(),
			It.IsAny<CancellationToken>()))
			.ReturnsAsync((Guid workerId, CancellationToken ct) => new PipelineWorker
			{
				Id = workerId,
				Name = "test-worker",
				Description = "Test worker for unit tests",
				CreatedDate = DateTimeOffset.UtcNow,
				UpdatedDate = DateTimeOffset.UtcNow
			});

		var mockServiceProvider = new Mock<IServiceProvider>();
		mockServiceProvider.Setup(sp => sp.GetService(typeof(IEnrollmentService)))
			.Returns(mockEnrollmentService.Object);
		mockServiceProvider.Setup(sp => sp.GetService(typeof(IPipelineService)))
			.Returns(mockPipelineService.Object);

		var mockServiceScope = new Mock<IServiceScope>();
		mockServiceScope.Setup(s => s.ServiceProvider).Returns(mockServiceProvider.Object);

		var mockServiceScopeFactory = new Mock<IServiceScopeFactory>();
		mockServiceScopeFactory
			.Setup(f => f.CreateScope())
			.Returns(mockServiceScope.Object);

		return mockServiceScopeFactory.Object;
	}

	/// <summary>
	/// Creates a test configuration with worker settings.
	/// Uses the same WorkerId across all tests in this fixture for consistency.
	/// </summary>
	public IConfiguration CreateTestConfiguration()
	{
		var inMemorySettings = new Dictionary<string, string?>
		{
			["PipelineWorker:Id"] = _testWorkerId.ToString()
		};

		return new ConfigurationBuilder()
			.AddInMemoryCollection(inMemorySettings)
			.Build();
	}

	/// <summary>
	/// Creates a mock HybridCache for testing
	/// </summary>
	public HybridCache CreateMockHybridCache()
	{
		var mockHybridCache = new Mock<HybridCache>();
		return mockHybridCache.Object;
	}

	/// <summary>
	/// Helper method to publish an enrollment to the test worker's stream.
	/// Uses the configured WorkerId as the stream name.
	/// </summary>
	public Task<RedisValue> PublishToTestWorkerAsync(StagedEnrollment enrollment)
	{
		return Publisher.PublishEnrollmentAsync(_testWorkerId.ToString(), enrollment);
	}

	/// <summary>
	/// Gets the in-memory messages for a specific stream (for test verification)
	/// </summary>
	public IReadOnlyList<StreamEntry> GetStreamMessages(string streamName)
	{
		return _streams.TryGetValue(streamName, out var messages)
			? messages.Values.ToList().AsReadOnly()
			: new List<StreamEntry>().AsReadOnly();
	}

	/// <summary>
	/// Gets all consumer groups for a specific stream (for test verification)
	/// </summary>
	public IReadOnlySet<string> GetConsumerGroups(string streamName)
	{
		return _consumerGroups.TryGetValue(streamName, out var groups)
			? new HashSet<string>(groups)
			: new HashSet<string>();
	}

	/// <summary>
	/// Gets all stream names that have been created (for test debugging)
	/// </summary>
	public IReadOnlyList<string> GetAllStreamNames()
	{
		return _streams.Keys.ToList().AsReadOnly();
	}
}

