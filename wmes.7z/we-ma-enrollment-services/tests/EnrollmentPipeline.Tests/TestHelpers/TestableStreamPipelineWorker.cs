using EnrollmentPipeline.Tests.Helpers;
using System.Runtime.CompilerServices;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Caching.Hybrid;
namespace EnrollmentPipeline.Tests.TestHelpers;

/// <summary>
/// Testable version of StreamPipelineWorker that exposes internal state and behavior
/// </summary>
public class TestableStreamPipelineWorker : StreamPipelineWorker
{
	private readonly List<StagedEnrollment> _processedEnrollments = new();
	private readonly TaskCompletionSource<bool> _processingComplete = new();
	private readonly SemaphoreSlim _processingLock = new(1, 1);

	public TestableStreamPipelineWorker(
		IConnectionMultiplexer redis,
		IStreamMessagePublisher publisher,
		ILogger<StreamPipelineWorker> logger,
		IServiceScopeFactory serviceScopeFactory,
		IConfiguration configuration,
		HybridCache hybridCache)
		: base(redis, publisher, logger, serviceScopeFactory, configuration, hybridCache)
	{
	}

	public override string WorkerName => "testable-stream-pipeline-worker";
	protected override int MaxBatchSize => 5;
	protected override TimeSpan ReadDelay => TimeSpan.FromMilliseconds(50);
	protected override TimeSpan ProcessingTimeout => TimeSpan.FromSeconds(2);
	protected override TimeSpan MetricsReportInterval => TimeSpan.FromMilliseconds(100);
	protected override TimeSpan RetryDelay => TimeSpan.FromMilliseconds(100);

	// Expose processed enrollments for verification
	public IReadOnlyList<StagedEnrollment> ProcessedEnrollments
	{
		get
		{
			_processingLock.Wait();
			try
			{
				return _processedEnrollments.AsReadOnly();
			}
			finally
			{
				_processingLock.Release();
			}
		}
	}

	// Wait for processing to complete
	public Task<bool> WaitForProcessingComplete(TimeSpan timeout)
	{
		return _processingComplete.Task.WaitAsync(timeout);
	}

	// Main processing implementation
	public override async IAsyncEnumerable<WorkerResult> ProcessBatch(
		IReadOnlyCollection<StagedEnrollment> messages,
		[EnumeratorCancellation] CancellationToken cancellationToken)
	{
		await _processingLock.WaitAsync(cancellationToken);
		try
		{
			foreach (var contact in messages)
			{
				cancellationToken.ThrowIfCancellationRequested();

				_processedEnrollments.Add(contact);

				// Small delay to simulate processing
				await Task.Delay(250, cancellationToken);

				var result = TestObjectFactory.CreateWorkerResult(contact, WorkerId);
				result.Status = PipelineStatus.Success;
				result.StartedAt = DateTimeOffset.UtcNow.AddMilliseconds(-250);
				result.EndedAt = DateTimeOffset.UtcNow;

				yield return result;
			}

			// Signal completion when we reach expected count
			if (_processedEnrollments.Count >= ExpectedMessageCount)
			{
				_processingComplete.TrySetResult(true);
			}
		}
		finally
		{
			_processingLock.Release();
		}
	}

	// Test configuration properties
	public int ExpectedMessageCount { get; set; } = 1;

	public void ResetProcessedContacts()
	{
		_processingLock.Wait();
		try
		{
			_processedEnrollments.Clear();
			_processingComplete.TrySetResult(false);
		}
		finally
		{
			_processingLock.Release();
		}
	}

	// Helper to access leader state
	public bool IsLeader
	{
		get
		{
			var fieldInfo = typeof(StreamPipelineWorker)
				.GetField("_isLeader", BindingFlags.NonPublic | BindingFlags.Instance);
			return fieldInfo?.GetValue(this) is bool isLeader && isLeader;
		}
	}

	// Helper to test scaling calculations
	public int TestCalculateOptimalWorkerCount(long totalLoad)
	{
		var method = typeof(StreamPipelineWorker)
			.GetMethod("CalculateOptimalWorkerCount", BindingFlags.NonPublic | BindingFlags.Instance);
		return method?.Invoke(this, new object[] { totalLoad }) is int result ? result : 1;
	}

	// Helper to test message parsing
	public bool TestTryParseStreamMessage(StreamEntry message, out StagedEnrollment? contact)
	{
		var method = typeof(StreamPipelineWorker)
			.GetMethod("TryParseStreamMessage", BindingFlags.NonPublic | BindingFlags.Instance);

		var parameters = new object?[] { message, null };
		var result = method!.Invoke(this, parameters);
		contact = (StagedEnrollment?)parameters[1];
		return result is bool boolResult ? boolResult : false;
	}

	public override void Dispose()
	{
		_processingLock?.Dispose();
		base.Dispose();
	}
}

