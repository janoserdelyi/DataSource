using System.Runtime.CompilerServices;
using EnrollmentPipeline.Tests.Helpers;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.AspNetCore.Builder;
using Moq;
using EnrollmentPipeline.Extensions;
namespace EnrollmentPipeline.Tests.Unit;

public class ServiceCollectionExtensionsTests
{
	[Fact]
	public void AddStreamPipelineWorker_WithSingleWorker_ShouldSucceed()
	{
		// Arrange
		var builder = WebApplication.CreateBuilder();
		builder.Services.AddSingleton<IConnectionMultiplexer>(sp => Mock.Of<IConnectionMultiplexer>());
		builder.Services.AddSingleton<IStreamMessagePublisher>(sp => Mock.Of<IStreamMessagePublisher>());
		builder.Services.AddSingleton(sp => Mock.Of<HybridCache>());

		// Act & Assert - Should not throw
		builder.AddStreamPipelineWorker<TestWorker1>();

		var app = builder.Build();
		var hostedServices = app.Services.GetServices<IHostedService>();

		Assert.NotEmpty(hostedServices);
		Assert.Contains(hostedServices, s => s.GetType() == typeof(TestWorker1));
	}

	[Fact]
	public void AddStreamPipelineWorker_WithMultipleWorkers_ShouldThrow()
	{
		// Arrange
		var builder = WebApplication.CreateBuilder();
		builder.Services.AddSingleton<IConnectionMultiplexer>(sp => Mock.Of<IConnectionMultiplexer>());
		builder.Services.AddSingleton<IStreamMessagePublisher>(sp => Mock.Of<IStreamMessagePublisher>());
		builder.Services.AddSingleton(sp => Mock.Of<HybridCache>());

		// Act
		builder.AddStreamPipelineWorker<TestWorker1>();

		// Assert
		var exception = Assert.Throws<InvalidOperationException>(() =>
			builder.AddStreamPipelineWorker<TestWorker2>());

		Assert.Contains("A StreamPipelineWorker (TestWorker1) is already registered", exception.Message);
		Assert.Contains("Only one StreamPipelineWorker per project is supported", exception.Message);
		Assert.Contains("Cannot register TestWorker2", exception.Message);
	}

	// Test worker classes
	private class TestWorker1(
		IConnectionMultiplexer redis,
		IStreamMessagePublisher publisher,
		ILogger<StreamPipelineWorker> logger,
		IServiceScopeFactory serviceScopeFactory,
		IConfiguration configuration,
		HybridCache hybridCache
	) : StreamPipelineWorker(redis, publisher, logger, serviceScopeFactory, configuration, hybridCache)
	{
		public override string WorkerName => "test-worker-1";
		protected override int MaxBatchSize => 1;
		protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(1);
		protected override TimeSpan ProcessingTimeout => TimeSpan.FromSeconds(1);
		public override async IAsyncEnumerable<WorkerResult> ProcessBatch(IReadOnlyCollection<StagedEnrollment> messages, [EnumeratorCancellation] CancellationToken cancellationToken)
		{
			await Task.Delay(1, cancellationToken);
			foreach (var message in messages)
			{
				var result = TestObjectFactory.CreateWorkerResult(message, Guid.NewGuid());
				result.Status = PipelineStatus.Success;
				result.StartedAt = DateTimeOffset.UtcNow;
				result.EndedAt = DateTimeOffset.UtcNow;
				yield return result;
			}
		}
	}

	private class TestWorker2(
		IConnectionMultiplexer redis,
		IStreamMessagePublisher publisher,
		ILogger<StreamPipelineWorker> logger,
		IServiceScopeFactory serviceScopeFactory,
		IConfiguration configuration,
		HybridCache hybridCache
	) : StreamPipelineWorker(redis, publisher, logger, serviceScopeFactory, configuration, hybridCache)
	{
		public override string WorkerName => "test-worker-2";
		protected override int MaxBatchSize => 1;
		protected override TimeSpan ReadDelay => TimeSpan.FromSeconds(1);
		protected override TimeSpan ProcessingTimeout => TimeSpan.FromSeconds(1);
		public override async IAsyncEnumerable<WorkerResult> ProcessBatch(IReadOnlyCollection<StagedEnrollment> messages, [EnumeratorCancellation] CancellationToken cancellationToken)
		{
			await Task.Delay(1, cancellationToken);
			foreach (var message in messages)
			{
				var result = TestObjectFactory.CreateWorkerResult(message, Guid.NewGuid());
				result.Status = PipelineStatus.Success;
				result.StartedAt = DateTimeOffset.UtcNow;
				result.EndedAt = DateTimeOffset.UtcNow;
				yield return result;
			}
		}
	}
}

