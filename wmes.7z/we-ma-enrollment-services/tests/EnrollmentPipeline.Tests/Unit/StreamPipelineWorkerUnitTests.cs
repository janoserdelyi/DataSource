using EnrollmentPipeline.Tests.Helpers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Hybrid;
using Moq;
using EnrollmentPipeline.Tests.TestHelpers;
using System.Text.Json;
using EnrollmentPipeline.Enums;
namespace EnrollmentPipeline.Tests.Unit;

public class StreamPipelineWorkerUnitTests
{
	private readonly Mock<IConnectionMultiplexer> _mockRedis;
	private readonly Mock<IStreamMessagePublisher> _mockPublisher;
	private readonly Mock<IDatabase> _mockDatabase;
	private readonly Mock<IServiceScopeFactory> _mockServiceScopeFactory;
	private readonly IConfiguration _configuration;
	private readonly Mock<HybridCache> _mockHybridCache;
	private readonly TestLogger<StreamPipelineWorker> _logger;
	private readonly TestableStreamPipelineWorker _worker;

	public StreamPipelineWorkerUnitTests()
	{
		_mockRedis = new Mock<IConnectionMultiplexer>();
		_mockDatabase = new Mock<IDatabase>();
		_mockPublisher = new Mock<IStreamMessagePublisher>();
		_mockServiceScopeFactory = new Mock<IServiceScopeFactory>();
		_mockHybridCache = new Mock<HybridCache>();
		_logger = new TestLogger<StreamPipelineWorker>();

		// Create real configuration with test values
		var inMemorySettings = new Dictionary<string, string?>
		{
			["PipelineWorker:Id"] = Guid.NewGuid().ToString()
		};
		_configuration = new ConfigurationBuilder()
			.AddInMemoryCollection(inMemorySettings)
			.Build();

		_mockRedis.Setup(r => r.GetDatabase(It.IsAny<int>(), It.IsAny<object>()))
			   .Returns(_mockDatabase.Object);

		_worker = new TestableStreamPipelineWorker(_mockRedis.Object, _mockPublisher.Object, _logger, _mockServiceScopeFactory.Object, _configuration, _mockHybridCache.Object);
	}

	[Fact]
	public void WorkerId_ShouldBeSet()
	{
		// Act
		var workerId = _worker.WorkerId;

		// Assert
		Assert.NotEqual(Guid.Empty, workerId);
	}

	[Fact]
	public void StreamName_ShouldDeriveFromWorkerId()
	{
		// Act
		var streamName = _worker.DefaultStreamName;

		// Assert
		Assert.Contains(_worker.WorkerId.ToString(), streamName);
	}

	[Fact]
	public void ConsumerGroupName_ShouldDeriveFromStreamName()
	{
		// Act
		var consumerGroupName = _worker.DefaultConsumerGroupName;

		// Assert
		Assert.Contains(_worker.DefaultStreamName, consumerGroupName);
	}

	[Fact]
	public void InstanceName_ShouldContainMachineNameAndGuid()
	{
		// Act
		var instanceName = _worker.InstanceName;

		// Assert
		Assert.Contains(Environment.MachineName, instanceName);
		Assert.Contains("-", instanceName);
		Assert.True(instanceName.Split('-').Length > 1);
	}

	[Theory]
	[InlineData(0, 1)]      // No load = 1 worker minimum
	[InlineData(5, 1)]      // Light load = 1 worker
	[InlineData(25, 5)]     // Medium load = 5 workers (25/5)
	[InlineData(100, 20)]   // High load = capped at 20 workers
	[InlineData(200, 20)]   // Very high load = still capped at 20 workers
	public void CalculateOptimalWorkerCount_ShouldReturnCorrectWorkerCount(long totalLoad, int expectedWorkers)
	{
		// Act
		var result = _worker.TestCalculateOptimalWorkerCount(totalLoad);

		// Assert
		Assert.Equal(expectedWorkers, result);
	}

	[Fact]
	public void TryParseStreamMessage_WithValidJson_ShouldReturnTrue()
	{
		// Arrange
		var enrollment = TestObjectFactory.CreateStagedEnrollment(123, 456);
		var json = JsonSerializer.Serialize(enrollment);

		var streamEntry = new StreamEntry(
			Guid.NewGuid().ToString(),
			new NameValueEntry[] { new(SharedConstants.StreamFieldKey, json) });

		// Act
		var result = _worker.TestTryParseStreamMessage(streamEntry, out var parsedEnrollment);

		// Assert
		Assert.True(result);
		Assert.NotNull(parsedEnrollment);
		Assert.Equal(123, parsedEnrollment.ContactId);
		Assert.Equal(456, parsedEnrollment.MarketingCampaignId);
	}

	[Fact]
	public void TryParseStreamMessage_WithInvalidJson_ShouldReturnFalse()
	{
		// Arrange
		var streamEntry = new StreamEntry(
			Guid.NewGuid().ToString(),
			new NameValueEntry[] { new(SharedConstants.StreamFieldKey, "invalid-json") });

		// Act
		var result = _worker.TestTryParseStreamMessage(streamEntry, out var parsedEnrollment);

		// Assert
		Assert.False(result);
		Assert.Null(parsedEnrollment);
	}

	[Fact]
	public void TryParseStreamMessage_WithNullValue_ShouldReturnFalse()
	{
		// Arrange
		var streamEntry = new StreamEntry(
			Guid.NewGuid().ToString(),
			new NameValueEntry[] { new(SharedConstants.StreamFieldKey, RedisValue.Null) });

		// Act
		var result = _worker.TestTryParseStreamMessage(streamEntry, out var parsedEnrollment);

		// Assert
		Assert.False(result);
		Assert.Null(parsedEnrollment);
	}

	[Fact]
	public void TryParseStreamMessage_WithDataField_ShouldWork()
	{
		// Arrange
		var enrollment = TestObjectFactory.CreateStagedEnrollment(789, 101112);
		var json = JsonSerializer.Serialize(enrollment);

		var streamEntry = new StreamEntry(
			Guid.NewGuid().ToString(),
			new NameValueEntry[] { new(SharedConstants.StreamFieldKey, json) });

		// Act
		var result = _worker.TestTryParseStreamMessage(streamEntry, out var parsedEnrollment);

		// Assert
		Assert.True(result);
		Assert.NotNull(parsedEnrollment);
		Assert.Equal(enrollment.ContactId, parsedEnrollment.ContactId);
		Assert.Equal(enrollment.MarketingCampaignId, parsedEnrollment.MarketingCampaignId);
	}

	[Fact]
	public async Task Worker_ShouldHandleBusyGroupException()
	{
		// Arrange
		_mockDatabase.Setup(db => db.StreamCreateConsumerGroupAsync(
			It.IsAny<RedisKey>(),
			It.IsAny<RedisValue>(),
			It.IsAny<RedisValue>(),
			It.IsAny<bool>(),
			It.IsAny<CommandFlags>()))
			.ThrowsAsync(new RedisServerException("BUSYGROUP Consumer Group name already exists"));

		_mockDatabase.Setup(db => db.StreamReadGroupAsync(
			It.IsAny<RedisKey>(),
			It.IsAny<RedisValue>(),
			It.IsAny<RedisValue>(),
			It.IsAny<RedisValue>(),
			It.IsAny<int>(),
			It.IsAny<CommandFlags>()))
			.ReturnsAsync(Array.Empty<StreamEntry>());

		// Act
		using var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(300));
		var task = _worker.StartAsync(cts.Token);

		// Wait for initialization to complete
		await Task.Delay(100);
		cts.Cancel();

		try
		{ await task; }
		catch (OperationCanceledException) { }

		// Assert - should have logged debug message about consumer group already existing
		Assert.True(_logger.HasLogLevel(LogLevel.Debug));
		Assert.True(_logger.HasLogContaining("already exists"));
	}

}
