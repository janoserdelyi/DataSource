using System.Text.Json;
using EnrollmentPipeline.Models;
using EnrollmentPipeline.Repositories;
using EnrollmentPipeline.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using OpenSearch.Client;
using OpenSearch.Net;

namespace EnrollmentPipeline.Tests.Unit;

[Trait("TestCategory", "Integration")]
public class ContactRepositoryTests
{
    private readonly IOpenSearchClient _client;
    private readonly TestLogger<ContactRepository> _logger;
    private readonly ContactRepository _repository;

    public ContactRepositoryTests()
    {
        // Load configuration from appsettings.json
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false)
            .Build();

        var openSearchUrl = configuration.GetConnectionString("OpenSearch") 
            ?? throw new InvalidOperationException("OpenSearch connection string not found in configuration");

        // Create a real OpenSearch client
        var pool = new SingleNodeConnectionPool(new Uri(openSearchUrl));
        var connectionSettings = new ConnectionSettings(pool)
            .DisableDirectStreaming()
            .DefaultIndex("contacts.reader")
            .ServerCertificateValidationCallback((o, certificate, chain, errors) => true); // Accept all SSL certificates for dev/test
        
        _client = new OpenSearchClient(connectionSettings);
        _logger = new TestLogger<ContactRepository>();
        _repository = new ContactRepository(_client, _logger);
    }

    [Theory]
    [InlineData(1000, 0)]
    [InlineData(50000, 0)]
    [InlineData(100000, 0)]
    public async Task GetAllContacts_WithValidParameters_ShouldReturnContacts(int limit, int offset)
    {
        // Act
        var result = await _repository.GetAllContacts(limit, offset);

        // Assert
        Assert.NotNull(result);
        Assert.True(result.Count() <= limit);
    }

    [Fact]
    public async Task GetAllContacts_WithZeroLimit_ShouldReturnEmptyList()
    {
        // Act
        var result = await _repository.GetAllContacts(0, 0);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }
}
