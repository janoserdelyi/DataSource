using EnrollmentPipeline;
using EnrollmentPipeline.Enums;
using EnrollmentPipeline.Models;
using Marketing.Enums;

namespace EnrollmentPipeline.Tests.Helpers;
/// <summary>
/// Helper class for creating test objects
/// </summary>
public static class TestObjectFactory
{
    /// <summary>
    /// Creates a StagedEnrollment for testing
    /// </summary>
    public static StagedEnrollment CreateStagedEnrollment(
        int contactId = 1,
        int campaignId = 1000,
        PipelineStatus statusId = PipelineStatus.Created,
        short pipelineVersionId = 1,
        MarketingBrands brandId = MarketingBrands.LoopNet)
    {
        return new StagedEnrollment
        (
            contactId,
            [],
            campaignId,
            brandId,
            pipelineVersionId
        );
    }

    /// <summary>
    /// Creates a WorkerResult with a test StagedEnrollment
    /// </summary>
    public static WorkerResult CreateWorkerResult(
        StagedEnrollment? stagedEnrollment = null,
        Guid? workerId = null)
    {
        stagedEnrollment ??= CreateStagedEnrollment();
        workerId ??= Guid.NewGuid();
        return new WorkerResult
        {
            WorkerId = workerId.Value,
            Enrollment = stagedEnrollment
        };
    }
}

