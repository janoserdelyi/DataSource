global using Xunit;
global using Microsoft.Extensions.Logging;
global using StackExchange.Redis;
global using EnrollmentPipeline;
global using System.Reflection;

