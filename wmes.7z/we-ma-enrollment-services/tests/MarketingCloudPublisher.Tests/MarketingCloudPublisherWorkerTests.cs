﻿using System;
using System.Collections.Generic;
using System.Text.Json.Nodes;
using Marketing.Enums;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Configuration;

namespace MarketingCloudPublisher.Tests;

/// <summary>
/// Unit tests for MarketingCloudPublisherWorker.
/// Note: ProcessBatch is a protected method from the base class StreamPipelineWorker.
/// These tests focus on the worker's configuration and properties.
/// For testing the actual processing logic, integration tests are recommended.
/// </summary>
public class MarketingCloudPublisherWorkerTests
{
    private readonly Mock<IConnectionMultiplexer> _mockRedis;
    private readonly Mock<IStreamMessagePublisher> _mockPublisher;
    private readonly Mock<ILogger<Worker>> _mockLogger;
    private readonly Mock<IServiceScopeFactory> _mockScopeFactory;
    private readonly IConfiguration _configuration;
    private readonly Mock<HybridCache> _mockHybridCache;

    public MarketingCloudPublisherWorkerTests()
    {
        _mockRedis = new Mock<IConnectionMultiplexer>();
        _mockPublisher = new Mock<IStreamMessagePublisher>();
        _mockLogger = new Mock<ILogger<Worker>>();
        _mockScopeFactory = new Mock<IServiceScopeFactory>();
        _mockHybridCache = new Mock<HybridCache>();

        // Create real configuration with test values
        var inMemorySettings = new Dictionary<string, string?>
        {
            ["PipelineWorker:Id"] = Guid.NewGuid().ToString()
        };
        _configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(inMemorySettings)
            .Build();
    }

    [Fact]
    public void Constructor_CreatesInstanceSuccessfully()
    {
        // Act
        var worker = CreateWorker();

        // Assert
        Assert.NotNull(worker);
        Assert.IsAssignableFrom<StreamPipelineWorker>(worker);
    }

    [Fact]
    public void Constructor_AcceptsAllRequiredDependencies()
    {
        // Arrange & Act
        var worker = new Worker(
            _mockRedis.Object,
            _mockPublisher.Object,
            _mockLogger.Object,
            _mockScopeFactory.Object,
            _configuration,
            _mockHybridCache.Object
        );

        // Assert
        Assert.NotNull(worker);
    }

    [Theory]
    [InlineData(1, MarketingBrands.Apartments, 1001)]
    [InlineData(2, MarketingBrands.Apartments, 1002)]
    [InlineData(3, MarketingBrands.LoopNet, 2001)]
    public void CreateEnrollment_CreatesValidEnrollmentObject(int campaignId, MarketingBrands brand, int contactId)
    {
        // Arrange & Act
        var enrollment = CreateEnrollment(campaignId, contactId, brand);

        // Assert
        Assert.NotNull(enrollment);
        Assert.Equal(campaignId, enrollment.MarketingCampaignId);
        Assert.Equal(brand, enrollment.BrandId);
        Assert.Equal(contactId, enrollment.ContactId);
        Assert.NotNull(enrollment.DataFields);
        Assert.Equal(contactId.ToString(), enrollment.DataFields["ContactId"]?.ToString());
    }

    private Worker CreateWorker()
    {
        return new Worker(
            _mockRedis.Object,
            _mockPublisher.Object,
            _mockLogger.Object,
            _mockScopeFactory.Object,
            _configuration,
            _mockHybridCache.Object
        );
    }

    private StagedEnrollment CreateEnrollment(int campaignId, int contactId, MarketingBrands brand = MarketingBrands.Apartments)
    {
        return new StagedEnrollment
        (
            contactId,
            new JsonObject
            {
                ["ContactId"] = contactId.ToString(),
                ["Email"] = $"test{contactId}@example.com"
            },
            campaignId,
            brand,
            1
        );
    }
}


