﻿global using Xunit;
global using Moq;
global using Microsoft.Extensions.Logging;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using StackExchange.Redis;
global using EnrollmentPipeline;
global using EnrollmentPipeline.Models;
global using EnrollmentPipeline.Enums;
global using EnrollmentPipeline.Repositories;
global using MarketingCloudPublisher;
global using MarketingCloudPublisher.Services;
global using MarketingCloudPublisher.Models;

