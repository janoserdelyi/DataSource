﻿# MarketingCloudPublisher Tests

This directory contains unit tests for the MarketingCloudPublisher project.

## Test Coverage

### MarketingCloudPublisherWorkerTests
Tests for the `MarketingCloudPublisherWorker` class:
- Constructor validation
- Worker creation with all required dependencies
- Enrollment object creation with various parameters

**Note**: The `ProcessBatch` method is protected and inherited from `StreamPipelineWorker`. Testing the actual processing logic requires integration tests that spin up the full pipeline infrastructure (Redis, PostgreSQL, etc.). The unit tests focus on the worker's configuration and instantiation.

### MarketingCloudClientTests
Comprehensive tests for the `MarketingCloudClient` class:
- Validation of upload objects (ensures key fields are present)
- Error handling for missing credentials
- Error handling for missing configuration
- Secret retrieval and decryption
- Valkey cache integration
- Various edge cases for missing credential fields (subdomain, client ID, client secret, grant type)

### MarketingCloudCredentialTests
Tests for the `MarketingCloudCredential` model:
- Property setting and getting
- Default values
- JSON serialization/deserialization
- Array deserialization for multiple credentials

### MarketingCloudPublishResultTests
Tests for the `MarketingCloudPublishResult` model:
- Success scenarios
- Failure scenarios with error messages
- Partial success scenarios
- Default values
- Edge cases

## Running the Tests

```bash
# Run all tests
dotnet test

# Run tests with coverage
dotnet test --collect:"XPlat Code Coverage"

# Run specific test class
dotnet test --filter "FullyQualifiedName~MarketingCloudClientTests"
```

## Integration Testing

For full end-to-end testing of the enrollment pipeline including the `ProcessBatch` method, refer to the integration tests which:
- Use Testcontainers for Redis and PostgreSQL
- Test the complete worker lifecycle
- Verify message processing, error handling, and retries
- Test campaign metadata retrieval and Marketing Cloud API interactions

Integration tests are maintained separately to keep unit tests fast and focused.

## Test Patterns

- **xUnit**: Test framework with built-in assertions
- **Moq**: For mocking dependencies
- **Theory/InlineData**: For parameterized tests

## Notes

- The MarketingCloudPublisher worker extends `StreamPipelineWorker` from the EnrollmentPipeline library
- The actual processing logic is in the protected `ProcessBatch` method
- Unit tests focus on testable components and configuration
- Integration tests (separate project) handle full pipeline testing

