﻿using System.Collections.Generic;
using System.Text.Json;

namespace MarketingCloudPublisher.Tests.Models;

public class MarketingCloudCredentialTests
{
    [Fact]
    public void MarketingCloudCredential_SetsPropertiesCorrectly()
    {
        // Arrange & Act
        var credential = new MarketingCloudCredential
        {
            AccountId = "12345",
            AccountName = "Test Account",
            ClientId = "test-client-id",
            ClientSecret = "test-client-secret",
            Subdomain = "test-subdomain",
            GrantType = "client_credentials",
            SourceApplicationExtensionId = "test-extension-id"
        };

        // Assert
        Assert.Equal("12345", credential.AccountId);
        Assert.Equal("Test Account", credential.AccountName);
        Assert.Equal("test-client-id", credential.ClientId);
        Assert.Equal("test-client-secret", credential.ClientSecret);
        Assert.Equal("test-subdomain", credential.Subdomain);
        Assert.Equal("client_credentials", credential.GrantType);
        Assert.Equal("test-extension-id", credential.SourceApplicationExtensionId);
    }

    [Fact]
    public void MarketingCloudCredential_DefaultsToEmptyStrings()
    {
        // Arrange & Act
        var credential = new MarketingCloudCredential();

        // Assert
        Assert.Equal(string.Empty, credential.AccountId);
        Assert.Equal(string.Empty, credential.AccountName);
        Assert.Equal(string.Empty, credential.ClientId);
        Assert.Equal(string.Empty, credential.ClientSecret);
        Assert.Equal(string.Empty, credential.Subdomain);
        Assert.Equal(string.Empty, credential.GrantType);
        Assert.Equal(string.Empty, credential.SourceApplicationExtensionId);
    }

    [Fact]
    public void MarketingCloudCredential_DeserializesFromJson()
    {
        // Arrange
        var json = """
        {
            "account_id": "12345",
            "account_name": "Test Account",
            "client_id": "test-client-id",
            "client_secret": "test-client-secret",
            "subdomain": "test-subdomain",
            "grant_type": "client_credentials",
            "source_application_extension_id": "test-extension-id"
        }
        """;

        // Act
        var credential = JsonSerializer.Deserialize<MarketingCloudCredential>(json);

        // Assert
        Assert.NotNull(credential);
        Assert.Equal("12345", credential.AccountId);
        Assert.Equal("Test Account", credential.AccountName);
        Assert.Equal("test-client-id", credential.ClientId);
        Assert.Equal("test-client-secret", credential.ClientSecret);
        Assert.Equal("test-subdomain", credential.Subdomain);
        Assert.Equal("client_credentials", credential.GrantType);
        Assert.Equal("test-extension-id", credential.SourceApplicationExtensionId);
    }

    [Fact]
    public void MarketingCloudCredential_SerializesToJson()
    {
        // Arrange
        var credential = new MarketingCloudCredential
        {
            AccountId = "12345",
            AccountName = "Test Account",
            ClientId = "test-client-id",
            ClientSecret = "test-client-secret",
            Subdomain = "test-subdomain",
            GrantType = "client_credentials",
            SourceApplicationExtensionId = "test-extension-id"
        };

        // Act
        var json = JsonSerializer.Serialize(credential);
        var deserialized = JsonSerializer.Deserialize<MarketingCloudCredential>(json);

        // Assert
        Assert.NotNull(deserialized);
        Assert.Equal(credential.AccountId, deserialized.AccountId);
        Assert.Equal(credential.ClientId, deserialized.ClientId);
        Assert.Equal(credential.ClientSecret, deserialized.ClientSecret);
        Assert.Equal(credential.Subdomain, deserialized.Subdomain);
        Assert.Equal(credential.GrantType, deserialized.GrantType);
    }

    [Fact]
    public void MarketingCloudCredential_DeserializesArray()
    {
        // Arrange
        var json = """
        [
            {
                "account_id": "12345",
                "account_name": "Account 1",
                "client_id": "client1",
                "client_secret": "secret1",
                "subdomain": "subdomain1",
                "grant_type": "client_credentials",
                "source_application_extension_id": "ext1"
            },
            {
                "account_id": "67890",
                "account_name": "Account 2",
                "client_id": "client2",
                "client_secret": "secret2",
                "subdomain": "subdomain2",
                "grant_type": "client_credentials",
                "source_application_extension_id": "ext2"
            }
        ]
        """;

        // Act
        var credentials = JsonSerializer.Deserialize<List<MarketingCloudCredential>>(json);

        // Assert
        Assert.NotNull(credentials);
        Assert.Equal(2, credentials.Count);
        Assert.Equal("12345", credentials[0].AccountId);
        Assert.Equal("67890", credentials[1].AccountId);
    }
}

