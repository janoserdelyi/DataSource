﻿namespace MarketingCloudPublisher.Tests.Models;

public class MarketingCloudPublishResultTests
{
    [Fact]
    public void MarketingCloudPublishResult_SetsPropertiesCorrectly()
    {
        // Arrange & Act
        var result = new MarketingCloudPublishResult
        {
            Success = true,
            PublishedCount = 10,
            ErrorMessage = null
        };

        // Assert
        Assert.True(result.Success);
        Assert.Equal(10, result.PublishedCount);
        Assert.Null(result.ErrorMessage);
    }

    [Fact]
    public void MarketingCloudPublishResult_CanSetFailureWithErrorMessage()
    {
        // Arrange & Act
        var result = new MarketingCloudPublishResult
        {
            Success = false,
            PublishedCount = 0,
            ErrorMessage = "API Error: Invalid credentials"
        };

        // Assert
        Assert.False(result.Success);
        Assert.Equal(0, result.PublishedCount);
        Assert.Equal("API Error: Invalid credentials", result.ErrorMessage);
    }

    [Fact]
    public void MarketingCloudPublishResult_DefaultValues()
    {
        // Arrange & Act
        var result = new MarketingCloudPublishResult();

        // Assert
        Assert.False(result.Success);
        Assert.Equal(0, result.PublishedCount);
        Assert.Null(result.ErrorMessage);
    }

    [Fact]
    public void MarketingCloudPublishResult_PartialSuccess()
    {
        // Arrange & Act
        var result = new MarketingCloudPublishResult
        {
            Success = true,
            PublishedCount = 5,
            ErrorMessage = "Some enrollments failed"
        };

        // Assert
        Assert.True(result.Success);
        Assert.Equal(5, result.PublishedCount);
        Assert.Equal("Some enrollments failed", result.ErrorMessage);
    }

    [Fact]
    public void MarketingCloudPublishResult_SuccessWithZeroCount()
    {
        // Arrange & Act
        var result = new MarketingCloudPublishResult
        {
            Success = true,
            PublishedCount = 0,
            ErrorMessage = null
        };

        // Assert
        Assert.True(result.Success);
        Assert.Equal(0, result.PublishedCount);
        Assert.Null(result.ErrorMessage);
    }
}

