# EnrollmentFilter.Tests

This test project contains comprehensive unit tests for the EnrollmentFilter worker and service components of the Marketing Automation Enrollment Pipeline.

## Test Coverage

### EnrollmentFilterService Tests

Located in `Services/EnrollmentFilterServiceTests.cs`, these tests cover:

#### IsOptedOut Method
- ✅ Returns false when CanEmail is true
- ✅ Returns true when CanEmail is false
- ✅ Handles string values ("true", "false")
- ✅ Throws FormatException when CanEmail is null
- ✅ Throws KeyNotFoundException when CanEmail is missing
- ✅ Throws FormatException when CanEmail is an invalid string

#### IsUkGovernmentEmail Method
- ✅ Returns true for UK government email domains (@voa.gsi.gov.uk, @voa.gov.uk)
- ✅ Returns false for non-UK government email domains
- ✅ Case-insensitive domain checking
- ✅ Returns false when email is empty or null

#### HasRequiredFieldsAsync Method
- ✅ Returns valid when all required fields are present
- ✅ Returns invalid when required field is missing
- ✅ Returns invalid when required field is empty
- ✅ Returns invalid when required field contains only whitespace
- ✅ Returns invalid when multiple fields are invalid
- ✅ Returns invalid when campaign is not found
- ✅ Returns valid when no required fields are configured

#### IsEmailAddressValidAsync Method
- ✅ Returns true as placeholder (TODO: implement with OpenSearch)

### EnrollmentFilterWorker Tests

Located in `EnrollmentFilterWorkerTests.cs`, these tests cover:

- ✅ Constructor creates instance successfully
- ✅ Constructor accepts all required dependencies
- ✅ Creates valid enrollment objects with correct properties
- ✅ Includes email address in enrollments
- ✅ Handles CanEmail field correctly
- ✅ Identifies UK government email addresses

## Running the Tests

### Run All Tests
```powershell
dotnet test tests/EnrollmentFilter.Tests/EnrollmentFilter.Tests.csproj
```

### Run with Detailed Output
```powershell
dotnet test tests/EnrollmentFilter.Tests/EnrollmentFilter.Tests.csproj --logger console --verbosity normal
```

### Run Only Unit Tests
```powershell
dotnet test tests/EnrollmentFilter.Tests/EnrollmentFilter.Tests.csproj --filter "TestCategory=Unit"
```

## Test Statistics

- **Total Tests**: 31
- **Unit Tests**: 31
- **Test Categories**: Unit
- **Code Coverage Target**: 100%

## Dependencies

- xUnit 2.9.3
- Moq 4.20.72
- Microsoft.NET.Test.Sdk 18.0.1

## Notes

- The `ProcessBatch` method from the base class `StreamPipelineWorker` is protected, so these unit tests focus on the worker's configuration and properties.
- For testing the actual processing logic of `ProcessBatch`, integration tests with real Redis streams are recommended.
- The `IsEmailAddressValidAsync` method is a placeholder implementation that always returns true. Full implementation will require OpenSearch integration.

## Future Enhancements

1. Add integration tests for the complete enrollment filtering workflow
2. Test `ProcessBatch` method behavior with various enrollment scenarios
3. Mock email validation service once OpenSearch integration is implemented
4. Add performance benchmarks for filtering operations
