using System.Collections.ObjectModel;
using System.Text.Json.Nodes;
using Marketing.Enums;

namespace EnrollmentFilter.Tests.Services;

/// <summary>
/// Unit tests for EnrollmentFilterService
/// </summary>
public class EnrollmentFilterServiceTests
{
    private readonly Mock<ICampaignRepository> _mockCampaignRepository;
    private readonly Mock<ILogger<EnrollmentFilterService>> _mockLogger;

    public EnrollmentFilterServiceTests()
    {
        _mockCampaignRepository = new Mock<ICampaignRepository>();
        _mockLogger = new Mock<ILogger<EnrollmentFilterService>>();
    }

    #region IsOptedOut Tests

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ReturnsFalse_WhenCanEmailIsTrue()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = true;

        // Act
        var result = service.IsOptedOut(enrollment);

        // Assert
        Assert.False(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ReturnsTrue_WhenCanEmailIsFalse()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = false;

        // Act
        var result = service.IsOptedOut(enrollment);

        // Assert
        Assert.True(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ReturnsFalse_WhenCanEmailIsStringTrue()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = "true";

        // Act
        var result = service.IsOptedOut(enrollment);

        // Assert
        Assert.False(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ReturnsTrue_WhenCanEmailIsStringFalse()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = "false";

        // Act
        var result = service.IsOptedOut(enrollment);

        // Assert
        Assert.True(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ThrowsFormatException_WhenCanEmailIsNull()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = null;

        // Act & Assert
        var exception = Assert.Throws<FormatException>(() => service.IsOptedOut(enrollment));
        Assert.Equal("CanEmail field is null", exception.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ThrowsKeyNotFoundException_WhenCanEmailIsMissing()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        // Don't add CanEmail field

        // Act & Assert
        var exception = Assert.Throws<KeyNotFoundException>(() => service.IsOptedOut(enrollment));
        Assert.Equal("CanEmail field is missing or invalid", exception.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsOptedOut_ThrowsFormatException_WhenCanEmailIsInvalidString()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["CanEmail"] = "invalid";

        // Act & Assert
        var exception = Assert.Throws<FormatException>(() => service.IsOptedOut(enrollment));
        Assert.Contains("Invalid CanEmail field value", exception.Message);
    }

    #endregion

    #region IsUkGovernmentEmail Tests

    [Theory]
    [InlineData("test@voa.gsi.gov.uk")]
    [InlineData("user@voa.gov.uk")]
    [InlineData("Test@VOA.GSI.GOV.UK")] // Case insensitive
    [Trait("TestCategory", "Unit")]
    public void IsUkGovernmentEmail_ReturnsTrue_WhenEmailIsUkGovernmentDomain(string email)
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["EmailAddress"] = email;

        // Act
        var result = service.IsUkGovernmentEmail(enrollment);

        // Assert
        Assert.True(result);
    }

    [Theory]
    [InlineData("test@example.com")]
    [InlineData("user@gmail.com")]
    [InlineData("admin@costar.com")]
    [Trait("TestCategory", "Unit")]
    public void IsUkGovernmentEmail_ReturnsFalse_WhenEmailIsNotUkGovernmentDomain(string email)
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["EmailAddress"] = email;

        // Act
        var result = service.IsUkGovernmentEmail(enrollment);

        // Assert
        Assert.False(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsUkGovernmentEmail_ReturnsFalse_WhenEmailIsEmpty()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["EmailAddress"] = "";

        // Act
        var result = service.IsUkGovernmentEmail(enrollment);

        // Assert
        Assert.False(result);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public void IsUkGovernmentEmail_ReturnsFalse_WhenEmailIsNull()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        // Don't set EmailAddress field

        // Act
        var result = service.IsUkGovernmentEmail(enrollment);

        // Assert
        Assert.False(result);
    }

    #endregion

    #region HasRequiredFieldsAsync Tests

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsValid_WhenAllRequiredFieldsPresent()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["FirstName"] = "John";
        enrollment.DataFields["LastName"] = "Doe";
        enrollment.DataFields["EmailAddress"] = "john@example.com";

        var campaign = CreateCampaign(100, new[]
        {
            CreateDataField("FirstName", isRequired: true),
            CreateDataField("LastName", isRequired: true),
            CreateDataField("EmailAddress", isRequired: true)
        });

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.True(result.HasRequiredFields);
        Assert.Empty(result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsInvalid_WhenRequiredFieldMissing()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["FirstName"] = "John";
        // LastName is missing

        var campaign = CreateCampaign(100, new[]
        {
            CreateDataField("FirstName", isRequired: true),
            CreateDataField("LastName", isRequired: true)
        });

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.False(result.HasRequiredFields);
        Assert.Contains("Missing required fields", result.Message);
        Assert.Contains("LastName", result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsInvalid_WhenRequiredFieldEmpty()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["FirstName"] = "John";
        enrollment.DataFields["LastName"] = ""; // Empty value

        var campaign = CreateCampaign(100, new[]
        {
            CreateDataField("FirstName", isRequired: true),
            CreateDataField("LastName", isRequired: true)
        });

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.False(result.HasRequiredFields);
        Assert.Contains("Empty required fields", result.Message);
        Assert.Contains("LastName", result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsInvalid_WhenRequiredFieldWhitespace()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["FirstName"] = "John";
        enrollment.DataFields["LastName"] = "   "; // Whitespace only

        var campaign = CreateCampaign(100, new[]
        {
            CreateDataField("FirstName", isRequired: true),
            CreateDataField("LastName", isRequired: true)
        });

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.False(result.HasRequiredFields);
        Assert.Contains("Empty required fields", result.Message);
        Assert.Contains("LastName", result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsInvalid_WhenMultipleFieldsInvalid()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["FirstName"] = ""; // Empty
        // LastName is missing (will be both missing AND empty when checked)
        // Note: The service checks if field exists first, and if it does, checks if it's empty
        // So LastName will appear in both missing and empty fields lists

        var campaign = CreateCampaign(100, new[]
        {
            CreateDataField("FirstName", isRequired: true),
            CreateDataField("LastName", isRequired: true)
        });

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.False(result.HasRequiredFields);
        Assert.Contains("Missing required fields", result.Message);
        Assert.Contains("LastName", result.Message);
        Assert.Contains("Empty required fields", result.Message);
        Assert.Contains("FirstName", result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsInvalid_WhenCampaignNotFound()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync((MarketingCampaign?)null);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.False(result.HasRequiredFields);
        Assert.Equal("Campaign 100 not found", result.Message);
    }

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task HasRequiredFieldsAsync_ReturnsValid_WhenNoRequiredFields()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);

        var campaign = CreateCampaign(100, Array.Empty<MarketingDataField>());

        _mockCampaignRepository
            .Setup(r => r.GetCachedCampaignByIdAsync(100))
            .ReturnsAsync(campaign);

        // Act
        var result = await service.HasRequiredFieldsAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.True(result.HasRequiredFields);
        Assert.Empty(result.Message);
    }

    #endregion

    #region IsEmailAddressValidAsync Tests

    [Fact]
    [Trait("TestCategory", "Unit")]
    public async Task IsEmailAddressValidAsync_ReturnsTrue_AsPlaceholder()
    {
        // Arrange
        var service = CreateService();
        var enrollment = CreateEnrollment(1, 100, 1);
        enrollment.DataFields["EmailAddress"] = "test@example.com";

        // Act
        var result = await service.IsEmailAddressValidAsync(enrollment, CancellationToken.None);

        // Assert
        Assert.True(result);
    }

    #endregion

    #region Helper Methods

    private EnrollmentFilterService CreateService()
    {
        return new EnrollmentFilterService(_mockCampaignRepository.Object, _mockLogger.Object);
    }

    private StagedEnrollment CreateEnrollment(long id, int campaignId, int contactId, MarketingBrands brand = MarketingBrands.LoopNet)
    {
        return new StagedEnrollment
        (
            contactId,
            new JsonObject
            {
                ["ContactId"] = contactId.ToString(),
                ["EmailAddress"] = $"test{contactId}@example.com"
            },
            campaignId,
            brand,
            1
        );
    }

    private MarketingCampaign CreateCampaign(int campaignId, MarketingDataField[] requiredFields)
    {
        return new MarketingCampaign
        {
            Id = campaignId,
            MarketingCampaignName = $"Test Campaign {campaignId}",
            MarketingBrandId = MarketingBrands.LoopNet,
            DataFields = new ReadOnlyCollection<MarketingDataField>(requiredFields)
        };
    }

    private MarketingDataField CreateDataField(string fieldName, bool isRequired = false, bool isActive = true)
    {
        return new MarketingDataField
        {
            MarketingDataFieldId = fieldName.GetHashCode(),
            FieldName = fieldName,
            IsRequiredForCampaign = isRequired,
            IsActiveForCampaign = isActive
        };
    }

    #endregion
}
