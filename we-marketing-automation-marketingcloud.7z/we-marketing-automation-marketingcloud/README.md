# Introduction
`we-marketing-automation-marketingcloud` is a one-stop shop for interfacing with Salesforce Marketing Cloud APIs. It was born from the Homes.com integration project due at the 2024 SuperBowl.

Marketing Cloud (referred to as `MC` or `SFMC`) uses a mix of SOAP and REST APIs. Their uses can be particular and non-obvious at first. This library seeks to smooth over those implementation details to make working with SFMC easy and straight-forward and consistent.

Additionally this library manages your authentication lifecycle for you. Provide appropriate credentials and go!

# Getting Started
## Installation
CLI : `dotnet add package we-marketing-automation-marketingcloud`
.csproj : `<PackageReference Include="we-marketing-automation-marketingcloud" Version="*"/>`

## Using
### Authentication
It's expected that you know the authentication values you need. This README does not provide guidance on that.
You will need to populate a `AuthParams` object with six **required** values.
1. `accountId` : This will determine which Business Unit in SFMC you are operating on. Rights and permissions for the account are controlled within SFMC.
2. `subdomain` : Your SFMC admin will provide this. It's how SFMC segments business relationships.
3. `baseUri` : This will include the subdomain and will typically be "https://{your subdomain}.auth.marketingcloudapis.com"
4. `clientId` : Your auth Id
5. `clientSecret` : Secret!
6. `grantType` : As of this writing this value will always be `client_credentials`

### The `MarketingCloud` Object
The root object is the `MarketingCloud` object. It is instantiated with an `AuthParams` object.
```csharp
var mycreds = new AuthParams (
	accountId : "12345678",
	subdomain : "randomset-o-lettersandnumbers",
	baseUri : "https://randomset-o-lettersandnumbers.auth.marketingcloudapis.com",
	clientId : "feefiefofum",
	clientSecret : "abc123ABC456secret",
	grantType : "client_credentials"
);
var mc = new MarketingCloud(mycreds);
```

The `MarketingCloud` object manages auth lifecycle is extended by SFMC objects like `DataExtension`, `Subscriber`, `Tracking`.

## Examples

### `DataExtension`

#### Creating a `DataExtension`

This is a pretty generic `DataExtension` example. Argument labels are used in some cases for clarity.

```csharp
var myDataExtension = await mc.DataExtension().Create (
	dataExtensionKey,
	dataExtensionKey,
	isSendable: false,
	new List<Field> {
		new Field (
			customerKey: "PrimaryKey",
			name: "PrimaryKey",
			fieldType: "Number",
			isRequired: true,
			isPrimaryKey: true
		),
		new Field (
			"Name",
			"Name",
			"Text",
			maxLength: 200,
			isRequired: true,
			isPrimaryKey: false
		),
		new Field (
			"EmailAddress",
			"EmailAddress",
			"Text",
			maxLength: 200,
			isRequired: true,
			isPrimaryKey: false
		),
		new Field (
			"Street",
			"Street",
			"Text",
			maxLength: 200,
			isRequired: true,
			isPrimaryKey: false
		),
		new Field (
			"City",
			"City",
			"Text",
			maxLength: 100,
			isRequired: true,
			isPrimaryKey: false
		),
		new Field (
			"PostalCode",
			"PostalCode",
			"Text",
			maxLength: 100,
			isRequired: true,
			isPrimaryKey: false
		)
	},
	null,
	null
);
```
#### Adding data to a `DataExtension`

Data is a `List<IDictionary<string, string>>` where the inner `Dictionary` represents a row.
The row's `<string, string>` paramaters are just a key/value pair of the Field name and the Value. Example : `{"Name", "Joe Bloggs"}`

It should be noted that the payload size should generally not exceed 20MiB. There is a method for adding data which takes that into account.

Assuming you have a `List` of records named `myListOfRecords`, here is the basic way you would add data in cases where you're not expecting thousands of records : 

```csharp
var myListOfRecords = new List<IDictionary<string, string?>>();

myListOfRecords.Add(new Dictionary<string, string?>(){
	{"PrimaryKey", "1"},
	{"Name", "Joe Bloggs"},
	{"EmailAddress", "joebloggs@example.com"},
	{"Street", "123 Street Rd"},
	{"City", "Townville"},
	{"PostalCode", "12345"}
});
myListOfRecords.Add(new Dictionary<string, string?>(){
	{"PrimaryKey", "2"},
	{"Name", "Fred Biggs"},
	{"EmailAddress", "fredbiggs@example.com"},
	{"Street", "456 Lane Pl"},
	{"City", "CityVillage"},
	{"PostalCode", "98765"}
});

DataExtensionInsertUpdateResponse? insertResponse = await mc.DataExtension().AddData (
	dataExtensionKey,
	"PrimaryKey",
	myListOfRecords,
	update:false
);
```

If you are expecting to add thousands of records potentially, it is recommended that you use the batch method. 
There is no real performance penalty for using the batch method, so please use it in the event where you may upoload many records.

```csharp
DataExtensionInsertUpdateResponse? insertResponse = await mc.DataExtension().AddDataChunked (
	dataExtensionKey,
	"PrimaryKey",
	myListOfRecords,
	update:false
);
```

The response from these methods will return two lists - the `OK` records and the `Error` records. They will both contain the primary key of each record and the reason so that the results may be analyzed and acted upon.

##### Adding data to a `DataExtension` with strongly-typed objects (instead of a Dictionary!)

Now if you have a class that you would prefer to pass in to the extension to populate it, you can do so! Let's walk through an example :

```csharp
public class TestDataRow
{
	[BindingName("PrimaryKey")]
	public int? Id {get;set;}
	public string? Name {get;set;}
	public string? EmailAddress {get;set;}
	public string? Street {get;set;}
	public string? City {get;set;}
	public string? PostalCode {get;set;}
}

var myListOfRecords = new List<TestDataRow>();

myListOfRecords.Add(new TestDataRow {
	Id = 1,
	Name = "Joe Bloggs",
	EmailAddress = "joebloggs@example.com",
	Street = "123 Street Rd",
	City = "Townville",
	PostalCode = "12345"
});

DataExtensionInsertUpdateResponse? insertResponse = await mc.DataExtension().AddData<TestDataRow> (
	dataExtensionKey,
	"PrimaryKey",
	myListOfRecords,
	update:false
);
```
This will convert the strongly-typed class into the appropriate Dictionary object that the payload needs.
Additionally you may have noticed the `[BindingName("PrimaryKey")]` attribute. You can use that to align your class property names with what the `DataExtension` is expecting.


#### Updating data in a `DataExtension`

You've seen `AddData`, check out `UpdateData`! This really only exists to feel natural. It's just `AddData` with the `update` boolean set to `true`.

There is no `UpdateDataChunked` as of this writing, sorry. use `AddDataChunked` and set `update` argument to `true`.

Updating data uses the primary key field to determine which reocrd(s) to update.


#### Selecting data from a `DataExtension`

Selecting involves filters. There are two types of filters, `SimpleFilterPart` and `ComplexFilterPart`. This isn't a full exposition on filters, but suffice to say whenever
a filter is called for in a method it can be of either type. Additionally, `ComplexFilterPart`s can take both `SimpleFilterPart`s and `ComplexFilterPart`s with unlimited nesting.

```csharp
var nameFilter = new SimpleFilterPart {
	Property = "Name",
	SimpleOperator = SimpleOperator.like,
	Value = new string[] { "Joe" }
};
var postalFilter = new SimpleFilterPart {
	Property = "PostalCode",
	SimpleOperator = SimpleOperator.equals,
	Value = new string[] { "12345" }
};
var namePostalFilter = new ComplexFilterPart {
	LeftOperand = nameFilter,
	Operator = LogicalOperator.AND,
	RightOperand = postalFilter
};

var data = await mc.DataExtension().GetData (
	deGet!.CustomerKey!,
	new List<string>(){"PrimaryKey", "Name", "EmailAddress", "Street", "City", "PostalCode"},
	namePostalFilter
);
```

Data in a `DataExtension` comes back as a list of results where each result is a dictionary of property names and values.
Operating on a dictionary this way is not particularly fun or elegant.

If you wish to convert the properties to a strongly typed object, there is an extension method for you!

```csharp
// assuming 'data' has at least one record for this example
var datarow = data.Results[0].To<TestDataRow>();

Console.WriteLine(datarow.EmailAddress);
```

#### Deleting data from a `DataExtension`

I'm just provinding a signature for this. 

```csharp
DeleteData(string dataExtensionKey, IDictionary<string, string> keys);
```


#### Getting the `DataExtension` itself

Want to inspect the properties of a `DataExtension`? Look no further.

```csharp
var yourDataExtension = await mc.DataExtension().Get(dataExtensionObjectId);
```

By default, Getting an Extension is done via the Object Id. However you can also easily get a `DataExtension` by the customer-defined key

```csharp
var yourDataExtension = await mc.DataExtension().GetByCustomerKey(dataExtensionCustomerKey);
```

If you wanted to get a `DataExtension` another way, pass in a filter to `Get` like :

```csharp
var yourDataExtension = await mc.DataExtension().Get (
	new SimpleFilterPart {
		Property = "ExampleField",
		SimpleOperator = Enums.SimpleOperator.equals,
		Value = new string[] {exampleValue}
	}
);
```

#### Delete a `DataExtension`

Careful!

```csharp
var deleteResponse = await mc.DataExtension().Delete(dataExtensionKey);
```

### `Journey`

#### Create a `Journey`
Creating a Journey is fairly complex task with many options. This is an example of how to create a fairly typical Journey backed by a sendable DataExtension where one of the DataExtension fields is the sendable email field.

```csharp
// just a test method. I would not advocate all the hard-coding contained herein
public static async Task CreateCampaign (
	AuthParams authParams
) {
	var mc = new MarketingCloud(authParams);

	// just looking to get a sourceApplicationExtensionId. the docs say to query /interaction/v1/eventDefinitions and pick one
	//string payload = await mc.SourceEvent().GetEventDefinitions();

	string campaignName = "janos 2024-07-22 04";
	string sourceApplicationExtensionId = "9adb989c-1fbc-4a75-8c3b-52fa68703a06";

	// check the campaign name to be sure it doesn't exist already
	var checkNameResponse = await mc.Journey().CheckName(campaignName);

	campaignName = checkNameResponse.Name;

	string sendableEmailFieldName = "EmailAddress"; // maps to a field name in the DataExtension

	var sendableDataExtensionField = new SendableDataExtensionField () {
		CustomerKey = sendableEmailFieldName, // the field name of the email address field in the data extension
		Name = sendableEmailFieldName,
		FieldType = "EmailAddress" // data type of the target field which will represent the email address in the data extension
	};

	// create the data extension for this campaign
	var de = await mc.DataExtension().Create (
		campaignName,
		campaignName,
		true,
		new List<Field> {
			new (
				customerKey : "PrimaryKey",
				name : "PrimaryKey",
				fieldType : "Number",
				isRequired : true,
				isPrimaryKey : true
			),
			new (
				customerKey : "Name",
				name : "Name",
				fieldType : "Text",
				maxLength : 200
			),
			new (
				customerKey : sendableEmailFieldName,
				name : sendableEmailFieldName,
				fieldType : "EmailAddress",
				isRequired: true
			),
			new (
				customerKey : "Street",
				name : "Street",
				fieldType : "Text",
				maxLength : 200,
				isRequired : true
			),
			new (
				customerKey : "City",
				name : "City",
				fieldType : "Text",
				maxLength : 100,
				isRequired : true
			),
			new (
				customerKey : "PostalCode",
				name : "PostalCode",
				fieldType : "Text",
				maxLength : 20,
				isRequired : true
			)
		},
		sendableDataExtensionField,
		new SendableSubscriberField ("Subscriber Key") // "Subscriber Key" or "Subscriber ID" depending on your usage
	);

	// select the data extension to get the correct data type and values for the journey create - plus i need an object id which does not come back in the DataExtension().Create(...) payload
	var deSelect = await mc.DataExtension().Get(de!.ObjectId!);

	// there is so little documentation on FilterDefinitions. It takes XML, but as of yet I have not written a programmatic way to build this and have no plans to
	// we only use this for lower environments to prevent real email sends outside of our org
	string filterDefiniition = @"<FilterDefinition>
<ConditionSet Operator=""OR"" ConditionSetName=""Individual Filter Grouping"">
	<Condition Operator=""Contains"" Key=""Email Addresses.Email Address"">
		<Value>
			<![CDATA[@costar.com]]>
		</Value>
	</Condition>
	<Condition Operator=""Contains"" Key=""Email Addresses.Email Address"">
		<Value>
			<![CDATA[@homes.com]]>
		</Value>
	</Condition>
</ConditionSet>
</FilterDefinition>";

	// create the journey for this campaign
	var journey = await mc.Journey().Create (
		campaignName,
		sourceApplicationExtensionId,
		deSelect!,
		sendableDataExtensionField : sendableDataExtensionField,
		configArgs: new MarketingCloudApi.Models.ConfigurationArguments {
			Criteria = filterDefiniition
		},
		triggerDescription: "Email Address contains @homes.com OR Email Address contains @costar.com" // not needed if not using a FilterDefinition
	);

}
```