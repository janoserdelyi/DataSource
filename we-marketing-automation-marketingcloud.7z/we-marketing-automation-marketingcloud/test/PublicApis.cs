﻿using MarketingCloudApi;
using MarketingCloudApi.Elements;
using MarketingCloudApi.Enums;
using Newtonsoft.Json;

namespace Tests;

public class PublicApiFixture : IDisposable
{
	public PublicApiFixture () {

		var configName = "test.config";

		if (File.Exists (configName) == false) {
			Console.WriteLine (@"Error, missing test.config
To run these tests you will need access to Marketing Cloud.
The format of test.config is as follows :
{
	""AccountId"":""12345678"",
	""Subdomain"":""mc0xxxxx-xxxxxxxxxxxxxxxxxxxx"",
	""BaseUri"":""https://mc0xxxxx-xxxxxxxxxxxxxxxxxxxx.auth.marketingcloudapis.com"",
	""ClientId"":""xxxxxxxxxxxxxxxxxxxxxxxxxx"",
	""ClientSecret"":""xxxxxxxxxxxxxxxxxxxxxxxx"",
	""GrantType"":""client_credentials""
}
		");
			throw new System.IO.FileNotFoundException ($"unable to locate {configName} to load Marketing cloud credentials");
		}

		var creds = JsonConvert.DeserializeObject<AuthParams> (File.ReadAllText (configName));

		if (creds == null) {
			Console.WriteLine ("Credentials are null for some reason");
			throw new Exception ("Credentials are null for some reason");
		}

		MC = new MarketingCloud (creds);

		TestDataExtensionName = "MarketingCloud API test table";

		// create a test data extension to test against
		// what's awkward is this assumes that DE creation works. that *is* tested but still
		string sourceApplicationExtensionId = "97e942ee-6914-4d3d-9e52-37ecb71f79ed";
		string sendableEmailFieldName = "EmailAddress";

		var sendableDataExtensionField = new SendableDataExtensionField () {
			CustomerKey = sendableEmailFieldName, // the field name of the email address field in the data extension
			Name = sendableEmailFieldName,
			FieldType = "EmailAddress" // data type of the target field which will represent the email address in the data extension
		};

		var checkNameResponse = MC.Journey ().CheckName (TestDataExtensionName).Result;

		// i don't know if i want to roll this way. we shall see
		TestDataExtensionName = checkNameResponse.Name;

		var deresp = MC.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.Name, TestDataExtensionName).Result;

		if (deresp == null) {
			var decreateresp = MC.DataExtension ().Create (
				TestDataExtensionName,
				TestDataExtensionName,
				isSendable: false,
				new List<Field> {
					new Field (
						customerKey: "ContactId",
						name: "ContactId",
						fieldType: "Number",
						isRequired: true,
						isPrimaryKey: true
					),
					new Field (
						"EmailAddress",
						"EmailAddress",
						"EmailAddress",
						isRequired: true,
						isPrimaryKey: false
					),
					new Field (
						"FirstName",
						"FirstName",
						"Text",
						isRequired: true,
						isPrimaryKey: false
					),
					new Field (
						"LastName",
						"LastName",
						"Text",
						isRequired: true,
						isPrimaryKey: false
					),
					new Field (
						"IsUserSuppressed",
						"IsUserSuppressed",
						"Boolean",
						isRequired: false,
						isPrimaryKey: false
					),
					new Field (
						"CreatedDate",
						"CreatedDate",
						"Date",
						isRequired: true,
						isPrimaryKey: false
					)
				},
				sendableDataExtensionField,
				new SendableSubscriberField ("Subscriber Key")
			).Result;

			if (decreateresp == null) {
				throw new Exception ($"error, no response attempting to create Data Extension '{TestDataExtensionName}'");
			}

			if (decreateresp.ErrorCode != null) {
				throw new Exception ($"error attempting to create Data Extension '{TestDataExtensionName}'. error code {decreateresp.ErrorCode}, status code {decreateresp.StatusCode}, message : {decreateresp.StatusMessage}");
			}

			deresp = MC.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.Name, TestDataExtensionName).Result;
		}

		if (deresp == null) {
			throw new Exception ($"error, unable to find Data Extension '{TestDataExtensionName}' even after creating it");
		}

		TestDataExtension = deresp;


		string filterDefiniition = @"<FilterDefinition>
	<ConditionSet Operator=""OR"" ConditionSetName=""Individual Filter Grouping"">
		<Condition Operator=""Contains"" Key=""Email Addresses.Email Address"">
			<Value>
				<![CDATA[@costar.com]]>
			</Value>
		</Condition>
	</ConditionSet>
</FilterDefinition>";

		var journey = MC.Journey ().Create (
			TestDataExtensionName,
			"Unit Test test harness",
			sourceApplicationExtensionId,
			deresp!,
			sendableDataExtensionField: sendableDataExtensionField,
			configArgs: new MarketingCloudApi.Models.ConfigurationArguments {
				Criteria = filterDefiniition
			},
			triggerDescription: "Email Address contains @costar.com"
		).Result;

		if (journey == null) {
			throw new Exception ("Error creating journey");
		}

		TestJourney = journey;

		// add some records to test against

	}

	public void Dispose () {
		if (TestJourney != null) {
			var deleteJourneyResp = MC.Journey ().Delete (TestJourney.JourneyInfo.Key!).Result;
			if (deleteJourneyResp == false) {
				Console.WriteLine ($"error deleting journey {TestJourney.JourneyInfo.Key!}");
			}
		}
		if (TestDataExtension != null) {
			var deleteDeResp = MC.DataExtension ().Delete (TestDataExtension.CustomerKey!).Result;
		}
	}

	public MarketingCloud MC { get; set; }
	public DataExtensionResponseObject TestDataExtension { get; set; }
	public MarketingCloudMetaData TestJourney { get; set; }
	public string TestDataExtensionName { get; set; }
}

public class PublicApis : IClassFixture<PublicApiFixture>
{
	public PublicApis (
		PublicApiFixture fixture
	) {
		this.fixture = fixture;
		this.mc = fixture.MC;
	}

	readonly PublicApiFixture fixture;
	readonly MarketingCloud mc;

	[Fact]
	public void Utils_SanitizeName_ExpectSafe () {

		string violatingName = "&!@#$%'^*()=[]{}.<>/\":?|,+Clean Name";

		string cleanName = Utils.NormalizeMarketingCloudName (violatingName);

		Assert.NotSame (violatingName, cleanName);
	}

	[Fact]
	public async Task DataExtension_GetNonExistantByName_ExpectNoDataExtension () {

		var name = $"TestDataExtension-{DateTime.Now.Ticks}";

		// name an extensions something which should not exist and try to get it
		var de = await mc.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.Name, name);

		Assert.Null (de);
	}

	[Fact]
	public async Task DataExtension_GeByName_ExpecDataExtension () {

		var de = await mc.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.Name, fixture.TestDataExtension.Name!);

		Assert.NotNull (de);
		Assert.Equal (fixture.TestDataExtension.Name, de.Name);
	}

	[Fact]
	public async Task DataExtension_GeByCustomerKey_ExpecDataExtension () {

		var de = await mc.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.CustomerKey, fixture.TestDataExtension.CustomerKey!);

		Assert.NotNull (de);
		Assert.Equal (fixture.TestDataExtension.CustomerKey, de.CustomerKey);
	}


	[Fact]
	public async Task DataExtension_GeByObjectId_ExpecDataExtension () {

		var de = await mc.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.ObjectId, fixture.TestDataExtension.ObjectId!);

		Assert.NotNull (de);
		Assert.Equal (fixture.TestDataExtension.ObjectId, de.ObjectId);
	}

	[Fact]
	public async Task DataExtension_Create_ExpectSuccess () {
		var dename = "MarketingCloud API unit test table";

		var de = await mc.DataExtension ().Get (MarketingCloudApi.Enums.DataExtensionSelectField.Name, dename);

		if (de != null) {
			await mc.DataExtension ().Delete (Utils.NormalizeMarketingCloudName (dename));
		}

		var decreateresp = createDisposableDataExtension (mc, dename);

		Assert.NotNull (decreateresp);
		Assert.Null (decreateresp.ErrorCode);
		Assert.Equal ("OK", decreateresp.StatusCode);
	}

	[Fact]
	public async Task DataExtension_Delete_ExpectSuccess () {

		var dename = "MarketingCloud API unit test table";

		createDisposableDataExtension (mc, dename);

		var de = await mc.DataExtension ().Delete (Utils.NormalizeMarketingCloudName (dename));

		Assert.NotNull (de);
		Assert.Equal ("OK", de.StatusCode);
	}

	[Fact]
	public async Task DataExtension_GetFields_ExpectSuccess () {
		var resp = await mc.DataExtension ().GetFields (fixture.TestDataExtension.CustomerKey!);

		Assert.NotNull (resp);
		Assert.True (resp.Fields.Count > 0);
	}

	// add a field
	[Fact]
	public async Task DataExtension_Addfield_ExpectSuccess () {

		// verify that the extension exists
		var extresp = await mc.DataExtension ().Get (DataExtensionSelectField.CustomerKey, fixture.TestDataExtension.CustomerKey!);

		Assert.NotNull (extresp);
		Assert.NotNull (extresp.Name);

		var resp = await mc.DataExtension ().AddFields (
			fixture.TestDataExtension.CustomerKey!,
			new List<Field> {
				new Field (
					customerKey: "TestField",
					name: "TestField",
					fieldType: "Text",
					maxLength: 100,
					isRequired: false,
					isPrimaryKey: false
				)
			}
		);

		Assert.NotNull (resp);
		Assert.Null (resp.ErrorCode);
		Assert.Equal ("OK", resp.OverallStatus);
	}

	// rename a journey and change its description
	[Fact]
	public async Task DataExtension_Journey_UpdateNameOrDescription_ExpectSuccess()
	{
		var journeyKey = fixture.TestJourney.JourneyInfo.Id;
		
		Assert.NotNull(journeyKey);
		Assert.NotEmpty(journeyKey);
		
		var newName = "NewName";
		var newDescription = "NewDescription";
		
		var response = await mc.Journey().UpdateName(
			journeyKey, 1, newName, newDescription);
		
		Assert.NotNull(response);
	}

	private static DataExtensionCreateResponse? createDisposableDataExtension (
		MarketingCloud mc,
		string dataExtensionName
	) {
		return mc.DataExtension ().Create (
			dataExtensionName,
			dataExtensionName,
			isSendable: false,
			new List<Field> {
				new Field (
					customerKey: "SubscriberID",
					name: "SubscriberID",
					fieldType: "Number",
					isRequired: true,
					isPrimaryKey: true
				),
				new Field (
					"SubscriberKey",
					"SubscriberKey",
					"Text",
					maxLength: 100,
					isRequired: true,
					isPrimaryKey: false
				),
				new Field (
					"CreatedDate",
					"CreatedDate",
					"Date",
					isRequired: true,
					isPrimaryKey: false
				),
				new Field (
					"EventDate",
					"EventDate",
					"Date",
					isRequired: true,
					isPrimaryKey: false
				),
				new Field (
					"JobId",
					"JobId",
					"Number",
					isRequired: true,
					isPrimaryKey: false
				),
				new Field (
					"EmailName",
					"EmailName",
					"Text",
					maxLength: 400,
					isRequired: false,
					isPrimaryKey: false
				),
				new Field (
					"ListId",
					"ListId",
					"Number",
					isRequired: false,
					isPrimaryKey: false
				),
				new Field (
					"PullDate",
					"PullDate",
					"Date",
					isRequired: true,
					isPrimaryKey: false
				),
				new Field (
					"LockDate",
					"LockDate",
					"Date",
					isRequired: false,
					isPrimaryKey: false
				),
			},
			null,
			null
		).Result;
	}
}


public class DataRecord
{
	public DataRecord (
		int contactId,
		string emailAddress,
		string firstName,
		string lastName,
		bool isUserSuppressed,
		DateTimeOffset createdDate
	) {
		ContactId = contactId;
		EmailAddress = emailAddress;
		FirstName = firstName;
		LastName = lastName;
		IsUserSuppressed = isUserSuppressed;
		CreatedDate = createdDate;
	}

	public int ContactId { get; set; }
	public string EmailAddress { get; set; }
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public bool IsUserSuppressed { get; set; }
	public DateTimeOffset CreatedDate { get; set; }
}
