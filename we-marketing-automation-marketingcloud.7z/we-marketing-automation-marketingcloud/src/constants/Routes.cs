namespace MarketingCloudApi.Routes;

public static class Rest
{
	/// <summary>
	/// GET a new short-lived auth token after providing credentials
	/// </summary>
	public const string GET_AUTH_TOKEN = "/v2/token";

	/// <summary>
	///
	/// </summary>
	public const string CREATE_JOURNEY = "/interaction/v1/interactions";
	public const string UPDATE_JOURNEY = "/interaction/v1/interactions";

	/// <summary>
	///
	/// </summary>
	public const string SOURCE_EVENT = "/interaction/v1/eventDefinitions";

	/// <summary>
	///
	/// </summary>
	public const string TRANSACTIONAL_MESSAGE = "/messaging/v1/email/messages";

	public const string TRANSACTIONAL_MESSAGE_STATUS = "/messaging/v1/email/messages/{messageKey}";

	public const string SEND_DEFINITION = "/messaging/v1/email/definitions";

	/// <summary>
	/// Use POST to upsert data extension in sync
	/// </summary>
	public const string UPSERT_DATAEXTENSION_ROW = "/hub/v1/dataevents";

	/// <summary>
	/// Create contact path
	/// </summary>
	public const string CREATE_CONTACT = "/contacts/v1/contacts";

	public const string CONTACT_SCHEMA = "/contacts/v1/schema";
	public const string ATTRIBUTESETS = "/contacts/v1/attributeSets";
	public const string ATTRIBUTESET_DEFINITIONS = "/contacts/v1/attributeSetDefinitions";
	public const string ATTRIBUTEGROUPS = "/contacts/v1/schemas/{schemaId}/attributeGroups";
	public const string ATTRIBUTEGROUP = "/contacts/v1/attributeGroups/{attributeGroupId}";

	public const string TRANSACTIONAL_EMAIL_DEFINITIONS = "/messaging/v1/email/definitions";

	/// <summary>
	/// Use POST for create. Use PATCH for update.
	/// </summary>
	public const string UPSERT_AUOTMATION = "/automation/v1/automations/";

	/// <summary>
	/// Use POST to create automation File Import activity.
	/// </summary>
	public const string UPSERT_AUTOMATION_FILE_IMPORT = "/automation/v1/imports/";

	/// <summary>
	/// The search contact by email address.
	/// </summary>
	public const string SEARCH_CONTACT_BY_EMAIL_ADDRESS = "/contacts/v1/addresses/email/search";

	/// <summary>
	/// Use GET to search automation.
	/// </summary>
	public const string SEARCH_AUTOMATION = "/legacy/v1/beta/automations/automation/definition/";

	/// <summary>
	/// Use POST to activate automation.
	/// </summary>
	public const string ACTIVATE_FILE_DROP_AUTOMATION = "/legacy/v1/beta/automations/filetrigger/";

	/// <summary>
	/// Use PUT to upsert data extension in async
	/// </summary>
	public const string UPSERT_DATA_EXTENSION_ASYNC = "/data/v1/async/dataextensions/{dataExtensionId}/rows";

	/// <summary>
	/// Use GET to check async upsert data extension request status
	/// </summary>
	public const string UPSERT_DATA_EXTENSION_ASYNC_STATUS = "/data/v1/async/{requestId}/status";

	/// <summary>
	/// Use GET to check async upsert data extension request results
	/// </summary>
	public const string UPSERT_DATA_EXTENSION_ASYNC_RESULT = "/data/v1/async/{requestId}/results";

	public const string CUSTOM_OBJECT_SCHEMA = "/data/v1/customobjects/{key}";

	/// <summary>
	/// Use POST to remove contact from active journey (limit of 50 contacts)
	/// </summary>
	public const string REMOVE_CONTACT_FROM_JOURNEY = "/interaction/v1/interactions/contactexit";

	/// <summary>
	/// Get, Create, Update, or Delete Domains and Domain Verifications
	/// </summary>
	public const string DOMAIN_VERIFICATION = "/messaging/v1/domainverification";
}
public static class Soap
{
	public const string ENDPOINT_URL_PATTERN = "https://{{et_subdomain}}.soap.marketingcloudapis.com/Service.asmx";
	public const string SERVICE_ENDPOINT = "Service.asmx";
}

