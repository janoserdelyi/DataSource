namespace MarketingCloudApi;

public static class XmlNamespaces
{
	public const string NAMESPACE_SOAP_ENVELOPE = "http://www.w3.org/2003/05/soap-envelope";
	public const string NAMESPACE_ADDRESSING = "http://schemas.xmlsoap.org/ws/2004/08/addressing";
	public const string NAMESPACE_SECURITY = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";
	public const string NAMESPACE_XSI = "http://www.w3.org/2001/XMLSchema-instance";
	public const string NAMESPACE_XSD = "http://www.w3.org/2001/XMLSchema";
	public const string NAMESPACE_EXACTTARGET = "http://exacttarget.com/wsdl/partnerAPI";
}
