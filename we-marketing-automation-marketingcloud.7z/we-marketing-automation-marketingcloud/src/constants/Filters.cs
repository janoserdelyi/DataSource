namespace MarketingCloudApi;

// condition filters. as of this writing just used for a non-production safety-net filter on data extensions
public static class Filters
{
	public static string CustomerKey = "CustomerKey";
	public static string equals = "equals";
	public static string SimpleFilterPart = "SimpleFilterPart";

	// Retrieve Request Properties
	public static string Name = "Name";
	public static string ObjectID = "ObjectID";

	// Filter Journey
	public static string COSTAR_EMAIL_FILTER = "<![CDATA[@costar.com]]>";
	public static string HOMES_EMAIL_FILTER = "<![CDATA[@homes.com]]>";
	public static string EMAIL_KEY = "Email Addresses.Email Address";
	public static string CONTAIN_OPERATOR = "Contains";
	public static string UI_METADATA_FILTER = "{&quot;groupToSetRelationshipId&quot;:&quot;f5522eb3-05a1-ee11-a5c1-5cba2c6f8680&quot;}";
	public static string OR_OPERATOR = "OR";
	public static string CONDITION_INDIVIDUAL_SET = "Individual Filter Grouping";
}
