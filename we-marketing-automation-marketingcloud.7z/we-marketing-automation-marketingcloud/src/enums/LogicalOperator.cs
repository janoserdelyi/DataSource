namespace MarketingCloudApi.Enums;

public enum LogicalOperator
{
	AND,
	OR
}