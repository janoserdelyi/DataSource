namespace MarketingCloudApi.Enums;

// common selection field names for Data Extensions
public enum DataExtensionSelectField
{
	ObjectId,
	CustomerKey,
	Name
}