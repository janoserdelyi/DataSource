namespace MarketingCloudApi.Enums;

public enum DataRetentionPeriod
{
	Days,
	Weeks,
	Months,
	Years
}