namespace MarketingCloudApi.Enums;

public enum StatusType
{
	OK,
	Error,
	MoreDataAvailable
}