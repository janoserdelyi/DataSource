namespace MarketingCloudApi.Enums;

public enum PerformAction
{
	ClearData
}