namespace MarketingCloudApi.Enums;

public enum TrackingType
{
	SentEvent,
	OpenEvent,
	ClickEvent,
	BounceEvent,
	UnsubEvent
}
