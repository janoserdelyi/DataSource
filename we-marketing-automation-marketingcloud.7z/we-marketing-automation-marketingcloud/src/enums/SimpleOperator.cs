namespace MarketingCloudApi.Enums;

// pulled from https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/simplefilterpart.html
// leave the case alone just in case
public enum SimpleOperator
{
	equals,
    notEquals,
    greaterThan,
    lessThan,
    isNotNull,
    isNull,
    greaterThanOrEqual,
    lessThanOrEqual,
    between,
    IN,
    like
}