namespace MarketingCloudApi.Enums;

// common selection field names for Data Extensions
public enum JourneySelectField
{
	InternalKey,
	CustomerKey // this is also a DefinitionId in some contexts
}
