namespace MarketingCloudApi.Enums;

public enum ActionType
{
	AddOnly, // insert only
	UpdateAdd, // this is an upsert,
	Retrieve,
	Create,
	Delete,
	Perform // so far just used in clearing all data from an extension
}