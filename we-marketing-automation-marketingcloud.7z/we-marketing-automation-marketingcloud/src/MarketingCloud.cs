﻿using System.Net.Http.Headers;
using System.Security;
using MarketingCloudApi.Routes;

namespace MarketingCloudApi;

// register all the public objects so that they will be wired to their parent
public static class MarketingCloudExtension
{
	public static DataExtension DataExtension (
		this MarketingCloud marketingCloud
	)
	{
		return new DataExtension (marketingCloud);
	}

	public static Subscriber Subscriber (
		this MarketingCloud marketingCloud
	)
	{
		return new Subscriber (marketingCloud);
	}

	public static Tracking Tracking (
		this MarketingCloud marketingCloud
	)
	{
		return new Tracking (marketingCloud);
	}

	public static Contact Contact (
		this MarketingCloud marketingCloud
	)
	{
		return new Contact (marketingCloud);
	}

	public static Automation Automation (
		this MarketingCloud marketingCloud
	)
	{
		return new Automation (marketingCloud);
	}

	public static SourceEvent SourceEvent (
		this MarketingCloud marketingCloud
	)
	{
		return new SourceEvent (marketingCloud);
	}

	public static EntrySource EntrySource (
		this MarketingCloud marketingCloud
	)
	{
		return new EntrySource (marketingCloud);
	}

	public static Journey Journey (
		this MarketingCloud marketingCloud
	)
	{
		return new Journey (marketingCloud);
	}

	public static TransactionalMessage TransactionalMessage (
		this MarketingCloud marketingCloud
	)
	{
		return new TransactionalMessage (marketingCloud);
	}

	public static TransactionalDefinitions TransactionalDefinitions (
		this MarketingCloud marketingCloud
	)
	{
		return new TransactionalDefinitions (marketingCloud);
	}

	public static Assets Assets (
		this MarketingCloud marketingCloud
	)
	{
		return new Assets (marketingCloud);
	}

	public static AttributeSet AttributeSet (
		this MarketingCloud marketingCloud
	)
	{
		return new AttributeSet (marketingCloud);
	}

	public static AttributeGroup AttributeGroup (
		this MarketingCloud marketingCloud
	)
	{
		return new AttributeGroup (marketingCloud);
	}

	public static DomainVerification DomainVerification (
		this MarketingCloud marketingCloud
	)
	{
		return new DomainVerification (marketingCloud);
	}
}

public class MarketingCloud
{
	public MarketingCloud (
		AuthParams credentials
	)
	{
		Credentials = credentials;
		soapClient.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue
		{
			NoCache = true
		};
	}

	// they can be input but we don't want anything outside of this reading it
	public AuthParams Credentials { internal get; set; }

	internal AccessTokenInfo? accessTokenInfo { get; set; }
	internal DateTime authLastRefreshTime = DateTime.MinValue;
	internal int authRefreshIntervalMinutes = 10;

	internal static HttpClient authClient = new ();
	internal static HttpClient restClient = new ();

	internal static HttpClient soapClient = new ()
	{
		Timeout = TimeSpan.FromMinutes (10)
	};

	// once set, i don't want to allow anyone to get the sensitive parts of the credentials, but setting accountId dynamically is necessary
	// this is not needed in the initial auth setting - only if a change is desired
	public void SetAccountId (
		string accountId
	)
	{
		if (Credentials == null)
		{
			throw new SecurityException ($"[{Utils.GetCurrentMethodName ()}] Credentials have not been loaded");
		}

		Credentials.AccountId = accountId;
	}

	internal async Task<AccessTokenInfo> retrieveAccessInfo (
	)
	{
		if (Credentials == null)
		{
			throw new SecurityException ($"[{Utils.GetCurrentMethodName ()}] Credentials have not been loaded");
		}

		if (accessTokenInfo != null && authLastRefreshTime.AddMinutes (authRefreshIntervalMinutes) > DateTime.Now)
		{
			return accessTokenInfo;
		}

		try
		{
			var tokenRequest = new GetTokenRequest (
				Credentials.AccountId,
				Credentials.ClientId,
				Credentials.ClientSecret,
				Credentials.GrantType
			);

			var request = new HttpRequestMessage (HttpMethod.Post, Credentials.BaseUri + Rest.GET_AUTH_TOKEN)
			{
				Content = new StringContent (JsonConvert.SerializeObject (tokenRequest))
			};
			request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse ("application/json");

			HttpResponseMessage? response = null;

			try
			{
				response = await authClient.SendAsync (request);
			}
			catch (Exception oops)
			{
				throw new Exception (
					$"[{Utils.GetCurrentMethodName ()}] Error getting auth response for account id {Credentials.AccountId} : {oops.Message}",
					oops
				);
			}

			if (response == null)
			{
				throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting auth response. No response returned for account id {Credentials.AccountId}");
			}

			if (response.IsSuccessStatusCode == false)
			{
				throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to get auth token from MarketingCloud for account id {Credentials.AccountId}. {response.StatusCode} {response.ReasonPhrase}");
			}

			var responseValue = JsonConvert.DeserializeObject<GetTokenResponse> (await response.Content.ReadAsStringAsync ());

			if (responseValue == null)
			{
				throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Auth response from MarketingCloud succeeded but returned nothing for account id {Credentials.AccountId}");
			}

			accessTokenInfo = new AccessTokenInfo (
				responseValue.SoapInstanceUrl!,
				responseValue.RestInstanceUrl!,
				responseValue.AccessToken!
			);

			// go ahead and adapt to the "expires_in" result. it's in seconds, we use minutes, so...
			if (responseValue.ExpiresIn != null)
			{
				authRefreshIntervalMinutes = responseValue.ExpiresIn.Value / 60; // i'm ok with the integer operation here possibly truncating the value down.
			}

			//set the last refresh time to now
			authLastRefreshTime = DateTime.Now;

			return accessTokenInfo;
		}
		catch (Exception oops)
		{
			throw new Exception (
				$"[{Utils.GetCurrentMethodName ()}] Unable to authenticate against MarketingCloud for account id {Credentials.AccountId} : {oops.Message}",
				oops
			);
		}
	}

	internal async Task<HttpResponseMessage> sendRestRequest (
		HttpMethod method,
		string routePath,
		string? payload = null
	)
	{
		AccessTokenInfo? accessInfo;

		accessInfo = await retrieveAccessInfo ();

		// avoid double slashes
		if (accessInfo.RestUri.EndsWith ('/') && routePath.StartsWith ('/'))
		{
			routePath = routePath.TrimStart ('/');
		}

		var request = new HttpRequestMessage (method, accessInfo.RestUri + routePath);

		if (!string.IsNullOrEmpty (payload))
		{
			request.Content = new StringContent (payload);
			request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse ("application/json");
		}

		request.Headers.Authorization = new AuthenticationHeaderValue ("Bearer", accessInfo.AccessToken);

		//_restClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessInfo.AccessToken);

		return await restClient.SendAsync (request);
	}
}
