namespace MarketingCloudApi;

[AttributeUsage (AttributeTargets.Property)]
public class BindingNameAttribute : System.Attribute
{
	public BindingNameAttribute (
		string name
	) {
		Name = name;
	}

	public string Name { get; set; }
}
