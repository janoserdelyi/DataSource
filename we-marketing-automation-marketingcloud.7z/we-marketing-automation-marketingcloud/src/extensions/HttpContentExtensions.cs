
namespace MarketingCloudApi;

// this is goofy. i could not find where the HttpContent.ReadAsync<T>() extension was. so this is temporary. i think
public static class HttpContentExtensions
{

	public static async Task<T> ReadAsJsonAsync<T> (this HttpContent content)
	{
		var json = await content.ReadAsStringAsync ();

		T value = JsonConvert.DeserializeObject<T> (json)!;

		return value;
	}
}
