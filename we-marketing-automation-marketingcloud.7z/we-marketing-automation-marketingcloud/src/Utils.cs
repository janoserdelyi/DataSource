using System.Diagnostics;
using System.Reflection;
using System.Runtime.Serialization;

namespace MarketingCloudApi;

public static partial class Utils
{
	// Returns the EnumMemberAttribute value, or .ToString() fallback
	public static string EnumMemberValue<T> (T enumValue) where T : Enum
	{
		var memberInfo = typeof (T).GetMember (enumValue.ToString ()).FirstOrDefault ();
		var attribute = memberInfo?.GetCustomAttribute<EnumMemberAttribute> ();
		return attribute?.Value ?? enumValue.ToString ();
	}

	public static JsonSerializerSettings StandardJsonSerializerSettings = new ()
	{
		NullValueHandling = NullValueHandling.Ignore,
		Formatting = Formatting.Indented
	};

	public static string? GetCurrentMethodName ()
	{
		var stackTrace = new StackTrace ();
		StackFrame? stackFrame = stackTrace.GetFrame (1);

		return stackFrame?.GetMethod ()?.Name;
	}

#if NET8_0_OR_GREATER
	// generating the regex at compile time
	[System.Text.RegularExpressions.GeneratedRegex (@"[&!@#$%'^*()=\[\]{}.<>/\\"":?|,+\s]+")]
	private static partial System.Text.RegularExpressions.Regex marketingCloudNameRegex ();
	public static string NormalizeMarketingCloudName (
		string dataExtensionName
	)
	{
		return marketingCloudNameRegex ().Replace (dataExtensionName, " ").Trim ();
	}
#else
	public static string NormalizeMarketingCloudName (
		string dataExtensionName
	) {
		return System.Text.RegularExpressions.Regex.Replace (dataExtensionName, @"[&!@#$%'^*()=\[\]{}.<>/\\"":?|,+\s]+", " ").Trim ();
	}
#endif

	internal static async Task<string> getResponseString (
		AccessTokenInfo accessInfo,
		string payload
	)
	{
		// testing a sad cache-buster
		var cachebuster = ""; //"?c=" + DateTime.Now.Ticks.ToString();

		using var request = new HttpRequestMessage (HttpMethod.Post, accessInfo.SoapUri + Routes.Soap.SERVICE_ENDPOINT + cachebuster);
		request.Headers.Add ("Authorization", $"Bearer {accessInfo.AccessToken}");
		request.Content = getStandardXmlContent (payload);

		HttpResponseMessage? response = null;

		try
		{
			response = await MarketingCloud.soapClient.SendAsync (request);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{GetCurrentMethodName ()}] Error getting auth response : {oops.Message}", oops);
		}

		if (response.IsSuccessStatusCode == false)
		{
			var exceptionMessage = $"[{GetCurrentMethodName ()}] Request failed.  {response.StatusCode} {response.ReasonPhrase}";

			if (response.StatusCode == HttpStatusCode.RequestEntityTooLarge)
			{
				throw new WebException ($"[{GetCurrentMethodName ()}] RequestEntityTooLarge", new Exception (exceptionMessage));
			}

			throw new Exception (exceptionMessage);
		}

		var responseValue = await response.Content.ReadAsStringAsync ();

		if (responseValue == null)
		{
			throw new Exception ($"[{GetCurrentMethodName ()}] No response returned");
		}

		return responseValue;
	}

	private static StringContent getStandardXmlContent (
		string payload
	)
	{
		return new StringContent (
			payload,
			Encoding.UTF8,
			"text/xml"
		);
	}

	// convert a strongly typed object to a Dictionary that the DataExtension Add methods need
	internal static Dictionary<string, string?> objectToDictionary<T> (T obj) where T : class
	{

		if (
			typeof (T) == typeof (IDictionary<string, string?>) ||
			typeof (T) == typeof (Dictionary<string, string?>)
		)
		{
			return (obj as Dictionary<string, string?>)!;
		}

		var dict = new Dictionary<string, string?> ();

		foreach (var prop in obj.GetType ().GetProperties ())
		{

			var attr = Attribute.GetCustomAttribute (prop, typeof (BindingNameAttribute));

			string? attrName = null;

			if (attr != null)
			{
				attrName = ((BindingNameAttribute)attr)?.Name;
			}

			var propName = attrName ?? prop.Name;

			dict.Add (propName, prop.GetValue (obj)?.ToString ());
		}

		return dict;
	}

	// intended to be used to convert DataExtensionObject.Properties to a strongly typed class
	public static T DictionaryToObject<T> (
		Dictionary<string, string?> dict
	) where T : class, new()
	{

		var obj = new T ();
		var objtype = obj.GetType ();

		// get any props that have a bindingname. i need to swap it out in the dict
		foreach (var prop in obj.GetType ().GetProperties ())
		{
			var attr = Attribute.GetCustomAttribute (prop, typeof (BindingNameAttribute));

			if (attr == null)
			{
				continue;
			}

			var attrName = ((BindingNameAttribute)attr).Name;

			// get the attrName value, remove that key/value add new key/value to the dict
			// not removing old key. waste of effort for no gain
			var val = dict[attrName];
			if (dict.ContainsKey (prop.Name))
			{
				dict[prop.Name] = val;
			}
			else
			{
				dict.Add (prop.Name, val);
			}
		}

		foreach (var kvp in dict)
		{
			var prop = objtype.GetProperty (kvp.Key);

			if (prop == null)
			{
				continue;
			}

			Type t = Nullable.GetUnderlyingType (prop.PropertyType) ?? prop.PropertyType;
			var val = kvp.Value;

			if (t == typeof (DateTime))
			{
				if (val != null && val.Trim () == "")
				{
					val = null;
				}
			}

			var safeValue = (val == null) ? null : Convert.ChangeType (val, t);
			prop.SetValue (obj, safeValue);
		}

		return obj;
	}

	public static List<IDictionary<string, string?>> ConvertToPayload<T> (
		List<T> uploadObjects
	) where T : class
	{
		List<IDictionary<string, string?>> convertedList = [];

		if (uploadObjects.Count == 0)
		{
			return convertedList;
		}

		var firstItem = uploadObjects[0];

		if (firstItem is IDictionary<string, string?>)
		{
			// i need to ensure that it's a fully new list of objects. the List will be ByVal, but the contents are ByRef when using Linq. this is problematic
			// DO NOT convert this to Linq .ToList()!
			uploadObjects.ForEach ((x) => convertedList.Add ((x as IDictionary<string, string?>)!));
		}
		else if (firstItem is IDictionary<string, object?>)
		{
			// ditto ^^^
			uploadObjects.ForEach ((x) =>
			{
				var dict = new Dictionary<string, string?> ();
				foreach (var kvp in (x as IDictionary<string, object?>)!)
				{
					dict[kvp.Key] = kvp.Value switch
					{
						DateTime dt => dt.ToString ("yyyy-MM-dd HH:mm:ss.fff"),
						DateTimeOffset dt => dt.ToString ("yyyy-MM-dd HH:mm:ss.fff"),
						bool b => b.ToString ().ToLower (),
						null => null,
						_ => kvp.Value.ToString ()
					};
				}

				convertedList.Add (dict);
			});
		}
		else
		{
			uploadObjects.ForEach ((x) => convertedList.Add (objectToDictionary<T> (x)));
		}

		return convertedList;
	}

	// ===================================================================================================================================
	// these really belong in a utility library outside of Marketing Cloud
	// ===================================================================================================================================
	public static string GetNoConflictValue (
		Func<string, bool> existenceChecker
	)
	{
		var keylength = 4;
		var collisions = 0;
		var val = GeneratePassword (false, keylength);

		while (existenceChecker (val))
		{
			collisions++;
			if (collisions > 2)
			{
				keylength++;
				collisions = 0;
			}

			val = GeneratePassword (false, keylength);
		}

		return val;
	}

	public static async Task<string> GetNoConflictValue (
		Func<string, Task<bool>> existenceChecker
	)
	{
		var keylength = 4;
		var collisions = 0;
		var val = GeneratePassword (false, keylength);

		while (await existenceChecker (val))
		{
			collisions++;
			if (collisions > 2)
			{
				keylength++;
				collisions = 0;
			}

			val = GeneratePassword (false, keylength);
		}

		return val;
	}

	public static string GeneratePassword (
		bool isCaseSensitive,
		int length
	)
	{
		var allowedChars = "abcdefghijkmnopqrstuvwxyz0123456789";
		if (isCaseSensitive)
		{
			allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
		}

		return GenerateRandomValue (length, allowedChars);
	}

	public static string GenerateNumericCode (
		int length
	)
	{
		return GenerateRandomValue (length, "0123456789");
	}

	public static string GenerateRandomValue (
		int length,
		string allowedChars
	)
	{
		var genLen = length;
		if (length < 4)
		{
			genLen = 4;
		}

		var randomBytes = new byte[genLen];
		var chars = new char[length];
		var allowedCharCount = allowedChars.Length;

		// System.Security.Cryptography.RNGCryptoServiceProvider is obsoleted in .net 7+
#if NET7_0_OR_GREATER

		var seed = System.Security.Cryptography.RandomNumberGenerator.GetInt32 (int.MaxValue);

		var random = new Random (seed);

		for (var i = 0; i < length; i++)
		{
			chars[i] = allowedChars[random.Next (0, allowedChars.Length - 1)];
		}

#else

		System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider ();
		rng.GetBytes (randomBytes);

		// Convert 4 bytes into a 32-bit integer value.
		int seed = (randomBytes[0] & 0x7f) << 24 |
					randomBytes[1] << 16 |
					randomBytes[2] << 8 |
					randomBytes[3];

		Random random = new Random (seed);

		for (int i = 0; i < length; i++) {
			chars[i] = allowedChars[(int)randomBytes[i] % allowedCharCount];
		}

#endif

		return new string (chars);
	}
}
