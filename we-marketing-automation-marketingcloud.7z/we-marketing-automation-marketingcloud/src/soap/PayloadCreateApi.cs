using System.Xml;
using MarketingCloudApi.Elements;
using MarketingCloudApi.Enums;
using MarketingCloudApi.Models;

namespace MarketingCloudApi.Soap;

// here's i'm looking to generate payloads only (parsing is in PayloadParseApi), not execute the network activity (yet)
// actual network calls for auth and data requests can certainly be added in here to pile on further to these helper methods
// payload parsing will likely be static methods. no need to feed in things like subdomains and access tokens to simply rip it apart. i just want to call Api.ParseSomething(resultOfSoapRequest);
public class PayloadCreateApi
{
	public PayloadCreateApi (
		string subdomain,
		string accessToken,
		XmlWriterSettings? settings = null
	)
	{
		Subdomain = subdomain;
		AccessToken = accessToken;

		if (settings != null)
		{
			Settings = settings;
		}
	}

	public string Subdomain { get; private set; }
	public string AccessToken { get; private set; }

	public XmlWriterSettings Settings { get; set; } = new XmlWriterSettings ()
	{
		Indent = true,
		IndentChars = "\t",
		OmitXmlDeclaration = false
	};

	// update data extension name
	public string? UpdateDataExtensionName (
		string clientId,
		string dataExtensionObjectId,
		string newDataExtensionName
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			ClientId = clientId,
			ObjectId = dataExtensionObjectId,
			CustomerKey = newDataExtensionName,
			Name = newDataExtensionName
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? UpdateDataExtensionRetention (
		string clientId,
		string dataExtensionObjectId,
		Enums.DataRetentionPeriod? dataRetentionPeriod = null,
		int? dataRetentionPeriodLength = null,
		bool? rowBasedRetention = null,
		bool? resetRetentionPeriodOnImport = null,
		bool? deleteAtEndOfRetentionPeriod = null,
		DateTimeOffset? retainUntil = null
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			ClientId = clientId,
			ObjectId = dataExtensionObjectId,
			DataRetentionPeriod = dataRetentionPeriod?.ToString (),
			DataRetentionPeriodLength = dataRetentionPeriodLength,
			RowBasedRetention = rowBasedRetention,
			ResetRetentionPeriodOnImport = resetRetentionPeriodOnImport,
			DeleteAtEndOfRetentionPeriod = deleteAtEndOfRetentionPeriod,
			RetainUntil = retainUntil
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	// CreateDataExtension
	public string? CreateDataExtension (
		string clientId,
		string customerKey,
		string name,
		bool isSendable,
		IList<Field> fields,
		SendableDataExtensionField? sendableDataExtensionField = null,
		SendableSubscriberField? sendableSubscriberField = null,
		int? categoryId = null,
		string? templateCustomerKey = null

	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new CreateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			ClientId = clientId,
			CustomerKey = customerKey,
			Name = name,
			IsSendable = isSendable,
			SendableDataExtensionField = sendableDataExtensionField,
			SendableSubscriberField = sendableSubscriberField,
			Fields = fields,
			CategoryID = categoryId,
			TemplateCustomerKey = templateCustomerKey

		};
		if (!string.IsNullOrEmpty (templateCustomerKey))
		{
			payloadobject.TemplateCustomerKey = templateCustomerKey;
		}

		((CreateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? AddFieldsToDataExtension (
		string customerKey,
		IList<Field> fields
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			CustomerKey = customerKey,
			Fields = fields
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? UpdateFieldsInDataExtension (
		string customerKey,
		IList<Field> fields
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		// you cannot updat the data type on a field
		// even if the data type matches, if it's passed in this call will error if the data type is included in the payload :/
		// null out the FieldType
		fields = fields.Select (x =>
		{
			x.FieldType = null;
			return x;
		}).ToList ();

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			CustomerKey = customerKey,
			Fields = fields
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/deleting_a_row_from_a_data_extension_via_the_web_service_api.html
	// it appears the documentation is wrong. gahhhh
	// Type = DataExtension, not DataExtensionObject
	// also instead of submitting Keys collection, submit Fields -> Field -> ObjectID (objectid of the fields to delete)
	public string? DeleteFieldsFromDataExtension (
		string customerKey,
		IList<Field> fields
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new DeleteRequest ()
			}
		};

		// the fields passed into this are a just a key/value pair of field name/field object id
		//var fieldDict = fields.ToDictionary(x=> x.Name, x => x.ObjectId );

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			CustomerKey = customerKey,
			Fields = fields
		};

		((DeleteRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? DeleteDataExtension (
		string dataExtensionCustomerKey
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Delete
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new DeleteRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "DataExtension",
			CustomerKey = dataExtensionCustomerKey
		};

		((DeleteRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	// this is adding only. any conflicting records will error - not an upsert
	public string? AddDataToExtension (
		string dataExtensionKey,
		IList<IDictionary<string, string?>> uploadObjects
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.AddOnly
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new CreateRequest ()
			}
		};

		foreach (var record in uploadObjects)
		{
			((CreateRequest)envelope.Body.Request).Objects.Add (new Objects
			{
				Type = "DataExtensionObject",
				CustomerKey = dataExtensionKey,
				Properties = record
			});
		}

		return writePayload (envelope, Settings);
	}

	public string? UpdateDataInExtension (
		string dataExtensionKey,
		IList<IDictionary<string, string?>> uploadObjects
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.UpdateAdd
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		foreach (var record in uploadObjects)
		{
			((UpdateRequest)envelope.Body.Request).Objects.Add (new Objects
			{
				Type = "DataExtensionObject",
				CustomerKey = dataExtensionKey,
				Properties = record
			});
		}

		return writePayload (envelope, Settings);
	}

	public string? DeleteDataFromExtension (
		string dataExtensionKey,
		IDictionary<string, string> keysAndValues
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Delete
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new DeleteRequest ()
			}
		};

		((DeleteRequest)envelope.Body.Request).Objects.Add (new Objects
		{
			Type = "DataExtensionObject",
			CustomerKey = dataExtensionKey,
			Keys = keysAndValues
		});

		return writePayload (envelope, Settings);
	}

	public string? ClearAllDataInDataExtension (
		string dataExtensionKey
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Perform
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new PerformRequest ()
			}
		};

		((PerformRequest)envelope.Body.Request).Action = PerformAction.ClearData;
		((PerformRequest)envelope.Body.Request).Definitions.Add (new Definition
		{
			Type = "DataExtension",
			CustomerKey = dataExtensionKey
		});

		return writePayload (envelope, Settings);
	}

	public string? RetrieveDataExtensionTemplates (DataExtensionTemplateFilter? filter)
	{

		var retrieveRequest = new RetrieveRequest
		{
			ObjectType = "DataExtensionTemplate",
			Properties =
			[
				"ObjectID", "CustomerKey", "Name", "CreatedDate", "ModifiedDate",
				"Client.ID", "Description", "IsSendable", "IsTestable",
				"SendableCustomObjectField", "SendableSubscriberField",
				"DataRetentionPeriodLength", "DataRetentionPeriodUnitOfMeasure",
				"RowBasedRetention", "ResetRetentionPeriodOnImport",
				"DeleteAtEndOfRetentionPeriod", "RetainUntil"
			]
		};

		if (filter != null && !string.IsNullOrEmpty (filter.Value))
		{
			retrieveRequest.Filter = new SimpleFilterPart
			{
				Type = "SimpleFilterPart",
				Property = filter.Field.ToString (), // enum value like Name, CustomerKey, etc.
				SimpleOperator = SimpleOperator.equals,
				Value = [filter.Value],
				ElementName = "Filter"
			};
		}

		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = retrieveRequest
				}
			}
		};
		return writePayload (envelope, Settings);
	}

	public string? GetDataExtension (
		IList<string> fields,
		IFilterPart filter
	)
	{

		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = "DataExtension",
						Properties = fields,
						Filter = filter
					}
				}
			}
		};

		return writePayload (envelope, Settings);
	}

	public string? GetDataExtensionByCustomerKey (
		string dataExtensionKey,
		IList<string> fields
	)
	{

		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = "DataExtension",
						Properties = fields,
						Filter = new SimpleFilterPart
						{
							Property = "CustomerKey",
							SimpleOperator = SimpleOperator.equals,
							Value = [dataExtensionKey]
						}
					}
				}
			}
		};

		return writePayload (envelope, Settings);
	}

	public string? GetFieldsForDataExtension (
		string dataExtensionKey, // object id
		IList<string>? fields = null
	)
	{

		if (fields == null || fields.Count == 0)
		{
			fields = new List<string> () { "CustomerKey", "Name", "ObjectID", "FieldType", "MaxLength", "IsRequired", "IsPrimaryKey", "Ordinal", "Scale" };
		}

		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = "DataExtensionField",
						Properties = fields,
						Filter = new SimpleFilterPart
						{
							Property = "DataExtension.CustomerKey",
							SimpleOperator = SimpleOperator.equals,
							Value = new string[] { dataExtensionKey }
						}
					}
				}
			}
		};

		return writePayload (envelope, Settings);
	}

	// TODO : i think this is mis-named. this is doing what GetDataExtensionPayload does. i need to change it to get data
	public string? GetDataFromExtension (
		string dataExtensionKey,
		IList<string> fields,
		IFilterPart? filter = null,
		string? continueRequestId = null
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = $"DataExtensionObject[{dataExtensionKey}]",
						Properties = fields,
						ContinueRequest = continueRequestId
					}
				}
			}
		};

		if (filter != null)
		{
			((RetrieveRequestMsg)envelope.Body.Request).RetrieveRequest!.Filter = filter;
		}

		return writePayload (envelope, Settings);
	}

	public string? CreateSubscriber (
		string customerKey,
		string emailAddress,
		IList<Elements.Attribute>? attributes = null
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new CreateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "Subscriber",
			CustomerKey = customerKey,
			EmailAddress = emailAddress,
			Attributes = attributes
		};

		((CreateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? UpdateSubscriber (
		string customerKey,
		string emailAddress,
		IList<Elements.Attribute>? attributes = null
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "Subscriber",
			CustomerKey = customerKey,
			EmailAddress = emailAddress,
			Attributes = attributes
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? ActivateSubscriber (
		string subscriberKey
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		var payloadobject = new Objects
		{
			Type = "Subscriber",
			SubscriberKey = subscriberKey,
			Status = "Active",
			Action = "Update"
		};

		((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);

		return writePayload (envelope, Settings);
	}

	public string? ActivateSubscriber (
		IList<string> subscriberKeys
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new UpdateRequest ()
			}
		};

		foreach (var subscriberKey in subscriberKeys)
		{
			var payloadobject = new Objects
			{
				Type = "Subscriber",
				SubscriberKey = subscriberKey,
				Status = "Active",
				Action = "Update"
			};

			((UpdateRequest)envelope.Body.Request).Objects.Add (payloadobject);
		}

		return writePayload (envelope, Settings);
	}

	// // https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/unsubscribing_and_logging_an_unsubevent_with_a_logunsubevent_execute_call.html
	public string? UnsubscribeSubscriber (
		string subscriberKey
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Create
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new ExecuteRequest ()
			}
		};

		var requestBody = new Requests ()
		{
			Name = "LogUnsubEvent"
		};
		requestBody.Parameters.Add (new Parameters ("SubscriberKey", subscriberKey));
		// a post i saw said to set the following to an empty string to global unsub the record
		requestBody.Parameters.Add (new Parameters ("JobID", ""));
		requestBody.Parameters.Add (new Parameters ("ListID", ""));
		requestBody.Parameters.Add (new Parameters ("BatchID", ""));

		((ExecuteRequest)envelope.Body.Request).Requests = requestBody;

		return writePayload (envelope, Settings);
	}

	// delete a subscriber
	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/deleting_a_subscriber.html
	public string? DeleteSubscriber (
		string subscriberKey
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Delete
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new DeleteRequest ()
			}
		};

		((DeleteRequest)envelope.Body.Request).Objects.Add (new Objects ()
		{
			Type = "Subscriber",
			SubscriberKey = subscriberKey
		});

		return writePayload (envelope, Settings);
	}

	public string? GetSubscribers (
		IList<string> fields,
		IFilterPart filter,
		string? continueRequestId = null
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = "Subscriber",
						Properties = fields,
						ContinueRequest = continueRequestId,
						Filter = filter
					}
				}
			}
		};

		return writePayload (envelope, Settings);
	}

	public string? GetSubscriberByKey (
		string subscriberKey,
		IList<string> fields
	)
	{
		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = "Subscriber",
						Properties = fields
					}
				}
			}
		};

		((RetrieveRequestMsg)envelope.Body.Request).RetrieveRequest!.Filter = new SimpleFilterPart ()
		{
			Property = "SubscriberKey",
			SimpleOperator = SimpleOperator.equals,
			Value = new string[] { subscriberKey }
		};

		return writePayload (envelope, Settings);
	}

	public string? GetTrackingData (
		TrackingType trackingType,
		IList<string>? fields = null,
		IFilterPart? filter = null,
		string? continueRequestId = null
	)
	{

		// a default set will be used based on the documentation. if you want others, pass them in!
		if (fields == null || fields.Count == 0)
		{
			// removing ListID. some articles show it as an option but the docs don't include it
			// meanwhile the docs show "CorrelationID" but the request pukes on it
			// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/sentevent.html
			// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/openevent.html
			fields = new List<string> { "Client.ID", "TriggeredSendDefinitionObjectID", "SendID", "SubscriberKey", "EventDate", "EventType", "BatchID" };

			switch (trackingType)
			{
				case TrackingType.SentEvent:
					fields.Add ("ListID");
					break;
				case TrackingType.OpenEvent:
				case TrackingType.ClickEvent:
					fields.Add ("ObjectId");
					break;
				case TrackingType.BounceEvent:
					fields.Add ("SMTPCode");
					fields.Add ("SMTPReason");
					break;
				case TrackingType.UnsubEvent:
					fields.Add ("IsMasterUnsubscribed");
					break;
			}
		}

		var envelope = new Envelope
		{
			Header = new Header
			{
				Action = new Elements.Action
				{
					MustUnderstand = 1,
					Text = ActionType.Retrieve
				},
				To = new To
				{
					MustUnderstand = 1,
					Text = Routes.Soap.ENDPOINT_URL_PATTERN.Replace ("{{et_subdomain}}", Subdomain)
				},
				Fueloauth = new Fueloauth
				{
					Xmlns = "http://exacttarget.com",
					Text = AccessToken
				}
			},
			Body = new Body
			{
				Request = new RetrieveRequestMsg
				{
					RetrieveRequest = new RetrieveRequest
					{
						ObjectType = Enum.GetName (typeof (TrackingType), trackingType),
						Properties = fields,
						ContinueRequest = continueRequestId
					}
				}
			}
		};

		if (filter != null)
		{
			((RetrieveRequestMsg)envelope.Body.Request).RetrieveRequest!.Filter = filter;
		}

		return writePayload (envelope, Settings);
	}

	private static string? writePayload (
		Envelope envelope,
		XmlWriterSettings settings
	)
	{
		if (envelope == null)
		{
			return null;
		}

		using var stw = new Utf8StringWriter ();
		using var writer = XmlWriter.Create (stw, settings);
		envelope.WriteXml (writer);
		writer.Close ();
		return stw.ToString ();
	}
}

// left to its own, the xml writing will default to utf-16
public class Utf8StringWriter : StringWriter
{
	public override System.Text.Encoding Encoding
	{
		get { return Encoding.UTF8; }
	}
}

