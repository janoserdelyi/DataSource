using System.Xml;
using System.Xml.XPath;

using MarketingCloudApi.Elements;
using MarketingCloudApi.Enums;

namespace MarketingCloudApi.Soap;

// here i'm looking to parse payloads only (creating payloads is in PayloadCreateApi), not execute the network activity (yet)
// actual network calls for auth and data requests can certainly be added in here to pile on further to these helper methods
// payload parsing will likely be static methods. no need to feed in things like subdomains and access tokens to simply rip it apart. i just want to call Api.ParseSomething(resultOfSoapRequest);
public static class PayloadParseApi
{
	private static XPathNavigator getNavigator (
		string payload
	)
	{
		using TextReader payloadtextreader = new StringReader (payload);
		using var xmlreader = XmlReader.Create (payloadtextreader);
		var doc = new XPathDocument (xmlreader);
		XPathNavigator nav = doc.CreateNavigator ();

		return nav;
	}

	public static DataExtensionDataResponse DataExtensionData (
		string payload
	)
	{

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);

		var response = new DataExtensionDataResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return response;
		}

		// now that we know we have something, let's make sure that the results are not null
		response.Results = new List<DataExtensionObject> ();

		foreach (XPathNavigator result in results)
		{

			var deo = new DataExtensionObject ();

			XPathNodeIterator? properties = result.Select ("epa:Properties/epa:Property", nsmgr);

			foreach (XPathNavigator property in properties)
			{
				deo.Properties.Add (
					property.SelectSingleNode ("epa:Name", nsmgr)?.Value!,
					property.SelectSingleNode ("epa:Value", nsmgr)?.Value!
				);
			}

			response.Results.Add (deo);
		}

		return response;
	}

	public static DataExtensionTemplateResponse ParseDataExtensionTemplates (string xml)
	{
		var templates = new List<DataExtensionTemplate> ();

		var xmlDoc = new XmlDocument ();
		xmlDoc.LoadXml (xml);

		var nsmgr = new XmlNamespaceManager (xmlDoc.NameTable);
		nsmgr.AddNamespace ("soap", "http://www.w3.org/2003/05/soap-envelope");
		nsmgr.AddNamespace ("epa", "http://exacttarget.com/wsdl/partnerAPI");
		nsmgr.AddNamespace ("xsi", "http://www.w3.org/2001/XMLSchema-instance");

		// Select all Results nodes with xsi:type="DataExtensionTemplate"
		var resultsNodes = xmlDoc.SelectNodes ("//epa:Results[@xsi:type='DataExtensionTemplate']", nsmgr);

		if (resultsNodes != null)
		{
			foreach (XmlNode resultNode in resultsNodes)
			{
				var template = new DataExtensionTemplate
				{
					CustomerKey = resultNode["CustomerKey"]?.InnerText,
					Name = resultNode["Name"]?.InnerText,
					Description = resultNode["Description"]?.InnerText
				};

				if (DateTime.TryParse (resultNode["CreatedDate"]?.InnerText, out DateTime createdDate))
				{
					template.CreatedDate = createdDate;
				}

				if (DateTime.TryParse (resultNode["ModifiedDate"]?.InnerText, out DateTime modifiedDate))
				{
					template.ModifiedDate = modifiedDate;
				}

				templates.Add (template);
			}
		}

		return new DataExtensionTemplateResponse ()
		{
			Results = templates
		};
	}

	public static DataExtensionInsertUpdateResponse InsertUpdateDataInDataExtension (
		string primaryKeyFieldName,
		string payload
	)
	{
		return InsertUpdateDataInDataExtension (
			new List<string> { primaryKeyFieldName },
			payload
		);
	}

	public static DataExtensionInsertUpdateResponse InsertUpdateDataInDataExtension (
		IList<string> primaryKeyFieldNames,
		string payload
	)
	{
		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		var response = new DataExtensionInsertUpdateResponse ();

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				var status = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;

				if (status == null)
				{
					continue;
				}

				var statusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
				if (!int.TryParse (result.SelectSingleNode ("epa:OrdinalID", nsmgr)?.Value, out var ordinal))
				{
					continue;
				}

				/*
				Look for Value where the parent has child Name with value 'SubscriberKey':
				//Value[../Name='SubscriberKey']
				*/
				var keyvalues = new List<string> ();

				foreach (var pkfieldname in primaryKeyFieldNames)
				{
					var keyvalue = result.SelectSingleNode ($"epa:Object/epa:Properties/epa:Property/epa:Value[../epa:Name='{pkfieldname}']", nsmgr)?.Value;

					if (keyvalue == null)
					{
						continue;
					}

					keyvalues.Add (keyvalue);
				}

				if (keyvalues.Count == 0)
				{
					// throw exception? the response will be wrong but the record in all likelyness did go to the DataExtension
					continue;
				}

				var dictionaryKey = string.Join (",", keyvalues);

				switch (status.ToLower ())
				{
					case "ok":
						if (response.Oks.ContainsKey (dictionaryKey))
						{
							break;
						}

						response.Oks.Add (dictionaryKey, new DataExtensionInsertUpdateResponseOk { StatusMessage = statusMessage, Ordinal = ordinal, SubscriberKey = dictionaryKey, Keys = keyvalues });
						break;
					case "error":
						if (response.Errors.ContainsKey (dictionaryKey))
						{
							break;
						}

						var errorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value;
						var errorMessage = result.SelectSingleNode ("epa:ErrorMessage", nsmgr)?.Value;
						response.Errors.Add (dictionaryKey, new DataExtensionInsertUpdateResponseError { StatusMessage = statusMessage, Ordinal = ordinal, SubscriberKey = dictionaryKey, ErrorCode = errorCode, ErrorMessage = errorMessage, Keys = keyvalues });
						break;
				}
			}
		}

		return response;
	}

	public static DataExtensionDeleteObjectResponse? DeleteDataFromDataExtension (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);

		var response = new DataExtensionDeleteObjectResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:DeleteResponse/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:DeleteResponse/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				var statusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;

				if (statusCode == null)
				{
					continue;
				}

				var deleteResp = new DataExtensionDeleteObjectResult
				{
					StatusCode = statusCode,
					StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value
				};

				if (int.TryParse (result.SelectSingleNode ("epa:OrdinalID", nsmgr)?.Value, out var ordinal))
				{
					deleteResp.OrdinalId = ordinal;
				}

				// if i were to load the Keys, this is where i would do it. I assume this structure is for acknowledging multiple row deletions
				XPathNodeIterator? keys = result.Select ("epa:Object/epa:Keys", nsmgr);

				foreach (XPathNavigator key in keys)
				{
					deleteResp.Keys.Add (
						key.SelectSingleNode ("epa:Key/epa:Name", nsmgr)?.Value!,
						key.SelectSingleNode ("epa:Key/epa:Value", nsmgr)?.Value!
					);
				}

				response.Results.Add (deleteResp);
			}
		}

		return response;
	}

	public static PerformResponse? ClearAllDataFromDataExtension (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);

		var response = new PerformResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:PerformResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:PerformResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				var status = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;

				if (status == null)
				{
					continue;
				}

				// var statusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
			}
		}

		return response;
	}

	public static DataExtensionResponse? DataExtensionRetrieve (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new DataExtensionResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{

				var objectIdNode = result.SelectSingleNode ("epa:ObjectID", nsmgr);
				var customerKeyNode = result.SelectSingleNode ("epa:CustomerKey", nsmgr);
				var nameNode = result.SelectSingleNode ("epa:Name", nsmgr);
				var isSendableNode = result.SelectSingleNode ("epa:IsSendable", nsmgr);

				// if there is no objectid, key, or name, this is not a legit response. skip
				if (
					objectIdNode == null ||
					customerKeyNode == null ||
					nameNode == null
				)
				{
					continue;
				}

				var dero = new DataExtensionResponseObject (
					objectIdNode.Value,
					customerKeyNode.Value,
					nameNode.Value,
					isSendableNode == null ? false : isSendableNode.Value == "true",
					null,
					null,
					null
				);

				var subscriberfield = result.SelectSingleNode ("epa:SendableSubscriberField/epa:Name", nsmgr)?.Value;

				if (subscriberfield != null)
				{
					dero.SendableSubscriberField = new SendableSubscriberField (subscriberfield);
				}

				var categoryId = result.SelectSingleNode ("epa:CategoryID", nsmgr)?.Value;
				var status = result.SelectSingleNode ("epa:Status", nsmgr)?.Value;

				if (categoryId != null)
				{
					dero.CategoryId = categoryId;
				}

				if (status != null)
				{
					dero.Status = status;
				}

				response.DataExtensions.Add (dero);
			}
		}

		return response;
	}

	public static DataExtensionCreateResponse? DataExtensionCreate (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new DataExtensionCreateResponse ();

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;
				response.StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
				response.ErrorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value;
				response.NewId = result.SelectSingleNode ("epa:NewID", nsmgr)?.Value;
				response.ClientId = result.SelectSingleNode ("epa:Object/epa:Client/epa:ID", nsmgr)?.Value;
				response.PartnerKey = result.SelectSingleNode ("epa:Object/epa:PartnerKey", nsmgr)?.Value;
				response.ObjectId = result.SelectSingleNode ("epa:Object/epa:ObjectID", nsmgr)?.Value;
				response.CustomerKey = result.SelectSingleNode ("epa:Object/epa:CustomerKey", nsmgr)?.Value;
				response.Name = result.SelectSingleNode ("epa:Object/epa:Name", nsmgr)?.Value;
				response.IsSendable = result.SelectSingleNode ("epa:Object/epa:IsSendable", nsmgr)?.Value == "true";

				if (response.IsSendable == true)
				{
					response.SendableSubscriberField = new SendableSubscriberField (result.SelectSingleNode ("epa:Object/epa:SendableSubscriberField/epa:Name", nsmgr)?.Value!);
					response.SendableDataExtensionField = new SendableDataExtensionField
					{
						PartnerKey = result.SelectSingleNode ("epa:Object/epa:SendableDataExtensionField/epa:PartnerKey", nsmgr)?.Value,
						ObjectId = result.SelectSingleNode ("epa:Object/epa:SendableDataExtensionField/epa:ObjectID", nsmgr)?.Value,
						CustomerKey = result.SelectSingleNode ("epa:Object/epa:SendableDataExtensionField/epa:CustomerKey", nsmgr)?.Value,
						Name = result.SelectSingleNode ("epa:Object/epa:SendableDataExtensionField/epa:Name", nsmgr)?.Value,
						FieldType = result.SelectSingleNode ("epa:Object/epa:SendableDataExtensionField/epa:FieldType", nsmgr)?.Value
					};
				}

				// i don't see the value in regurgiating the Fields definition back in the response but we can do that here if needed

				break; // since i'm not yet handling the possible multi-result return i'm just breaking after the firt read
			}
		}

		return response;
	}

	public static DataExtensionFieldResponse? DataExtensionFields (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new DataExtensionFieldResponse ();

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{

				int? maxlength = null;
				if (int.TryParse (result.SelectSingleNode ("epa:MaxLength", nsmgr)?.Value, out var ml))
				{
					maxlength = ml;
				}

				// i'm pretty sure this cannot be returned. maxlength (ugh) is used in its stead
				int? precision = null;
				if (int.TryParse (result.SelectSingleNode ("epa:Precision", nsmgr)?.Value, out var pr))
				{
					precision = pr;
				}

				int? scale = null;
				if (int.TryParse (result.SelectSingleNode ("epa:Scale", nsmgr)?.Value, out var sc))
				{
					scale = sc;
				}

				response.Fields.Add (new Field (
					customerKey: result.SelectSingleNode ("epa:CustomerKey", nsmgr)?.Value!,
					name: result.SelectSingleNode ("epa:Name", nsmgr)?.Value!,
					fieldType: result.SelectSingleNode ("epa:FieldType", nsmgr)?.Value!,
					maxLength: maxlength,
					precision: precision,
					scale: scale,
					isRequired: result.SelectSingleNode ("epa:IsRequired", nsmgr)?.Value == "true",
					isPrimaryKey: result.SelectSingleNode ("epa:IsPrimaryKey", nsmgr)?.Value == "true",
					objectId: result.SelectSingleNode ("epa:ObjectID", nsmgr)?.Value
				));
			}
		}

		return response;
	}

	public static DataExtensionUpdateResponse? DataExtensionUpdate (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new DataExtensionUpdateResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:UpdateResponse/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:UpdateResponse/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;
				response.StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;

				// i don't see the value in regurgiating the Fields definition back in the response but we can do that here if needed

				// TODO: this should really change. this is bascially a per-field response
				break; // since i'm not yet handling the possible multi-result return i'm just breaking after the first read.
			}
		}

		return response;
	}

	public static DataExtensionDeleteResponse? DataExtensionDelete (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new DataExtensionDeleteResponse ();

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;
				response.StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
				response.ErrorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value;
				response.PartnerKey = result.SelectSingleNode ("epa:Object/epa:PartnerKey", nsmgr)?.Value;
				response.ObjectId = result.SelectSingleNode ("epa:Object/epa:ObjectID", nsmgr)?.Value;
				response.CustomerKey = result.SelectSingleNode ("epa:Object/epa:CustomerKey", nsmgr)?.Value;

				break; // since i'm not yet handling the possible multi-result return i'm just breaking after the first read
			}
		}

		return response;
	}

	public static SubscriberCreateUpdateResponse? SubscriberCreate (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new SubscriberCreateUpdateResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:CreateResponse/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:CreateResponse/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;
				response.StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
				response.ErrorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value;
				response.NewId = result.SelectSingleNode ("epa:NewID", nsmgr)?.Value;
				response.ObjectId = result.SelectSingleNode ("epa:Object/epa:ObjectID", nsmgr)?.Value;
				response.CustomerKey = result.SelectSingleNode ("epa:Object/epa:CustomerKey", nsmgr)?.Value;
				response.Name = result.SelectSingleNode ("epa:Object/epa:Name", nsmgr)?.Value;

				// i don't see the value in regurgiating the Attributes back in the response but we can do that here if needed

				break; // since i'm not yet handling the possible multi-result return i'm just breaking after the first read
			}
		}

		return response;
	}

	public static SubscriberActivateResponse SubscriberActivate (
		string payload
	)
	{

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new SubscriberActivateResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:UpdateResponse/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:UpdateResponse/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return response;
		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				var resp = new SubscriberActivateResponseResult
				{
					StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value,
					StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value,
					ErrorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value,
					Id = result.SelectSingleNode ("epa:Object/epa:ID", nsmgr)?.Value,
					SubscriberKey = result.SelectSingleNode ("epa:Object/epa:SubscriberKey", nsmgr)?.Value,
					Status = result.SelectSingleNode ("epa:Object/epa:Status", nsmgr)?.Value
				};

				response.Results.Add (resp);
			}
		}

		return response;
	}

	public static SubscriberDeleteResponse? SubscriberDelete (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new SubscriberDeleteResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:DeleteResponse/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:DeleteResponse/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.StatusCode = result.SelectSingleNode ("epa:StatusCode", nsmgr)?.Value;
				response.StatusMessage = result.SelectSingleNode ("epa:StatusMessage", nsmgr)?.Value;
				response.ErrorCode = result.SelectSingleNode ("epa:ErrorCode", nsmgr)?.Value;
				//response.Id = result.SelectSingleNode("epa:Object/epa:ID", nsmgr)?.Value;
				//response.SubscriberKey = result.SelectSingleNode("epa:Object/epa:SubscriberKey", nsmgr)?.Value;
				//response.Status = result.SelectSingleNode("epa:Object/epa:Status", nsmgr)?.Value;

				break; // since i'm not yet handling the possible multi-result return i'm just breaking after the first read
			}
		}

		return response;
	}

	public static SubscriberResponse? SubscriberGet (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new SubscriberResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{
			foreach (XPathNavigator result in results)
			{
				response.SubscriberKey = result.SelectSingleNode ("epa:SubscriberKey", nsmgr)?.Value;
				response.EmailAddress = result.SelectSingleNode ("epa:EmailAddress", nsmgr)?.Value;
				response.Status = result.SelectSingleNode ("epa:Status", nsmgr)?.Value;
				response.EmailTypePreference = result.SelectSingleNode ("epa:EmailTypePreference", nsmgr)?.Value;
				response.ClientId = result.SelectSingleNode ("epa:Client/epa:ID", nsmgr)?.Value;

				var createddate = result.SelectSingleNode ("epa:CreatedDate", nsmgr)?.Value;
				if (string.IsNullOrEmpty (createddate) == false && DateTime.TryParse (createddate, out DateTime cdate))
				{
					response.CreatedDate = cdate;
				}

				var unsubdate = result.SelectSingleNode ("epa:UnsubscribedDate", nsmgr)?.Value;
				if (string.IsNullOrEmpty (unsubdate) == false && DateTime.TryParse (unsubdate, out DateTime udate))
				{
					response.UnsubscribedDate = udate;
				}

				break;
			}
		}

		return response;
	}

	public static SubscribersResponse? SubscribersGet (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new SubscribersResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			// the request can be OK but not match anything
			return null;
		}

		// this can be changed to return a collection, but i think we should not be returning more than one result realistically
		if (results != null && results.Count > 1)
		{

		}

		if (results != null && results.Count > 0)
		{

			response.Results = [];

			foreach (XPathNavigator result in results)
			{
				var resp = new SubscriberResponse
				{
					SubscriberKey = result.SelectSingleNode ("epa:SubscriberKey", nsmgr)?.Value,
					EmailAddress = result.SelectSingleNode ("epa:EmailAddress", nsmgr)?.Value,
					Status = result.SelectSingleNode ("epa:Status", nsmgr)?.Value,
					EmailTypePreference = result.SelectSingleNode ("epa:EmailTypePreference", nsmgr)?.Value,
					ClientId = result.SelectSingleNode ("epa:Client/epa:ID", nsmgr)?.Value
				};

				var createddate = result.SelectSingleNode ("epa:CreatedDate", nsmgr)?.Value;
				if (string.IsNullOrEmpty (createddate) == false && DateTime.TryParse (createddate, out DateTime cdate))
				{
					resp.CreatedDate = cdate;
				}

				var unsubdate = result.SelectSingleNode ("epa:UnsubscribedDate", nsmgr)?.Value;
				if (string.IsNullOrEmpty (unsubdate) == false && DateTime.TryParse (unsubdate, out DateTime udate))
				{
					resp.UnsubscribedDate = udate;
				}

				response.Results.Add (resp);
			}
		}

		return response;
	}

	public static TrackingEventResponse? TrackingEventRetrieve (
		string payload
	)
	{
		if (payload == null)
		{
			return null;
		}

		var navigator = getNavigator (payload);

		var nsmgr = new XmlNamespaceManager (navigator.NameTable);
		nsmgr.AddNamespace ("soap", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		nsmgr.AddNamespace ("epa", XmlNamespaces.NAMESPACE_EXACTTARGET);
		nsmgr.AddNamespace ("xsi", XmlNamespaces.NAMESPACE_XSI);
		nsmgr.AddNamespace ("wsi", XmlNamespaces.NAMESPACE_ADDRESSING);
		nsmgr.AddNamespace ("wsu", XmlNamespaces.NAMESPACE_SECURITY);

		var response = new TrackingEventResponse
		{
			OverallStatus = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:OverallStatus", nsmgr)?.Value,
			RequestId = navigator.SelectSingleNode ("//soap:Body/epa:RetrieveResponseMsg/epa:RequestID", nsmgr)?.Value
		};

		XPathNodeIterator? results = navigator.Select ("//epa:Results", nsmgr);

		if (results == null || results.Count == 0)
		{
			return response;
		}

		if (results != null && results.Count > 0)
		{

			var tzi = TimeZoneInfo.FindSystemTimeZoneById ("America/Chicago");

			response.Results = new List<TrackingEventResult> ();

			foreach (XPathNavigator result in results)
			{

				var ter = new TrackingEventResult ();

				var trackingtype = result.GetAttribute ("type", XmlNamespaces.NAMESPACE_XSI);
				if (Enum.TryParse (trackingtype, out TrackingType tt))
				{
					ter.TrackingType = tt;
				}

				ter.ClientId = result.SelectSingleNode ("epa:Client/epa:ID", nsmgr)?.Value;

				var listid = result.SelectSingleNode ("epa:PartnerProperties/epa:Value[../epa:Name='ListID']", nsmgr)?.Value;
				if (int.TryParse (listid, out var lid))
				{
					ter.ListId = lid;
				}

				var sendid = result.SelectSingleNode ("epa:SendID", nsmgr)?.Value;
				if (int.TryParse (sendid, out var sid))
				{
					ter.SendId = sid;
				}

				ter.SubscriberKey = result.SelectSingleNode ("epa:SubscriberKey", nsmgr)?.Value;

				var eventdt = result.SelectSingleNode ("epa:EventDate", nsmgr)?.Value;
				if (DateTimeOffset.TryParse (eventdt, out DateTimeOffset edt))
				{
					if (edt.DateTime.Kind == DateTimeKind.Unspecified)
					{
						//Console.WriteLine(edt.ToString("o"));
						edt = new DateTimeOffset (edt.DateTime, tzi.BaseUtcOffset);
						//Console.WriteLine(edt.ToString("o"));
					}

					ter.EventDate = edt;
				}

				ter.EventType = result.SelectSingleNode ("epa:EventType", nsmgr)?.Value;
				ter.TriggeredSendDefinitionObjectId = result.SelectSingleNode ("epa:TriggeredSendDefinitionObjectID", nsmgr)?.Value;

				// var batchid = result.SelectSingleNode ("epa:BatchID", nsmgr)?.Value;

				if (int.TryParse (sendid, out var bid))
				{
					ter.BatchId = bid;
				}

				/*
				<PartnerProperties>
                    <Name>ObjectId</Name>
                    <Value>2167661848</Value>
                </PartnerProperties>
				*/
				var objectid = result.SelectSingleNode ("epa:PartnerProperties/epa:Value[../epa:Name='ObjectId']", nsmgr)?.Value;
				if (long.TryParse (objectid, out var obid))
				{
					ter.ObjectId = obid;
				}

				var smtpcode = result.SelectSingleNode ("epa:SMTPCode", nsmgr)?.Value;
				if (!string.IsNullOrEmpty (smtpcode))
				{
					if (smtpcode.Length > 3)
					{
						smtpcode = smtpcode.Substring (0, 3); // there are enhanced codes to extend standard codes. i do not want those
					}

					if (int.TryParse (smtpcode, out var smtpCode))
					{
						ter.SmtpCode = smtpCode;
					}
				}

				ter.SmtpReason = result.SelectSingleNode ("epa:SMTPReason", nsmgr)?.Value;

				var ismasterunsub = result.SelectSingleNode ("epa:IsMasterUnsubscribed", nsmgr)?.Value;
				if (bool.TryParse (ismasterunsub, out var imu))
				{
					ter.IsMasterUnsubscribed = imu;
				}

				response.Results.Add (ter);
			}
		}

		/*
<Results xsi:type=""SentEvent"">
    <EventDate>2024-01-14T09:40:33.18</EventDate>
</Results>
*/

		return response;
	}
}
