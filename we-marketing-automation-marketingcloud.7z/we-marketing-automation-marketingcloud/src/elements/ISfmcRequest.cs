namespace MarketingCloudApi.Elements;

public interface ISfmcRequest
{
	void WriteXml (System.Xml.XmlWriter writer);
}
