using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class Definition : IXmlSerializable
{
	public string ElementName { get; set; } = "Definition";
	public string Type { get; set; } = "DataExtension"; // possibly dangerous. so far only seen operations on DataExtensions though. subject to change
	public string? CustomerKey { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement (ElementName);
		writer.WriteAttributeString ("xsi", "type", XmlNamespaces.NAMESPACE_XSI, Type);

		if (CustomerKey != null)
		{
			writer.WriteStartElement ("CustomerKey");
			writer.WriteValue (CustomerKey);
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
