using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class SendableDataExtensionField : IXmlSerializable
{
	public string? PartnerKey { get; set; }
	public string? ObjectId { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public string? FieldType { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("SendableDataExtensionField");

		if (PartnerKey != null)
		{
			writer.WriteStartElement ("PartnerKey");
			writer.WriteValue (PartnerKey);
			writer.WriteEndElement ();
		}

		if (ObjectId != null)
		{
			writer.WriteStartElement ("ObjectId");
			writer.WriteValue (ObjectId);
			writer.WriteEndElement ();
		}

		if (CustomerKey != null)
		{
			writer.WriteStartElement ("CustomerKey");
			writer.WriteValue (CustomerKey);
			writer.WriteEndElement ();
		}

		if (Name != null)
		{
			writer.WriteStartElement ("Name");
			writer.WriteValue (Name);
			writer.WriteEndElement ();
		}

		if (FieldType != null)
		{
			writer.WriteStartElement ("FieldType");
			writer.WriteValue (FieldType);
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
