using System.Xml;
using System.Xml.Serialization;
using MarketingCloudApi.Enums;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "Action")]
public class Action : IXmlSerializable
{
	[XmlAttribute (AttributeName = "mustUnderstand")]
	public int MustUnderstand { get; set; }

	[XmlText]
	public ActionType Text { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		XmlReader reader
	)
	{

	}

	public void WriteXml (
		XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("a", "Action", XmlNamespaces.NAMESPACE_ADDRESSING);
		writer.WriteAttributeString ("s", "mustUnderstand", null, MustUnderstand.ToString ());
		writer.WriteString (Enum.GetName (typeof (ActionType), Text));
		writer.WriteEndElement ();
	}
}
