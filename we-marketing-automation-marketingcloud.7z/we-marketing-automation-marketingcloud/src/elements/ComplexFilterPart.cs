using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class ComplexFilterPart : IXmlSerializable, IFilterPart
{
	public string ElementName { get; set; } = "Filter";
	public string Type { get; set; } = "ComplexFilterPart";

	public IFilterPart? LeftOperand { get; set; }
	public Enums.LogicalOperator Operator { get; set; }
	public IFilterPart? RightOperand { get; set; }

	// if these were to get more complex or i needed to deserialize them (i don't) i would break these out to distinct objects

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		if (LeftOperand == null)
		{
			return;
		}

		if (RightOperand == null)
		{
			return;
		}

		LeftOperand.ElementName = "LeftOperand";
		RightOperand.ElementName = "RightOperand";

		writer.WriteStartElement (ElementName);
		writer.WriteAttributeString ("xsi", "type", XmlNamespaces.NAMESPACE_XSI, Type);

		LeftOperand.WriteXml (writer);

		writer.WriteStartElement ("LogicalOperator");
		writer.WriteValue (Enum.GetName<Enums.LogicalOperator> (Operator));
		writer.WriteEndElement ();

		RightOperand.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
