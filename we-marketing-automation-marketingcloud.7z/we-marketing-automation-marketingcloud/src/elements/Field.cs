using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class Field : IXmlSerializable
{
	public Field (
		string customerKey,
		string name,
		string fieldType,
		int? maxLength = null,
		bool isRequired = false,
		bool isPrimaryKey = false,
		string? objectId = null,
		int? precision = null,
		int? scale = null
	)
	{
		CustomerKey = customerKey;
		Name = name;
		FieldType = fieldType;
		MaxLength = maxLength;
		IsRequired = isRequired;
		IsPrimaryKey = isPrimaryKey;
		ObjectId = objectId;
		Precision = precision;
		Scale = scale;
	}

	public string CustomerKey { get; set; }
	public string Name { get; set; }
	public string? FieldType { get; set; }
	public int? MaxLength { get; set; }
	public bool IsRequired { get; set; } = false;
	public bool IsPrimaryKey { get; set; } = false;
	public string? ObjectId { get; set; }
	public int? Precision { get; set; }
	public int? Scale { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("Field");

		writer.WriteStartElement ("CustomerKey");
		writer.WriteValue (CustomerKey);
		writer.WriteEndElement ();

		writer.WriteStartElement ("Name");
		writer.WriteValue (Name);
		writer.WriteEndElement ();

		if (FieldType != null)
		{
			writer.WriteStartElement ("FieldType");
			writer.WriteValue (FieldType);
			writer.WriteEndElement ();
		}

		if (MaxLength != null)
		{
			writer.WriteStartElement ("MaxLength");
			writer.WriteValue (MaxLength.Value.ToString ());
			writer.WriteEndElement ();
		}

		if (Precision != null)
		{
			writer.WriteStartElement ("Precision");
			writer.WriteValue (Precision.Value.ToString ());
			writer.WriteEndElement ();
		}

		if (Scale != null)
		{
			writer.WriteStartElement ("Scale");
			writer.WriteValue (Scale.Value.ToString ());
			writer.WriteEndElement ();
		}

		writer.WriteStartElement ("IsRequired");
		writer.WriteValue (IsRequired ? "true" : "false");
		writer.WriteEndElement ();

		writer.WriteStartElement ("IsPrimaryKey");
		writer.WriteValue (IsPrimaryKey ? "true" : "false");
		writer.WriteEndElement ();

		if (ObjectId != null)
		{
			writer.WriteStartElement ("ObjectID");
			writer.WriteValue (ObjectId);
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
