using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class Requests : IXmlSerializable, ISfmcRequest
{
	public string? Name { get; set; }
	public IList<Parameters> Parameters { get; set; } = [];
	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "Requests", XmlNamespaces.NAMESPACE_EXACTTARGET);

		if (Name != null)
		{
			writer.WriteStartElement ("Name");
			writer.WriteValue (Name);
			writer.WriteEndElement ();
		}

		if (Parameters != null && Parameters.Count > 0)
		{
			foreach (var objects in Parameters)
			{
				objects.WriteXml (writer);
			}
		}

		writer.WriteEndElement ();
	}
}
