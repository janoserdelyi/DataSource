using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class Objects : IXmlSerializable
{
	public string? ObjectId { get; set; }
	public string? Type { get; set; }
	public string? CustomerKey { get; set; }
	public IDictionary<string, string?> Properties = new Dictionary<string, string?> ();
	public IDictionary<string, string> Keys = new Dictionary<string, string> ();
	public string? ClientId { get; set; }
	public string? Name { get; set; }
	public string? EmailAddress { get; set; }
	public bool? IsSendable { get; set; }
	public SendableDataExtensionField? SendableDataExtensionField { get; set; }
	public SendableSubscriberField? SendableSubscriberField { get; set; }
	public IList<Attribute>? Attributes { get; set; }
	public IList<Field>? Fields { get; set; } = null;
	public string? SubscriberKey { get; set; }
	public string? Status { get; set; }
	public string? Action { get; set; }
	public int? CategoryID { get; set; }
	public string? TemplateCustomerKey { get; set; }

	public string? DataRetentionPeriod { get; set; } // Days, Weeks, Months, Years
	public int? DataRetentionPeriodLength { get; set; }
	public bool? RowBasedRetention { get; set; }
	public bool? ResetRetentionPeriodOnImport { get; set; }
	public bool? DeleteAtEndOfRetentionPeriod { get; set; }
	public DateTimeOffset? RetainUntil { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{
	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("Objects");
		writer.WriteAttributeString ("xsi", "type", XmlNamespaces.NAMESPACE_XSI, Type);

		// there is an Options object here that's empty in the example SOAP requests. leaving it out

		/*
		<PartnerKey xsi:nil="true" />
		<ObjectID xsi:nil="true" />
		<CustomerKey>jerdelyi_sandbox</CustomerKey>
		*/
		/*
		writer.WriteStartElement("PartnerKey");
		writer.WriteAttributeString("xsi", "nil", XmlNamespaces.NAMESPACE_XSI, "true");
		writer.WriteEndElement();

		writer.WriteStartElement("ObjectID");
		writer.WriteAttributeString("xsi", "nil", XmlNamespaces.NAMESPACE_XSI, "true");
		writer.WriteEndElement();
		*/

		if (ObjectId != null)
		{
			writer.WriteStartElement ("ObjectID");
			writer.WriteValue (ObjectId);
			writer.WriteEndElement ();
		}

		if (ClientId != null)
		{
			writer.WriteStartElement ("Client");
			writer.WriteStartElement ("ID");
			writer.WriteValue (ClientId);
			writer.WriteEndElement ();
			writer.WriteEndElement ();
		}

		writer.WriteStartElement ("CustomerKey");
		writer.WriteValue (CustomerKey);
		writer.WriteEndElement ();

		if (Name != null)
		{
			writer.WriteStartElement ("Name");
			writer.WriteValue (Name);
			writer.WriteEndElement ();
		}

		if (CategoryID != null)
		{
			writer.WriteStartElement ("CategoryID");
			writer.WriteValue (CategoryID.Value.ToString ());
			writer.WriteEndElement ();
		}

		if (!string.IsNullOrEmpty (TemplateCustomerKey))
		{
			writer.WriteStartElement ("Template");
			writer.WriteStartElement ("CustomerKey");
			writer.WriteValue (TemplateCustomerKey);
			writer.WriteEndElement (); // </CustomerKey>

			writer.WriteEndElement (); // </Template>
		}

		if (EmailAddress != null)
		{
			writer.WriteStartElement ("EmailAddress");
			writer.WriteValue (EmailAddress);
			writer.WriteEndElement ();
		}

		if (IsSendable != null)
		{
			writer.WriteStartElement ("IsSendable");
			writer.WriteValue (IsSendable.Value == true ? "true" : "false");
			writer.WriteEndElement ();
		}

		SendableDataExtensionField?.WriteXml (writer);

		SendableSubscriberField?.WriteXml (writer);

		if (Properties != null && Properties.Count > 0)
		{
			writer.WriteStartElement ("Properties");
			foreach (var kvp in Properties)
			{
				writer.WriteStartElement ("Property");

				writer.WriteStartElement ("Name");
				writer.WriteValue (kvp.Key);
				writer.WriteEndElement ();

				// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/updating_a_data_extension_object_with_a_null_field_value.html
				writer.WriteStartElement ("Value");
				if (kvp.Value == null)
				{
					writer.WriteAttributeString ("xsi", "type", XmlNamespaces.NAMESPACE_XSI, "NullAPIProperty");
				}
				else
				{
					writer.WriteValue (kvp.Value);
				}

				writer.WriteEndElement ();

				writer.WriteEndElement ();
			}

			writer.WriteEndElement ();
		}

		if (Fields != null && Fields.Count > 0)
		{
			writer.WriteStartElement ("Fields");
			foreach (var field in Fields)
			{
				field.WriteXml (writer);
			}

			writer.WriteEndElement ();
		}

		if (Keys != null && Keys.Count > 0)
		{
			writer.WriteStartElement ("Keys");
			foreach (var kvp in Keys)
			{
				writer.WriteStartElement ("Key");
				writer.WriteStartElement ("Name");
				writer.WriteValue (kvp.Key);
				writer.WriteEndElement ();
				writer.WriteStartElement ("Value");
				writer.WriteValue (kvp.Value);
				writer.WriteEndElement ();
				writer.WriteEndElement ();
			}

			writer.WriteEndElement ();
		}

		if (Attributes != null && Attributes.Count > 0)
		{
			foreach (var attribute in Attributes)
			{
				writer.WriteStartElement ("Attributes");
				writer.WriteStartElement ("Name");
				writer.WriteValue (attribute.Name);
				writer.WriteEndElement ();
				writer.WriteStartElement ("Value");
				writer.WriteValue (attribute.Value);
				writer.WriteEndElement ();
				writer.WriteEndElement ();
			}
		}

		if (SubscriberKey != null)
		{
			writer.WriteStartElement ("SubscriberKey");
			writer.WriteValue (SubscriberKey);
			writer.WriteEndElement ();
		}

		if (Status != null)
		{
			writer.WriteStartElement ("Status");
			writer.WriteValue (Status);
			writer.WriteEndElement ();
		}

		if (Action != null)
		{
			writer.WriteStartElement ("Action");
			writer.WriteValue (Action);
			writer.WriteEndElement ();
		}

		if (DataRetentionPeriod != null)
		{
			writer.WriteStartElement ("DataRetentionPeriod");
			writer.WriteValue (DataRetentionPeriod);
			writer.WriteEndElement ();
		}

		if (DataRetentionPeriodLength != null)
		{
			writer.WriteStartElement ("DataRetentionPeriodLength");
			writer.WriteValue (DataRetentionPeriodLength.Value.ToString ());
			writer.WriteEndElement ();
		}

		if (RowBasedRetention != null)
		{
			writer.WriteStartElement ("RowBasedRetention");
			writer.WriteValue (RowBasedRetention.Value ? "true" : "false");
			writer.WriteEndElement ();
		}

		if (ResetRetentionPeriodOnImport != null)
		{
			writer.WriteStartElement ("RowBasedRetention");
			writer.WriteValue (ResetRetentionPeriodOnImport.Value ? "true" : "false");
			writer.WriteEndElement ();
		}

		if (DeleteAtEndOfRetentionPeriod != null)
		{
			writer.WriteStartElement ("DeleteAtEndOfRetentionPeriod");
			writer.WriteValue (DeleteAtEndOfRetentionPeriod.Value ? "true" : "false");
			writer.WriteEndElement ();
		}

		// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/dataextension.html
		// from the docs : "Verify that the value passed to this property is correctly formatted based on the Date Format setting of the API user."
		// it looks like it accepts ISO 8601 formats with or without offset
		if (RetainUntil != null)
		{
			writer.WriteStartElement ("RetainUntil");
			writer.WriteValue (RetainUntil.Value.ToUniversalTime ().ToString ("yyyy-MM-dd HH:mm:ssZ"));
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
