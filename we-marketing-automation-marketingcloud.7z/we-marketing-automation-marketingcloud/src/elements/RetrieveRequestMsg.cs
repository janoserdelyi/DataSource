using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class RetrieveRequestMsg : IXmlSerializable, ISfmcRequest
{
	public RetrieveRequest? RetrieveRequest { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "RetrieveRequestMsg", XmlNamespaces.NAMESPACE_EXACTTARGET);

		RetrieveRequest?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
