namespace MarketingCloudApi.Elements;

public class ContactExit
{
	public ContactExit (
		string contactKey,
		string definitionKey
	)
	{
		ContactKey = contactKey;
		DefinitionKey = definitionKey;
	}

	public string ContactKey { get; set; }
	public string DefinitionKey { get; set; }
}
