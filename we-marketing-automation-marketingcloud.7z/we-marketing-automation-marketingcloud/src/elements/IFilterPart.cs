namespace MarketingCloudApi.Elements;

public interface IFilterPart
{
	string ElementName { get; set; }
	void WriteXml (System.Xml.XmlWriter writer);
}
