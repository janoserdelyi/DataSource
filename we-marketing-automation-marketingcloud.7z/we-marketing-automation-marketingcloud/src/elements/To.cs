using System.Xml;
using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "To")]
public class To : IXmlSerializable
{
	[XmlAttribute (AttributeName = "mustUnderstand")]
	public int MustUnderstand { get; set; }

	[XmlText]
	public string? Text { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("a", "To", XmlNamespaces.NAMESPACE_ADDRESSING);
		writer.WriteAttributeString ("s", "mustUnderstand", null, MustUnderstand.ToString ());
		writer.WriteString (Text);
		writer.WriteEndElement ();
	}
}
