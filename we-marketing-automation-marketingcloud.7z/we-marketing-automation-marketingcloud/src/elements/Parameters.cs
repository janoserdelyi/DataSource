using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class Parameters : IXmlSerializable, ISfmcRequest
{
	public Parameters ()
	{

	}

	public Parameters (
		string name,
		string value
	)
	{
		Name = name;
		Value = value;
	}

	public string? Name { get; set; }
	public string? Value { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("Parameters");

		if (Name != null)
		{
			writer.WriteStartElement ("Name");
			writer.WriteValue (Name);
			writer.WriteEndElement ();
		}

		if (Value != null)
		{
			writer.WriteStartElement ("Value");
			writer.WriteValue (Value);
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
