using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class ExecuteRequest : IXmlSerializable, ISfmcRequest
{
	public Requests? Requests { get; set; }
	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "ExecuteRequestMsg", XmlNamespaces.NAMESPACE_EXACTTARGET);

		Requests?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
