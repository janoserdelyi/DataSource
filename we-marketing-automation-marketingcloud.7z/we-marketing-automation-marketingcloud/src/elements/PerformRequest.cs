using System.Xml.Serialization;
using MarketingCloudApi.Enums;

namespace MarketingCloudApi.Elements;

public class PerformRequest : IXmlSerializable, ISfmcRequest
{
	public PerformAction Action { get; set; }
	public IList<Definition> Definitions { get; set; } = [];
	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "PerformRequestMsg", XmlNamespaces.NAMESPACE_EXACTTARGET);

		writer.WriteStartElement ("Action");
		writer.WriteValue (Enum.GetName<Enums.PerformAction> (Action));
		writer.WriteEndElement ();

		writer.WriteStartElement ("Definitions");
		if (Definitions != null && Definitions.Count > 0)
		{
			foreach (var definition in Definitions)
			{
				definition.WriteXml (writer);
			}
		}

		writer.WriteEndElement ();

		writer.WriteEndElement ();
	}
}
