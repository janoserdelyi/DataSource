using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class RetrieveRequest : IXmlSerializable
{
	public string? ObjectType { get; set; }
	public IList<string> Properties { get; set; } = [];
	public IFilterPart? Filter { get; set; }
	public string? ContinueRequest { get; set; } = null; // pass in a request id to continue a large request (over 2500 records)

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("RetrieveRequest");

		if (ContinueRequest != null)
		{
			writer.WriteStartElement ("ContinueRequest");
			writer.WriteValue (ContinueRequest);
			writer.WriteEndElement ();
		}

		if (ObjectType != null)
		{
			writer.WriteStartElement ("ObjectType");
			writer.WriteValue (ObjectType);
			writer.WriteEndElement ();
		}

		if (Properties != null && Properties.Count > 0)
		{
			foreach (var prop in Properties)
			{
				writer.WriteStartElement ("Properties");
				writer.WriteValue (prop);
				writer.WriteEndElement ();
			}
		}

		Filter?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
