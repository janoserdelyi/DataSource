using System.Xml;
using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "fueloauth")]
public class Fueloauth : IXmlSerializable
{

	[XmlAttribute (AttributeName = "xmlns")]
	public string? Xmlns { get; set; }

	[XmlText]
	public string? Text { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "fueloauth", Xmlns);
		writer.WriteString (Text);
		writer.WriteEndElement ();
	}
}
