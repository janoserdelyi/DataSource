using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "Body")]
public class Body : IXmlSerializable
{
	public ISfmcRequest? Request { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("s", "Body", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);

		//writer.WriteAttributeString("xmlns", "xsi", null, XmlNamespaces.NAMESPACE_XSI);
		//writer.WriteAttributeString("xmlns", "xsd", null, XmlNamespaces.NAMESPACE_XSD);

		Request?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
