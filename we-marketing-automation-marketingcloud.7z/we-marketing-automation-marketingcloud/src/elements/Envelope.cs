using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "Envelope")]
public class Envelope : IXmlSerializable
{
	public Header? Header { get; set; }

	public Body? Body { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{
		/*
		// just rando example stuff. ignore
		reader.MoveToContent();

		Boolean isEmptyElement = reader.IsEmptyElement;
		reader.ReadStartElement();

		if (!isEmptyElement) {
			var str = reader.ReadContentAsString();
			string[] sa = str.Split(' ');
			Amount = double.Parse(sa[0]);
			CurrencyCode = sa[1];
			reader.ReadEndElement();
		}
		*/
	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("s", "Envelope", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);

		writer.WriteAttributeString ("xmlns", "s", null, XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);
		writer.WriteAttributeString ("xmlns", "a", null, XmlNamespaces.NAMESPACE_ADDRESSING);
		writer.WriteAttributeString ("xmlns", "u", null, XmlNamespaces.NAMESPACE_SECURITY);
		writer.WriteAttributeString ("xmlns", "xsi", null, XmlNamespaces.NAMESPACE_XSI);
		writer.WriteAttributeString ("xmlns", "xsd", null, XmlNamespaces.NAMESPACE_XSD);

		Header?.WriteXml (writer);

		Body?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
