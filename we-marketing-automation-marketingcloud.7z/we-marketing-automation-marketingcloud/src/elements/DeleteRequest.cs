using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class DeleteRequest : IXmlSerializable, ISfmcRequest
{
	public IList<Objects> Objects { get; set; } = new List<Objects> ();
	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("", "DeleteRequest", XmlNamespaces.NAMESPACE_EXACTTARGET);

		// there is an Options object here that's empty in the example SOAP requests. leaving it out

		if (Objects != null && Objects.Count > 0)
		{
			foreach (var objects in Objects)
			{
				objects.WriteXml (writer);
			}
		}

		writer.WriteEndElement ();
	}
}
