using System.Xml;
using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

[XmlRoot (ElementName = "Header")]
public class Header : IXmlSerializable
{
	[XmlElement (ElementName = "Action")]
	public Action? Action { get; set; }

	[XmlElement (ElementName = "To")]
	public To? To { get; set; }

	[XmlElement (ElementName = "fueloauth")]
	public Fueloauth? Fueloauth { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement ("s", "Header", XmlNamespaces.NAMESPACE_SOAP_ENVELOPE);

		Action?.WriteXml (writer);

		To?.WriteXml (writer);

		Fueloauth?.WriteXml (writer);

		writer.WriteEndElement ();
	}
}
