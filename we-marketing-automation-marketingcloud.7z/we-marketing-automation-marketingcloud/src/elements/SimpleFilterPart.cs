using System.Xml.Serialization;

namespace MarketingCloudApi.Elements;

public class SimpleFilterPart : IXmlSerializable, IFilterPart
{
	public string ElementName { get; set; } = "Filter";
	public string Type { get; set; } = "SimpleFilterPart"; // this is what i've seen so far - nothing else. break out to enum if multiple show up

	// if these were to get more complex or i needed to deserialize them (i don't) i would break these out to distinct objects
	public string? Property { get; set; }
	public Enums.SimpleOperator SimpleOperator { get; set; }
	public string[]? Value { get; set; }
	public bool? BooleanValue { get; set; }
	public DateTime? DateValue { get; set; }
	public int? IntValue { get; set; }

	public System.Xml.Schema.XmlSchema? GetSchema ()
	{
		return null;
	}

	public void ReadXml (
		System.Xml.XmlReader reader
	)
	{

	}

	public void WriteXml (
		System.Xml.XmlWriter writer
	)
	{
		ArgumentNullException.ThrowIfNull (writer);

		writer.WriteStartElement (ElementName);
		writer.WriteAttributeString ("xsi", "type", XmlNamespaces.NAMESPACE_XSI, Type);

		if (Property != null)
		{
			writer.WriteStartElement ("Property");
			writer.WriteValue (Property);
			writer.WriteEndElement ();
		}

		writer.WriteStartElement ("SimpleOperator");
		writer.WriteValue (Enum.GetName<Enums.SimpleOperator> (SimpleOperator));
		writer.WriteEndElement ();

		if (Value != null && Value.Length > 0)
		{
			foreach (var value in Value)
			{
				writer.WriteStartElement ("Value");
				writer.WriteValue (value);
				writer.WriteEndElement ();
			}
		}

		if (BooleanValue != null)
		{
			writer.WriteStartElement ("Value");
			writer.WriteValue (BooleanValue.Value ? 1 : 0);
			writer.WriteEndElement ();
		}

		if (DateValue != null)
		{
			writer.WriteStartElement ("DateValue");
			writer.WriteValue (DateValue.Value.ToUniversalTime ().ToString ("yyyy-MM-ddThh:mm:ss"));
			writer.WriteEndElement ();
		}

		if (IntValue != null)
		{
			writer.WriteStartElement ("Value");
			writer.WriteValue (IntValue);
			writer.WriteEndElement ();
		}

		writer.WriteEndElement ();
	}
}
