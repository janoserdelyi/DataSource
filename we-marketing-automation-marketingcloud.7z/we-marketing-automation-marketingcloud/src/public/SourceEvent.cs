
using MarketingCloudApi.Models;

namespace MarketingCloudApi;

public class SourceEvent
{
	private MarketingCloud parent { get; set; }

	public SourceEvent (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<SourceEventResponse> Create (
		string campaignName,
		string campaignDescription,
		string sourceApplicationExtensionId,
		string dataExtensionObjectId,
		string sourceEventType = "EmailAudience",
		string sourceEventMode = "Production",
		string sourceEventCategory = "Audience",
		SourceEventFilter? sourceEventFilter = null
	)
	{

		campaignName = Utils.NormalizeMarketingCloudName (campaignName);
		campaignDescription = Utils.NormalizeMarketingCloudName (campaignDescription);

		var eventDefKey = "DEAudience-" + Guid.NewGuid ().ToString ();

		var sourceEvent = new SourceEventDefintition
		{
			Type = sourceEventType,
			Name = campaignName,
			Description = campaignDescription,
			Mode = sourceEventMode,
			EventDefinitionKey = eventDefKey,
			DataExtensionId = dataExtensionObjectId,
			DataExtensionName = campaignName,
			SourceApplicationExtensionId = sourceApplicationExtensionId,
			Category = sourceEventCategory,
			Arguments = new SourceEventArguments
			{
				SerializedObjectType = 3,
				EventDefinitionId = Guid.NewGuid ().ToString (),
				EventDefinitionKey = eventDefKey,
				DataExtensionId = dataExtensionObjectId,
				UseHighWatermark = false
			},
			MetaData = new SourceEventMetaData
			{
				ScheduleState = "No Schedule", // TODO: should these be broken out to default value params also?
				CriteriaDescription = "",
				ScheduleFlowMode = "runOnce",
				RunOnceScheduleMode = "onPublish"
			},
			// Schedule = new SourceEventSchedule { // setting some defaults
			// 	StartDateTime = DateTime.Now.AddDays (1).ToString ("yyyy-MM-ddTHH:mm:ss"),
			// 	EndDateTime = DateTime.Now.AddYears (60).ToString ("yyyy-MM-ddTHH:mm:ss"),
			// 	TimeZone = "Eastern Standard Time",
			// 	Occurrences = 438289,
			// 	EndType = "EndDate",
			// 	Frequency = "Hourly",
			// 	RecurrencePattern = "Interval",
			// 	Interval = 1
			// },
			ConfigurationArguments = new ConfigurationArguments
			{
				Unconfigured = false
			}
		};

		if (sourceEventFilter != null)
		{
			sourceEvent.FilterDefinitionTemplate = sourceEventFilter.DefinitionTemplate;
			sourceEvent.FilterDefinitionId = sourceEventFilter.DefinitionId;
			sourceEvent.MetaData.CriteriaDescription = sourceEventFilter.CriteriaDescription;
			sourceEvent.Arguments.Criteria = sourceEventFilter.Criteria;
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Post,
			Routes.Rest.SOURCE_EVENT,
			JsonConvert.SerializeObject (sourceEvent, Utils.StandardJsonSerializerSettings)
		);

		if (!response.IsSuccessStatusCode)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to send the request. {response.ReasonPhrase}");
		}

		//var stringresponse = await response.Content.ReadAsStringAsync();

		var resp = await response.Content.ReadAsJsonAsync<SourceEventResponse> ();

		if (resp == null)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Got empty deserialized response. {resp}");
		}

		return resp;
	}

	// temporary
	public async Task<string> GetEventDefinitions ()
	{
		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			Routes.Rest.SOURCE_EVENT
		);

		if (!response.IsSuccessStatusCode)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to send the request. {response.ReasonPhrase}");
		}

		var stringresponse = await response.Content.ReadAsStringAsync ();

		return stringresponse;
	}

	// bad request
	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/getEventDefinition.html
	public async Task<SourceEventDefintition> GetEventDefinition (
		string id
	)
	{
		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Routes.Rest.SOURCE_EVENT}/{id}"
		);

		if (!response.IsSuccessStatusCode)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to send the request. {response.ReasonPhrase}");
		}

		// var stringresponse = await response.Content.ReadAsStringAsync ();

		return await response.Content.ReadAsJsonAsync<SourceEventDefintition> ();
	}

	public async Task<string> GetEventDefinitionByJourneyName (
		string name
	)
	{
		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Routes.Rest.SOURCE_EVENT}?name={name}"
		);

		if (!response.IsSuccessStatusCode)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to send the request. {response.ReasonPhrase}");
		}

		var stringresponse = await response.Content.ReadAsStringAsync ();

		return stringresponse;
	}
}

/*
example of above but with values subbed in and removing UiMetaData

<FilterDefinition>
	<ConditionSet Operator="OR" ConditionSetName="Individual Filter Grouping">
		<Condition Operator="Contains" Key="Email Addresses.Email Address">
			<Value>
				<![CDATA[@costar.com]]>
			</Value>
		</Condition>
		<Condition Operator="Contains" Key="Email Addresses.Email Address">
			<Value>
				<![CDATA[@homes.com]]>
			</Value>
		</Condition>
	</ConditionSet>
</FilterDefinition>
*/

/*
// example from https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/getInteractionCollection.html?q=conditionset

<FilterDefinition Source='SubscriberAttribute'>
	<ConditionSet Operator='AND' ConditionSetName='Grouping'>
		<Condition ID='cbc0db2e-9a1d-e411-9805-78e3b50b4f00' isParam='false' Operator='Contains' operatorTemplate='undefined' operatorEditable='1' valueEditable='1' conditionValid='1'>
			<Value>
				<![CDATA[5]]>
			</Value>
		</Condition>
	</ConditionSet>
</FilterDefinition>
*/

// my own class. this is not a response or structure from SFMC
public class SourceEventFilter
{
	public string? DefinitionTemplate { get; set; }
	public string? DefinitionId { get; set; }
	public string? CriteriaDescription { get; set; }
	public string? Criteria { get; set; }
}
