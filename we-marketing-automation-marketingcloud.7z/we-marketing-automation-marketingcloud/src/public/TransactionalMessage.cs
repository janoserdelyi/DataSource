namespace MarketingCloudApi;

public class TransactionalMessage
{
	private MarketingCloud parent { get; set; }

	public TransactionalMessage (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_transactional_messaging_email/sendMessageMultipleRecipients.html
	// no more than 500 recipients at a time are recommended if they have attributes
	// no more than 2000 without attributes
	public async Task<TransactionalMessageResponse> Send (
		Payload payload
	)
	{
		var payloadString = JsonConvert.SerializeObject (payload, Utils.StandardJsonSerializerSettings);

		var searchResp = await parent.sendRestRequest (
			HttpMethod.Post,
			Routes.Rest.TRANSACTIONAL_MESSAGE,
			payloadString
		);

		var result = await searchResp.Content.ReadAsJsonAsync<TransactionalMessageResponse> ();

		return result;
	}

	// TODO: get message send status for a transactional send by message id : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/getSendStatusForRecipient.html
	public async Task<TransactionalSendStatusResponse> GetSendStatus (
		string messagetKey
	)
	{
		var searchResp = await parent.sendRestRequest (
			HttpMethod.Get,
			Routes.Rest.TRANSACTIONAL_MESSAGE_STATUS.Replace ("{messageKey}", messagetKey)
		);

		var result = await searchResp.Content.ReadAsJsonAsync<TransactionalSendStatusResponse> ();

		result.MessageFound = searchResp.StatusCode == HttpStatusCode.OK;

		return result;
	}
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Recipient
{
	public Recipient (
		string contactKey,
		string to,
		IDictionary<string, string> attributes
	)
	{
		ContactKey = contactKey;
		To = to;
		Attributes = attributes;
		MessageKey = Guid.NewGuid ().ToString ();
	}

	public Recipient (
		string contactKey,
		string to,
		string messageKey,
		IDictionary<string, string> attributes
	)
	{
		ContactKey = contactKey;
		To = to;
		Attributes = attributes;
		MessageKey = messageKey;
	}

	public string ContactKey { get; set; }
	public string To { get; set; }
	public string MessageKey { get; set; }
	public IDictionary<string, string> Attributes { get; set; } = new Dictionary<string, string> ();
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Payload
{
	public Payload (
		string definitionKey,
		IList<Recipient> recipients
	)
	{
		DefinitionKey = definitionKey;
		Recipients = recipients;
	}

	public Payload (
		string definitionKey,
		IList<Recipient> recipients,
		IDictionary<string, string> attributes
	)
	{
		DefinitionKey = definitionKey;
		Recipients = recipients;
		Attributes = attributes;
	}

	public string DefinitionKey { get; set; }
	public IList<Recipient> Recipients { get; set; } = new List<Recipient> ();
	public IDictionary<string, string> Attributes { get; set; } = new Dictionary<string, string> ();
}
