using MarketingCloudApi.Elements;
using MarketingCloudApi.Models;

namespace MarketingCloudApi;

// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/dataextension.html
// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/soap_tech_articles_de.html
public class DataExtension
{
	private MarketingCloud parent { get; set; }

	public DataExtension (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	// this gets the full response with possibility of multiple data extensions returned
	public async Task<DataExtensionResponse?> Get (
		IFilterPart filter,
		IList<string>? fields = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		fields ??= new List<string> { "ObjectID", "CustomerKey", "Name", "IsSendable", "SendableSubscriberField.Name" };

		var payload = payloadCreateApi.GetDataExtension (fields, filter);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting a DataExtension definition");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting DataExtension definition : {oops.Message}", oops);
		}

		// todo: convert to return a list of dataextensions
		DataExtensionResponse? ret = Soap.PayloadParseApi.DataExtensionRetrieve (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionResponseObject?> Get (
		Enums.DataExtensionSelectField selectField,
		string value,
		IList<string>? fields = null
	)
	{
		var response = await Get (
			filter: new SimpleFilterPart
			{
				Property = selectField.ToString (),
				SimpleOperator = Enums.SimpleOperator.equals,
				Value = new string[] { value }
			},
			fields: fields
		);

		if (response?.DataExtensions.Count > 0)
		{
			return response.DataExtensions[0];
		}

		return null;
	}

	public async Task<DataExtensionResponseObject?> Get (
		string dataExtensionObjectId,
		IList<string>? fields = null
	)
	{
		return await Get (
			Enums.DataExtensionSelectField.ObjectId,
			dataExtensionObjectId,
			fields: fields
		);
	}

	// keeping because it's in the wild
	[Obsolete ("v0.15.0 - use Get (Enums.DataExtensionSelectField.CustomerKey, dateExtensionCustomerKey, fields?) instead")]
	public async Task<DataExtensionResponseObject?> GetByCustomerKey (
		string dateExtensionCustomerKey,
		IList<string>? fields = null
	)
	{
		return await Get (
			Enums.DataExtensionSelectField.CustomerKey,
			dateExtensionCustomerKey,
			fields: fields
		);
	}

	public async Task<DataExtensionUpdateResponse?> UpdateName (
		string dataExtensionObjectId,
		string newDataExtensionName
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.UpdateDataExtensionName (
			parent.Credentials.AccountId,
			dataExtensionObjectId,
			newDataExtensionName
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for updating a DataExtension name");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error updating DataExtension name : {oops.Message}", oops);
		}

		DataExtensionUpdateResponse? ret = Soap.PayloadParseApi.DataExtensionUpdate (responseValue);

		// some error handling? verification?

		return ret;
	}

	/*
	public string? DataRetentionPeriod { get; set; } // Days, Weeks, Months, Years
	public int? DataRetentionPeriodLength { get; set; }
	public bool? RowBasedRetention { get; set; }
	public bool? ResetRetentionPeriodOnImport { get; set; }
	public bool? DeleteAtEndOfRetentionPeriod { get; set; }
	public DateTimeOffset? RetainUntil { get; set; }
	*/
	public async Task<DataExtensionUpdateResponse?> UpdateRetention (
		string dataExtensionObjectId,
		Enums.DataRetentionPeriod? dataRetentionPeriod = null,
		int? dataRetentionPeriodLength = null,
		bool? rowBasedRetention = null,
		bool? resetRetentionPeriodOnImport = null,
		bool? deleteAtEndOfRetentionPeriod = null,
		DateTimeOffset? retainUntil = null
	)
	{

		// going to do some basic validation here. like retainUntl can't be with a dataRetentionPeriod for example
		if (retainUntil != null && dataRetentionPeriod != null)
		{
			throw new ArgumentException ("Cannot have both 'retainUntil' and a 'dataRetentionPeriod' value");
		}

		if (dataRetentionPeriod != null && dataRetentionPeriodLength == null)
		{
			throw new ArgumentException ("'dataRetentionPeriodLength' must have a value if using 'dataRetentionPeriod'");
		}

		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.UpdateDataExtensionRetention (
			parent.Credentials.AccountId,
			dataExtensionObjectId,
			dataRetentionPeriod,
			dataRetentionPeriodLength,
			rowBasedRetention,
			resetRetentionPeriodOnImport,
			deleteAtEndOfRetentionPeriod,
			retainUntil
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for updating DataExtension retention policy");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error updating DataExtension retention policy : {oops.Message}", oops);
		}

		DataExtensionUpdateResponse? ret = Soap.PayloadParseApi.DataExtensionUpdate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionTemplateResponse> RetrieveDataExtensionTemplates (
		DataExtensionTemplateFilter? filter = null)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;
		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (Exception ex)
		{
			throw new Exception ("Error retrieving access info", ex);
		}

		var payloadApi = new Soap.PayloadCreateApi (parent.Credentials.Subdomain, accessInfo.AccessToken);

		// Generate SOAP request based on either key or name
		var payload = payloadApi.RetrieveDataExtensionTemplates (filter);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for retrieving DataExtensionTemplates");
		}

		string? responseValue;
		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error retrieving DataExtensionTemplates: {oops.Message}", oops);
		}

		return Soap.PayloadParseApi.ParseDataExtensionTemplates (responseValue);
	}

	public async Task<DataExtensionCreateResponse?> Create (
		string dataExtensionKey,
		string name,
		bool isSendable,
		IList<Field> fields,
		SendableDataExtensionField? sendableDataExtensionField,
		SendableSubscriberField? sendableSubscriberField,
		int? folderId = null,
		string? templateCustomerKey = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
				parent.Credentials.Subdomain,
				accessInfo.AccessToken
			);

		var payload = payloadCreateApi.CreateDataExtension (
			parent.Credentials.AccountId,
			dataExtensionKey,
			name,
			isSendable,
			fields,
			sendableDataExtensionField,
			sendableSubscriberField,
			folderId,
			templateCustomerKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for creating a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error creating DataExtension : {oops.Message}", oops);
		}

		DataExtensionCreateResponse? ret = Soap.PayloadParseApi.DataExtensionCreate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionDeleteResponse?> Delete (
		string dataExtensionKey
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.DeleteDataExtension (dataExtensionKey);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for deleting a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error deleting DataExtension : {oops.Message}", oops);
		}

		DataExtensionDeleteResponse? ret = Soap.PayloadParseApi.DataExtensionDelete (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionDataResponse?> GetData (
		string dataExtensionKey,
		IList<string> fields,
		IFilterPart? filter = null,
		string? continueRequestId = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo = null;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.GetDataFromExtension (dataExtensionKey, fields, filter, continueRequestId: continueRequestId);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting data from a DataExtension");
		}

		string? responseValue = null;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting data from DataExtensionKey: {dataExtensionKey} Error Message : {oops.Message}", oops);
		}

		if (responseValue == null)
		{
			throw new Exception ($"[{nameof (AddData)}] Unknown error getting response : null response returned");
		}

		DataExtensionDataResponse ret = Soap.PayloadParseApi.DataExtensionData (responseValue);

		// some error handling? verification?

		return ret;
	}

	// this is a wrapper for GetData to get ALL data since it comes down in batches of 2500
	public async Task<List<DataExtensionObject>> GetDataBatch (
		string dataExtensionKey,
		IList<string> fields,
		IFilterPart? filter = null
	)
	{
		var totalList = new List<DataExtensionObject> ();

		string? eventDataStatus;
		string? continueRequestId = null;
		do
		{
			var dataChunk = await GetData (
				dataExtensionKey,
				fields,
				filter: filter,
				continueRequestId: continueRequestId
			);

			eventDataStatus = dataChunk?.OverallStatus;

			if (
				dataChunk == null ||
				dataChunk.Results == null ||
				dataChunk.Results.Count == 0
			)
			{
				break;
			}

			totalList.AddRange (dataChunk.Results);

			if (eventDataStatus == "MoreDataAvailable")
			{
				continueRequestId = dataChunk?.RequestId;
			}
			else
			{
				continueRequestId = null;
			}
		} while (eventDataStatus == "MoreDataAvailable");

		return totalList;
	}

	// add data to data extension
	// by default this will add only, but can be flagged to update
	public async Task<DataExtensionInsertUpdateResponse?> AddData<T> (
		string dataExtensionKey,
		string primaryKeyFieldName,
		List<T> uploadObjects,
		bool update = false,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{
		return await AddData<T> (
			dataExtensionKey,
			new List<string> { primaryKeyFieldName },
			uploadObjects,
			update,
			targetPayloadSizeBytes
		);
	}
	public async Task<DataExtensionInsertUpdateResponse?> AddData<T> (
		string dataExtensionKey,
		List<string> primaryKeyFieldNames,
		List<T> uploadObjects,
		bool update = false,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{

		if (uploadObjects == null || uploadObjects.Count == 0)
		{
			throw new ArgumentNullException ("uploadObjects", "uploadObjects are required in order to update a Data Extension");
		}

		List<IDictionary<string, string?>> convertedList = Utils.ConvertToPayload<T> (uploadObjects);

		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo = null;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		string? payload = null;

		if (update == false)
		{
			payload = payloadCreateApi.AddDataToExtension (
				dataExtensionKey,
				convertedList
			);
		}
		else
		{
			payload = payloadCreateApi.UpdateDataInExtension (
				dataExtensionKey,
				convertedList
			);
		}

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for adding data to a DataExtension");
		}

		// i want to see how large this payload is
		//Console.WriteLine("payload size in utf-8 encoded bytes");
		// keep in mind this is just the objects, it's not including the SOAP wrapper, though that will be small
		var payloadSize = Encoding.UTF8.GetBytes (payload).Length;
		//Console.WriteLine(payloadSize);

		if (payloadSize > targetPayloadSizeBytes)
		{

			var calcs = new UploadSize (
				maxSizeBytes: targetPayloadSizeBytes,
				payloadSizeBytes: payloadSize,
				objectCount: uploadObjects.Count
			);

			return new DataExtensionInsertUpdateResponse ()
			{
				OverallStatus = "Oversized",
				OverallStatusMessage = $"Your payload exceeds the target payload maximium size by {calcs.PayloadSizeBytes - calcs.MaxSizeBytes} bytes. Average row byte size : {calcs.AverageRowSizeBytes}, Suggested number of rows to upload : {calcs.SuggestedRowcountConservative}",
				SuggestedUploadRowCount = calcs.SuggestedRowcountConservative
			};
		}

		string? responseValue = null;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (System.Net.WebException oops)
		{
			// i throw this when the request payload is too large
			if (oops.Message == "RequestEntityTooLarge")
			{
				// unfortunately we don't really get feedback on what the max allowable is. so if we do ever get this far, i will assume 20MiB since that seems to be SF's ftp max payload size

				var calcs = new UploadSize (
					maxSizeBytes: 20 * 1024 * 1024,
					payloadSizeBytes: payloadSize,
					objectCount: uploadObjects.Count
				);

				return new DataExtensionInsertUpdateResponse ()
				{
					OverallStatus = "Oversized",
					OverallStatusMessage = $"Your payload exceeds the target payload maximium size by {calcs.PayloadSizeBytes - calcs.MaxSizeBytes} bytes. Average row byte size : {calcs.AverageRowSizeBytes}, Suggested number of rows to upload : {calcs.SuggestedRowcountConservative}",
					SuggestedUploadRowCount = calcs.SuggestedRowcountConservative
				};
			}

			throw new Exception ($"[{nameof (AddData)}] Error getting response : {oops.Message}", oops);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{nameof (AddData)}] Error getting response : {oops.Message}", oops);
		}

		if (responseValue == null)
		{
			throw new Exception ($"[{nameof (AddData)}] Unknown error getting response : null response returned");
		}

		DataExtensionInsertUpdateResponse ret = Soap.PayloadParseApi.InsertUpdateDataInDataExtension (primaryKeyFieldNames, responseValue);

		ret.OverallStatus = "OK";

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionInsertUpdateResponse?> UpdateData<T> (
		string dataExtensionKey,
		string primaryKeyFieldName,
		List<T> uploadObjects,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{
		return await AddData<T> (
			dataExtensionKey,
			primaryKeyFieldName,
			uploadObjects,
			true,
			targetPayloadSizeBytes
		);
	}

	public async Task<DataExtensionInsertUpdateResponse?> UpdateData<T> (
		string dataExtensionKey,
		List<string> primaryKeyFieldNames,
		List<T> uploadObjects,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{
		return await AddData<T> (
			dataExtensionKey,
			primaryKeyFieldNames,
			uploadObjects,
			true,
			targetPayloadSizeBytes
		);
	}

	// i plan on eventually getting rid of the AddData/AddDataChunked split and making every thing chunked under the hood but without the Chunked naming - just "AddData", "UpdateData", "UpsertData"
	// so internally this upsert will use the chunked approach by default. one less thing to convert
	public async Task<DataExtensionInsertUpdateResponse?> UpsertData<T> (
		string dataExtensionKey,
		string primaryKeyFieldName,
		List<T> uploadObjects,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{
		return await UpsertData<T> (
			dataExtensionKey,
			new List<string> { primaryKeyFieldName },
			uploadObjects,
			targetPayloadSizeBytes
		);
	}

	public async Task<DataExtensionInsertUpdateResponse?> UpsertData<T> (
		string dataExtensionKey,
		List<string> primaryKeyFieldNames,
		List<T> uploadObjects,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{

		var addResponse = await AddDataChunked<T> (
			dataExtensionKey,
			primaryKeyFieldNames,
			uploadObjects,
			update: false,
			targetPayloadSizeBytes
		);

		if (addResponse == null)
		{
			return addResponse;
		}

		if (addResponse.Errors.Count == 0)
		{
			return addResponse;
		}

		// now figure out if any of the errors are due to duplicate conflicts and try to update those
		// errorcode : 71005
		// errormessage : Violation of PRIMARY KEY constraint 'PK_A2277335F33A4B37B892425E70C51F82'. Cannot insert duplicate key in object 'C10948067.Business Immo Newsletter Subscriptions'. The duplicate key value is (janos.erdelyi+test04@gmail.com, 1). The statement has been terminated.
		// in want a dictionary of (keyvalues, errorobject) to flatten this out for comparison/lookup later
		var errorsToRetry = addResponse.Errors.Where (x => x.Value.ErrorCode == "71005" && x.Value.ErrorMessage!.StartsWith ("Violation of PRIMARY KEY constraint"));
		var errorsToRetryFlattened = errorsToRetry.ToDictionary (x => x.Value.SubscriberKey!, x => x);

		// we need to remove these errors from the actual error collection we finally return
		foreach (var errorToRetry in errorsToRetry)
		{
			addResponse.Errors.Remove (errorToRetry);
		}

		List<IDictionary<string, string?>> convertedList = Utils.ConvertToPayload<T> (uploadObjects);

		var updateList = new List<IDictionary<string, string?>> ();

		// ugh there is no really efficient way about this is there
		foreach (var convert in convertedList)
		{
			// there can be multiple primary key fields, hence the added fun here
			// create a key as a comma-delimited list of the primaryKeyFieldNames values
			var keynameArr = new List<string> ();
			foreach (var pkname in primaryKeyFieldNames)
			{
				if (convert.ContainsKey (pkname))
				{
					keynameArr.Add (convert[pkname]!);
				}
			}

			var keyname = string.Join (",", keynameArr);
			if (errorsToRetryFlattened.ContainsKey (keyname!))
			{
				// add `convert` to a new collection to process
				updateList.Add (convert);
			}
		}

		var updateResponse = await AddDataChunked<IDictionary<string, string?>> (
			dataExtensionKey,
			primaryKeyFieldNames,
			updateList,
			update: true,
			targetPayloadSizeBytes
		);

		if (updateResponse == null)
		{
			return addResponse;
		}

		if (updateResponse.Oks.Count == 0)
		{
			return addResponse;
		}

		var upsertResponse = new DataExtensionInsertUpdateResponse ();

		// no AddRange for dictionarys. get ready for the pain
		foreach (var ok in addResponse.Oks)
		{
			upsertResponse.Oks.Add (ok);
		}

		foreach (var ok in updateResponse.Oks)
		{
			upsertResponse.Oks.Add (ok);
		}

		// now pile on the errors
		// there can potentially be other types of Insert errors, be sure to propagate those
		foreach (var addError in addResponse.Errors)
		{
			upsertResponse.Errors.Add (addError);
		}

		foreach (var updateError in updateResponse.Errors)
		{
			upsertResponse.Errors.Add (updateError);
		}

		return upsertResponse;
	}

	public async Task<DataExtensionInsertUpdateResponse?> AddDataChunked<T> (
		string dataExtensionKey,
		string primaryKeyFieldName,
		List<T> uploadObjects,
		bool update = false,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{
		return await AddDataChunked<T> (
			dataExtensionKey,
			new List<string> { primaryKeyFieldName },
			uploadObjects,
			update,
			targetPayloadSizeBytes
		);
	}

	public async Task<DataExtensionInsertUpdateResponse?> AddDataChunked<T> (
		string dataExtensionKey,
		List<string> primaryKeyFieldNames,
		List<T> uploadObjects,
		bool update = false,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	) where T : class
	{

		List<IDictionary<string, string?>> convertedList = Utils.ConvertToPayload<T> (uploadObjects);

		var finalResponse = new DataExtensionInsertUpdateResponse ();
		List<IDictionary<string, string?>> uploadObjectsCopy = convertedList;
		var sliceSize = 0;

		do
		{
			DataExtensionInsertUpdateResponse? ret = null;

			convertedList.RemoveRange (0, sliceSize);

			if (uploadObjectsCopy.Count == 0)
			{
				break;
			}

			try
			{
				ret = await AddData (
					dataExtensionKey,
					primaryKeyFieldNames,
					uploadObjectsCopy,
					update,
					targetPayloadSizeBytes
				);
			}
			catch (Exception oops)
			{
				throw new Exception ($"[{nameof (AddDataChunked)}] Error getting response : {oops.Message}", oops);
			}

			if (ret == null || ret.OverallStatus == null)
			{
				throw new Exception ($"[{nameof (AddDataChunked)}] Unknown error getting response. nothing returned");
			}

			if (ret.OverallStatus == "OK")
			{
				// add all items to the final return and exit
				finalResponse.OverallStatus = ret.OverallStatus;
				finalResponse.OverallStatusMessage = ret.OverallStatusMessage;

				// sadly no AddRange for our Dictionary friends
				foreach (var okkvp in ret.Oks)
				{
					if (finalResponse.Oks.ContainsKey (okkvp.Key))
					{
						continue;
					}

					finalResponse.Oks.Add (okkvp.Key, okkvp.Value);
				}

				foreach (var errorkvp in ret.Errors)
				{
					if (finalResponse.Errors.ContainsKey (errorkvp.Key))
					{
						continue;
					}

					finalResponse.Errors.Add (errorkvp.Key, errorkvp.Value);
				}

				// continue to move the chunks along at this size
				//sliceSize = convertedList.Count < uploadObjectsCopy.Count ? convertedList.Count : uploadObjectsCopy.Count;
				sliceSize = sliceSize > convertedList.Count ? convertedList.Count : sliceSize;
#if NET8_0_OR_GREATER
				uploadObjectsCopy = convertedList.Slice (0, sliceSize);
#else
				uploadObjectsCopy = convertedList.Slice(0, sliceSize).ToList();
#endif
			}

			// we need to try again, but with just a portion of the uploadObjects
			if (ret.OverallStatus == "Oversized")
			{
				// put the list back on the stack, otherwise records will get lost. but not on the first run where it contains the entire set!
				if (uploadObjectsCopy.Count != uploadObjects.Count)
				{
					convertedList.AddRange (uploadObjectsCopy);
				}

				// i suppose this could happen - the estimations are off
				if (ret.SuggestedUploadRowCount!.Value > convertedList.Count)
				{
					// chop the uploadCount in half and go from there?
#if NET8_0_OR_GREATER
					uploadObjectsCopy = convertedList.Slice (0, convertedList.Count / 2);
#else
					uploadObjectsCopy = convertedList.Slice(0, convertedList.Count / 2).ToList();
#endif
					// remove that same range now that it's been copied
					convertedList.RemoveRange (0, uploadObjectsCopy.Count);
				}
				else
				{
					// chop the uploads down to the suggested count
					sliceSize = convertedList.Count < ret.SuggestedUploadRowCount!.Value ? convertedList.Count : ret.SuggestedUploadRowCount!.Value;
#if NET8_0_OR_GREATER
					uploadObjectsCopy = convertedList.Slice (0, sliceSize);
#else
					uploadObjectsCopy = convertedList.Slice(0, sliceSize).ToList();
#endif
				}
			}
		} while (convertedList.Count > 0);

		return finalResponse;
	}

	// delete a single record from a DE. the API only allows one
	public async Task<DataExtensionDeleteObjectResponse?> DeleteData (
		string dataExtensionKey,
		IDictionary<string, string> keysAndValues
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.DeleteDataFromExtension (
			dataExtensionKey,
			keysAndValues
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for deleting data from a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error deleting data from DataExtension : {oops.Message}", oops);
		}

		DataExtensionDeleteObjectResponse? ret = Soap.PayloadParseApi.DeleteDataFromDataExtension (responseValue);

		// some error handling? verification?

		return ret;
	}

	// while it looks like you should be able to delete multiple records at once with the api.. that is not the case
	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/deleting_a_row_from_a_data_extension_via_the_web_service_api.html
	// we, however will make it possible! use this method
	public async Task<IList<DataExtensionDeleteObjectResponse>> DeleteData (
		string dataExtensionKey,
		IList<IDictionary<string, string>> keysAndValues
	)
	{
		var response = new List<DataExtensionDeleteObjectResponse> ();

		if (keysAndValues == null || keysAndValues.Count == 0)
		{
			return response;
		}

		foreach (var keyAndValue in keysAndValues)
		{
			var resp = await DeleteData (dataExtensionKey, keyAndValue);
			if (resp != null)
			{
				response.Add (resp);
			}
		}

		return response;
	}

	// TODO: change data extension name? is this possible?

	public async Task<DataExtensionFieldResponse?> GetFields (
		string dataExtensionKey
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.GetFieldsForDataExtension (
			dataExtensionKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting fields for a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting fields for a DataExtension : {oops.Message}", oops);
		}

		DataExtensionFieldResponse? ret = Soap.PayloadParseApi.DataExtensionFields (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionUpdateResponse?> AddFields (
		string dataExtensionKey,
		IList<Field> fields
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.AddFieldsToDataExtension (
			dataExtensionKey,
			fields
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for adding fields to a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error adding fields to a DataExtension : {oops.Message}", oops);
		}

		DataExtensionUpdateResponse? ret = Soap.PayloadParseApi.DataExtensionUpdate (responseValue);

		// some error handling? verification?

		return ret;
	}

	// TODO: alter column?
	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/updating_column_properties_for_an_existing_data_extension.html
	public async Task<DataExtensionUpdateResponse?> UpdateFields (
		string dataExtensionKey,
		IList<Field> fields
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.UpdateFieldsInDataExtension (
			dataExtensionKey,
			fields
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for updating fields in a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error updating fields in a DataExtension : {oops.Message}", oops);
		}

		DataExtensionUpdateResponse? ret = Soap.PayloadParseApi.DataExtensionUpdate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<DataExtensionUpdateResponse?> DeleteFields (
		string dataExtensionKey,
		IList<Field> fields
	)
	{

		// 2024-08-13 jerdelyi. i found a fun one - if you submit this request with zero fields to delete, it deletes the entire data extension
		if (fields == null || fields.Count == 0)
		{
			return new DataExtensionUpdateResponse ()
			{
				StatusCode = "OK",
				OverallStatus = "OK",
				StatusMessage = "No fields provided to delete"
			};
		}

		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.DeleteFieldsFromDataExtension (
			dataExtensionKey,
			fields
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for deleting fields from a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error deleting fields from a DataExtension : {oops.Message}", oops);
		}

		DataExtensionUpdateResponse? ret = Soap.PayloadParseApi.DataExtensionUpdate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<PerformResponse?> ClearAllData (
		string dataExtensionKey
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.ClearAllDataInDataExtension (
			dataExtensionKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for clearing all data from a DataExtension");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error clearing all data from DataExtension : {oops.Message}", oops);
		}

		PerformResponse? ret = Soap.PayloadParseApi.ClearAllDataFromDataExtension (responseValue);

		// some error handling? verification?

		return ret;
	}

	// testing
	public async Task<DataExtensionDescriptionResponse?> Describe (
		string dataExtensionKey
	)
	{
		try
		{
			var response = await parent.sendRestRequest (
				HttpMethod.Get,
				Routes.Rest.CUSTOM_OBJECT_SCHEMA.Replace ("{key}", Uri.EscapeDataString (dataExtensionKey))
			);

			response.EnsureSuccessStatusCode ();

			return await response.Content.ReadAsJsonAsync<DataExtensionDescriptionResponse> ();
		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			return default;
		}
	}
}

internal class UploadSize
{
	public UploadSize (
		int maxSizeBytes,
		int payloadSizeBytes,
		int objectCount
	)
	{
		if (payloadSizeBytes < maxSizeBytes)
		{
			return;
		}

		MaxSizeBytes = maxSizeBytes;
		PayloadSizeBytes = payloadSizeBytes;

		AverageRowSizeBytes = payloadSizeBytes / objectCount;
		SuggestedRowCount = maxSizeBytes / AverageRowSizeBytes;
		//SuggestedRowcountConservative = (int)(SuggestedRowCount - (objectCount * .05)); // reduce by 5% for some error padding
		// reduce by 5% for some error padding
		SuggestedRowcountConservative = (int)(SuggestedRowCount * .95);
		// if the conservative amount is the same as the suggested row count, reduce by one. not awesome, but not nothing
		if (SuggestedRowcountConservative == SuggestedRowCount)
		{
			SuggestedRowcountConservative--;
		}

		if (SuggestedRowcountConservative <= 0)
		{
			// i should maybe throw an error, really. this suggests that the overall payload size is too small to even carry a single record plus the soap wrapping information
			//SuggestedRowcountConservative = 1;
			throw new ArgumentOutOfRangeException ($"the overall payload size of {payloadSizeBytes} bytes is too small to carry the envelope and a single record");
		}
	}

	public int MaxSizeBytes { get; private set; }
	public int PayloadSizeBytes { get; private set; }
	public int SuggestedRowCount { get; private set; }
	public int SuggestedRowcountConservative { get; private set; }
	public int AverageRowSizeBytes { get; private set; }
}

#if NET6_0
// get rid of this once we switch to .net 8
public static class EnumerableExtensions
{
	public static IEnumerable<T> Slice<T> (
		this IEnumerable<T> collection,
		int start,
		int end
	) {
		int index = 0;
		int count = 0;

		if (collection == null) {
			throw new ArgumentNullException ("collection");
		}

		// Optimise item count for ICollection interfaces.
		if (collection is ICollection<T>) {
			count = ((ICollection<T>)collection).Count;
		} else if (collection is System.Collections.ICollection) {
			count = ((System.Collections.ICollection)collection).Count;
		} else {
			count = collection.Count ();
		}

		// Get start/end indexes, negative numbers start at the end of the collection.
		if (start < 0) {
			start += count;
		}

		if (end < 0) {
			end += count;
		}

		foreach (var item in collection) {
			if (index >= end) {
				yield break;
			}

			if (index >= start) {
				yield return item;
			}

			++index;
		}
	}

	public static IEnumerable<T> Slice<T> (
		this IList<T> collection,
		int start,
		int end
	) {
		int index = 0;
		int count = 0;

		if (collection == null) {
			throw new ArgumentNullException ("collection");
		}

		count = collection.Count;

		// Get start/end indexes, negative numbers start at the end of the collection.
		if (start < 0) {
			start += count;
		}

		if (end < 0) {
			end += count;
		}

		foreach (var item in collection) {
			if (index >= end) {
				yield break;
			}

			if (index >= start) {
				yield return item;
			}

			++index;
		}
	}
}
#endif
