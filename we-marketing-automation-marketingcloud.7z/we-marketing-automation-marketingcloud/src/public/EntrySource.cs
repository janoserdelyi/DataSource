namespace MarketingCloudApi;

public class EntrySource
{
	private MarketingCloud parent { get; set; }

	public EntrySource (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	// TODO: return and actual response object at some point
	public async Task<bool> Delete (
		string entrySourceId
	)
	{
		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Delete,
			$"{Routes.Rest.SOURCE_EVENT}/{entrySourceId}"
		);

		// If Success, it returns a string with the entry source Id within it
		var responseText = await response.Content.ReadAsStringAsync ();

		if (responseText.Contains (entrySourceId))
		{
			return true;
		}
		else
		{ // Else convert to error object
			var responseValue = JsonConvert.DeserializeObject<DeleteRestFailureResponse> (responseText);
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to delete entry source {responseValue}");
		}
	}
}
