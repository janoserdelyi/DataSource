
namespace MarketingCloudApi;

public class AttributeSet
{
	private MarketingCloud parent { get; set; }

	public AttributeSet (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	// list all attributeSet definitions
	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_contacts/retrieveAllAttributeSetDefinitions.html
	// public async Task<ContactSearchByEmailResponse?> GetAll (

	// ) {
	// 	try {
	// 		var response = await parent.SendRestRequest (
	// 			HttpMethod.Get,
	// 			Routes.Rest.ATTRIBUTESET_DEFINITIONS
	// 		);

	// 		response.EnsureSuccessStatusCode ();

	// 		var foo = await response.Content.ReadAsStringAsync ();

	// 		return await response.Content.ReadAsJsonAsync<ContactSearchByEmailResponse> ();
	// 	} catch (Exception oops) {
	// 		Console.WriteLine (oops.ToString ());
	// 		return default;
	// 	}
	// }

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_contacts/attributeSetsDataName.html
	public async Task<ContactSearchByEmailResponse?> GetByName (
		string attributeSetName
	)
	{
		try
		{
			var response = await parent.sendRestRequest (
				HttpMethod.Get,
				Routes.Rest.ATTRIBUTESETS + $"/name:{Uri.EscapeDataString (attributeSetName)}"
			);

			response.EnsureSuccessStatusCode ();

			var foo = await response.Content.ReadAsStringAsync ();

			return await response.Content.ReadAsJsonAsync<ContactSearchByEmailResponse> ();
		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			return default;
		}
	}

	/*
	Link the Attribute Set to a Data Extension

	POST /contacts/v1/attributeGroups/{groupId}/attributeSetDefinitions
	Authorization: Bearer YOUR_ACCESS_TOKEN
	Content-Type: application/json

	{
		"attributeSetId": "12345678-90ab-cdef-1234-567890abcdef",
		"storageReference": {
			"type": "DataExtension",
			"customerKey": "YourDataExtensionCustomerKey"
		}
	}
	*/
}
