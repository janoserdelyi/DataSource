
namespace MarketingCloudApi;

// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_domain_verfication?meta=getDomains
public class DomainVerification
{
	private MarketingCloud parent { get; set; }

	public DomainVerification (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<DomainVerificationResponse> Get (
		List<DomainVerificationFilter>? filters = null,
		DomainVerificationOrderField? orderBy = null,
		SortDirection? sortDirection = null,
		int? page = null,
		int? pageSize = null
	)
	{

		var uri = new StringBuilder (Routes.Rest.DOMAIN_VERIFICATION);
		var queryParams = new List<string> ();

		if (filters != null && filters.Any ())
		{
			var filterStrings = new List<string> ();
			foreach (var filter in filters)
			{
				// both status and domaintype should not have a value. they should be two different filters. so skip in this case to avoid strange results
				// i realize this is not the most lovely approach
				if (filter.Status != null && filter.DomainType != null)
				{
					continue;
				}

				// var opStr = filter.Operator.ToString().ToLower();

				if (filter.Status != null)
				{
					var statusStr = filter.Status.ToString ();//.ToLower();
					filterStrings.Add ($"status in ('{statusStr}')");
				}

				if (filter.DomainType != null)
				{
					var domaintypeStr = filter.DomainType.ToString ();//.ToLower();
					filterStrings.Add ($"domaintype in ('{domaintypeStr}')");
				}

				// presently i'm only able to get one filter at a time working, so i will exit after the first. i hope this is temporary
				break;
			}

			queryParams.Add ($"$filter={string.Join (" or ", filterStrings)}");
		}

		if (orderBy.HasValue)
		{
			var orderField = char.ToLowerInvariant (orderBy.Value.ToString ()[0]) + orderBy.Value.ToString ()[1..];
			var direction = sortDirection?.ToString ().ToUpper () ?? "ASC";
			queryParams.Add ($"$orderBy={orderField} {direction}");
		}

		if (page.HasValue)
		{
			queryParams.Add ($"$page={page.Value}");
		}

		if (pageSize.HasValue)
		{
			queryParams.Add ($"$pagesize={pageSize.Value}");
		}

		if (queryParams.Count > 0)
		{
			uri.Append ('?').Append (string.Join ('&', queryParams));
		}

		var stringUri = uri.ToString ();

		// a test. filtering seems to be getting completely ignored
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=status in ('Verified') or domaintype in ('RegisteredDomain')&$orderBy=status DESC&$page=1&$pagesize=150";
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=status eq 'Verified' or domaintype eq 'RegisteredDomain'&$orderBy=status DESC&$page=1&$pagesize=150";
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=status in ('Verified') or domaintype in ('RegisteredDomain')";
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=status eq 'Verified' or domaintype eq 'RegisteredDomain'";
		// or it 500 explodes
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=domaintype eq 'RegisteredDomain'";
		// these work individually, but cannot seem to stack multiple filters
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=domaintype in ('RegisteredDomain')";
		// stringUri = Routes.Rest.DOMAIN_VERIFICATION + "?$filter=status in ('Verified')";

		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			stringUri
		);

		if (!response.IsSuccessStatusCode)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to send the request. {response.ReasonPhrase}");
		}

		//var stringresponse = await response.Content.ReadAsStringAsync();

		var resp = await response.Content.ReadAsJsonAsync<DomainVerificationResponse> ();

		if (resp == null)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Got empty deserialized response. {resp}");
		}

		return resp;
	}
}

public enum DomainVerificationOrderField
{
	Domain,
	Status,
	DefinitionKey,
	IsSendable,
	DomainType,
	ModifiedDate
}

public class DomainVerificationFilter
{
	// public FilterOperator Operator { get; set; } // filters for this appear to be in the format of "domaintype in ('foo', 'bar')", not with operators like 'eq' or 'neq'
	public DomainVerificationStatus? Status { get; set; } = null;
	public DomainVerificationDomainType? DomainType { get; set; } = null;
}

public enum DomainVerificationStatus
{
	Verified,
	Pending,
	Inactive,
	Deleted
}

public enum DomainVerificationDomainType
{
	RegisteredDomain,
	UserDomain,
	SAP,
	PrivateDomain
}
