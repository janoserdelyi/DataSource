
namespace MarketingCloudApi;

public class Contact
{
	private MarketingCloud parent { get; set; }

	public Contact (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<ContactSearchByEmailResponse?> SearchByEmail (
		string contactEmailAddress
	)
	{
		try
		{
			//reference: https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/retrieveContactKey.html
			var content = JsonConvert.SerializeObject (new SearchContactByEmailAddressRequest (contactEmailAddress));

			var response = await parent.sendRestRequest (
				HttpMethod.Post,
				Routes.Rest.SEARCH_CONTACT_BY_EMAIL_ADDRESS,
				content
			);

			response.EnsureSuccessStatusCode ();

			return await response.Content.ReadAsJsonAsync<ContactSearchByEmailResponse> ();
		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			// i think i may throw the exception. more testing though
			return default;
		}
	}

	public async Task<bool> UpdateEmailAddress (
		string contactKey,
		string contactEmailAddress
	)
	{
		try
		{
			var contactRequest = new MarketingCloudCreateContactRequest
			{
				ContactKey = contactKey,
				AttributeSets = new List<ContactAttributeSet> ()
				{
					new ( // ContactAttributeSet
						name : "Email Addresses",
						items : new List<ContactAttributeValues> () {
							new () {
								Values = new List<ContactAttributePair>()
								{
									new (
										name : "Email Address",
										value : contactEmailAddress
									),
									new (
										name : "HTML Enabled",
										value : true
									)
								}
							}
						}
					)
				}
			};

			var content = JsonConvert.SerializeObject (contactRequest);
			var response = await parent.sendRestRequest (HttpMethod.Patch, Routes.Rest.CREATE_CONTACT, content);

			response.EnsureSuccessStatusCode ();

			// TODO: this is inadequate
			return true;
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to update contact for '{contactKey}' with '{contactEmailAddress}' : {oops.Message}", oops);
		}
	}

	public async Task<ContactUpdateResponse> UpsertAttributeSet (
		string contactKey,
		ContactAttributeSet attributeSet
	)
	{
		try
		{
			var contactRequest = new MarketingCloudCreateContactRequest
			{
				ContactKey = contactKey,
				AttributeSets = new List<ContactAttributeSet> () {
					attributeSet
				}
			};

			var content = JsonConvert.SerializeObject (contactRequest);
			var response = await parent.sendRestRequest (HttpMethod.Patch, Routes.Rest.CREATE_CONTACT, content);

			response.EnsureSuccessStatusCode ();

			// just for debugging
			// string raw = await response.Content.ReadAsStringAsync ();

			return await response.Content.ReadAsJsonAsync<ContactUpdateResponse> ();
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to update contact for '{contactKey}' with attributeSet '{attributeSet.Name}' : {oops.Message}", oops);
		}
	}

	public async Task<ContactUpdateResponse> UpsertAttributeSets (
		string contactKey,
		List<ContactAttributeSet> attributeSets
	)
	{
		try
		{
			var contactRequest = new MarketingCloudCreateContactRequest
			{
				ContactKey = contactKey,
				AttributeSets = attributeSets
			};

			var content = JsonConvert.SerializeObject (contactRequest);
			var response = await parent.sendRestRequest (
				HttpMethod.Patch,
				Routes.Rest.CREATE_CONTACT,
				content
			);

			response.EnsureSuccessStatusCode ();

			return await response.Content.ReadAsJsonAsync<ContactUpdateResponse> ();
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to update contact for '{contactKey}' with attributeSets '{string.Join (',', attributeSets.Select (s => s.Name))}' : {oops.Message}", oops);
		}
	}

	public async Task<ContactSchemaResponse> GetDataSchemas (

	)
	{
		try
		{
			var response = await parent.sendRestRequest (HttpMethod.Get, Routes.Rest.CONTACT_SCHEMA);

			response.EnsureSuccessStatusCode ();

			// var respstring = await response.Content.ReadAsStringAsync ();

			return await response.Content.ReadAsJsonAsync<ContactSchemaResponse> ();
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to get contact schemas : {oops.Message}", oops);
		}
	}
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SearchContactByEmailAddressRequest
{
	/// <summary>
	/// Initializes a new instance of the <see cref="SearchContactByEmailAddressRequest"/> class.
	/// </summary>
	/// <param name="contactEmailAddress">The contact email address.</param>
	public SearchContactByEmailAddressRequest (string contactEmailAddress)
	{
		ChannelAddressList = new List<string> () { contactEmailAddress };
		MaximumCount = 1;
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="SearchContactByEmailAddressRequest"/> class.
	/// </summary>
	/// <param name="contactEmailAddresses">The contact email addresses.</param>
	public SearchContactByEmailAddressRequest (List<string> contactEmailAddresses)
	{
		ChannelAddressList = contactEmailAddresses;
	}

	/// <summary>
	/// Gets or sets the channel address list. that you want to search for
	/// </summary>
	/// <value>
	/// The channel address list.
	/// </value>
	public IEnumerable<string> ChannelAddressList { get; set; }

	/// <summary>
	/// Gets the maximum count returned by search request
	/// </summary>
	/// <value>
	/// The maximum count.
	/// </value>
	public int? MaximumCount { get; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class MarketingCloudCreateContactRequest
{
	public string? ContactKey { get; set; } // Should be the WE Contact ID
	public IEnumerable<ContactAttributeSet>? AttributeSets { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactAttributeSet
{
	public ContactAttributeSet (
		string name,
		IEnumerable<ContactAttributeValues> items
	)
	{
		Name = name;
		Items = items;
	}

	public string Name { get; set; }
	public IEnumerable<ContactAttributeValues> Items { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactAttributeValues
{
	public ContactAttributeValues ()
	{
		Values = new List<ContactAttributePair> ();
	}

	public IEnumerable<ContactAttributePair> Values { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactAttributePair
{
	public ContactAttributePair (
		string name,
		object value
	)
	{
		Name = name;
		Value = value;
	}

	public string Name { get; set; }
	public object Value { get; set; }
}
