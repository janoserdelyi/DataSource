using MarketingCloudApi.Elements;

namespace MarketingCloudApi;

public class Subscriber
{
	private MarketingCloud parent { get; set; }

	public Subscriber (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<SubscriberResponse?> GetBySubscriberKey (
		string subscriberKey
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var fields = new List<string> { "Client.ID", "EmailAddress", "SubscriberKey", "CreatedDate", "Status", "UnsubscribedDate", "EmailTypePreference" };

		var payload = payloadCreateApi.GetSubscriberByKey (
			subscriberKey,
			fields
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting a Subscriber : {oops.Message}", oops);
		}

		SubscriberResponse? ret = Soap.PayloadParseApi.SubscriberGet (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<SubscribersResponse?> Get (
		IFilterPart filter,
		string? continueRequestId = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var fields = new List<string> { "Client.ID", "EmailAddress", "SubscriberKey", "CreatedDate", "Status", "UnsubscribedDate", "EmailTypePreference" };

		var payload = payloadCreateApi.GetSubscribers (
			fields,
			filter,
			continueRequestId: continueRequestId
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting Subscribers");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting Subscribers : {oops.Message}", oops);
		}

		SubscribersResponse? ret = Soap.PayloadParseApi.SubscribersGet (responseValue);

		// some error handling? verification?

		return ret;
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/creating_a_subscriber.html
	public async Task<SubscriberCreateUpdateResponse?> Create (
		string customerKey,
		string name,
		IList<Elements.Attribute>? attributes = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.CreateSubscriber (
			customerKey,
			name,
			attributes
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for creating a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error creating Subscriber definition : {oops.Message}", oops);
		}

		SubscriberCreateUpdateResponse? ret = Soap.PayloadParseApi.SubscriberCreate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<SubscriberCreateUpdateResponse?> Update (
		string customerKey,
		string emailAddress,
		IList<Elements.Attribute>? attributes = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.UpdateSubscriber (
			customerKey,
			emailAddress,
			attributes
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for creating a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error updating Subscriber definition : {oops.Message}", oops);
		}

		SubscriberCreateUpdateResponse? ret = Soap.PayloadParseApi.SubscriberCreate (responseValue);

		// some error handling? verification?

		return ret;
	}

	public async Task<SubscriberActivateResponseResult?> Activate (
		string subscriberKey // usually email address, could be contact id depending on the system
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.ActivateSubscriber (
			subscriberKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for activating a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error activating Subscriber : {oops.Message}", oops);
		}

		var overallret = Soap.PayloadParseApi.SubscriberActivate (responseValue);

		if (overallret.Results == null || overallret.Results.Count == 0)
		{
			return null;
		}

		return overallret.Results[0];
	}

	public async Task<SubscriberActivateResponse?> Activate (
		List<string> subscriberKeys,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo = null;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.ActivateSubscriber (
			subscriberKeys
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for activating a Subscriber");
		}

		var payloadSize = Encoding.UTF8.GetBytes (payload).Length;

		if (payloadSize > targetPayloadSizeBytes)
		{

			var calcs = new UploadSize (
				maxSizeBytes: targetPayloadSizeBytes,
				payloadSizeBytes: payloadSize,
				objectCount: subscriberKeys.Count
			);

			return new SubscriberActivateResponse ()
			{
				OverallStatus = "Oversized",
				OverallStatusMessage = $"Your payload exceeds the target payload maximium size by {calcs.PayloadSizeBytes - calcs.MaxSizeBytes} bytes. Average row byte size : {calcs.AverageRowSizeBytes}, Suggested number of rows to upload : {calcs.SuggestedRowcountConservative}",
				SuggestedUploadRowCount = calcs.SuggestedRowcountConservative
			};
		}

		string? responseValue = null;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (WebException oops)
		{
			// i throw this when the request payload is too large
			if (oops.Message == "RequestEntityTooLarge")
			{
				// unfortunately we don't really get feedback on what the max allowable is. so if we do ever get this far, i will assume 20MiB since that seems to be SF's ftp max payload size

				var calcs = new UploadSize (
					maxSizeBytes: 20 * 1024 * 1024,
					payloadSizeBytes: payloadSize,
					objectCount: subscriberKeys.Count
				);

				return new SubscriberActivateResponse ()
				{
					OverallStatus = "Oversized",
					OverallStatusMessage = $"Your payload exceeds the target payload maximium size by {calcs.PayloadSizeBytes - calcs.MaxSizeBytes} bytes. Average row byte size : {calcs.AverageRowSizeBytes}, Suggested number of rows to upload : {calcs.SuggestedRowcountConservative}",
					SuggestedUploadRowCount = calcs.SuggestedRowcountConservative
				};
			}

			throw new Exception ($"[{nameof (Activate)}] Error getting response : {oops.Message}", oops);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error activating Subscriber : {oops.Message}", oops);
		}

		var ret = Soap.PayloadParseApi.SubscriberActivate (responseValue);

		ret.OverallStatus = "OK";

		return ret;
	}

	public async Task<SubscriberActivateResponse?> ActivateChunked (
		List<string> subscriberKeys,
		int targetPayloadSizeBytes = 20971520 // 20MiB
	)
	{
		var subscriberKeysCopyToSlice = new List<string> ();
		foreach (var subscriberKey in subscriberKeys)
		{
			subscriberKeysCopyToSlice.Add (subscriberKey);
		}

		var finalResponse = new SubscriberActivateResponse ();
		List<string> subscriberKeysCopy = subscriberKeysCopyToSlice;
		var sliceSize = 0;

		SubscriberActivateResponse? ret = null;
		do
		{
			ret = null;

			subscriberKeysCopyToSlice.RemoveRange (0, sliceSize);

			if (subscriberKeysCopy.Count == 0)
			{
				break;
			}

			try
			{
				ret = await Activate (
					subscriberKeysCopy,
					targetPayloadSizeBytes
				);
			}
			catch (Exception oops)
			{
				throw new Exception ($"[{nameof (ActivateChunked)}] Error getting response : {oops.Message}", oops);
			}

			if (ret == null || ret.OverallStatus == null)
			{
				throw new Exception ($"[{nameof (ActivateChunked)}] Unknown error getting response. nothing returned");
			}

			if (ret.OverallStatus == "OK")
			{
				// add all items to the final return and exit
				finalResponse.OverallStatus = ret.OverallStatus;
				finalResponse.OverallStatusMessage = ret.OverallStatusMessage;

				foreach (var result in ret.Results)
				{
					finalResponse.Results.Add (result);
				}

				// remove that same range now that it's been copied
				subscriberKeysCopyToSlice.RemoveRange (0, subscriberKeysCopy.Count);

				// continue to move the chunks along at this size
				sliceSize = subscriberKeysCopyToSlice.Count < subscriberKeysCopy.Count ? subscriberKeysCopyToSlice.Count : subscriberKeysCopy.Count;
#if NET8_0_OR_GREATER
				subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, sliceSize);
#else
				subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, sliceSize).ToList ();
#endif

				continue;
			}

			// we need to try again, but with just a portion of the uploadObjects
			if (ret.OverallStatus == "Oversized")
			{
				// put the list back on the stack, otherwise records will get lost. but not on the first run where it contains the entire set!
				if (subscriberKeysCopy.Count != subscriberKeys.Count)
				{
					subscriberKeysCopyToSlice.AddRange (subscriberKeysCopy);
				}

				// i suppose this could happen - the estimations are off
				if (ret.SuggestedUploadRowCount!.Value > subscriberKeysCopyToSlice.Count)
				{
					// chop the uploadCount in half and go from there?
#if NET8_0_OR_GREATER
					subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, subscriberKeysCopyToSlice.Count / 2);
#else
					subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, subscriberKeysCopyToSlice.Count / 2).ToList ();
#endif
					// remove that same range now that it's been copied
					subscriberKeysCopyToSlice.RemoveRange (0, subscriberKeysCopy.Count);
				}
				else
				{
					// chop the uploads down to the suggested count
					sliceSize = subscriberKeysCopyToSlice.Count < ret.SuggestedUploadRowCount!.Value ? subscriberKeysCopyToSlice.Count : ret.SuggestedUploadRowCount!.Value;
#if NET8_0_OR_GREATER
					subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, sliceSize);
#else
					subscriberKeysCopy = subscriberKeysCopyToSlice.Slice (0, sliceSize).ToList ();
#endif
				}
			}
		} while (subscriberKeysCopyToSlice.Count > 0);

		return finalResponse;
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/unsubscribing_and_logging_an_unsubevent_with_a_logunsubevent_execute_call.html
	public async Task<SubscriberActivateResponseResult?> Unsubscribe (
		string subscriberKey // usually email address, could be contact id depending on the system
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.UnsubscribeSubscriber (
			subscriberKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for activating a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error deactivating Subscriber : {oops.Message}", oops);
		}

		var overallret = Soap.PayloadParseApi.SubscriberActivate (responseValue);

		if (overallret.Results == null || overallret.Results.Count == 0)
		{
			return null;
		}

		return overallret.Results[0];
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/deleting_a_subscriber.html
	public async Task<SubscriberDeleteResponse?> Delete (
		string subscriberKey
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.DeleteSubscriber (
			subscriberKey
		);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for activating a Subscriber");
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error deactivating Subscriber : {oops.Message}", oops);
		}

		SubscriberDeleteResponse? ret = Soap.PayloadParseApi.SubscriberDelete (responseValue);

		// some error handling? verification?

		return ret;
	}
}
