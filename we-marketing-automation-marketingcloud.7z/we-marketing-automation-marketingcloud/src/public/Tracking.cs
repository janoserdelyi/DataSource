using MarketingCloudApi.Elements;

namespace MarketingCloudApi;

public class Tracking
{
	private MarketingCloud parent { get; set; }

	public Tracking (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<TrackingEventResponse?> Get (
		Enums.TrackingType trackingType,
		IList<string>? fields = null,
		IFilterPart? filter = null,
		string? continueRequestId = null
	)
	{
		if (parent.Credentials == null)
		{
			throw new System.Security.SecurityException ("Credentials have not been loaded");
		}

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var payloadCreateApi = new Soap.PayloadCreateApi (
			parent.Credentials.Subdomain,
			accessInfo.AccessToken
		);

		var payload = payloadCreateApi.GetTrackingData (trackingType, fields, filter, continueRequestId: continueRequestId);

		if (payload == null)
		{
			throw new Exception ("Unable to generate SOAP payload for getting tracking data : " + Enum.GetName (typeof (Enums.TrackingType), trackingType));
		}

		string? responseValue;

		try
		{
			responseValue = await Utils.getResponseString (accessInfo, payload);
		}
		catch (Exception oops)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Error getting Tracking Data : {oops.Message}", oops);
		}

		TrackingEventResponse? ret = Soap.PayloadParseApi.TrackingEventRetrieve (responseValue);

		return ret;
	}
}
