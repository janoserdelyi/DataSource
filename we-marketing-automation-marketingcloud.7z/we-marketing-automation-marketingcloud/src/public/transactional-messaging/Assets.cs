using System.Runtime.Serialization;
using Newtonsoft.Json.Converters;

namespace MarketingCloudApi;

public class Assets
{
	private MarketingCloud parent { get; }

	public Assets (MarketingCloud parent)
	{
		this.parent = parent;
	}

	public async Task<AdvancedAssetQueryResponse> QueryAssetsAdvancedAsync (AdvancedAssetQueryRequest req)
	{
		var payload = JsonConvert.SerializeObject (req,
			Utils.StandardJsonSerializerSettings);
		var response = await parent.sendRestRequest (HttpMethod.Post,
			"/asset/v1/content/assets/query",
			payload);
		if (response.StatusCode != HttpStatusCode.OK)
		{
			var err = await response.Content.ReadAsStringAsync ();
			throw new HttpRequestException ($"Asset advanced query failed with {(int)response.StatusCode}: {err}");
		}

		return await response.Content.ReadAsJsonAsync<AdvancedAssetQueryResponse> ();
	}

	public async Task<CreateAssetResponse> CreateAssetAsync (CreateAssetRequest req)
	{
		var payload = JsonConvert.SerializeObject (req,
			Utils.StandardJsonSerializerSettings);
		var response = await parent.sendRestRequest (HttpMethod.Post,
			"/asset/v1/content/assets",
			payload);
		if (response.StatusCode != HttpStatusCode.OK && response.StatusCode != HttpStatusCode.Created)
		{
			var body = await response.Content.ReadAsStringAsync ();
			throw new HttpRequestException ($"CreateAssetAsync failed ({(int)response.StatusCode}): {body}");
		}

		return await response.Content.ReadAsJsonAsync<CreateAssetResponse> ();
	}

	public async Task<CreateAssetResponse> UpdateAssetAsync (int assetId, UpdateAssetRequest req)
	{

		var payload = JsonConvert.SerializeObject (req, Utils.StandardJsonSerializerSettings);

		var response = await parent.sendRestRequest (HttpMethod.Patch,
			$"/asset/v1/content/assets/{assetId}",
			payload);

		if (response.StatusCode != HttpStatusCode.OK)
		{
			var body = await response.Content.ReadAsStringAsync ();
			throw new HttpRequestException ($"UpdateAssetAsync failed ({(int)response.StatusCode}): {body}");
		}

		return await response.Content.ReadAsJsonAsync<CreateAssetResponse> ();
	}

	public async Task<SimpleAssetQueryResponse> QueryAssetsSimpleAsync (
		AssetField field,
		SimpleOperators op,
		string? value = null,
		int page = 1,
		int pageSize = 50
	)
	{
		var fieldStr = Utils.EnumMemberValue (field);

		string filter;
		if (op == SimpleOperators.IsNull || op == SimpleOperators.IsNotNull)
		{
			filter = $"{fieldStr} {MapOperator (op)}";
		}
		else if (op == SimpleOperators.In)
		{
			filter = $"{fieldStr} {MapOperator (op)} ({value})";
		}
		else
		{
			filter = $"{fieldStr} {MapOperator (op)} '{value}'";
		}

		var url = $"/asset/v1/content/assets?$filter={Uri.EscapeDataString (filter)}&$page={page}&$pagesize={pageSize}";

		var response = await parent.sendRestRequest (HttpMethod.Get, url);
		if (response.StatusCode != HttpStatusCode.OK)
		{
			var err = await response.Content.ReadAsStringAsync ();
			throw new HttpRequestException ($"Simple asset query failed with {(int)response.StatusCode}: {err}");
		}

		return await response.Content.ReadAsJsonAsync<SimpleAssetQueryResponse> ();
	}

	private static string MapOperator (SimpleOperators op)
	{
		return op switch
		{
			SimpleOperators.Equal => "eq",
			SimpleOperators.NotEqual => "ne",
			SimpleOperators.LessThan => "lt",
			SimpleOperators.LessThanOrEqual => "le",
			SimpleOperators.GreaterThan => "gt",
			SimpleOperators.GreaterThanOrEqual => "ge",
			SimpleOperators.Like => "like",
			SimpleOperators.IsNull => "is null",
			SimpleOperators.IsNotNull => "is not null",
			SimpleOperators.Contains => "contains",
			SimpleOperators.MustContain => "mustcontain",
			SimpleOperators.StartsWith => "startswith",
			SimpleOperators.In => "in",
			_ => throw new NotSupportedException ($"Operator '{op}' is not supported.")
		};
	}
}

[JsonConverter (typeof (StringEnumConverter))]
public enum SimpleOperators
{
	Equal,
	NotEqual,
	LessThan,
	LessThanOrEqual,
	GreaterThan,
	GreaterThanOrEqual,
	Like,
	IsNull,
	IsNotNull,
	Contains,
	MustContain,
	StartsWith,
	In
}

[JsonConverter (typeof (StringEnumConverter))]
public enum LogicalOperator
{
	AND,
	OR
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SimpleAssetQueryResponse
{
	public List<AssetItem> Items { get; set; } = [];
	public int Count { get; set; }
	public int Page { get; set; }
	public int PageSize { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AdvancedAssetQueryRequest
{
	public List<AssetField> Fields { get; set; } = [];

	public PageRequest? Page { get; set; }

	public QueryNode? Query { get; set; }

	public List<SortRule>? Sort { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SortRule
{
	[JsonProperty (Required = Required.Always)]
	public AssetField Property { get; set; }

	[JsonProperty (Required = Required.Always)]
	public Direction Direction { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class PageRequest
{
	public int Page { get; set; } = 1;
	public int PageSize { get; set; } = 50;
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class QueryNode
{
	public AssetField? Property { get; set; }
	public SimpleOperators? SimpleOperator { get; set; }

	public object? Value { get; set; }

	public LogicalOperator? LogicalOperator { get; set; }
	public QueryNode? LeftOperand { get; set; }
	public QueryNode? RightOperand { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AdvancedAssetQueryResponse
{
	public List<AssetItem> Items { get; set; } = [];
	public int Count { get; set; }
	public int Page { get; set; }
	public int PageSize { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AssetItem
{
	public int Id { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public int? ModelVersion { get; set; }

	public AssetType? AssetType { get; set; }
	public Category? Category { get; set; }
	public Views? Views { get; set; }
	public string? Content { get; set; }

	public DateTime? CreatedDate { get; set; }
	public DateTime? ModifiedDate { get; set; }
	public StatusType? Status { get; set; }

	// Add other properties from the documentation if you plan to use them
}

public class StatusType
{
	public int Id { get; set; }
	public string? Name { get; set; }
}
public class AssetType
{
	public int Id { get; set; }
	public string? Name { get; set; }
	public string? DisplayName { get; set; }
}

public class Category
{
	public int Id { get; set; }
	public string? Name { get; set; }
	public string? FolderPath { get; set; }
	public int? ParentId { get; set; }
}

public class Views
{
	public ViewDetail? Html { get; set; }
	public ViewDetail? Text { get; set; }
	public ViewDetail? Subjectline { get; set; }
	public ViewDetail? Preheader { get; set; }
}

public class ViewDetail
{
	public string? Content { get; set; }
}

[JsonConverter (typeof (StringEnumConverter))]
public enum Direction
{
	[EnumMember (Value = "ASC")] Asc,
	[EnumMember (Value = "DESC")] Desc
}

[JsonConverter (typeof (StringEnumConverter))]
public enum AssetField
{
	[EnumMember (Value = "id")] Id,
	[EnumMember (Value = "customerKey")] CustomerKey,
	[EnumMember (Value = "objectID")] ObjectID,
	[EnumMember (Value = "name")] Name,
	[EnumMember (Value = "description")] Description,
	[EnumMember (Value = "contentType")] ContentType,
	[EnumMember (Value = "version")] Version,
	[EnumMember (Value = "locked")] Locked,
	[EnumMember (Value = "createdDate")] CreatedDate,
	[EnumMember (Value = "modifiedDate")] ModifiedDate,
	[EnumMember (Value = "activeDate")] ActiveDate,
	[EnumMember (Value = "expirationDate")] ExpirationDate,
	[EnumMember (Value = "assetType.id")] AssetTypeId,
	[EnumMember (Value = "assetType.name")] AssetTypeName,
	[EnumMember (Value = "category.id")] CategoryId,
	[EnumMember (Value = "category.name")] CategoryName,
	[EnumMember (Value = "tags")] Tags,
	[EnumMember (Value = "content")] Content,
	[EnumMember (Value = "design")] Design,
	[EnumMember (Value = "superContent")] SuperContent,
	[EnumMember (Value = "file")] File,
	[EnumMember (Value = "views")] Views,
	[EnumMember (Value = "blocks")] Blocks,
	[EnumMember (Value = "minBlocks")] MinBlocks,
	[EnumMember (Value = "maxBlocks")] MaxBlocks,
	[EnumMember (Value = "allowedBlocks")] AllowedBlocks,
	[EnumMember (Value = "channels")] Channels,
	[EnumMember (Value = "slots")] Slots,
	[EnumMember (Value = "businessUnitAvailability")] BusinessUnitAvailability,
	[EnumMember (Value = "sharingProperties")] SharingProperties,
	[EnumMember (Value = "template")] Template,
	[EnumMember (Value = "customFields")] CustomFields,
	[EnumMember (Value = "data")] Data,
	[EnumMember (Value = "generateFrom")] GenerateFrom,
	[EnumMember (Value = "status.id")] StatusId,
	[EnumMember (Value = "status.name")] StatusName,
	[EnumMember (Value = "status")] Status,

}

[JsonConverter (typeof (StringEnumConverter))]
public enum SharingType
{
	[EnumMember (Value = "view")] View,
	[EnumMember (Value = "edit")] Edit,
	[EnumMember (Value = "local")] Local
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateAssetRequest
{
	public string? CustomerKey { get; set; }

	[JsonProperty (Required = Required.Always)]
	public string? ContentType { get; set; }

	public object? Data { get; set; }

	[JsonProperty (Required = Required.Always)]
	public AssetType? AssetType { get; set; }

	public int? Version { get; set; }
	public bool? Locked { get; set; }

	[JsonProperty (Required = Required.Always)]
	public string? Name { get; set; }

	public string? Description { get; set; }
	public Category? Category { get; set; }
	public List<string>? Tags { get; set; }
	public string? Content { get; set; }
	public string? Design { get; set; }
	public string? SuperContent { get; set; }
	public object? CustomFields { get; set; }
	public object? Views { get; set; }
	public object? Blocks { get; set; }
	public int? MinBlocks { get; set; }
	public int? MaxBlocks { get; set; }
	public object? Channels { get; set; }
	public List<object>? AllowedBlocks { get; set; }
	public object? Slots { get; set; }
	public BusinessUnitAvailability? BusinessUnitAvailability { get; set; }
	public SharingProperties? SharingProperties { get; set; }
	public object? Template { get; set; }
	public string? File { get; set; }
	public string? GenerateFrom { get; set; }
}
[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class UpdateAssetRequest
{
	public string? CustomerKey { get; set; }

	public string? ContentType { get; set; }

	public object? Data { get; set; }

	public AssetType? AssetType { get; set; }

	public int? Version { get; set; }
	public bool? Locked { get; set; }

	public string? Name { get; set; }

	public string? Description { get; set; }
	public Category? Category { get; set; }
	public List<string>? Tags { get; set; }
	public string? Content { get; set; }
	public string? Design { get; set; }
	public string? SuperContent { get; set; }
	public object? CustomFields { get; set; }
	public object? Views { get; set; }
	public object? Blocks { get; set; }
	public int? MinBlocks { get; set; }
	public int? MaxBlocks { get; set; }
	public object? Channels { get; set; }
	public List<object>? AllowedBlocks { get; set; }
	public object? Slots { get; set; }
	public BusinessUnitAvailability? BusinessUnitAvailability { get; set; }
	public SharingProperties? SharingProperties { get; set; }
	public object? Template { get; set; }
	public string? File { get; set; }
	public string? GenerateFrom { get; set; }
}

public class BusinessUnitAvailability
{
	public Dictionary<string, bool>? MemberAvailability { get; set; }
}

public class SharingProperties
{
	public List<int>? SharedWith { get; set; }

	[JsonProperty (Required = Required.Always)]
	public SharingType SharingType { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateAssetResponse
{
	public string? CustomerKey { get; set; }
	public string? ContentType { get; set; }
	public object? Data { get; set; }
	public AssetType? AssetType { get; set; }
	public int Version { get; set; }
	public bool Locked { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public Category? Category { get; set; }
	public List<string>? Tags { get; set; }
	public string? Content { get; set; }
	public string? Design { get; set; }
	public string? SuperContent { get; set; }
	public object? CustomFields { get; set; }
	public object? Views { get; set; }
	public object? Blocks { get; set; }
	public object? Channels { get; set; }
	public object? Slots { get; set; }
	public BusinessUnitAvailability? BusinessUnitAvailability { get; set; }
	public SharingProperties? SharingProperties { get; set; }
	public object? Template { get; set; }
	public string? File { get; set; }
	public string? GenerateFrom { get; set; }
}
