using MarketingCloudApi.Routes;
using Newtonsoft.Json.Converters;

namespace MarketingCloudApi;

public class TransactionalDefinitions
{
	private MarketingCloud parent { get; }

	public TransactionalDefinitions (MarketingCloud parent)
	{
		this.parent = parent;
	}
	public async Task<ListEmailDefinitionsResponse> GetAllEmailDefinitionsAsync (
		List<EmailDefinitionFilter>? filters = null,
		EmailDefinitionOrderField? orderBy = null,
		SortDirection? sortDirection = null,
		int? page = null,
		int? pageSize = null
	)
	{
		var uri = new StringBuilder (Rest.TRANSACTIONAL_EMAIL_DEFINITIONS);
		var queryParams = new List<string> ();

		if (filters != null && filters.Any ())
		{
			var filterStrings = new List<string> ();
			foreach (var filter in filters)
			{
				var opStr = filter.Operator.ToString ().ToLower ();
				var statusStr = filter.Status.ToString ().ToLower ();
				filterStrings.Add ($"status {opStr} '{statusStr}'");
			}

			queryParams.Add ($"$filter={string.Join (" or ", filterStrings)}");
		}

		if (orderBy.HasValue)
		{
			var orderField = char.ToLowerInvariant (orderBy.Value.ToString ()[0]) + orderBy.Value.ToString ()[1..];
			var direction = sortDirection?.ToString ().ToUpper () ?? "ASC";
			queryParams.Add ($"$orderBy={orderField} {direction}");
		}

		if (page.HasValue)
		{
			queryParams.Add ($"$page={page.Value}");
		}

		if (pageSize.HasValue)
		{
			queryParams.Add ($"$pagesize={pageSize.Value}");
		}

		if (queryParams.Count > 0)
		{
			uri.Append ("?").Append (string.Join ("&", queryParams));
		}

		var stringUri = uri.ToString ();

		var response = await parent.sendRestRequest (HttpMethod.Get, stringUri);

		return await response.Content.ReadAsJsonAsync<ListEmailDefinitionsResponse> ();
	}

	public async Task<CreateEmailSendDefinitionResponse> CreateEmailDefinitionAsync (
		CreateEmailSendDefinitionRequest req)
	{
		try
		{
			var payload = JsonConvert.SerializeObject (req, Utils.StandardJsonSerializerSettings);

			var response = await parent.sendRestRequest (
				HttpMethod.Post,
				Rest.TRANSACTIONAL_EMAIL_DEFINITIONS,
				payload
			);

			// Throw if status is not 200 or 201
			if (response.StatusCode != HttpStatusCode.OK && response.StatusCode != HttpStatusCode.Created)
			{
				var errorContent = await response.Content.ReadAsStringAsync ();
				throw new HttpRequestException (
					$"CreateEmailDefinitionAsync failed with status {(int)response.StatusCode}: {response.StatusCode}. Response: {errorContent}");
			}

			var result = await response.Content.ReadAsJsonAsync<CreateEmailSendDefinitionResponse> ();
			return result;
		}
		catch (Exception ex)
		{
			throw new ApplicationException ("An error occurred while creating the email send definition.", ex);
		}
	}

	public async Task<SendEmailToMultipleRecipientsResponse> SendEmailToMultipleRecipientsAsync<TAttributes> (
		SendEmailToMultipleRecipientsRequest<TAttributes> request)
	{
		try
		{
			var url = "/messaging/v1/email/messages";

			var payload = JsonConvert.SerializeObject (request, Utils.StandardJsonSerializerSettings);

			var response = await parent.sendRestRequest (HttpMethod.Post, url, payload);

			if (!response.IsSuccessStatusCode)
			{
				var errorContent = await response.Content.ReadAsStringAsync ();
				throw new HttpRequestException (
					$"SendEmailToMultipleRecipientsAsync failed with status {(int)response.StatusCode}: {response.StatusCode}. Response: {errorContent}");
			}

			return await response.Content.ReadAsJsonAsync<SendEmailToMultipleRecipientsResponse> ();
		}
		catch (Exception ex)
		{
			throw new ApplicationException ("An error occurred while sending email to multiple recipients.", ex);
		}
	}

	public async Task<SendEmailToRecipientResponse> SendEmailToSingleRecipientAsync<TAttributes> (
		SendEmailToRecipientRequest<TAttributes> request,
		Guid? messageKey = null)
	{
		try
		{
			var generatedMessageKey = messageKey ?? Guid.NewGuid ();
			var url = $"/messaging/v1/email/messages/{generatedMessageKey}";

			var payload = JsonConvert.SerializeObject (request, Utils.StandardJsonSerializerSettings);

			var response = await parent.sendRestRequest (
				HttpMethod.Post,
				url,
				payload
			);

			if (!response.IsSuccessStatusCode)
			{
				var errorContent = await response.Content.ReadAsStringAsync ();
				throw new HttpRequestException (
					$"SendEmailToSingleRecipientAsync failed with status {(int)response.StatusCode}: {response.StatusCode}. Response: {errorContent}");
			}

			return await response.Content.ReadAsJsonAsync<SendEmailToRecipientResponse> ();
		}
		catch (Exception ex)
		{
			throw new ApplicationException ("An error occurred while sending the transactional email.", ex);
		}
	}

	public async Task<EmailStatusResponse> GetEmailStatusAsync (string messageKey)
	{
		if (string.IsNullOrWhiteSpace (messageKey))
		{
			throw new ArgumentException ("messageKey must be provided", nameof (messageKey));
		}

		var url = $"/messaging/v1/email/messages/{messageKey}";
		var response = await parent.sendRestRequest (HttpMethod.Get, url);

		var content = await response.Content.ReadAsStringAsync ();

		if (response.IsSuccessStatusCode)
		{
			try
			{
				return JsonConvert.DeserializeObject<EmailStatusResponse> (content)
					   ?? throw new ApplicationException ("Failed to deserialize successful response.");
			}
			catch (JsonException ex)
			{
				throw new ApplicationException ("Failed to parse EmailStatusResponse JSON.", ex);
			}
		}

		ErrorResponse? error;
		try
		{
			error = JsonConvert.DeserializeObject<ErrorResponse> (content);
		}
		catch
		{
			throw new HttpRequestException (
				$"GetEmailStatusAsync failed with status {(int)response.StatusCode}: {response.StatusCode}. Raw response: {content}");
		}

		throw new HttpRequestException (
			$"GetEmailStatusAsync failed with status {(int)response.StatusCode}: {response.StatusCode}. " +
			$"Message: {error?.Message ?? "Unknown error"}. ErrorCode: {error?.ErrorCode}.");
	}

	public class SendEmailToRecipientRequest<TAttributes>
	{
		[JsonProperty ("definitionKey", Required = Required.Always)]
		public string? DefinitionKey { get; set; }

		[JsonProperty ("recipient", Required = Required.Always)]
		public EmailRecipient<TAttributes>? Recipient { get; set; }
	}

	public class EmailRecipient<TAttributes>
	{
		[JsonProperty ("contactKey", Required = Required.Always)]
		public string? ContactKey { get; set; }

		[JsonProperty ("to", Required = Required.Always)]
		public string? To { get; set; }

		[JsonProperty ("attributes")]
		public TAttributes? Attributes { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class SendEmailToRecipientResponse
	{
		public string? RequestId { get; set; }
		public string? MessageKey { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class Recipient
	{
		[JsonProperty (Required = Required.Always)]
		public string? ContactKey { get; set; }

		[JsonProperty (Required = Required.Always)]
		public string? Address { get; set; }

		public string? SubscriberKey { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class CreateEmailSendDefinitionResponse
	{
		public string? RequestId { get; set; }
		public string? DefinitionId { get; set; }
		public string? DefinitionKey { get; set; }
		public string? Name { get; set; }
		public string? Description { get; set; }
		public string? Status { get; set; }
		public DateTime? CreatedDate { get; set; }
		public DateTime? ModifiedDate { get; set; }
		public EmailContent? Content { get; set; }
		public EmailSubscriptions? Subscriptions { get; set; }
		public EmailOptions? Options { get; set; }
		public int Id { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class CreateEmailSendDefinitionRequest
	{
		[JsonProperty (Required = Required.Always)]
		public string? DefinitionKey { get; set; }

		[JsonProperty (Required = Required.Always)]
		public string? Name { get; set; }

		public string? Description { get; set; }

		[JsonProperty (Required = Required.Always)]
		public DefinitionStatus Status { get; set; }

		[JsonProperty (Required = Required.Always)]
		public EmailContent? Content { get; set; }

		[JsonProperty (Required = Required.Always)]
		public EmailSubscriptions? Subscriptions { get; set; }

		public EmailOptions? Options { get; set; }

		public Journey? Journey { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class EmailContent
	{
		[JsonProperty ("customerKey", Required = Required.Always)]
		public string? CustomerKey { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class EmailSubscriptions
	{
		public bool? AutoAddSubscriber { get; set; } = true;
		public bool? UpdateSubscriber { get; set; } = true;
		public string? DataExtension { get; set; }
		public string? List { get; set; }
	}

	[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
	public class EmailOptions
	{
		public bool? TrackLinks { get; set; } = false;
		public List<string>? Cc { get; set; }
		public List<string>? Bcc { get; set; }
		public bool? CreateJourney { get; set; } = false;
	}
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ListEmailDefinitionsResponse
{
	public string? RequestId { get; set; }
	public List<EmailDefinition> Definitions { get; set; } = [];
	public int Count { get; set; }
	public int Page { get; set; }
	public int PageSize { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class EmailDefinition
{
	public string? DefinitionId { get; set; }
	public string? DefinitionKey { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public string? Status { get; set; } // active, inactive, deleted
	public DateTime? CreatedDate { get; set; }
	public DateTime? ModifiedDate { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateSmsSendDefinitionResponse
{
	public string? RequestId { get; set; }
	public string? DefinitionId { get; set; }
	public string? DefinitionKey { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public string? Status { get; set; }

	public DateTime? CreatedDate { get; set; }
	public DateTime? ModifiedDate { get; set; }

	public SmsContent? Content { get; set; }
	public SmsSubscriptions? Subscriptions { get; set; }
	public SmsOptions? Options { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateSmsSendDefinitionRequest
{
	[JsonProperty (Required = Required.Always)]
	public string? DefinitionKey { get; set; }

	[JsonProperty (Required = Required.Always)]
	public string? Name { get; set; }

	public string? Description { get; set; }

	[JsonProperty (Required = Required.Always)]
	public string? Status { get; set; } // "active" | "inactive"

	[JsonProperty (Required = Required.Always)]
	public SmsContent? Content { get; set; }

	[JsonProperty (Required = Required.Always)]
	public SmsSubscriptions? Subscriptions { get; set; }

	public SmsOptions? Options { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SmsContent
{
	[JsonProperty ("message", Required = Required.Always)]
	public string? Message { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SmsSubscriptions
{
	[JsonProperty ("shortCode", Required = Required.Always)]
	public string? ShortCode { get; set; }

	public string? CountryCode { get; set; }

	[JsonProperty ("keyword", Required = Required.Always)]
	public string? Keyword { get; set; }

	public bool AutoAddSubscriber { get; set; } = true;
	public bool UpdateSubscriber { get; set; } = true;
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SmsOptions
{
	public UrlShortenerOptions? UrlShortenerOptions { get; set; }
	public string? SmsMessageRegulatoryAuthorityTemplateId { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class UrlShortenerOptions
{
	public bool IsLinkShorteningEnabled { get; set; }
	public bool IsSubscriberTrackingEnabled { get; set; }
	public string? ShortenerType { get; set; } // e.g., "SFMC"
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Content
{
	[JsonProperty ("message", Required = Required.Always)]
	public string? Message { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Subscriptions
{
	[JsonProperty ("shortCode", Required = Required.Always)]
	public string? ShortCode { get; set; }

	public string? CountryCode { get; set; }

	[JsonProperty (Required = Required.Always)]
	public string? Keyword { get; set; }

	public bool AutoAddSubscriber { get; set; } = true;
	public bool UpdateSubscriber { get; set; } = true;
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class Options
{
	public UrlShortenerOptions? UrlShortenerOptions { get; set; }
	public string? SmsMessageRegulatoryAuthorityTemplateId { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateDefinitionRequest
{
	public string? DefinitionKey { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public string? Classification { get; set; }
	public Content? Content { get; set; }
	public Subscriptions? Subscriptions { get; set; }
	public Options? Options { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class CreateDefinitionResponse
{
	public string? RequestId { get; set; }
	public string? DefinitionId { get; set; }
	public string? DefinitionKey { get; set; }
	public string? Name { get; set; }
	public string? Status { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ListDefinitionsResponse
{
	public List<DefinitionInfo> Definitions { get; set; } = [];
	public int Count;
	public int Page;
	public int PageSize;
	public string? RequestId;
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DefinitionInfo
{
	public string? DefinitionKey { get; set; }
	public string? Name { get; set; }
	public string? Status { get; set; }
	public string? CreatedDate { get; set; }
	public string? ModifiedDate { get; set; }
}
[JsonConverter (typeof (StringEnumConverter))]

public enum DefinitionStatus
{
	Active,
	Inactive,
	Deleted
}

public enum FilterOperator
{
	Eq, // eq
	Neq // neq
}

public enum OrderByField
{
	DefinitionKey,
	Name,
	CreatedDate,
	ModifiedDate,
	Status
}

public enum SortDirection
{
	Asc,
	Desc
}

public enum EmailDefinitionOrderField
{
	DefinitionKey,
	Name,
	CreatedDate,
	ModifiedDate,
	Status
}

public class EmailDefinitionFilter
{
	public FilterOperator Operator { get; set; }
	public DefinitionStatus Status { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SendEmailToRecipientsResponse
{
	public string? RequestId { get; set; }
	public string? MessageKey { get; set; }
}

public class SendEmailToMultipleRecipientsRequest<TAttributes>
{
	[JsonProperty ("definitionKey", Required = Required.Always)]
	public string? DefinitionKey { get; set; }

	[JsonProperty ("recipients", Required = Required.Always)]
	public List<MultiEmailRecipient<TAttributes>>? Recipients { get; set; }

	[JsonProperty ("attributes", NullValueHandling = NullValueHandling.Ignore)]
	public TAttributes? Attributes { get; set; }
}

public class MultiEmailRecipient<TAttributes>
{
	[JsonProperty ("contactKey", Required = Required.Always)]
	public string? ContactKey { get; set; }

	[JsonProperty ("to", Required = Required.Always)]
	public string? To { get; set; }

	[JsonProperty ("messageKey", Required = Required.Always)]
	public string? MessageKey { get; set; }

	[JsonProperty ("attributes")]
	public TAttributes? Attributes { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SendEmailToMultipleRecipientsResponse
{
	[JsonProperty ("requestId")]
	public string? RequestId { get; set; }

	[JsonProperty ("errorcode")]
	public int ErrorCode { get; set; }

	[JsonProperty ("responses")]
	public List<RecipientSendResponse>? Responses { get; set; }
}

public class RecipientSendResponse
{
	[JsonProperty ("messageKey")]
	public string? MessageKey { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class EmailStatusResponse
{
	public string? RequestId { get; set; }
	public string? EventCategoryType { get; set; }
	public DateTime? Timestamp { get; set; }
	public string? CompositeId { get; set; }
	public EmailStatusInfo? Info { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class EmailStatusInfo
{
	public string? MessageKey { get; set; }
	public string? ContactKey { get; set; }
	public string? To { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ErrorResponse
{
	public string? Message { get; set; }
	public int? ErrorCode { get; set; }
	public string? Documentation { get; set; }
}
