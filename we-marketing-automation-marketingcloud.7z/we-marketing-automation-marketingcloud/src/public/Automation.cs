namespace MarketingCloudApi;

public class Automation
{
	private MarketingCloud parent { get; set; }

	public Automation (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<AutomationRequest?> Get (
		string automationId
	)
	{
		var automationInfo = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Routes.Rest.UPSERT_AUOTMATION}{automationId}"
		);

		//var automationInfoContent = await automationInfo.Content.ReadAsStringAsync();
		//AutomationRequest? automationInfoResult = JsonConvert.DeserializeObject<AutomationRequest>(automationInfoContent);

		var automationInfoResult = await automationInfo.Content.ReadAsJsonAsync<AutomationRequest> ();

		return automationInfoResult;
	}

	public async Task<AutomationSearchResponse?> SearchByCampaignName (
		string campaignName
	)
	{
		var searchResp = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Routes.Rest.SEARCH_AUTOMATION}?$top=25&$skip=0&$sort=createdDate%20desc&view=list&status=InactiveTrigger&automationtype=triggered&$where=name like {campaignName}"
		);

		//var searchRespContent = await searchResp.Content.ReadAsStringAsync();
		//AutomationSearchResponse? searchResult = JsonConvert.DeserializeObject<AutomationSearchResponse>(searchRespContent);

		var searchResult = await searchResp.Content.ReadAsJsonAsync<AutomationSearchResponse> ();

		return searchResult;
	}

	// this is too tied to a file automation it appears. leaving commented out for now
	// this needs to be more general-purpose
	/*
	private async Task Activate (
		string campaignName
	) {
		// search the created Automation to get id to activate
		var searchResp = await parent.SendRESTClientAsync (
			HttpMethod.Get,
			$"{Routes.Rest.SEARCH_AUTOMATION}?$top=25&$skip=0&$sort=createdDate%20desc&view=list&status=InactiveTrigger&automationtype=triggered&$where=name like {campaignName}"
		);

		var searchRespContent = await searchResp.Content.ReadAsStringAsync();

		AutomationSearchResponse? searchResult = JsonConvert.DeserializeObject<AutomationSearchResponse>(searchRespContent);

		if (
			searchResult == null ||
			searchResult.TotalResults <= 0 ||
			searchResult.Entry == null ||
			searchResult.Entry.Count() <= 0
		) {
			throw new Exception($"[{Utils.GetCurrentMethodName()}] Failed to search Marketing Cloud Automation for Campaign Name: {campaignName}'");
		}

		// activate the automation
		string activationPayload = $"{{\"publish\":true,\"fileTriggerProgramId\":\"{searchResult.Entry.First().Id}\"}}";

		var activationResp = await parent.SendRESTClientAsync (
			HttpMethod.Post,
			$"{Routes.Rest.ACTIVATE_FILE_DROP_AUTOMATION}",
			activationPayload
		);

		if (!activationResp.IsSuccessStatusCode) {
			throw new Exception($"[{Utils.GetCurrentMethodName()}] Failed to activate Automation. {activationResp.ReasonPhrase} - Campaign Name: {campaignName} - Payload: {activationPayload}'");
		}
	}
	*/
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationRequest
{
	public string? Name { get; set; }

	public string? Description { get; set; }

	public string? Key { get; set; }

	public List<AutomationStep>? Steps { get; set; }

	public AutomationStartSource? StartSource { get; set; }

	public int CategoryId { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationStartSource
{
	/// <summary>
	/// Get or set TypeId
	/// 2: Triggered Auto
	/// </summary>
	public int TypeId { get; set; }

	/// <summary>
	/// Get or set FileDrop
	/// </summary>
	public AutomationFileDrop? FileDrop { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationFileDrop
{
	public enum FilenamePatternType
	{
		NoName = 0,
		Contains = 1,
		BeginWith = 2,
		EndWith = 3
	}

	/// <summary>
	/// Get or set FilenamePatternTypeId
	/// 0 is no name, 1 Contains, 2 begins with, 3 ends with
	/// </summary>
	public FilenamePatternType FilenamePatternTypeId { get; set; }

	/// <summary>
	/// Get or set FilenamePattern
	/// only used with 1-3 to set string for filename - remove for 0
	/// </summary>
	public string? FilenamePattern { get; set; }

	/// <summary>
	/// Get or set FolderLocation
	/// </summary>
	public string? FolderLocation { get; set; }

	/// <summary>
	/// Get or set StatusId
	/// </summary>
	public int StatusId { get; set; }

	/// <summary>
	/// Get or set queueFiles
	/// </summary>
	public bool? QueueFiles { get; set; }

	///// <summary>
	///// Get or set TriggerActive
	///// </summary>
	//public bool? TriggerActive { get; set; }

	///// <summary>
	///// Get or set IsPublished
	///// </summary>
	//public bool? IsPublished { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationStep
{
	public string? Id { get; set; }

	public int? StepNumber { get; set; }

	public string? Annotation { get; set; }

	public List<AutomationActivity>? Activities { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationActivity
{
	public enum ObjectType
	{
		SalesforceSend = 771,
		QueryActivity = 300,
		DataExtract = 73,
		FileTransfer = 53,
		FilterActivity = 303,
		FireEvent = 749,
		ImportFile = 43,
		ScriptActivity = 423,
		GuidedSend = 42,
		WaitActivity = 467,
		VerificationActivity = 1000,
		RefreshGroup = 45,
		DataFactoryUtility = 425,
		SendSMS = 725,
		ImportMobileContacts = 726,
		RefreshMobileFilteredList = 724,
		SendGroupConnect = 783,
		ReportDefinition = 84,
		SendPush = 736
	}

	public string? Id { get; set; }

	public string? Name { get; set; }

	/// <summary>
	/// Get or set ObjectTypeId. Keep the data type in INT since we don't control enum type.
	/// </summary>
	public int? ObjectTypeId { get; set; }

	public int DisplayOrder { get; set; }

	public string? ActivityObjectId { get; set; }

	public string? SerializedObject { get; set; }

	public List<AutomationDataExtension>? TargetDataExtensions { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationDataExtension
{
	public string? Id { get; set; }

	public string? Name { get; set; }

	public string? Key { get; set; }

	public int? RowCount { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationSearchResponse
{
	public int StartIndex { get; set; }

	public int ItemsPerPage { get; set; }

	public int TotalResults { get; set; }

	[JsonProperty ("entry")]
	public List<AutomationSearchResultItem>? Entries { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AutomationSearchResultItem
{
	public string? Id { get; set; }

	public string? Key { get; set; }

	public DateTime? CreatedDate { get; set; }

	public string? Name { get; set; }

	public string? Description { get; set; }

	public bool? IsActive { get; set; }

	public DateTime? ModifiedDate { get; set; }

	public string? Status { get; set; }

	public string? ScheduledTime { get; set; }

	public string? Notifications { get; set; }

	public string? AutomationType { get; set; }

	public string? FileTriggerFolderLocation { get; set; }

	public string? LastRunStatus { get; set; }
}
