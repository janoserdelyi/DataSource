namespace MarketingCloudApi;

public class AttributeGroup
{
	private MarketingCloud parent { get; set; }

	public AttributeGroup (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	public async Task<AttributeGroupsResponse?> GetAll (
		string schemaId
	)
	{
		try
		{
			var response = await parent.sendRestRequest (
				HttpMethod.Get,
				Routes.Rest.ATTRIBUTEGROUPS.Replace ("{schemaId}", schemaId)
			);

			response.EnsureSuccessStatusCode ();

			var foo = await response.Content.ReadAsStringAsync ();

			return await response.Content.ReadAsJsonAsync<AttributeGroupsResponse> ();
		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			return default;
		}
	}

	public async Task<AttributeGroupResponse?> Get (
		string attributeGroupId
	)
	{
		try
		{
			var response = await parent.sendRestRequest (
				HttpMethod.Get,
				Routes.Rest.ATTRIBUTEGROUP.Replace ("{attributeGroupId}", attributeGroupId)
			);

			response.EnsureSuccessStatusCode ();

			return await response.Content.ReadAsJsonAsync<AttributeGroupResponse> ();
		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			return default;
		}
	}

	public async Task<AttributeGroupResponseItem?> GetByName (
		string schemaId,
		string name
	)
	{
		try
		{
			var response = await parent.sendRestRequest (
				HttpMethod.Get,
				Routes.Rest.ATTRIBUTEGROUPS.Replace ("{schemaId}", schemaId)
			);

			response.EnsureSuccessStatusCode ();

			var allResp = await response.Content.ReadAsJsonAsync<AttributeGroupsResponse> ();

			if (allResp == null || allResp.Items == null || allResp.Items.Count == 0)
			{
				return null;
			}

			return allResp.Items.FirstOrDefault (item => item.Name == name);

		}
		catch (Exception oops)
		{
			Console.WriteLine (oops.ToString ());
			return default;
		}
	}

	// public async Task<bool> AssociateToDataExtension (
	// 	string attributeGroupId,
	// 	string attributeSetId,
	// 	string dataExtensionCustomerKey
	// ) {

	// 	return false;
	// }
}
