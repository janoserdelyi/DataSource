using MarketingCloudApi.Elements;
using MarketingCloudApi.Models;
using MarketingCloudApi.Routes;

namespace MarketingCloudApi;

public class Journey
{
	private MarketingCloud parent { get; set; }

	public Journey (
		MarketingCloud parent
	)
	{
		this.parent = parent;
	}

	// TODO: i'd like to return some sort of response at some point
	public async Task<bool> Delete (
		string journeyKey
	)
	{

		AccessTokenInfo? accessInfo;

		try
		{
			accessInfo = await parent.retrieveAccessInfo ();
		}
		catch (System.Security.SecurityException)
		{
			throw;
		}
		catch (Exception)
		{
			throw;
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Delete,
			$"{Rest.CREATE_JOURNEY}/{journeyKey}"
		);

		// If Success, it returns a string with the journey Id within it
		var responseText = await response.Content.ReadAsStringAsync ();

		if (responseText.Contains (journeyKey))
		{
			return true;
		}
		else
		{ // Else convert to error object
			var responseValue = JsonConvert.DeserializeObject<DeleteRestFailureResponse> (responseText);
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to delete journey {responseValue}");
		}
	}

	// TODO: pause journey by definition id : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/JourneyPauseByDefinitionId.html

	// TODO: pause journey by definition key : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/JourneyPauseByDefinitionKey.html

	// TODO: resume journey by definition id : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/JourneyResumeByDefinitionId.html

	// TODO: resume journey by definition key : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/JourneyResumeByDefinitionKey.html

	// TODO: stop a journey : https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/postStopInteractionById.html

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/contactExitRequest.html
	public async Task<JourneyRemoveContactResponse> RemoveContact (
		string journeyKey,
		string contactKey
	)
	{
		return await RemoveContacts (journeyKey, new List<string> { contactKey });
	}

	public async Task<JourneyRemoveContactResponse> RemoveContacts (
		string journeyKey,
		IEnumerable<string> contactKeys
	)
	{
		var journeyDefinition = await parent.Journey ().Get (Enums.JourneySelectField.CustomerKey, journeyKey);

		if (journeyDefinition == null)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to remove contact(s) from journey. unable to retrieve journey definition");
		}

		if (journeyDefinition.Key == null)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to remove contact(s) from journey. unable to retrieve journey definition key");
		}

		var finalResponse = new JourneyRemoveContactResponse ();

		var chunks = contactKeys.Chunk<string> (50);

		foreach (var chunk in chunks)
		{
			try
			{
				var removeContactList = new List<ContactExit> ();

				foreach (var contactKey in chunk)
				{
					removeContactList.Add (
						new ContactExit (
							contactKey: contactKey,
							definitionKey: journeyDefinition.Key
						)
					);
				}

				var payload = JsonConvert.SerializeObject (removeContactList, Utils.StandardJsonSerializerSettings);

				var response = await parent.sendRestRequest (
					HttpMethod.Post,
					Rest.REMOVE_CONTACT_FROM_JOURNEY,
					payload
				);

				response.EnsureSuccessStatusCode ();

				var resp = await response.Content.ReadAsJsonAsync<JourneyRemoveContactResponse> ();

				finalResponse.Errors.AddRange (resp.Errors);

			}
			catch (Exception ex)
			{
				throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to remove contact(s) from journey", ex);
			}
		}

		return finalResponse;
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/jb-api-specification.html
	// create a journey https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/postCreateInteraction.html

	/*
	if (!SharedConstants.Environment.IsProduction() && !SharedConstants.Environment.IsEnvironment("prd"))
	{
		configArgs.criteria = JourneyFilter();
		configArgs.schemaVersionId = 12;
	}

	if (!SharedConstants.Environment.IsProduction() && !SharedConstants.Environment.IsEnvironment("prd"))
	{
		trigger.description = "Email Address contains @homes.com OR Email Address contains @costar.com";
	}


	and example creation :

	string campaignName = "Janos's Big Fun Campaign";
	string sourceApplicationExtensionId = "9adb989c-1fbc-4a75-8c3b-52fa68703a06";

	// check the campaign name
	var checkNameResponse = await mc.Journey().CheckName(campaignName);

	campaignName = checkNameResponse.Name;

	string sendableEmailFieldName = "EmailAddress";

	await mc.DataExtension().Delete(campaignName);

	// create the data extension for this campaign
	var de = await mc.DataExtension().Create (
		campaignName,
		campaignName,
		true,
		new List<Field> {
			new (
				customerKey : "PrimaryKey",
				name : "PrimaryKey",
				fieldType : "Number",
				isRequired : true,
				isPrimaryKey : true
			),
			new (
				customerKey : "Name",
				name : "Name",
				fieldType : "Text",
				maxLength : 200
			),
			new (
				customerKey : sendableEmailFieldName,
				name : sendableEmailFieldName,
				fieldType : "EmailAddress",
				//maxLength: 254,
				isRequired: true
			),
			new (
				customerKey : "Street",
				name : "Street",
				fieldType : "Text",
				maxLength : 200,
				isRequired : true
			),
			new (
				customerKey : "City",
				name : "City",
				fieldType : "Text",
				maxLength : 100,
				isRequired : true
			),
			new (
				customerKey : "PostalCode",
				name : "PostalCode",
				fieldType : "Text",
				maxLength : 20,
				isRequired : true
			)
		},
		new SendableDataExtensionField () {
			//CustomerKey = sendableEmailFieldName,
			Name = sendableEmailFieldName,
			//FieldType = "EmailAddress"
		},
		new SendableSubscriberField ("Subscriber Key") // no idea why this is "Subscriber Key" but based on some buisness unit rules i think it must be. the other option tends to be "Subscriber ID"
	);

	// select the data extension to get the correct data type and values for the journey create. plus i need an object id
	var deSelect = await mc.DataExtension().Get(de!.ObjectId!);

	string filterDefiniition = @"<FilterDefinition>
<ConditionSet Operator=""OR"" ConditionSetName=""Individual Filter Grouping"">
	<Condition Operator=""Contains"" Key=""Email Addresses.Email Address"">
		<Value>
			<![CDATA[@costar.com]]>
		</Value>
	</Condition>
	<Condition Operator=""Contains"" Key=""Email Addresses.Email Address"">
		<Value>
			<![CDATA[@homes.com]]>
		</Value>
	</Condition>
</ConditionSet>
</FilterDefinition>";

	// create the journey for this campaign
	var journey = await mc.Journey().Create (
		campaignName,
		sourceApplicationExtensionId,
		deSelect!,
		new MarketingCloudApi.Models.ConfigurationArguments {
			Criteria = filterDefiniition
		},
		triggerDescription: "Email Address contains @homes.com OR Email Address contains @costar.com"
	);
	*/

	[Obsolete ("Use Create() with description. This is deprecated as of version 0.31.0")]
	public async Task<MarketingCloudMetaData> Create (
		string campaignName,
		string sourceApplicationExtensionId,
		DataExtensionResponseObject dataExtension,
		SendableDataExtensionField? sendableDataExtensionField = null,
		ConfigurationArguments? configArgs = null,
		string? triggerDescription = null
	)
	{
		return await Create (campaignName, campaignName, sourceApplicationExtensionId, dataExtension, sendableDataExtensionField, configArgs, triggerDescription);
	}

	public async Task<MarketingCloudMetaData> Create (
		string campaignName,
		string campaignDescription,
		string sourceApplicationExtensionId,
		DataExtensionResponseObject dataExtension,
		SendableDataExtensionField? sendableDataExtensionField = null,
		ConfigurationArguments? configArgs = null,
		string? triggerDescription = null
	)
	{
		ArgumentNullException.ThrowIfNull (campaignName);
		ArgumentNullException.ThrowIfNull (campaignDescription);
		ArgumentNullException.ThrowIfNull (sourceApplicationExtensionId);
		ArgumentNullException.ThrowIfNull (dataExtension);

		// if there is a filter definition, there needs to be a triggerDescription
		if (configArgs != null && configArgs.Criteria != null && triggerDescription == null)
		{
			throw new ArgumentNullException ("If a configArgs.Criteria value is provided, a triggerDescription is also required");
		}

		// tehcnically this is not true. but it *is* true for how we use journeys backed by data extensions
		// if (dataExtension.IsSendable && sendableDataExtensionField == null) {
		// 	throw new ArgumentNullException("If a data extension is sendable, a sendableDataExtensionField is also required");
		// }

		campaignName = Utils.NormalizeMarketingCloudName (campaignName);

		// check the campaign name
		var checkNameResponse = await parent.Journey ().CheckName (campaignName);

		campaignName = checkNameResponse.Name;

		// create the send definition for the journey
		var sourceEvent = await parent.SourceEvent ().Create (
			campaignName,
			campaignDescription,
			sourceApplicationExtensionId,
			dataExtension.ObjectId!
		);

		// Create the trigger
		var trigger = new JourneyTrigger
		{
			Id = sourceEvent.Id,
			Key = Guid.NewGuid ().ToString (), // "TRIGGER",
			Name = "TRIGGER",
			Type = "EmailAudience",
			MetaData = new TriggerMetaData
			{
				EventDefinitionId = sourceEvent.Id,
				EventDefinitionKey = sourceEvent.EventDefinitionKey,
				SourceInteractionId = "00000000-0000-0000-0000-000000000000",
				ConfigurationRequired = false,
			},
			ConfigurationArguments = configArgs,
			Description = triggerDescription
		};

		// Default sent email address to be the one from DE
		EmailDefault? defaults = null;

		if (sendableDataExtensionField != null)
		{
			defaults = new EmailDefault
			{
				Email = ["{{Event." + sourceEvent.EventDefinitionKey + ".\"" + sendableDataExtensionField.Name + "\"}}"]
			};
		}

		// Create Journey
		var journey = new SimpleJourney
		{
			Key = Guid.NewGuid ().ToString (),
			Name = sourceEvent.Name,
			Description = sourceEvent.Description,
			EntryMode = "MultipleEntries",
			WorkflowApiVersion = 1,
			Triggers = [trigger],
			Defaults = defaults
		};

		var payload = JsonConvert.SerializeObject (journey, Utils.StandardJsonSerializerSettings);

		var response = await parent.sendRestRequest (
			HttpMethod.Post,
			Rest.CREATE_JOURNEY,
			payload
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		//var stringresponse = await response.Content.ReadAsStringAsync();

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponseItem> ();

		if (resp == null || string.IsNullOrEmpty (resp.Id))
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Failed to create journey");
		}

		return new MarketingCloudMetaData (
			journeyInfo: resp,
			dataExtension: dataExtension,
			entrySourceInfo: sourceEvent
		);
	}

	public async Task<JourneyCheckNameResponse> CheckName (
		string campaignName,
		string? matchModifer = null
	)
	{

		campaignName = Utils.NormalizeMarketingCloudName (campaignName);

		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Rest.CREATE_JOURNEY}/?name={campaignName}"
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		//var stringresponse = await response.Content.ReadAsStringAsync();

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponse> ();

		if (resp.Items != null && resp.Items.Count > 0)
		{
			var matchingItem = resp.Items.FirstOrDefault (item => item.Name!.ToLower ().Trim () == campaignName.ToLower ().Trim ());

			if (matchingItem != null)
			{
				matchModifer ??= "_" + Guid.NewGuid ().ToString ();
				// If a matching item is found, return a modified name
				return new JourneyCheckNameResponse (matchingItem.Name + matchModifer, true);
			}
			else
			{
				// If no matching item is found, handle accordingly
				// For example, you might want to proceed with using the original journeyName
				return new JourneyCheckNameResponse (campaignName, false);
			}
		}

		return new JourneyCheckNameResponse (campaignName, false);
	}

	public async Task<JourneyResponseItem> Get (
		Enums.JourneySelectField selectField,
		string value,
		int? versionNumber = null
	)
	{
		return selectField switch
		{
			Enums.JourneySelectField.CustomerKey => await Get (value, versionNumber),
			Enums.JourneySelectField.InternalKey => await getByInternalKey (value, versionNumber),
			_ => throw new Exception ("Unknown Journey select type"),
		};
	}

	public async Task<JourneyResponseItem> Get (
		string interactionGuid,
		int? versionNumber = null
	)
	{

		var versionQuery = "";

		if (versionNumber != null)
		{
			versionQuery = $"&versionNumber={versionNumber}";
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Rest.CREATE_JOURNEY}/{interactionGuid}?extras=all{versionQuery}"
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		// var stringresponse = await response.Content.ReadAsStringAsync ();

		//return stringresponse;

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponseItem> ();

		return resp;
	}

	private async Task<JourneyResponseItem> getByInternalKey (
		string journeyInternalKey,
		int? versionNumber = null
	)
	{

		var versionQuery = "";

		if (versionNumber != null)
		{
			versionQuery = $"&versionNumber={versionNumber}";
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			$"{Rest.CREATE_JOURNEY}/key:{journeyInternalKey}?extras=all{versionQuery}"
		// $"{Rest.CREATE_JOURNEY}/{journeyInternalKey}?extras=all{versionQuery}"
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		// var stringresponse = await response.Content.ReadAsStringAsync ();

		//return stringresponse;

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponseItem> ();

		return resp;
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/getInteractionCollection.html
	[Obsolete ("Use Get(JourneySelectField selectField, string value, int? version) instead")]
	public async Task<JourneyResponseItem> GetByKey (
		string journeyExternalKey,
		int? versionNumber = null
	)
	{

		var versionQuery = "";

		if (versionNumber != null)
		{
			versionQuery = $"&versionNumber={versionNumber}";
		}

		var response = await parent.sendRestRequest (
			HttpMethod.Get,
			// $"{Rest.CREATE_JOURNEY}/key:{journeyExternalKey}?extras=all{versionQuery}"
			$"{Rest.CREATE_JOURNEY}/{journeyExternalKey}?extras=all{versionQuery}"
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		// var stringresponse = await response.Content.ReadAsStringAsync ();

		//return stringresponse;

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponseItem> ();

		return resp;
	}

	[Obsolete ("Use UpdateName (string journeyKey,int journeyVersion, string name, string? description = null)")]
	public async Task<JourneyResponseItem> UpdateName (
		string journeyKey,
		int journeyVersion,
		decimal workflowApiVersion,
		DateTime modifiedDate,
		string name,
		string? description = null
	)
	{
		return await UpdateName (journeyKey, journeyVersion, name, description);
	}

	// https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/putUpdateInteraction.html
	public async Task<JourneyResponseItem> UpdateName (
		string journeyKey,
		int journeyVersion,
		string name,
		string? description = null
	)
	{
		// 2024-09-18 it appears that just updating the name detaches or destroys the event definition attachement to the journey (also known as triggers)
		// get the journey first so that we can get this info
		var journey = await Get (Enums.JourneySelectField.CustomerKey, journeyKey, journeyVersion);

		if (journey == null)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] No Journey found for key {journeyKey} version {journeyVersion}");
		}

		name = Utils.NormalizeMarketingCloudName (name);

		if (description != null)
		{
			description = Utils.NormalizeMarketingCloudName (description);
		}

		journey.Name = name;
		journey.Description = description;

		var payload = JsonConvert.SerializeObject (journey);

		var response = await parent.sendRestRequest (
			HttpMethod.Put,
			$"{Rest.UPDATE_JOURNEY}",
			payload: payload
		);

		if (response.IsSuccessStatusCode == false)
		{
			throw new Exception ($"[{Utils.GetCurrentMethodName ()}] Response is empty. {response.Content}");
		}

		// var stringresponse = await response.Content.ReadAsStringAsync ();

		//return stringresponse;

		var resp = await response.Content.ReadAsJsonAsync<JourneyResponseItem> ();

		return resp;
	}
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyUpdateObject
{
	/*
	@$"{{
		""key"": ""{journeyKey}"",
		""modifiedDate"": ""{modifiedDate.ToString ("yyyy-MM-ddTHH:mm:ss.fff")}"",
		""name"": ""{name}"",
		""version"": {journeyVersion},
		{(description == null ? "" : "\"description\": \"" + description + "\",")}
		""workflowApiVersion"": {String.Format ("{0:0.0}", workflowApiVersion)}
	}}";
	*/

	public string? Key { get; set; }
	public string? ModifiedDate { get; set; } // yep, string. don't feel like dealing with the serialization format. it's "yyyy-MM-ddTHH:mm:ss.fff" btw
	public string? Name { get; set; }
	public int? Version { get; set; }
	public string? Description { get; set; }
	public decimal WorkflowApiVersion { get; set; }
	public List<JourneyUpdateTrigger> Triggers { get; set; } = [];
}
// yep, this is a slightly different format than other trigger objects
public class JourneyUpdateTrigger
{
	public string? Key { get; set; }
	public string? Name { get; set; }
	public string? Type { get; set; }
	public string? EventDefinitionKey { get; set; }
	public ConfigurationArguments ConfigurationArguments { get; set; } = new ConfigurationArguments ();
}

public class MarketingCloudMetaData
{

	public MarketingCloudMetaData (
		JourneyResponseItem journeyInfo,
		DataExtensionResponseObject dataExtension,
		SourceEventResponse entrySourceInfo
	)
	{
		JourneyInfo = journeyInfo;
		DataExtension = dataExtension;
		EntrySourceInfo = entrySourceInfo;
	}

	public JourneyResponseItem JourneyInfo { get; set; }
	public DataExtensionResponseObject DataExtension { get; set; }
	public SourceEventResponse EntrySourceInfo { get; set; }
	public string? AutomationId { get; set; }
}
