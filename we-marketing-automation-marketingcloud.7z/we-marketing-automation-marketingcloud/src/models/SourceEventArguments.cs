namespace MarketingCloudApi.Models;

[JsonObject(NamingStrategyType = typeof(CamelCaseNamingStrategy))]
public class SourceEventArguments
{
	public string? EventDefinitionId { get; set; }
	public string? EventDefinitionKey { get; set; }
	public string? DataExtensionId { get; set; }
	public bool UseHighWatermark { get; set; }
	public string? AutomationId { get; set; }
	public int? SerializedObjectType { get; set; }
	public string? Criteria {  get; set; }
}
