namespace MarketingCloudApi.Models;

[JsonObject(NamingStrategyType = typeof(CamelCaseNamingStrategy))]
public class SourceEventMetaData
{
	public string? CriteriaDescription { get; set; }
	public string? ScheduleFlowMode { get; set; }
	public string? RunOnceScheduleMode { get; set; }
	public string? ScheduleState { get; set; }
}
