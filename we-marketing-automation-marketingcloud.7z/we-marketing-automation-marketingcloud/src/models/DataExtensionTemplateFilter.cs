namespace MarketingCloudApi.Models;

public class DataExtensionTemplateFilter
{
	public DataExtensionTemplateFilterField Field { get; set; }
	public string? Value { get; set; }
}
public enum DataExtensionTemplateFilterField
{
	CustomerKey,
	ObjectID,
	Name
}