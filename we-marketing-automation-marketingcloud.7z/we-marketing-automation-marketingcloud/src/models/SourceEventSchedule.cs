namespace MarketingCloudApi.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SourceEventSchedule
{
	// there are more properties than this, but this is what i'm starting with
	/*
	"schedule": {
		"startDateTime": "2024-09-17T17:30:00",
		"endDateTime": "2074-09-17T17:30:00",
		"timeZone": "Eastern Standard Time",
		"occurrences": 438289,
		"endType": "EndDate",
		"frequency": "Hourly",
		"recurrencePattern": "Interval",
		"interval": 1
	},
	*/
	public string? StartDateTime { get; set; }
	public string? EndDateTime { get; set; }
	public string? TimeZone { get; set; } = "Eastern Standard Time";
	public int Occurrences { get; set; } = 0;
	public string? EndType { get; set; }
	public string? Frequency { get; set; }
	public string? RecurrencePattern { get; set; }
	public int Interval { get; set; } = 1;
}
