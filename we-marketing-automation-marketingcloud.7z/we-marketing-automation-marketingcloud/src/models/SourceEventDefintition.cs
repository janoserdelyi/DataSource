
namespace MarketingCloudApi.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SourceEventDefintition
{
	public string? Type { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public string? Mode { get; set; }
	public string? EventDefinitionKey { get; set; }
	public string? SourceApplicationExtensionId { get; set; }
	public string? DataExtensionId { get; set; }
	public string? DataExtensionName { get; set; }
	public bool? IsVisibleInPicker { get; set; }
	public string? Category { get; set; }
	public string? FilterDefinitionId { get; set; }
	public string? FilterDefinitionTemplate { get; set; }
	public string? AutomationId { get; set; }
	public SourceEventArguments? Arguments { get; set; }
	public SourceEventMetaData? MetaData { get; set; }
	public ConfigurationArguments? ConfigurationArguments { get; set; }
	public SourceEventSchedule? Schedule { get; set; }
}