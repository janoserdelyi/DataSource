namespace MarketingCloudApi.Models;

[JsonObject(NamingStrategyType = typeof(CamelCaseNamingStrategy))]
public class EmailDefault
{
	public string[]? Email { get; set; }
}
