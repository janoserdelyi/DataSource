namespace MarketingCloudApi.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class TriggerMetaData
{
	public string? EventDefinitionId { get; set; }
	public string? EventDefinitionKey { get; set; }
	public string? SourceInteractionId { get; set; } = "00000000-0000-0000-0000-000000000000";
	public bool? ConfigurationRequired { get; set; }
	public string IconUrl { get; set; } = "/images/icon-data-extension.svg";
	public string Title { get; set; } = "Data Extension";
	public string EntrySourceGroupConfigUrl { get; set; } = "jb:///data/entry/audience/entrysourcegroupconfig.json";
	public string ChainType { get; set; } = "None";
}
