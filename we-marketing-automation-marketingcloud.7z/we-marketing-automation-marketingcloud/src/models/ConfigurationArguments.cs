namespace MarketingCloudApi.Models;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ConfigurationArguments
{
	public bool? Unconfigured { get; set; }
	public int SchemaVersionId { get; set; } = 12;
	public string? Criteria { get; set; }
	public string? FilterDefinitionId { get; set; }
	public int? WaitDuration { get; set; }
	public string? WaitUnit { get; set; }
}
