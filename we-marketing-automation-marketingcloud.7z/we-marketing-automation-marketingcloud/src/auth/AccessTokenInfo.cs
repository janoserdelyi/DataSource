namespace MarketingCloudApi;

public class AccessTokenInfo (
	string soapUri,
	string restUri,
	string accessToken
)
{
	[JsonProperty (PropertyName = "soapUri")]
	public string SoapUri { get; set; } = soapUri;

	[JsonProperty (PropertyName = "restUri")]
	public string RestUri { get; set; } = restUri;

	[JsonProperty (PropertyName = "access_token")]
	public string AccessToken { get; set; } = accessToken;
}
