namespace MarketingCloudApi;

public class GetTokenResponse
{
	[JsonProperty (PropertyName = "access_token")]
	public string? AccessToken { get; set; }

	[JsonProperty (PropertyName = "token_type")]
	public string? TokenType { get; set; }

	[JsonProperty (PropertyName = "expires_in")]
	public int? ExpiresIn { get; set; }

	[JsonProperty (PropertyName = "scope")]
	public string? Scope { get; set; }

	[JsonProperty (PropertyName = "soap_instance_url")]
	public string? SoapInstanceUrl { get; set; }

	[JsonProperty (PropertyName = "rest_instance_url")]
	public string? RestInstanceUrl { get; set; }
}
