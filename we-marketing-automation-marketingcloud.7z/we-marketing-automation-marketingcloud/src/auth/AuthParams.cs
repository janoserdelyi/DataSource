namespace MarketingCloudApi;

public class AuthParams (
	string accountId,
	string subdomain,
	string baseUri,
	string clientId,
	string clientSecret,
	string grantType = "client_credentials"
)
{
	public string AccountId { get; set; } = accountId;
	public string Subdomain { get; set; } = subdomain;
	public string BaseUri { get; set; } = baseUri;
	public string ClientId { get; set; } = clientId;
	public string ClientSecret { get; set; } = clientSecret;
	public string GrantType { get; set; } = grantType;
}
