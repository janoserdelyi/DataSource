# ChangeLog

## [0.35.0] - 2025-07-18 jerdelyi
### Added
- overload to `Journey().Get(...)` to take an enum to define what type of Key is being passed in. much like wth DataExtensions

### Deprecated
- `Journey().GetByKey(...)`

## [0.34.0] - 2025-06-11 jerdelyi
### Added
- `Contact().UpsertAttributeSet(...)`
- `Contact().UpsertAttributeSets(...)`
- `Contact().GetDataSchemas()`
- `AttributeSet()` base object
- `AttributeGroup()` base object
- `DataExtension().Describe(...)`

## [0.33.4] - 2025-06-05 jerdelyi
### Fixed
- updated `Journey.GetByKey(...)` to reference the Journey Key in the URL correctly
- updated `Journey.RemoveContacts(...)` to lookup the Journey DefintionKey based on the External/Customer Journey Key

## [0.33.3] - 2025-02-19 jerdelyi
### Changed
- discovered an explicit nullable value expression in the documentation when updating a nullable field to null. `NullAPIProperty`
### Added
- `Scale` to `Decimal` field declarations and field retrieval

## [0.33.2] - 2025-02-14 jerdelyi
### Fixed
- wrong payload definition in `Journey().RemoveContacts(...)`

## [0.33.1] - 202?-??-?? jerdelyi
### Fixed
- whoops! i don't recall the date. Bug in auto-chunking code fixed

## [0.33.0] - 2024-11-21 jerdelyi
### Added
- account id to authentication failures to aid in debugging
### Removed
- .net 6.0 support

## [0.32.2] - 2024-10-31 - jerdelyi
### Fixed
- `Subscriber().ActivateChunked(...)` bug resizing collection when evaluating oversized payloads

## [0.32.1] - 2024-10-31 - jerdelyi
### Fixed
- `DataExtension().UpsertData(...)` bug resizing collection when evaluating oversized payloads

## [0.32.0] - 2024-10-24 - jerdelyi
### Added
- `Subscriber().ActivateChunked(...)` to take a large number of records to Activate at once
### Fixed 
- found bug where auto-sizing chunks was losing the initial set of values when a Oversized result was coming back

## [0.31.1] - 2024-10-04 - jerdelyi
### Fixed
- When using a Dictionary collection to Upsert data, `byref` problem using `as` to cast to temporary operating collection

## [0.31.0] - 2024-10-02 - jerdelyi
### Added
- `Journey().Create(...)` now requires a distinct Description value from Name

## [0.30.1] - 2024-09-19 - jerdelyi
### Fixed
- `Journey().UpdateName(...)` was obliterating associated data when updating name
- cleaned up some possible null ref warnings in `DataExtension().Get(...)`

## [0.30.0] - 2024-09-03 - jerdelyi
### Added
- `DataExtension().UpdateRetention(...)`

## [0.29.0] - 2024-08-21 - jerdelyi
### Added
- `Journey().UpdateName(...)`

## [0.28.0] - 2024-08-20 - jerdelyi
### Changed
- greatly expanded the disallowed characters in `Utils.NormalizeMarketingCloudName(...)`
- changed regex in `Utils.NormalizeMarketingCloudName(...)` to be generated at compile time if using .net8

## [0.27.1] - 2024-08-20 - jerdelyi
### Added
- `DataExtension().UpdateName(...)`

## [0.26.0] - 2024-08-14 - jerdelyi
### Changed
- removed legacy `clientId` parameter from `Subscriber.Update(...)`
- changed parameter `name` to `emailAddress` in `Subscriber.Update(...)`

## [0.25.1] - 2024-08-13 - jerdelyi
### Added
- put safety guardrails on `DataExtension().DeleteFields(...)` - if the field count submitted to this method is zero, it deletes the *entire* Data Extension. We don't want that


## [0.25.0] - 2024-08-12 - jerdelyi
### Added
- `DataExtension().DeleteFields(...)`
- `DataExtension().UpdateFields(...)`

### Fixed
- bug getting `MaxLength` in Data Extension field definitions


## [0.24.0] - 2024-07-22 - jerdelyi
### Added
- `Journey().Get(...)` and `Journey.GetByKey(...)`
- Added Journey creation to README since it's a complex topic

## [0.23.0] - 2024-07-16 - jerdelyi
### Added
- `Journey().CheckName(...)` call to API to see if a journey name already exists
- `SourceEvent().Create(...)` to create source events for journeys
- `Journey().Create(...)` to create a Journey. A filter can be passed in, bu there is no builder for the filter
- more Journey name sanitizing. Cannot contain single quote
- more error handling when getting a Data Extension

## [0.22.0] - 2024-06-07 - jerdelyi
### Added
- `Subscriber().Delete(...)` functionality
### Changed
- changed `Subscriber().Create(...)` removed `clientId` arguement. it was not being used
- changed `Subscriber().Create(...)` `attributes` paramater is now optional

## [0.21.0] - 2024-05-29 - jerdelyi
### Added
- adding `DataExtension().Upsert(....)` upsert method to handle auto-retries of just the PK violation inserts as an update (MC SOAP API does not have an actual upsert)
### Changed
- obsoleting `DataExtension().AddDataTypedChunked<T>` in favor of `DataExtension().AddDataChunked<T>`
- changing signature of `DataExtension().UpdateData()` which takes a `List<IDictionary<string, string?>>` in favor of `List<T>`
### Fixed
- bug fix - first round of data insertions get attempted twice - this no longer happens

## [0.20.0] - 2024-05-17 - jerdelyi
### Added
- `mc.TransactionalMessage().GetSendStatus(string messageKey);` to get single call status on a message, provided you know/gave the message key

- removed extraneous Console.Writeline calls which can bubble up to cause noise in logging systems

## [0.19.0] - 2024-05-17 - jerdelyi
### Added
- `mc.TransactionalMessage().Send(...);` to send transactional journey messages to multiple recipients in a single call

## [0.18.1] - 2024-04-26 - jerdelyi
### FIXED
- Some previously null values being converted to DateTime were changed to empty string causing the data type conversion to error. patched

## [0.18.0] - 2024-04-26 - jerdelyi
### Added
- The Marketing Cloud API does not appear to handle deleting multiple records from a `DataExtension` in one call even though it will accept the payload. Added a new `DataExtension().DeleteData(...);` method to handle any number of records

## [0.17.1] - 2024-04-26 - jerdelyi
### Fixed
- Some null reference errors when retrieving Data Extensions which lack some properties

## [0.17.0] - 2024-04-19 - jerdelyi
### Added
- `Subcriber().Unsubscribe(...);` functionality

## [0.16.1] - 2024-04-15 - jerdelyi
### Changed and Added
- Deleting data from a `DataExtension` was not returning the full set of data that it should. This has been fixed.
- The object returned has been renamed to align better with other responses. it's now a `DataExtensionDeleteObjectResponse`

## [0.16.0] - 2024-04-12 - jerdelyi
### Added
- Added the ability to Add data to and Update data in `DataExtension`s which have composite Primary Keys.
### Changed
- When passing in a primary key field, it can now accept a `List<string>` of primary key field names.
  This will impact the response. Both `Ok` and `Error` collections have an added `Keys` property which is a `List<string>` of the same primary key field *values*.
- Also the singular returned key value for debugging  will return a `string` which is a join of the key values involved in the Add/Update.


## [0.15.0] - 2024-04-08 - jerdelyi
### Changed
- The base `DataExtension.Get(filter, fields?)` method is now built to be able to return multiple DataExtensions.
- The `DataExtensionResponse` now has a `DataExtensions` property which is a collection of `DataExtensionResponseObject`s
- The `DataExtensionResponseObject` now contains most of the DataExtension properties that the `DataExtensionResponse` previous contained.
- To avoid having to check for the first DataExtension in a collection, the main methods for getting a single DataExtension when one is reasonably expected have been retained.
- `DataExtension().Get(dataExtensionObjectId, fields?)` will still return a single DataExtension in the form of a `DataExtensionResponseObject`
- `DataExtension().Get(selectField, value, fields?)` can now be used for both `ObjectId` and `CustomerKey` where `selectField` is a new `Enums.DataExtensionSelectField` enum.
### Deprecated
- `DataExtension().GetByCustomerKey(dateExtensionCustomerKey, fields?)` is being deprecated in favor of `DataExtension().Get(selectField, value, fields?)`
  It is still present but will give an `Obsolete` warning and should be removed as it could be removed in any future release.