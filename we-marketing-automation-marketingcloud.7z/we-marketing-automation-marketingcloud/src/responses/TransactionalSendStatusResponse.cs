namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class TransactionalSendStatusResponse
{
	// i added this one since it's not part of the payload
	public bool MessageFound { get; set; } = false;

	public string? RequestId { get; set; }
	public string? EventCategoryType { get; set; }
	public DateTime? Timestamp { get; set; }
	public string? CompositeId { get; set; }
	public TransactionalSendStatusInfo? Info { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class TransactionalSendStatusInfo
{
	public string? MessageKey { get; set; }
	public string? ContactKey { get; set; }
	public string? To { get; set; }
	public int? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
}
