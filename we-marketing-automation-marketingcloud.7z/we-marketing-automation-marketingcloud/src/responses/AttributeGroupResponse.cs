namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AttributeGroupsResponse
{
	public required int Page { get; set; }
	public required int PageSize { get; set; }
	public required int Count { get; set; }
	public required IList<AttributeGroupResponseItem> Items { get; set; }
	public required AttributeGroupResponseLinks Links { get; set; }
	[JsonProperty ("requestServiceMessageID")]
	public required string RequestServiceMessageId { get; set; }
	[JsonProperty ("serviceMessageID")]
	public required string ServiceMessageId { get; set; }
	public required DateTimeOffset ResponseDateTime { get; set; }
	// public List<object> resultMessages { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AttributeGroupResponse
{
	public required AttributeGroupResponseItem Item { get; set; }
	public required AttributeGroupResponseLinks Links { get; set; }
	[JsonProperty ("requestServiceMessageID")]
	public required string RequestServiceMessageId { get; set; }
	[JsonProperty ("serviceMessageID")]
	public required string ServiceMessageId { get; set; }
	public required DateTimeOffset ResponseDateTime { get; set; }
	// public List<object> resultMessages { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AttributeGroupResponseItem
{
	public required string Id { get; set; }
	public required bool IsSystemDefined { get; set; }
	public required string ApplicationID { get; set; }
	public required string ApplicationKey { get; set; }
	public required string FullyQualifiedName { get; set; }
	public required string AttributeGroupType { get; set; }
	public required bool CanAddRelationships { get; set; }
	public required bool CanModify { get; set; }
	public required bool CanRemove { get; set; }
	public required string Key { get; set; }
	public required string Name { get; set; }
	public required string AttributeGroupIconKey { get; set; }
	public required bool IsPopulationType { get; set; }
	public required AttributeGroupResponseLinks Links { get; set; }
	public required string ObjectState { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class AttributeGroupResponseLinks
{
	public ContactSchemaResponseLinkTypeBase? Self { get; set; }
	public ContactSchemaResponseLinkTypeBase? AttributeSetDefinitions { get; set; }
	public ContactSchemaResponseLinkTypeBase? Schema { get; set; }
}

public class AttributeGroupResponseLinkTypeBase
{
	public required string Href { get; set; }
}
