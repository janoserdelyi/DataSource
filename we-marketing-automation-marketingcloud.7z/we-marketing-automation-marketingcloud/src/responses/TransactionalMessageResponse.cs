namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class TransactionalMessageResponse
{
	public string? RequestId { get; set; }
	public int? Errorcode { get; set; }
	public IList<TransactionalMessageResponseObject> Responses { get; set; } = new List<TransactionalMessageResponseObject> ();
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class TransactionalMessageResponseObject
{
	public string? MessageKey { get; set; }
	public int? Errorcode { get; set; }
	public string? Message { get; set; }
}
