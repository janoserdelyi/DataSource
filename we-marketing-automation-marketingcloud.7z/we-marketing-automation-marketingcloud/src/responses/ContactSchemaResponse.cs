namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactSchemaResponse
{
	public required ContactSchemaResponseItem Item { get; set; }
	public required ContactSchemaResponseLinks Links { get; set; }
	[JsonProperty ("requestServiceMessageID")]
	public required string RequestServiceMessageId { get; set; }
	[JsonProperty ("serviceMessageID")]
	public required string ServiceMessageId { get; set; }
	public required DateTimeOffset ResponseDateTime { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactSchemaResponseItem
{
	[JsonProperty ("schemaID")]
	public required string SchemaId { get; set; }
	[JsonProperty ("enterpriseID")]
	public required string EnterpriseId { get; set; }
	public required int Version { get; set; }
	public required bool IsModelOwner { get; set; }
	public required string SchemaType { get; set; }
	public required string ObjectState { get; set; }
	public required ContactSchemaResponseLinks Links { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactSchemaResponseLinks
{
	public ContactSchemaResponseLinkTypeBase? AttributeGroups { get; set; }
	public ContactSchemaResponseLinkTypeBase? AttributeSetDefinitions { get; set; }
	public ContactSchemaResponseLinkTypeBase? Schema { get; set; }
}

public class ContactSchemaResponseLinkTypeBase
{
	public required string Href { get; set; }
}
