namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DeleteRestFailureResponse
{
	public string? Message { get; set; }
	public int Errorcode { get; set; }
	public string? Documentation { get; set; }
}