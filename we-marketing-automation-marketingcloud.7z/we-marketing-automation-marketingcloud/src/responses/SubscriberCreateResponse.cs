namespace MarketingCloudApi;

public class SubscriberCreateUpdateResponse
{
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? ErrorCode { get; set; }
	public string? NewId { get; set; }
	public string? ObjectId { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public string? RequestId { get; set; }
	public string? OverallStatus { get; set; }
}
