namespace MarketingCloudApi;

public class SubscriberResponse
{
	public string? ClientId { get; set; }
	public DateTime? CreatedDate { get; set; }
	public string? EmailAddress { get; set; }
	public string? SubscriberKey { get; set; }
	public string? Status { get; set; }
	public string? EmailTypePreference { get; set; }
	public DateTime? UnsubscribedDate { get; set; }
	public string? RequestId { get; set; }
	public string? OverallStatus { get; set; }
}
