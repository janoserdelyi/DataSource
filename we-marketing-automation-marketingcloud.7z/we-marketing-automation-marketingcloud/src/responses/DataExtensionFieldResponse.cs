using MarketingCloudApi.Elements;

namespace MarketingCloudApi;

public class DataExtensionFieldResponse
{
	public IList<Field> Fields { get; set; } = new List<Field> ();
}
