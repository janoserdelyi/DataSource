namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DataExtensionDescriptionResponse
{
	public required string Id { get; set; }
	public required string Name { get; set; }
	public required string Key { get; set; }
	public required string Description { get; set; }
	public required bool IsActive { get; set; }
	public required bool IsSendable { get; set; }
	public required string SendableCustomObjectField { get; set; }
	public required string SendableSubscriberField { get; set; }
	public required bool IsTestable { get; set; }
	public required int Status { get; set; }
	public required int CategoryId { get; set; }
	public required int OwnerId { get; set; }
	public required bool IsObjectDeletable { get; set; }
	public required bool IsFieldAdditionAllowed { get; set; }
	public required bool IsFieldModificationAllowed { get; set; }
	public required DateTime CreatedDate { get; set; }
	public required int CreatedById { get; set; }
	public required DateTime ModifiedDate { get; set; }
	public required int ModifiedById { get; set; }
	public required string ModifiedByName { get; set; }
	public required int RowCount { get; set; }
	public required DataExtensionDescriptionResponseDataRetentionProperties DataRetentionProperties { get; set; }
	public required int FieldCount { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DataExtensionDescriptionResponseDataRetentionProperties
{
	public required int DataRetentionPeriodLength { get; set; }
	public required int DataRetentionPeriodUnitOfMeasure { get; set; }
	public required bool IsDeleteAtEndOfRetentionPeriod { get; set; }
	public required bool IsRowBasedRetention { get; set; }
	public required bool IsResetRetentionPeriodOnImport { get; set; }
	public required DateTime RetainUntil { get; set; }
	public required int RowBasedThreshold { get; set; }
}
