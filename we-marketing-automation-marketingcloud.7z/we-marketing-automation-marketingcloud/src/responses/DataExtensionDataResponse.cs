namespace MarketingCloudApi;

public class DataExtensionDataResponse
{
	public string? OverallStatus { get; set; }
	public string? RequestId { get; set; }
	public IList<DataExtensionObject>? Results { get; set; }
}

public class DataExtensionObject
{
	public IDictionary<string, string?> Properties { get; set; } = new Dictionary<string, string?> ();
}

// extension method to cast this to a strongly type object if desired
public static class DataExtensionObjectExtensions
{
	public static T To<T> (this DataExtensionObject obj) where T : class, new()
	{
		return Utils.DictionaryToObject<T> ((Dictionary<string, string?>)obj.Properties);
	}
}
