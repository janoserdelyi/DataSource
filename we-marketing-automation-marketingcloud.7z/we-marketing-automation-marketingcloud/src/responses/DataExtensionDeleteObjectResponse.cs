namespace MarketingCloudApi;

// used to contain values from parsing a DataExtension soap payload
// this really should be renamed to DataExtensionDeleteObjectResponse
public class DataExtensionDeleteObjectResponse
{
	public string? OverallStatus { get; set; }
	public string? RequestId { get; set; }

	// i won't bother pulling back Keys yet

	public IList<DataExtensionDeleteObjectResult> Results { get; set; } = new List<DataExtensionDeleteObjectResult> ();
}

public class DataExtensionDeleteObjectResult
{
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	[BindingName ("OrdinalID")]
	public int? OrdinalId { get; set; }
	public IDictionary<string, string> Keys { get; set; } = new Dictionary<string, string> ();
}
