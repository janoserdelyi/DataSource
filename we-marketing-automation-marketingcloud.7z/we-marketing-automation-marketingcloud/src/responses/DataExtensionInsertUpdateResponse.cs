namespace MarketingCloudApi;

public class DataExtensionInsertUpdateResponse
{
	// the payload does NOT return an overall status or message. i am adding these
	public string? OverallStatus { get; set; }
	public string? OverallStatusMessage { get; set; }
	public int? SuggestedUploadRowCount { get; set; }

	// the keys are the subscriber keys in case you want to look them up that way
	public IDictionary<string, DataExtensionInsertUpdateResponseOk> Oks { get; set; } = new Dictionary<string, DataExtensionInsertUpdateResponseOk> ();
	public IDictionary<string, DataExtensionInsertUpdateResponseError> Errors { get; set; } = new Dictionary<string, DataExtensionInsertUpdateResponseError> ();
}

public class DataExtensionInsertUpdateResponseOk
{
	public string? StatusMessage { get; set; }
	public int Ordinal { get; set; }
	public string? SubscriberKey { get; set; } // this doesn't quite work with composite PK data extensions. retaining for ease and backwards compat
	public List<string> Keys { get; set; } = new List<string> ();
}

public class DataExtensionInsertUpdateResponseError
{
	public string? StatusMessage { get; set; }
	public string? ErrorMessage { get; set; }
	public string? ErrorCode { get; set; }
	public int Ordinal { get; set; }
	public string? SubscriberKey { get; set; }
	public List<string> Keys { get; set; } = new List<string> ();
}
