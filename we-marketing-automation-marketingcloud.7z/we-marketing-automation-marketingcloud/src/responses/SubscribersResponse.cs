namespace MarketingCloudApi;

public class SubscribersResponse
{
	public string? RequestId { get; set; }
	public string? OverallStatus { get; set; }
	public IList<SubscriberResponse>? Results { get; set; }
}
