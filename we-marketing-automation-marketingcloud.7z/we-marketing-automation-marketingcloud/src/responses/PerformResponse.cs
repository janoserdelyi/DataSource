namespace MarketingCloudApi;

// used to contain values from parsing a DataExtension soap payload
public class PerformResponse
{
	public string? OverallStatus { get; set; }
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? RequestId { get; set; }
}
