namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DomainVerificationResponse
{
	[JsonProperty ("page")]
	public int Page { get; set; }

	[JsonProperty ("pageSize")]
	public int PageSize { get; set; }

	[JsonProperty ("count")]
	public int Count { get; set; }

	[JsonProperty ("items")]
	public List<DomainVerificationItem> Items { get; set; } = [];
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class DomainVerificationItem
{
	[JsonProperty ("enterpriseId")]
	public int EnterpriseId { get; set; }

	[JsonProperty ("domain")]
	public string Domain { get; set; } = string.Empty;

	[JsonProperty ("status")]
	public string Status { get; set; } = string.Empty;

	[JsonProperty ("domainType")]
	public string DomainType { get; set; } = string.Empty;

	[JsonProperty ("isSendable")]
	public bool IsSendable { get; set; }

	[JsonProperty ("memberId")]
	public int MemberId { get; set; }

	[JsonProperty ("emailSendTime")]
	public DateTime EmailSendTime { get; set; }
}
