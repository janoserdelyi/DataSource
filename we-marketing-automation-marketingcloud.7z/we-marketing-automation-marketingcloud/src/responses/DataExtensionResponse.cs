namespace MarketingCloudApi;

// used to contain values from parsing a DataExtension soap payload
public class DataExtensionResponse
{
	public string? OverallStatus { get; set; }
	public string? RequestId { get; set; }
	public IList<DataExtensionResponseObject> DataExtensions = new List<DataExtensionResponseObject> ();
}

public class DataExtensionResponseObject
{
	public DataExtensionResponseObject (
		string objectId,
		string customerKey,
		string name,
		bool isSendable,
		Elements.SendableSubscriberField? sendableSubscriberField,
		string? categoryId,
		string? status
	)
	{
		ObjectId = objectId;
		CustomerKey = customerKey;
		Name = name;
		IsSendable = isSendable;
		SendableSubscriberField = sendableSubscriberField;
		CategoryId = categoryId;
		Status = status;
	}

	public string? ObjectId { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public bool IsSendable { get; set; }
	public Elements.SendableSubscriberField? SendableSubscriberField { get; set; }
	public string? CategoryId { get; set; }
	public string? Status { get; set; }
}

