namespace MarketingCloudApi;

// note : this is built around the idea of a single delete at a time. the responding payload appears to be structured to allow for multiple
public class DataExtensionDeleteResponse
{
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? ErrorCode { get; set; }
	public string? PartnerKey { get; set; }
	public string? ObjectId { get; set; }
	public string? CustomerKey { get; set; }
	public string? RequestId { get; set; }
	public string? OverallStatus { get; set; }
}
