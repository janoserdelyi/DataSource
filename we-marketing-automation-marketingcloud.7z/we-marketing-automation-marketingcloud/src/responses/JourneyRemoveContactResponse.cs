namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyRemoveContactResponse
{
	public List<JourneyRemoveContactError> Errors { get; set; } = new List<JourneyRemoveContactError> ();
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyRemoveContactError
{
	public string? ContactKey { get; set; }
	public string? DefinitionKey { get; set; }
	public List<JourneyRemoveContactStatus>? Status { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyRemoveContactStatus
{
	public int? Version { get; set; }
	public string? Message { get; set; }
}
