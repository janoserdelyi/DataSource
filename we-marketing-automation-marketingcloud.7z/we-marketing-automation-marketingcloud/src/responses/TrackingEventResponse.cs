namespace MarketingCloudApi;

// used to contain values from parsing a DataExtension soap payload
public class TrackingEventResponse
{
	public string? OverallStatus { get; set; } // hesitant to convert this to StatusType enum. pretty sure i've seen explanations of errors dumped un this field *with* the "Error" keyword. this would cause failures
	public string? RequestId { get; set; }
	public IList<TrackingEventResult>? Results { get; set; }
}

public class TrackingEventResult
{
	public Enums.TrackingType TrackingType { get; set; }
	public string? ClientId { get; set; }
	public int? ListId { get; set; }
	public int? SendId { get; set; }
	public string? SubscriberKey { get; set; }
	public DateTimeOffset? EventDate { get; set; }
	public string? EventType { get; set; }
	public string? TriggeredSendDefinitionObjectId { get; set; }
	public int? BatchId { get; set; }
	public long? ObjectId { get; set; }
	public int? SmtpCode { get; set; }
	public string? SmtpReason { get; set; }
	public bool? IsMasterUnsubscribed { get; set; }
}
