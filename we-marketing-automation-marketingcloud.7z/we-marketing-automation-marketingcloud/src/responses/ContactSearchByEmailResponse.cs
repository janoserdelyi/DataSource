namespace MarketingCloudApi;

/// <summary>
/// Search Contact By EmailAddress Response
/// </summary>
[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactSearchByEmailResponse
{
	/// <summary>
	/// Initializes a new instance of the <see cref="ContactSearchByEmailResponse"/> class.
	/// </summary>
	public ContactSearchByEmailResponse ()
	{
		ChannelAddressResponseEntities = new List<ChannelAddressResponseEntity> ();
	}

	/// <summary>
	/// Gets or sets the channel address response entities.
	/// </summary>
	/// <value>
	/// The channel address response entities.
	/// </value>
	public IEnumerable<ChannelAddressResponseEntity>? ChannelAddressResponseEntities { get; set; }

	/// <summary>
	/// Gets or sets the operation status.
	/// </summary>
	/// <value>
	/// The operation status.
	/// </value>
	public string? OperationStatus { get; set; }

	/// <summary>
	/// Gets or sets the request service message identifier.
	/// </summary>
	/// <value>
	/// The request service message identifier.
	/// </value>
	public string? RequestServiceMessageID { get; set; }

	/// <summary>
	/// Gets or sets the result messages.
	/// </summary>
	/// <value>
	/// The result messages.
	/// </value>
	public IEnumerable<string>? ResultMessages { get; set; }

	/// <summary>
	/// Gets or sets the service message identifier.
	/// </summary>
	/// <value>
	/// The service message identifier.
	/// </value>
	public string? ServiceMessageID { get; set; }
}

public class ChannelAddressResponseEntity
{

	public ChannelAddressResponseEntity (List<ContactKeyDetails> contactKeyDetails, string channelAddress)
	{
		ContactKeyDetails = contactKeyDetails;
		ChannelAddress = channelAddress;
	}

	/// <summary>
	/// Gets or sets the contact key details.
	/// </summary>
	/// <value>
	/// The contact key details.
	/// </value>
	public IEnumerable<ContactKeyDetails> ContactKeyDetails { get; set; }

	/// <summary>
	/// Gets or sets the channel address.
	/// </summary>
	/// <value>
	/// The channel address.
	/// </value>
	public string ChannelAddress { get; set; }
}

public class ContactKeyDetails
{
	public ContactKeyDetails (string contactKey, DateTime createDate)
	{
		ContactKey = contactKey;
		CreateDate = createDate;
	}

	/// <summary>
	/// Gets or sets the contact key.
	/// </summary>
	/// <value>
	/// The contact key.
	/// </value>
	public string ContactKey { get; set; }

	/// <summary>
	/// Gets or sets the create date.
	/// </summary>
	/// <value>
	/// The create date.
	/// </value>
	public DateTime CreateDate { get; set; }
}
