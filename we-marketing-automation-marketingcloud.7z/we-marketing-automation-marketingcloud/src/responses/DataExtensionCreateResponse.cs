namespace MarketingCloudApi;

public class DataExtensionCreateResponse
{
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? ErrorCode { get; set; }
	public string? NewId { get; set; }
	public string? ClientId { get; set; }
	public string? PartnerKey { get; set; }
	public string? ObjectId { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public bool IsSendable { get; set; }
	public Elements.SendableDataExtensionField? SendableDataExtensionField { get; set; }
	public Elements.SendableSubscriberField? SendableSubscriberField { get; set; }
}
