namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactUpdateResponse
{
	public string? OperationStatus { get; set; }
	public int? RowsAffected { get; set; }
	public string? ContactKey { get; set; }
	public int? ContactId { get; set; }
	[JsonProperty ("contactTypeID")]
	public int? ContactTypeId { get; set; }
	public bool? IsNewContactKey { get; set; }
	[JsonProperty ("requestServiceMessageID")]
	public string? RequestServiceMessageId { get; set; }
	public bool? HasErrors { get; set; }
	public IList<ContactUpdateResponseResultMessage>? ResultMessages { get; set; }
	[JsonProperty ("serviceMessageID")]
	public string? ServiceMessageId { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class ContactUpdateResponseResultMessage
{
	public string? ResultType { get; set; }

	public string? ResultClass { get; set; }

	public string? ResultCode { get; set; }

	public string? Message { get; set; }
}
