
using MarketingCloudApi.Models;

namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyTriggerResponse
{
	public string? Id { get; set; }
	public string? Key { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public string? Type { get; set; }
	public TriggerMetaData? MetaData { get; set; }
	public string? EventDefinitionKey { get; set; }
	public ConfigurationArguments? ConfigurationArguments { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyResponse
{
	public int? Count { get; set; }
	public int? Page { get; set; }
	public int? PageSize { get; set; }
	public List<JourneyResponseItem>? Items { get; set; }
}

// as seen in here https://developer.salesforce.com/docs/marketing/marketing-cloud/references/mc_rest_interaction/getInteractionCollection.html
[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyResponseItem
{
	public string? Id { get; set; }
	public string? Key { get; set; }
	public string? Name { get; set; }
	public DateTime? LastPublishedDate { get; set; }
	public string? Description { get; set; }
	public int? Version { get; set; }
	public double? WorkflowApiVersion { get; set; }
	public DateTime? CreatedDate { get; set; }
	public DateTime? ModifiedDate { get; set; }
	public List<object>? Goals { get; set; }
	public List<object>? Exits { get; set; }
	public List<object>? Notifiers { get; set; }
	public JourneyStats? Stats { get; set; }
	public string? EntryMode { get; set; }
	public string? DefinitionType { get; set; }
	public string? Channel { get; set; }
	public JourneyMetaData? MetaData { get; set; }
	public string? ExecutionMode { get; set; }
	public int? CategoryId { get; set; }
	public string? Status { get; set; }
	public string? DefinitionId { get; set; }
	public string? ScheduledStatus { get; set; }
	public JourneyDefaults? Defaults { get; set; }
	public List<JourneyTriggerResponse>? Triggers { get; set; }
	public string? Type { get; set; }
	public ConfigurationArguments? ConfigurationArguments { get; set; }
	public List<JourneyActivity>? Activities { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyActivity
{
	public string? Id { get; set; }
	public string? Key { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public List<JourneyActivityOutcome>? Outcomes { get; set; }
	public object? Arguments { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyActivityOutcome
{
	public string? Key { get; set; }
	public string? Next { get; set; }
	public object? Arguments { get; set; } // i just have no idea at the moment what this contains. hence "object"
	public JourneyMetaData? Metadata { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyStats
{
	public int? CurrentPopulation { get; set; }
	public int? CumulativePopulation { get; set; }
	public int? MetGoal { get; set; }
	public int? MetExitCriteria { get; set; }
	public double? GoalPerformance { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyMetaData
{
	public string? DataSource { get; set; }
	public string? WaitType { get; set; }
	public string? Label { get; set; }
	public bool? SkipI18n { get; set; }
	public bool? IsLabelFromConversion { get; set; }
	public string? CriteriaDescription { get; set; }
	public bool? Invalid { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyDefaults
{
	public string[]? Email { get; set; }
	public JourneyDefaultsProperties? Properties { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyDefaultsProperties
{
	public JourneyDefaultsPropertiesAnalyticsTracking? AnalyticsTracking { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyDefaultsPropertiesAnalyticsTracking
{
	public bool? Enabled { get; set; }
	public string? AnalyticsType { get; set; }
	public string[]? UrlDomainsToTrack { get; set; }
}

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class JourneyArguments
{
	public string? SerializedObjectType { get; set; }
	public string? EventDefinitionId { get; set; }
	public string? EventDefinitionKey { get; set; }
	public string? DataExtensionId { get; set; }
}

// journey activity arguments
/*
"arguments": {
	"waitEndDateAttributeDataBound": "",
	"waitDefinitionId": "e84944af-cff7-468b-a96f-721b0c174aaa",
	"waitForEventId": "",
	"executionMode": "{{Context.ExecutionMode}}",
	"startActivityKey": "{{Context.StartActivityKey}}",
	"waitQueueId": "{{Context.WaitQueueId}}"
},
*/
// journey activity configuration arguments
/*
"configurationArguments": {
	"waitDuration": 1,
	"waitUnit": "MINUTES",
	"specifiedTime": "00:00",
	"timeZone": "Eastern Standard Time",
	"description": "",
	"waitEndDateAttributeExpression": "",
	"specificDate": "",
	"waitForEventKey": ""
},
*/
public class JourneyCheckNameResponse
{
	public JourneyCheckNameResponse (
		string name,
		bool collisionFound // was there already a journey with this name found?
	)
	{
		Name = name;
		CollisionFound = collisionFound;
	}

	public string Name { get; set; }
	public bool CollisionFound { get; set; }
}
