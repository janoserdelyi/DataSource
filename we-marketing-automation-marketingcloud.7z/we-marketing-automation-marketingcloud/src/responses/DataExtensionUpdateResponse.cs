namespace MarketingCloudApi;

public class DataExtensionUpdateResponse
{
	public string? OverallStatus;
	public string? RequestId { get; set; }
	public string? StatusCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? ErrorCode { get; set; }
}
