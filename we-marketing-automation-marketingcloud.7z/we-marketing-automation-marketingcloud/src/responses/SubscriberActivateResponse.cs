namespace MarketingCloudApi;

public class SubscriberActivateResponse
{
	public string? OverallStatus { get; set; }
	public string? RequestId { get; set; }
	public string? OverallStatusMessage { get; set; }
	public int? SuggestedUploadRowCount { get; set; }

	public IList<SubscriberActivateResponseResult> Results { get; set; } = new List<SubscriberActivateResponseResult> ();
}

public class SubscriberActivateResponseResult
{
	public string? Id { get; set; }
	public string? SubscriberKey { get; set; }
	public string? Status { get; set; }
	public string? StatusCode { get; set; }
	public string? ErrorCode { get; set; }
	public string? StatusMessage { get; set; }
	public string? RequestId { get; set; }

	[Obsolete ("use Status instead. deprecated as of version 0.32.0")]
	public string? OverallStatus { get; set; }
}
