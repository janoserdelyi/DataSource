namespace MarketingCloudApi;

[JsonObject (NamingStrategyType = typeof (CamelCaseNamingStrategy))]
public class SourceEventResponse
{
	public string? Id { get; set; }
	public string? Type { get; set; }
	public string? Name { get; set; }
	public string? Description { get; set; }
	public DateTime? CreatedDate { get; set; }
	public int? CreatedBy { get; set; }
	public DateTime? ModifiedDate { get; set; }
	public int? ModifiedBy { get; set; }
	public string? Mode { get; set; }
	public string? EventDefinitionKey { get; set; }
	public string? DataExtensionId { get; set; }
	public string? FilterDefinitionId { get; set; }
	public string? IconUrl { get; set; }
	public JourneyArguments? Arguments { get; set; }
	public JourneyMetaData? MetaData { get; set; }
	public int? InteractionCount { get; set; }
	public bool? IsVisibleInPicker { get; set; }
	public string? Category { get; set; }
	public int? PublishedInteractionCount { get; set; }
	public string? AutomationId { get; set; }
}
