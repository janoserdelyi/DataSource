namespace MarketingCloudApi;

public class DataExtensionTemplateResponse
{
	public IList<DataExtensionTemplate>? Results { get; set; }
}

public class DataExtensionTemplate
{

	public string? ObjectID { get; set; }
	public string? CustomerKey { get; set; }
	public string? Name { get; set; }
	public DateTime? CreatedDate { get; set; }
	public DateTime? ModifiedDate { get; set; }

	public int? ClientID { get; set; } // Client.ID mapped to ClientID for simplicity
	public string? Description { get; set; }
	public bool? IsSendable { get; set; }
	public bool? IsTestable { get; set; }

	public string? SendableCustomObjectField { get; set; }
	public string? SendableSubscriberField { get; set; }

	public int? DataRetentionPeriodLength { get; set; }
	public string? DataRetentionPeriodUnitOfMeasure { get; set; } // e.g. "Days", "Weeks", "Months", "Years"

	public bool? RowBasedRetention { get; set; }
	public bool? ResetRetentionPeriodOnImport { get; set; }
	public bool? DeleteAtEndOfRetentionPeriod { get; set; }
	public DateTimeOffset? RetainUntil { get; set; }

	// Optional: dictionary for any future fields or extensions
	public Dictionary<string, string?> AdditionalProperties { get; set; } = new Dictionary<string, string?> ();
}
